spmesh uses algebraic method for creating 3D mesh.

Use: spmesh.exe
the prompts are self-explainatory.

In this folder a file called 'GMiga-brain.nml' is provided as an input example.
The output generated with spmesh code is called 'miga15.nml'

For more information please refer to readme2.txt in this folder.

If one wants to automate the process a sample file for inputing parameters
to spmesh.exe is provided: 'param.in'

Also two images of a the GMiga brain can be found in this folder.
