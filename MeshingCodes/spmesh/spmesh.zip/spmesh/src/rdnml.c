  
/*
  ************************************************************************
  *  rdnml.c :	Read in a new NML format file				 *
  *									 *
  *  Qingyang Zhang				   Dec. 29, 1994	 *
  ************************************************************************
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include <math.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define external global varibles */
#include "defglb.h"
#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))



/*
** External Functions
*/



/*
** Local Functions
*/
int	rdnml (int done_file);
int	gtkeywd (FILE *fp, char *keyword);
int     tri_patch_bound (BMeshNode **nnptr, double *xmin, double *ymin, 
               double *zmin, double *xmax, double *ymax, double *zmax);
int	rd_bdy_node (FILE *fp, long tmp_bdy_nodes, int tmp_dimen);
int	rd_bdy_elem (FILE *fp, long tmp_bdy_elem, int bdy_lst_type);
int	rd_msh_node (FILE *fp, long tmp_msh_nodes, int tmp_dimen);
int	rd_msh_elem (FILE *fp, long tmp_msh_elem, int msh_lst_type);
int	rd_sp_node (FILE *fp, int num_nodes);
int	rd_sp_elem (FILE *fp, int num_elem) ;
int	rd_sp_poly_node (FILE *fp, int num_nodes);
int	rd_sp_poly_elem (FILE *fp, int num_elem) ;
int	mk_adjlist (MeshNode *n_head, long num_node, MeshElem *e_head, long num_elem);
int set_adj_node_elem (MeshElem *eptr);
int	nod_in_elem (MeshNode *nptr, MeshElem *eptr, int *enode_idx);
int	set_adjlist (MeshNode *nptr, AdjList **aptr, MeshElem *eptr, int enode_idx);
BMeshNode *conv_bnode_idx (BMeshNode *head, long node_idx);
long conv_bnode_ptr (BMeshNode *head, BMeshNode *node_ptr, long total_nodes);
BMeshElem *conv_belem_idx (BMeshElem *head, long elem_idx);
long conv_belem_ptr (BMeshElem *head, BMeshElem *elem_ptr, long total_elem);
MeshNode *conv_node_idx (MeshNode *head, long node_idx);
long conv_node_ptr (MeshNode *head, MeshNode *node_ptr, long total_nodes);
MeshElem *conv_elem_idx (MeshElem *head, long elem_idx);
long conv_elem_ptr (MeshElem *head, MeshElem *elem_ptr, long total_elem);
LineData *conv_line_idx (LineData *head, long line_idx);
long conv_line_ptr (LineData *head, LineData *line_ptr, long total_lines);
int	free_bnode_list (BMeshNode *head, long num_node);
int	free_belem_list (BMeshElem *head, long num_elem);
int	free_node_list (MeshNode *head, long num_node);
int	free_elem_list (MeshElem *head, long num_elem);
int     free_MeshNode (MeshNode *nptr);
int	free_adj (AdjList *ad_ptr);
int     free_adj_elem (AdjElem *ad_ptr);
int	free_line_list (LineData *head, int num_elem);
int     free_polyline_list (LineData **head,  int *seg_in_poly, int num_poly);
int	alloc_error (char *str);
int	debug_output (char *fout_name);
int	final_output_wpi (void);

/*
** Global Variables
*/



/*
** Local Variables
*/






/*++
**
**  Function:	    int rdnml ()
**
**  Description:    Reads session file.
**
**  Parameters:     IO:
**  Returns:	    0 = no errors
**		    1 = errors were encountered.
**
**  Notes:
**
**--
*/

int
rdnml (int done_file)
{
    char    keyword[80];
    long    ii, tmp_bdy_nodes, tmp_bdy_elem, tmp_msh_nodes, tmp_msh_elem;
    int     status=0, tmp_dimen, bdy_lst_type, msh_lst_type;
    FILE    *fp;

    if (done_file == 0)
    {
      printf ("\nInput NML+ File Name : ");
      scanf  ("%s", Input_name);

      if ((fp = fopen (Input_name, "r")) == NULL) {
	    printf ("\nCan't open input file : %s\n", Input_name);
	    return (BAD);
      }
    }
    else
    {
      if ((fp = fopen ("sysout.nml", "rt")) == NULL) {
	    printf ("\nCan't open input file : 'sysout.nml' \n");
	    return (BAD);
      }
    }

 /* search for keyword and match */
    do {
	    if (gtkeywd (fp, keyword) == BAD) {
	        printf ("Warning: End of file abnormally !!");
	        status = BAD;
	        goto EXIT;
	    }

	    if (!strcmp (keyword, "end_of_file")) {
	        /*	printf ("#End_of_file reached !\n");	  */
	        status = OK;
	    }

	    else if (!strcmp (keyword, "rem")) {
	        /* comment line, skip !*/
	        ;
	    }

	    else if (!strcmp (keyword, "model_name")) {
	        fscanf (fp, "%s", Model_name);
	    }

	    else if (!strcmp (keyword, "numbering")) {
	        fscanf (fp, "%d", &Numbering);
	    }

	    else if (!strcmp (keyword, "analy_type")) {
	        fscanf (fp, "%d", &Analy_type);
	    }

	    else if (!strcmp (keyword, "dimension")) {
	        fscanf (fp, "%d", &Dimen);
	    }

	    else if (!strcmp (keyword, "mesh_type")) {
	        fscanf (fp, "%d", &Mesh_type);
	    }

	    else if (!strcmp (keyword, "global_size")) {
	        fscanf (fp, "%lf", &Global_size);
	    }

	    else if (!strcmp (keyword, "bound_box")) {
	        fscanf (fp, "%lf %lf %lf %lf %lf %lf",
		        &BDxmin, &BDymin, &BDzmin, &BDxmax, &BDymax, &BDzmax);
	    }

	    else if (!strcmp (keyword, "bdy_nodes")) {
	        fscanf (fp, "%ld", &Bdy_nodes);
        }

	    else if (!strcmp (keyword, "bdy_elem")) {
	        fscanf (fp, "%ld", &Bdy_elem);
	    }

	    else if (!strcmp (keyword, "mesh_nodes")) {
	        fscanf (fp, "%ld", &Msh_nodes);
	    }

	    else if (!strcmp (keyword, "mesh_elem")) {
	        fscanf (fp, "%ld", &Msh_elem);
	    }

	    else if (!strcmp (keyword, "bdy_node_coor")) {
	        fscanf (fp, "%ld %d", &tmp_bdy_nodes, &tmp_dimen);
	        rd_bdy_node (fp, tmp_bdy_nodes, tmp_dimen);
	    }

	    else if (!strcmp (keyword, "bdy_elem_list")) {
	        fscanf (fp, "%ld %d", &tmp_bdy_elem, &bdy_lst_type);
	        if (Bdy_node_head_ptr)
	        {
		        rd_bdy_elem (fp, tmp_bdy_elem, bdy_lst_type);
		        Bdy_lst_type = bdy_lst_type;
	        }
	        else  printf ("\nError... Should read in BDY nodes first!!");
	    }

	    else if (!strcmp (keyword, "mesh_node_coor")) {
	        fscanf (fp, "%ld %d", &tmp_msh_nodes, &tmp_dimen);
	        rd_msh_node (fp, tmp_msh_nodes, tmp_dimen);
	    }

	    else if (!strcmp (keyword, "mesh_elem_list")) {
	        fscanf (fp, "%ld %d", &tmp_msh_elem, &msh_lst_type);
	        if (Msh_node_head_ptr)
	        {
		    rd_msh_elem (fp, tmp_msh_elem, msh_lst_type) ;
		    Msh_lst_type = msh_lst_type;
	        }
	        else  printf ("\nError... Should read in mesh nodes first!!");
	    }

	    else if (!strcmp (keyword, "sp_nodes")) {
	        fscanf (fp, "%d", &Sp_nodes);
	        rd_sp_node (fp, Sp_nodes);
	    }

	    else if (!strcmp (keyword, "sp_lines")) {
	        fscanf (fp, "%d", &Sp_elem);
	        if (Sp_node_head_ptr)
		        rd_sp_elem (fp, Sp_elem) ;
	        else  printf ("\nError... Should read in Sp. nodes first!!");
	    }

	    else if (!strcmp (keyword, "sp_poly_node")) {
	        fscanf (fp, "%d", &Sp_poly_nodes);
	        rd_sp_poly_node (fp, Sp_poly_nodes);
	    }

	    else if (!strcmp (keyword, "sp_poly_line")) {
	        fscanf (fp, "%d", &Sp_poly_elem);
	        if (Spoly_node_head_ptr)
		        rd_sp_poly_elem (fp, Sp_poly_elem) ;
	        else  printf ("\nError... Should read in Sp_poly. nodes first!!");
	    }

    } while (!status);


    /* create node adjacent list for ELEM */
    if (Msh_node_head_ptr != NULL && Msh_nodes != BAD)
      mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);


EXIT:
    fclose (fp);

    /* check if bounding box existed ?  if not make one */
    if (BDxmin==BAD && BDxmax==BAD && BDymin==BAD && BDymax==BAD && 
        BDzmin==BAD && BDzmax==BAD)
    {
        BDxmin = BDymin = BDzmin =  1.e10;
        BDxmax = BDymax = BDzmax = -1.e10;

	    Bdy_elem_curt_ptr = Bdy_elem_head_ptr;
        for (ii=0; ii<Bdy_elem; ii++)
	    {  /* just check each BDY patch's bounding box which was created
              during input
           */

	        if (Bdy_elem_curt_ptr->xmin < BDxmin) 
	                    BDxmin = Bdy_elem_curt_ptr->xmin;
	        if (Bdy_elem_curt_ptr->xmax < BDxmin) 
	                    BDxmin = Bdy_elem_curt_ptr->xmax;
	        if (Bdy_elem_curt_ptr->xmin > BDxmax) 
	                    BDxmax = Bdy_elem_curt_ptr->xmin;
	        if (Bdy_elem_curt_ptr->xmax > BDxmin) 
	                    BDxmax = Bdy_elem_curt_ptr->xmax;
 
	        if (Bdy_elem_curt_ptr->ymin < BDymin) 
	                    BDymin = Bdy_elem_curt_ptr->ymin;
	        if (Bdy_elem_curt_ptr->ymax < BDymin) 
	                    BDymin = Bdy_elem_curt_ptr->ymax;
	        if (Bdy_elem_curt_ptr->ymin > BDymax) 
	                    BDymax = Bdy_elem_curt_ptr->ymin;
	        if (Bdy_elem_curt_ptr->ymax > BDymin) 
	                    BDymax = Bdy_elem_curt_ptr->ymax;
 
	        if (Bdy_elem_curt_ptr->zmin < BDzmin) 
	                    BDzmin = Bdy_elem_curt_ptr->zmin;
	        if (Bdy_elem_curt_ptr->zmax < BDzmin) 
	                    BDzmin = Bdy_elem_curt_ptr->zmax;
	        if (Bdy_elem_curt_ptr->zmin > BDzmax) 
	                    BDzmax = Bdy_elem_curt_ptr->zmin;
	        if (Bdy_elem_curt_ptr->zmax > BDzmin) 
	                    BDzmax = Bdy_elem_curt_ptr->zmax;
 
	        Bdy_elem_curt_ptr = Bdy_elem_curt_ptr->Next; 
	    }
    }

    /* if in BAD status, does the memory need be free ? */
    /* print out file here for debug */
    /* debug_output ("spdebug.out"); */

    return (status);
}




/*++
**
**  Name:	 gtkeywd
**
**  Synopsis:	 int gtkeywd (fp, keyword)
**
**  Parameters:  fp	  ----	pointer to the file
**		 keyword  ----	return keyword
**
**  Description:  get a keyword from input file
**
**  Returns:	  1 --	Get a keyword / -1 end of file
**
**  Side Effects:
**
**  Notes:
**
**  Errata:
**
**--
*/


int
gtkeywd (fp, keyword)
FILE   *fp;
char   *keyword;
{
    int     c, i;
    char   *tmp;

    tmp = keyword;
    while ((c = fgetc (fp)) != EOF) {

	if (c == '#') {
	    while (isspace (c = fgetc (fp)));
	    /* eliminate spaces infront of keyword */

	    *tmp++ = c;
	    while (!isspace (c = fgetc (fp))) {
		*tmp++ = c;
	    }
	    *tmp = '\0';
	    /* convert upper case to lower */
	    for (i = 0; keyword[i] != 0; i++) {
		keyword[i] = tolower (keyword[i]);
	    }
	    keyword[i + 1] = 0;
	    return (OK);
	}
    }
    return (BAD);
}





/* read in boundary nodes */
int
rd_bdy_node (FILE *fp, long tmp_bdy_nodes, int tmp_dimen)
{
    long ii, ldummy;
    BMeshNode *nptr;

    if ((tmp_bdy_nodes != Bdy_nodes) || (tmp_dimen != Dimen))
      printf ("\nWarning...Boundary node number or Dimension uncompatible!\n");

    /* first node */
    Bdy_node_head_ptr = (BMeshNode *) malloc (sizeof (BMeshNode));
    if (!Bdy_node_head_ptr)   alloc_error ("rdnml-1");
    else
    {
	Bdy_node_head_ptr->Prev = NULL;
	Bdy_node_head_ptr->Next = NULL;
    }

    nptr = Bdy_node_curt_ptr = Bdy_node_head_ptr;

    if (Numbering == OK)
    {
	fscanf (fp, "%ld %lf %lf %lf", &ldummy,
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }
    else
    {
	fscanf (fp, "%lf %lf %lf",
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }

    /* 2 to last node */
    for (ii=1; ii<tmp_bdy_nodes; ii++)
    {
	nptr = (BMeshNode *) malloc (sizeof (BMeshNode));
	if (!nptr)	alloc_error ("rdnml-2");
	else
	{
	    nptr->Prev = NULL;
	    nptr->Next = NULL;
	}

	/* set node link */
	Bdy_node_curt_ptr->Next = nptr;
	nptr->Prev = Bdy_node_curt_ptr;

	Bdy_node_curt_ptr = nptr;

	/* read in node coordinates */
	if (Numbering == OK)
	{
	    fscanf (fp, "%ld %lf %lf %lf", &ldummy,
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
	else
	{
	    fscanf (fp, "%lf %lf %lf",
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
    }

    /* close the link */
    nptr->Next = Bdy_node_head_ptr;
    Bdy_node_head_ptr->Prev = nptr;

    return (OK);

}



/* read in boundary elements */
int
rd_bdy_elem (FILE *fp, long tmp_bdy_elem, int bdy_lst_type)
{
    int         k, count, external_code;
    long        ii, ldummy, lnum_1, lnum_2, lnum_3;
    BMeshElem   *eptr;

    ldummy = bdy_lst_type;    /* get rid of complier warning message */

    if ((tmp_bdy_elem != Bdy_elem))
      printf ("\nWarning...Boundary elem number uncompatible!\n");

    if (bdy_lst_type == BD3D)
    {
        /* first elem */
        Bdy_elem_head_ptr = (BMeshElem *) malloc (sizeof (BMeshElem));
        if (!Bdy_elem_head_ptr)   alloc_error ("rdnml-3");
        else
	    {
	        Bdy_elem_head_ptr->Prev = NULL;
	        Bdy_elem_head_ptr->Next = NULL;
	        Bdy_elem_head_ptr->ref_levlel = 0;
	        Bdy_elem_head_ptr->Mtrl_in = BAD;
	        Bdy_elem_head_ptr->Mtrl_out = BAD;
        }

        eptr = Bdy_elem_curt_ptr = Bdy_elem_head_ptr;

        if (Numbering == OK)
        {
	        fscanf (fp, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
       }
       else
       {
	        fscanf (fp, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
       }
       
       tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 

       /* 2 to last elem */
       for (ii=1; ii<tmp_bdy_elem; ii++)
       {
	        eptr = (BMeshElem *) malloc (sizeof (BMeshElem));
	        if (!eptr)	alloc_error ("rdnml-4");
	        else
	        {
                eptr->ref_levlel = 0;
	            eptr->Mtrl_in = BAD;
	            eptr->Mtrl_out = BAD;
	            eptr->Prev = NULL;
	            eptr->Next = NULL;
	        }

	        /* set node link */
	        Bdy_elem_curt_ptr->Next = eptr;
	        eptr->Prev = Bdy_elem_curt_ptr;

	        Bdy_elem_curt_ptr = eptr;

	        if (Numbering == OK)
	        {
	            fscanf (fp, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
	            eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	            eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	            eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
	        }
	        else
	        {
	            fscanf (fp, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
	            eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	            eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	            eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
	        }

            tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 
       }

       /* close the link */
       eptr->Next = Bdy_elem_head_ptr;
       Bdy_elem_head_ptr->Prev = eptr;
    }
    else if (bdy_lst_type == BD3DMTRL)
    {
        /* first elem */
        Bdy_elem_head_ptr = (BMeshElem *) malloc (sizeof (BMeshElem));
        if (!Bdy_elem_head_ptr)   alloc_error ("rdnml-5");
        else
        {
            Bdy_elem_head_ptr->ref_levlel = 0;
	        Bdy_elem_head_ptr->Mtrl_in = BAD;
	        Bdy_elem_head_ptr->Mtrl_out = BAD;
	        Bdy_elem_head_ptr->Prev = NULL;
	        Bdy_elem_head_ptr->Next = NULL;
	    }

        eptr = Bdy_elem_curt_ptr = Bdy_elem_head_ptr;

        if (Numbering == OK)
        {
	        fscanf (fp, "%ld %ld %ld %ld %d %d", &ldummy, 
                      &lnum_1, &lnum_2, &lnum_3,
                      &eptr->Mtrl_in, &eptr->Mtrl_out);
	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
       }
       else
       {
	        fscanf (fp, "%ld %ld %ld %d %d", &lnum_1, &lnum_2, &lnum_3,
                      &eptr->Mtrl_in, &eptr->Mtrl_out);
	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
       }

       tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 

       /* 2 to last elem */
       for (ii=1; ii<tmp_bdy_elem; ii++)
       {
	        eptr = (BMeshElem *) malloc (sizeof (BMeshElem));
	        if (!eptr)	alloc_error ("rdnml-6");
	        else
	        {
                eptr->ref_levlel = 0;
	            eptr->Mtrl_in = BAD;
	            eptr->Mtrl_out = BAD;
	            eptr->Prev = NULL;
	            eptr->Next = NULL;
	        }

	        /* set node link */
	        Bdy_elem_curt_ptr->Next = eptr;
	        eptr->Prev = Bdy_elem_curt_ptr;

	        Bdy_elem_curt_ptr = eptr;

	        if (Numbering == OK)
	        {
	            fscanf (fp, "%ld %ld %ld %ld %d %d", &ldummy, 
                      &lnum_1, &lnum_2, &lnum_3,
                      &eptr->Mtrl_in, &eptr->Mtrl_out);
	            eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	            eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	            eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
	        }
	        else
	        {
	            fscanf (fp, "%ld %ld %ld %d %d",
		                &lnum_1, &lnum_2, &lnum_3,
		                &eptr->Mtrl_in, &eptr->Mtrl_out);
	            eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (Bdy_node_head_ptr, lnum_1);
	            eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (Bdy_node_head_ptr, lnum_2);
	            eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (Bdy_node_head_ptr, lnum_3);
	        }
            tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 

       }

       /* close the link */
       eptr->Next = Bdy_elem_head_ptr;
       Bdy_elem_head_ptr->Prev = eptr;

       /* check external region (default as '0' region) */
       for (k=0; k<MAX_MTRL_NUM; k++)      
            Mtrl_code[k] = 0;

       for (ii=0, eptr=Bdy_elem_head_ptr; ii<tmp_bdy_elem; ii++, eptr = eptr->Next)
       {
           if (eptr->Mtrl_in == 0 || eptr->Mtrl_out == 0)
                return (OK);
           else
           {
               if (eptr->Mtrl_in > BDY_NODE_CODE || eptr->Mtrl_out > BDY_NODE_CODE)
               {
                   printf ("\nError... Invalid Material Code (>%d)!\n", (int)BDY_NODE_CODE);
                   exit (-1);
               }
               else
               {
                    Mtrl_code[eptr->Mtrl_in]  = 1;
                    Mtrl_code[eptr->Mtrl_out] = 1;
               }
           }
       }

       printf ("\nWarning...No external boundary defined!\n");
RE:
       printf ("\nPlease define external region in following Mtrl. Codes :\n");
       count = 0;
       for (k=0; k<MAX_MTRL_NUM; k++) 
       {
           if (Mtrl_code[k])
           {
               if (count>10) 
               {
                   count = 0;
                   printf ("\n");
               }
               count++;
               ldummy = k;
               printf ("%4ld", ldummy);
           }
       }
       count = 0;
       for (;;)
       {
            printf ("\n==> ");
            scanf ("%d", &external_code);
            if (external_code >= 0 && external_code < MAX_MTRL_NUM)
            {
                if (Mtrl_code[external_code])
                {
                    count = 1;
                    Mtrl_code[external_code] = 0;
                    break;
                }
            }
            printf ("\nInvalid Mtrl Code!!\n");
       } 
       /* set external region as '0' mtrl region */
       for (ii=0, eptr=Bdy_elem_head_ptr; ii<tmp_bdy_elem; ii++, eptr = eptr->Next)
       {
           if (eptr->Mtrl_in == external_code)  eptr->Mtrl_in = 0;
           else if (eptr->Mtrl_out == external_code)  eptr->Mtrl_out = 0;
       }

       printf ("\nDefine another outer region? (Yes=1 / No=0): ");
       scanf ("%d", &count);
       if (count == 1)  goto RE;
    }
    else
    {
       printf ("\nUnkown BDY list type .... Skip !\n");
    }
    return (OK);
}



/* read in mesh nodes */
int
rd_msh_node (FILE *fp, long tmp_msh_nodes, int tmp_dimen)
{
    long ii, ldummy;
    MeshNode *nptr;

    if ((tmp_msh_nodes != Msh_nodes) || (tmp_dimen != Dimen))
      printf ("\nWarning...grid node number or Dimension uncompatible!\n");

    /* first node */
    Msh_node_head_ptr = (MeshNode *) malloc (sizeof (MeshNode));
    if (!Msh_node_head_ptr)   alloc_error ("rdnml-7");
    else
    {
	Msh_node_head_ptr->Fst_adj = NULL;
	Msh_node_head_ptr->Fst_adj_elem = NULL;
	Msh_node_head_ptr->status = 0;
	Msh_node_head_ptr->in_zone = 0;
	Msh_node_head_ptr->Mtrl = BAD;
	Msh_node_head_ptr->Prev = NULL;
	Msh_node_head_ptr->Next = NULL;
    }


    nptr = Msh_node_curt_ptr = Msh_node_head_ptr;
    nptr->Num_adj = nptr->Num_adj_elem = nptr->status = nptr->in_zone = 0;

    if (Numbering == OK)
    {
	fscanf (fp, "%ld %lf %lf %lf", &ldummy,
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }
    else
    {
	fscanf (fp, "%lf %lf %lf",
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }

    /* 2 to last node */
    for (ii=1; ii<tmp_msh_nodes; ii++)
    {
	nptr = (MeshNode *) malloc (sizeof (MeshNode));
	if (!nptr)	alloc_error ("rdnml-8");
	else
	{
	    nptr->Fst_adj = NULL;
	    nptr->Fst_adj_elem = NULL;
	    nptr->status = nptr->in_zone = 0;
	    nptr->Mtrl   = BAD;
	    nptr->Prev = NULL;
	    nptr->Next = NULL;
	}


	nptr->Num_adj = nptr->Num_adj_elem = nptr->status = nptr->in_zone = 0;

	/* set node link */
	Msh_node_curt_ptr->Next = nptr;
	nptr->Prev = Msh_node_curt_ptr;

	Msh_node_curt_ptr = nptr;

	/* read in node coordinates */
	if (Numbering == OK)
	{
	    fscanf (fp, "%ld %lf %lf %lf", &ldummy,
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
	else
	{
	    fscanf (fp, "%lf %lf %lf",
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
    }

    /* close the link */
    nptr->Next = Msh_node_head_ptr;
    Msh_node_head_ptr->Prev = nptr;

    return (OK);

}


/* find bounding box for given trianglar patch */
int
tri_patch_bound (BMeshNode **nnptr, double *xmin, double *ymin, double *zmin, 
                                    double *xmax, double *ymax, double *zmax)
{
    int    i;
    
    *xmin = *ymin = *zmin =  1.e10;
    *xmax = *ymax = *zmax = -1.e10;

    for (i=0; i<3; i++)
    {
        if (nnptr[i]->Coor[X] < *xmin)   *xmin = nnptr[i]->Coor[X]; 
        if (nnptr[i]->Coor[X] > *xmax)   *xmax = nnptr[i]->Coor[X]; 
        if (nnptr[i]->Coor[Y] < *ymin)   *ymin = nnptr[i]->Coor[Y]; 
        if (nnptr[i]->Coor[Y] > *ymax)   *ymax = nnptr[i]->Coor[Y]; 
        if (nnptr[i]->Coor[Z] < *zmin)   *zmin = nnptr[i]->Coor[Z]; 
        if (nnptr[i]->Coor[Z] > *zmax)   *zmax = nnptr[i]->Coor[Z]; 
    }

    return (OK);
} 







/* read in mesh element list */
int
rd_msh_elem (FILE *fp, long tmp_msh_elem, int msh_lst_type)
{
    int  i, elem_type, num_p;
    long ii, ldummy, lnum_1;
    MeshElem *eptr;
    MeshNode **nnptr;

    ldummy = msh_lst_type;    /* get rid of complier warning message */

    if ((tmp_msh_elem != Msh_elem))
      printf ("\nWarning...Mesh elem number uncompatible!\n");

    /* first elem */
    Msh_elem_head_ptr = (MeshElem *) malloc (sizeof (MeshElem));
    if (!Msh_elem_head_ptr)   alloc_error ("rdnml-9");
    else
    {
	    Msh_elem_head_ptr->attr = 0;      
        Msh_elem_head_ptr->Mtrl_in = BAD;
	    Msh_elem_head_ptr->Mtrl_out = BAD;
	    Msh_elem_head_ptr->Prev = NULL;
	    Msh_elem_head_ptr->Next = NULL;
    }

    eptr = Msh_elem_curt_ptr = Msh_elem_head_ptr;


    if (Numbering == OK)
    {
	    fscanf (fp, "%ld", &ldummy);
    }

    fscanf (fp, "%d", &elem_type);
    switch (elem_type)
    {
	    case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case PYRAM5:
		    num_p = 5;
		    nnptr = eptr->Elem.pyr5.NodePtr;
		    break;
	    case PRISM6:
		    num_p = 6;
		    nnptr = eptr->Elem.prm6.NodePtr;
		    break;
	    case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    case TRI6:
		    num_p = 6;
		    nnptr = eptr->Elem.tri6.NodePtr;
		    break;
	    default:
		    num_p = -1;
		    printf ("\nError...Unknown element type!\n");
		    return (BAD);
    }

    /* read in elem. node list and convert to MeshNode ptr. */
    for (i=0; i<num_p; i++)
    {
	    fscanf (fp, "%ld", &lnum_1);
	    nnptr[i]=conv_node_idx (Msh_node_head_ptr, lnum_1);
    }
    
    if (msh_lst_type == 1)   fscanf(fp, "%d", &eptr->Mtrl_in);
    eptr->E_type =  elem_type;


    /* 2 to last elem */
    for (ii=1; ii<tmp_msh_elem; ii++)
    {
	    eptr = (MeshElem *) malloc (sizeof (MeshElem));
	    if (!eptr)	alloc_error ("rdnml-10");
	    else
	    {
	        eptr->attr = 0;                
	        eptr->Mtrl_in = BAD;
	        eptr->Mtrl_out = BAD;
	        eptr->Prev = NULL;
	        eptr->Next = NULL;
	    }


	    /* set node link */
	    Msh_elem_curt_ptr->Next = eptr;
	    eptr->Prev = Msh_elem_curt_ptr;

	    Msh_elem_curt_ptr = eptr;


	    if (Numbering == OK)
	    {
	        fscanf (fp, "%ld", &ldummy);
	    }

	    fscanf (fp,  "%d", &elem_type);
	    switch (elem_type)
	    {
	        case TET4:
		        num_p = 4;
		        nnptr = eptr->Elem.tet4.NodePtr;
		        break;
	        case PYRAM5:
		        num_p = 5;
		        nnptr = eptr->Elem.pyr5.NodePtr;
		        break;
	        case PRISM6:
		        num_p = 6;
		        nnptr = eptr->Elem.prm6.NodePtr;
		        break;
	        case HEX8:
		        num_p = 8;
		        nnptr = eptr->Elem.hex8.NodePtr;
		        break;
	        case TRI6:
		        num_p = 6;
		        nnptr = eptr->Elem.tri6.NodePtr;
		        break;
	        default:
		        num_p = -1;
		        printf ("\nError...Unknown element type!\n");
		        return (BAD);
	    }

	    /* read in elem. node list and convert to MeshNode ptr. */
	    for (i=0; i<num_p; i++)
	    {
	        fscanf (fp, "%ld", &lnum_1);
	        nnptr[i]=conv_node_idx (Msh_node_head_ptr, lnum_1);
	    }

	    if (msh_lst_type == 1)   fscanf(fp, "%d", &eptr->Mtrl_in);
	    eptr->E_type =	elem_type;

    }

    /* close the link */
    eptr->Next = Msh_elem_head_ptr;
    Msh_elem_head_ptr->Prev = eptr;

    return (OK);
}


/* read in specialty node */
int
rd_sp_node (FILE *fp, int num_nodes)
{
    int  idummy;
    int  i;
    MeshNode *nptr;

    if (num_nodes < 0)
    {
      printf ("\nWarning...unreasonable sp. node number!\n");
      return (BAD);
    }

    /* first node */
    Sp_node_head_ptr = (MeshNode *) malloc (sizeof (MeshNode));
    if (!Sp_node_head_ptr)   alloc_error ("rdnml-11");
    else
    {
	Sp_node_head_ptr->Fst_adj = NULL;
	Sp_node_head_ptr->Fst_adj_elem = NULL;
	Sp_node_head_ptr->status = 0;
	Sp_node_head_ptr->Mtrl = BAD;
	Sp_node_head_ptr->Prev = NULL;
	Sp_node_head_ptr->Next = NULL;
    }

    nptr = Sp_node_curt_ptr = Sp_node_head_ptr;
    nptr->Num_adj = nptr->Num_adj_elem = nptr->status = nptr->in_zone = 0;

    if (Numbering == OK)
    {
	fscanf (fp, "%d %lf %lf %lf", &idummy,
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }
    else
    {
	fscanf (fp, "%lf %lf %lf",
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }

    /* 2 to last node */
    for (i=1; i<num_nodes; i++)
    {
	nptr = (MeshNode *) malloc (sizeof (MeshNode));
	if (!nptr)	alloc_error ("rdnml-2");
	else
	{
	    nptr->Fst_adj = NULL;
	    nptr->Fst_adj_elem = NULL;
	    nptr->status = nptr->in_zone = 0;
	    nptr->Mtrl   = BAD;
	    nptr->Prev = NULL;
	    nptr->Next = NULL;
	}


	nptr->Num_adj = nptr->Num_adj_elem = nptr->status = 0;

	/* set node link */
	Sp_node_curt_ptr->Next = nptr;
	nptr->Prev = Sp_node_curt_ptr;

	Sp_node_curt_ptr = nptr;

	/* read in node coordinates */
	if (Numbering == OK)
	{
	    fscanf (fp, "%d %lf %lf %lf", &idummy,
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
	else
	{
	    fscanf (fp, "%lf %lf %lf",
		  &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	}
    }

    /* close the link */
    nptr->Next = Sp_node_head_ptr;
    Sp_node_head_ptr->Prev = nptr;

    return (OK);

}



/* read in specialty line list */
int
rd_sp_elem (FILE *fp, int num_elem)
{
    int   i, idummy, num_1, num_2;
    LineData	*eptr;

    if (num_elem < 0)
    {
      printf ("\nWarning...Unreasonable sp. line number !\n");
      return (BAD);
    }
    /* first elem */
    Sp_line_head_ptr = (LineData *) malloc (sizeof (LineData));
    if (!Sp_line_head_ptr)	 alloc_error ("rdnml-13");
    else
    {
	Sp_line_head_ptr->Prev = NULL;
	Sp_line_head_ptr->Next = NULL;
	Sp_line_head_ptr->StPtr = Sp_line_head_ptr->EdPtr = NULL;
    }

    eptr = Sp_line_curt_ptr = Sp_line_head_ptr;

    if (Numbering == OK)
    {
	fscanf (fp, "%d %d %d", &idummy, &num_1, &num_2);
	eptr->StPtr=conv_node_idx (Sp_node_head_ptr, num_1);
	eptr->EdPtr=conv_node_idx (Sp_node_head_ptr, num_2);
    }
    else
    {
	fscanf (fp, "%d %d", &num_1, &num_2);
	eptr->StPtr=conv_node_idx (Sp_node_head_ptr, num_1);
	eptr->EdPtr=conv_node_idx (Sp_node_head_ptr, num_2);
    }

    /* 2 to last elem */
    for (i=1; i<num_elem; i++)
    {
	eptr = (LineData *) malloc (sizeof (LineData));
	if (!eptr)	alloc_error ("rdnml-14");
	else
	{
	    eptr->Prev = NULL;
	    eptr->Next = NULL;
	    eptr->StPtr = eptr->EdPtr = NULL;
	}


	/* set elem link */
	Sp_line_curt_ptr->Next = eptr;
	eptr->Prev = Sp_line_curt_ptr;

	Sp_line_curt_ptr = eptr;


	if (Numbering == OK)
	{
	    fscanf (fp, "%d %d %d", &idummy, &num_1, &num_2);
	    eptr->StPtr=conv_node_idx (Sp_node_head_ptr, num_1);
	    eptr->EdPtr=conv_node_idx (Sp_node_head_ptr, num_2);
	}
	else
	{
	    fscanf (fp, "%d %d", &num_1, &num_2);
	    eptr->StPtr=conv_node_idx (Sp_node_head_ptr, num_1);
	    eptr->EdPtr=conv_node_idx (Sp_node_head_ptr, num_2);
	}


    }

    /* close the link */
    eptr->Next = Sp_line_head_ptr;
    Sp_line_head_ptr->Prev = eptr;

    return (OK);
}




/* read in specialty polyline node */
int
rd_sp_poly_node (FILE *fp, int num_nodes)
{
    int  idummy;
    int  i;
    MeshNode *nptr;

    if (num_nodes < 0)
    {
      printf ("\nWarning...unreasonable sp. poly node number!\n");
      return (BAD);
    }

    /* first node */
    Spoly_node_head_ptr = (MeshNode *) malloc (sizeof (MeshNode));
    if (!Spoly_node_head_ptr)   alloc_error ("rdnml-15");
    else
    {
	    Spoly_node_head_ptr->Fst_adj = NULL;
	    Spoly_node_head_ptr->Fst_adj_elem = NULL;
	    Spoly_node_head_ptr->status = 0;
	    Spoly_node_head_ptr->Mtrl = BAD;
	    Spoly_node_head_ptr->Prev = NULL;
	    Spoly_node_head_ptr->Next = NULL;
    }

    nptr = Spoly_node_curt_ptr = Spoly_node_head_ptr;
    nptr->Num_adj = nptr->Num_adj_elem = nptr->status = nptr->in_zone = 0;

    if (Numbering == OK)
    {
	    fscanf (fp, "%d %lf %lf %lf", &idummy,
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }
    else
    {
	    fscanf (fp, "%lf %lf %lf",
	      &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
    }

    /* 2 to last node */
    for (i=1; i<num_nodes; i++)
    {
	    nptr = (MeshNode *) malloc (sizeof (MeshNode));
	    if (!nptr)	alloc_error ("rdnml-16");
	    else
	    {
	        nptr->Fst_adj = NULL;
	        nptr->Fst_adj_elem = NULL;
	        nptr->status = nptr->in_zone = 0;
	        nptr->Mtrl   = BAD;
	        nptr->Prev = NULL;
	        nptr->Next = NULL;
	    }

	    nptr->Num_adj = nptr->Num_adj_elem = nptr->status = 0;

	    /* set node link */
	    Spoly_node_curt_ptr->Next = nptr;
	    nptr->Prev = Spoly_node_curt_ptr;

	    Spoly_node_curt_ptr = nptr;

	    /* read in node coordinates */
	    if (Numbering == OK)
	    {
	        fscanf (fp, "%d %lf %lf %lf", &idummy,
		        &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	    }
	    else
	    {
	        fscanf (fp, "%lf %lf %lf",
		    &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
	    }
    }

    /* close the link */
    nptr->Next = Spoly_node_head_ptr;
    Spoly_node_head_ptr->Prev = nptr;

    return (OK);

}





/* read in specialty line list */
int
rd_sp_poly_elem (FILE *fp, int num_elem)
{
    int         i, idummy, num_1, num_2;
    MeshNode    *nptr;
    LineData	*eptr;

    /* first read sp. polyline general data and then create the
	detail list of each piece of polyline
    */
    if (num_elem < 0)
    {
      printf ("\nWarning...Unreasonable sp. polyline number !\n");
      return (BAD);
    }
    /* first elem */
    Spoly_elem_head_ptr = (LineData *) malloc (sizeof (LineData));
    if (!Spoly_elem_head_ptr)	 alloc_error ("rdnml-17");
    else
    {
	Spoly_elem_head_ptr->Prev = NULL;
	Spoly_elem_head_ptr->Next = NULL;
	Spoly_elem_head_ptr->StPtr = Spoly_elem_head_ptr->EdPtr = NULL;
    }

    eptr = Spoly_elem_curt_ptr = Spoly_elem_head_ptr;

    if (Numbering == OK)
    {
	fscanf (fp, "%d %d %d", &idummy, &num_1, &num_2);
	eptr->StPtr=conv_node_idx (Spoly_node_head_ptr, num_1);
	eptr->EdPtr=conv_node_idx (Spoly_node_head_ptr, num_2);
    }
    else
    {
	fscanf (fp, "%d %d", &num_1, &num_2);
	eptr->StPtr=conv_node_idx (Spoly_node_head_ptr, num_1);
	eptr->EdPtr=conv_node_idx (Spoly_node_head_ptr, num_2);
    }

    /* 2 to last elem */
    for (i=1; i<num_elem; i++)
    {
	eptr = (LineData *) malloc (sizeof (LineData));
	if (!eptr)	alloc_error ("rdnml-18");
	else
	{
	    eptr->Prev = NULL;
	    eptr->Next = NULL;
	    eptr->StPtr = eptr->EdPtr = NULL;
	}


	/* set elem link */
	Spoly_elem_curt_ptr->Next = eptr;
	eptr->Prev = Spoly_elem_curt_ptr;

	Spoly_elem_curt_ptr = eptr;


	if (Numbering == OK)
	{
	    fscanf (fp, "%d %d %d", &idummy, &num_1, &num_2);
	    eptr->StPtr=conv_node_idx (Spoly_node_head_ptr, num_1);
	    eptr->EdPtr=conv_node_idx (Spoly_node_head_ptr, num_2);
	}
	else
	{
	    fscanf (fp, "%d %d", &num_1, &num_2);
	    eptr->StPtr=conv_node_idx (Spoly_node_head_ptr, num_1);
	    eptr->EdPtr=conv_node_idx (Spoly_node_head_ptr, num_2);
	}


    }

    /* close the link */
    eptr->Next = Spoly_elem_head_ptr;
    Spoly_elem_head_ptr->Prev = eptr;



    /* create detail list of polylines */
    /* allocate space for pointer and node num. array with size of num_elem */
    Spoly_list_head_ptr = (LineData **) malloc (num_elem * sizeof (LineData *));
    if (!Spoly_list_head_ptr)	 alloc_error ("rdnml-19");
    Num_seg_in_poly = (int *) malloc (num_elem * sizeof (int));
    if (!Num_seg_in_poly)	 alloc_error ("rdnml-20");

    Spoly_elem_curt_ptr = Spoly_elem_head_ptr;
    /* for each polyline */
    /* Note that : the num. of segment of polyline is equal to (num. of node - 1) 
                   and in polyline segment list, the End node of previous seg.
		   is the same node as the Start node of next seg.
		   if the Start node of first seg. is the same as the End node
		   of last seg. then it is a closed polyline (polygon),
		   otherwise is a open polyline.
    */
    for (i=0; i<num_elem; i++)
    {
	Num_seg_in_poly[i] = 0;
	/* allocate for header pointer */
	Spoly_list_head_ptr[i] = (LineData *) malloc (sizeof (LineData));
	
	if (!Spoly_list_head_ptr[i])	 alloc_error ("rdnml-21");
	else
	{
	  ++Num_seg_in_poly[i];
	  Spoly_list_head_ptr[i]->Prev = NULL;
	  Spoly_list_head_ptr[i]->Next = NULL;
	  Spoly_list_head_ptr[i]->StPtr = Spoly_list_head_ptr[i]->EdPtr = NULL;
	}
	eptr = Spoly_list_curt_ptr = Spoly_list_head_ptr[i];
        if (Spoly_elem_curt_ptr->StPtr == NULL || 
	    Spoly_elem_curt_ptr->EdPtr == NULL)      return (BAD);

	eptr->StPtr  = nptr = Spoly_elem_curt_ptr->StPtr;
	eptr->EdPtr  = nptr->Next;

        nptr = nptr->Next;
        while (nptr != Spoly_elem_curt_ptr->EdPtr)
	{
	  /* allocate memory */
	  eptr = (LineData *) malloc (sizeof (LineData));
	
	  if (!eptr)	 alloc_error ("rdnml-22");
	  else
	  {
	    ++Num_seg_in_poly[i];
	    eptr->Prev = NULL;
	    eptr->Next = NULL;
	    eptr->StPtr = eptr->EdPtr = NULL;
	  }
	  /* set elem link */
	  Spoly_list_curt_ptr->Next = eptr;
	  eptr->Prev = Spoly_list_curt_ptr;

	  Spoly_list_curt_ptr = eptr;

	  /* set nodes of the segment */
	  eptr->StPtr  = nptr;
	  eptr->EdPtr  = nptr->Next;

	  nptr = nptr->Next;
	  
	}  
        /* close the link of the polyline */
        eptr->Next = Spoly_list_head_ptr[i];
        Spoly_list_head_ptr[i]->Prev = eptr;

        /* to next polyline entity */
	Spoly_elem_curt_ptr = Spoly_elem_curt_ptr->Next;
    }

    return (OK);
}






/* create node adjacent list and node-element list*/

int
mk_adjlist (MeshNode *n_head, long num_node, MeshElem *e_head, long num_elem)
{
    long     ii=0;
    MeshElem *cur_eptr;
    
    cur_eptr = e_head;
    do
    {
        ii++;
	    set_adj_node_elem (cur_eptr);
	    cur_eptr = cur_eptr->Next;
    } while (cur_eptr != e_head);

    if (ii != num_elem)
      printf ("\nWarning...Number Elem. = %ld (num_elem = %ld)!\n",
	            ii, num_elem);

    return (OK);
}




/* given node find the relationship with the given element */
/* enode_idx -- the order of given node in the element, which
   will decide the adjacent node order within the element
*/
int
nod_in_elem (MeshNode *nptr, MeshElem *eptr, int *enode_idx)
{

    int  i, num_p;
    MeshNode **nnptr;

    switch (eptr->E_type)
    {
	case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	case PYRAM5:
		    num_p = 5;
		    nnptr = eptr->Elem.pyr5.NodePtr;
		    break;
	case PRISM6:
		    num_p = 6;
		    nnptr = eptr->Elem.prm6.NodePtr;
		    break;
	case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	case TRI6:
		    num_p = 6;
		    nnptr = eptr->Elem.tri6.NodePtr;
		    break;
	default:
		    num_p = -1;
		    printf ("\nError...Unknown element type!\n");
		    return (BAD);
    }

    /* read in elem. node list and convert to MeshNode ptr. */
    *enode_idx = 0;
    for (i=0; i<num_p; i++)
    {
	    (*enode_idx)++;
	    if (nptr == nnptr[i])
	    {
		return (OK);
	    }
    }

    return (0);
}


/* allocate memory and set up for adjacent node and  elem link list */

int
set_adj_node_elem (MeshElem *eptr)
{
    int  i, inod, num_p, n_adj, adj_idx[4], dup_sign;
    AdjList *tmp_aptr, *aptr;
    AdjElem *tmp_aeptr, *aeptr;
    MeshNode **nnptr, *nptr;

    /* determine the num. of nodes and node pointer for the given type of elem */
    switch (eptr->E_type)
    {
	    case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case PYRAM5:
		    num_p = 5;
		    nnptr = eptr->Elem.pyr5.NodePtr;
		    break;
	    case PRISM6:
		    num_p = 6;
		    nnptr = eptr->Elem.prm6.NodePtr;
		    break;
	    case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    case TRI6:
		    num_p = 6;
		    nnptr = eptr->Elem.tri6.NodePtr;
		    break;
	    default:
		    num_p = -1;
		    printf ("\nError...Unknown element type!\n");
		    return (BAD);
    }

    /* traverse all the node in the elem. */
    for (inod=0; inod<num_p; inod++)
    {
	    nptr = nnptr[inod];
        if (nptr == NULL)   continue;
	    aptr = nptr->Fst_adj;
	    /* point to the last component in the list */
	    if (aptr)  
        {
            while (aptr->ptr) aptr = aptr->ptr;
        }
	    aeptr = nptr->Fst_adj_elem;
	    /* point to the last component in the list */
	    if (aeptr)  
        {
            while (aeptr->ptr) aeptr = aeptr->ptr;
        }
	    /* determine the local node index connect to current node */
	    switch (eptr->E_type)
	    {
		    case TRI3:
		        /* set adj. element node idx */
		        n_adj = 0;
		        for (i=0; i<num_p; i++)
		        {
			        if (i+1 != inod+1)
			        {
			            adj_idx[n_adj] = i+1;
			            n_adj++;
			        }
		        }
		        break;
		    case TET4:
		        /* set adj. element node idx */
		        n_adj = 0;
		        for (i=0; i<num_p; i++)
		        {
			        if (i+1 != inod+1)
			        {
			            adj_idx[n_adj] = i+1;
			            n_adj++;
			        }
		        }
		        break;
		    case PYRAM5:
		        n_adj = 3;
		        switch (inod+1)
		        {
			        case 1:
				        adj_idx[0] = 2;
				        adj_idx[1] = 4;
				        adj_idx[2] = 5;
				        break;
			        case 2:
				        adj_idx[0] = 1;
				        adj_idx[1] = 3;
				        adj_idx[2] = 5;
				        break;
			        case 3:
				        adj_idx[0] = 2;
				        adj_idx[1] = 4;
				        adj_idx[2] = 5;
				        break;
			        case 4:
				        adj_idx[0] = 1;
				        adj_idx[1] = 3;
				        adj_idx[2] = 5;
				        break;
			        case 5:
				        adj_idx[0] = 1;
				        adj_idx[1] = 2;
				        adj_idx[2] = 3;
				        adj_idx[3] = 4;
				        n_adj = 4;
				        break;
			        default:
				        n_adj = 0;
		        }
		        break;
		    case PRISM6:
		        n_adj = 3;
		        switch (inod+1)
		        {
			        case 1:
				        adj_idx[0] = 2;
				        adj_idx[1] = 3;
				        adj_idx[2] = 4;
				        break;
			        case 2:
				        adj_idx[0] = 1;
				        adj_idx[1] = 3;
				        adj_idx[2] = 5;
				        break;
			        case 3:
				        adj_idx[0] = 1;
				        adj_idx[1] = 2;
				        adj_idx[2] = 6;
				        break;
			        case 4:
				        adj_idx[0] = 1;
				        adj_idx[1] = 5;
				        adj_idx[2] = 6;
				        break;
			        case 5:
				        adj_idx[0] = 2;
				        adj_idx[1] = 4;
				        adj_idx[2] = 6;
				        break;
			        case 6:
				        adj_idx[0] = 3;
				        adj_idx[1] = 4;
				        adj_idx[2] = 5;
				        break;
			        default:
				        n_adj = 0;
		        }
		        break;
		    case HEX8:
		        /* set adj. element node idx */
		        n_adj = 3;
		        switch (inod+1)
		        {
			        case 1:
				        adj_idx[0] = 2;
				        adj_idx[1] = 4;
				        adj_idx[2] = 5;
				        break;
			        case 2:
				        adj_idx[0] = 1;
				        adj_idx[1] = 3;
				        adj_idx[2] = 6;
				        break;
			        case 3:
				        adj_idx[0] = 2;
				        adj_idx[1] = 4;
				        adj_idx[2] = 7;
				        break;
			        case 4:
				        adj_idx[0] = 1;
				        adj_idx[1] = 3;
				        adj_idx[2] = 8;
				        break;
			        case 5:
				        adj_idx[0] = 1;
				        adj_idx[1] = 6;
				        adj_idx[2] = 8;
				        break;
			        case 6:
				        adj_idx[0] = 2;
				        adj_idx[1] = 5;
				        adj_idx[2] = 7;
				        break;
			        case 7:
				        adj_idx[0] = 3;
				        adj_idx[1] = 6;
				        adj_idx[2] = 8;
				        break;
			        case 8:
				        adj_idx[0] = 4;
				        adj_idx[1] = 5;
				        adj_idx[2] = 7;
				        break;
			        default:
				        n_adj = 0;
		        }
		        break;
		    case TRI6:
		        /* set adj. element node idx */
		        n_adj = 0;
		        /* need double check !!!*/
		        for (i=0; i<num_p-3; i++)
		        {
			        if (i+1 != inod+1)
			        {
			            adj_idx[n_adj] = i+1;
			            n_adj++;
			        }
		        }
		        break;
	    }

	    /* check set node adj. list for each adjacent node (with local index) */
	    for (i=0; i<n_adj; i++)
	    {   /* check the adj node if already in the list -- yes - skip */
	        dup_sign = 0;
	        tmp_aptr = nptr->Fst_adj;
	        while (tmp_aptr)
	        {
		        if (nnptr[adj_idx[i]-1] != tmp_aptr->idx)
		        {
		            tmp_aptr = tmp_aptr->ptr;
		        }
		        else
		        {
			        dup_sign = OK;
			        break;
		        }
	        }

	        if (dup_sign != OK)
	        {	 /* no duplicated node */
		        tmp_aptr  = (AdjList *) malloc (sizeof (AdjList));
		        if (!tmp_aptr)	  alloc_error ("rdnml-23");
		        else
		        {
		            tmp_aptr->ptr = NULL;
		        }

		        if (aptr)
		        {
			        aptr->ptr = tmp_aptr;
		        }
		        else
		        {
			        /* it's first one in the list */
			        nptr->Fst_adj = tmp_aptr;
		        }
		        aptr      = tmp_aptr;
		        aptr->idx = nnptr[adj_idx[i]-1];
		        nptr->Num_adj++;           /* counter increment */
	        }
	    }

	    /* set up node-elem adj. list */
	    /* check if the element is already in the node-elem list first */
	    dup_sign = 0;
	    tmp_aeptr = nptr->Fst_adj_elem;
	    while (tmp_aeptr)
	    {
	        if (eptr != tmp_aeptr->idx)
	        {
		        tmp_aeptr = tmp_aeptr->ptr;
	        }
	        else
	        {
			    dup_sign = OK;
			    break;
	        }
	    }

	    if (dup_sign != OK)
	    {	 /* no duplicated elem */
	        tmp_aeptr  = (AdjElem *) malloc (sizeof (AdjElem));
	        if (!tmp_aeptr)	  alloc_error ("rdnml-24");
	        else
	        {
		        tmp_aeptr->ptr = NULL;
	        }

	        if (aeptr)
	        {
			    aeptr->ptr = tmp_aeptr;
	        }
	        else
	        {
			    /* it's first one in the list */
			    nptr->Fst_adj_elem = tmp_aeptr;
	        }
	        aeptr  = tmp_aeptr;
	        aeptr->idx = eptr;
	        nptr->Num_adj_elem++;           /* counter increment */
	    }
    }
    return (OK);
}

/* allocate memory and set up for adjacent link list */

int
set_adjlist (MeshNode *nptr, AdjList **aptr, MeshElem *eptr, int enode_idx)
{
    int  i, num_p, n_adj, adj_idx[4], dup_sign;
    AdjList *tmp_aptr;
    MeshNode **nnptr;

    switch (eptr->E_type)
    {
	case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    /* set adj. element node idx */
		    n_adj = 0;
		    for (i=0; i<num_p; i++)
		    {
			if (i+1 != enode_idx)
			{
			    adj_idx[n_adj] = i+1;
			    n_adj++;
			}
		    }
		    break;
	case PYRAM5:
		    num_p = 5;
		    nnptr = eptr->Elem.pyr5.NodePtr;
		    n_adj = 3;
		    switch (enode_idx)
		    {
			case 1:
				adj_idx[0] = 2;
				adj_idx[1] = 4;
				adj_idx[2] = 5;
				break;
			case 2:
				adj_idx[0] = 1;
				adj_idx[1] = 3;
				adj_idx[2] = 5;
				break;
			case 3:
				adj_idx[0] = 2;
				adj_idx[1] = 4;
				adj_idx[2] = 5;
				break;
			case 4:
				adj_idx[0] = 1;
				adj_idx[1] = 3;
				adj_idx[2] = 5;
				break;
			case 5:
				adj_idx[0] = 1;
				adj_idx[1] = 2;
				adj_idx[2] = 3;
				adj_idx[3] = 4;
				n_adj = 4;
				break;
			default:
				n_adj = 0;
		    }
		    break;
	case PRISM6:
		    num_p = 6;
		    nnptr = eptr->Elem.prm6.NodePtr;
		    n_adj = 3;
		    switch (enode_idx)
		    {
			case 1:
				adj_idx[0] = 2;
				adj_idx[1] = 3;
				adj_idx[2] = 4;
				break;
			case 2:
				adj_idx[0] = 1;
				adj_idx[1] = 3;
				adj_idx[2] = 5;
				break;
			case 3:
				adj_idx[0] = 1;
				adj_idx[1] = 2;
				adj_idx[2] = 6;
				break;
			case 4:
				adj_idx[0] = 1;
				adj_idx[1] = 5;
				adj_idx[2] = 6;
				break;
			case 5:
				adj_idx[0] = 2;
				adj_idx[1] = 4;
				adj_idx[2] = 6;
				break;
			case 6:
				adj_idx[0] = 3;
				adj_idx[1] = 4;
				adj_idx[2] = 5;
				break;
			default:
				n_adj = 0;
		    }
		    break;
	case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    /* set adj. element node idx */
		    n_adj = 3;
		    switch (enode_idx)
		    {
			case 1:
				adj_idx[0] = 2;
				adj_idx[1] = 4;
				adj_idx[2] = 5;
				break;
			case 2:
				adj_idx[0] = 1;
				adj_idx[1] = 3;
				adj_idx[2] = 6;
				break;
			case 3:
				adj_idx[0] = 2;
				adj_idx[1] = 4;
				adj_idx[2] = 7;
				break;
			case 4:
				adj_idx[0] = 1;
				adj_idx[1] = 3;
				adj_idx[2] = 8;
				break;
			case 5:
				adj_idx[0] = 1;
				adj_idx[1] = 6;
				adj_idx[2] = 8;
				break;
			case 6:
				adj_idx[0] = 2;
				adj_idx[1] = 5;
				adj_idx[2] = 7;
				break;
			case 7:
				adj_idx[0] = 3;
				adj_idx[1] = 6;
				adj_idx[2] = 8;
				break;
			case 8:
				adj_idx[0] = 4;
				adj_idx[1] = 5;
				adj_idx[2] = 7;
				break;
			default:
				n_adj = 0;
		    }
		    break;
	case TRI6:
		    num_p = 6;
		    nnptr = eptr->Elem.tri6.NodePtr;
		    /* set adj. element node idx */
		    n_adj = 0;
		    /* need double check !!!*/
		    for (i=0; i<num_p-3; i++)
		    {
			if (i+1 != enode_idx)
			{
			    adj_idx[n_adj] = i+1;
			    n_adj++;
			}
		    }
		    break;
	default:
		    num_p = -1;
		    printf ("\nError...Unknown element type!\n");
		    return (BAD);
    }

    if (enode_idx > num_p)
    {
	printf ("\nBad element-node index!!\n");
	return (BAD);
    }


    for (i=0; i<n_adj; i++)
    {
	dup_sign = 0;
	tmp_aptr = nptr->Fst_adj;
	while (tmp_aptr)
	{
	     if (nnptr[adj_idx[i]-1] != tmp_aptr->idx)
	     {
		    tmp_aptr = tmp_aptr->ptr;
	     }
	     else
	     {
		 dup_sign = OK;
		 break;
	     }
	}

	if (dup_sign != OK)
	{ /* no duplicated node */
	    tmp_aptr  = (AdjList *) malloc (sizeof (AdjList));
	    if (!tmp_aptr)	  alloc_error ("rdnml-25");
	    else
	    {
		 tmp_aptr->ptr = NULL;
	    }

	    if (*aptr)
	    {
		(*aptr)->ptr = tmp_aptr;
	    }
	    else
	    {
		nptr->Fst_adj = tmp_aptr;
	    }
	    *aptr      = tmp_aptr;
	    (*aptr)->idx = nnptr[adj_idx[i]-1];
	    nptr->Num_adj++;
	}

    }

    return (OK);
}





/* given bdy node index find Node pointer */

BMeshNode *
conv_bnode_idx (BMeshNode *head, long node_idx)
{
     int ii;
     BMeshNode *nptr;

     nptr = head;
     for (ii=1; ii<node_idx; ii++)	  nptr = nptr->Next;

     return (nptr);
}




/* given BDY node pointer find Node index */
long
conv_bnode_ptr (BMeshNode *head, BMeshNode *node_ptr, long total_nodes)
{
     long node_idx;
     BMeshNode *nptr;

     nptr = head;
     node_idx = 1;
     while (nptr != node_ptr)
     {
	if (nptr == NULL)
	{
	    printf ("\nCan't match bdy node index\n");
	    return ((long) BAD);
	}
	nptr = nptr->Next;
	if (node_idx > total_nodes)
	{
	    printf ("\nCan't match bdy node index...over numbering!\n");
	    return ((long)BAD);
	}
	node_idx++;
     }

     return (node_idx);
}






/* given BDY elem index find elem pointer */

BMeshElem *
conv_belem_idx (BMeshElem *head, long elem_idx)
{
     long ii;
     BMeshElem *eptr;

     eptr = head;
     for (ii=1; ii<elem_idx; ii++)	  eptr = eptr->Next;

     return (eptr);
}




/* given bdy element pointer find element index */
long
conv_belem_ptr (BMeshElem *head, BMeshElem *elem_ptr, long total_elem)
{
     long elem_idx;
     BMeshElem *eptr;

     eptr = head;
     elem_idx = 1;
     while (eptr != elem_ptr)
     {
	if (eptr == NULL)
	{
	    printf ("\nCan't match bdy elem index\n");
	    return ((long) BAD);
	}
	eptr = eptr->Next;
	if (elem_idx > total_elem)
	{
	    printf ("\nCan't match bdy elem index...over numbering!\n");
	    return ((long)BAD);
	}
	elem_idx++;
     }

     return (elem_idx);
}





/* given node index find Node pointer */

MeshNode *
conv_node_idx (MeshNode *head, long node_idx)
{
     int ii;
     MeshNode *nptr;

     nptr = head;
     for (ii=1; ii<node_idx; ii++)	  nptr = nptr->Next;

     return (nptr);
}




/* given node pointer find Node index */
long
conv_node_ptr (MeshNode *head, MeshNode *node_ptr, long total_nodes)
{
     long node_idx;
     MeshNode *nptr;

     nptr = head;
     node_idx = 1;
     while (nptr != node_ptr)
     {
	if (nptr == NULL)
	{
	    printf ("\nCan't match node index\n");
	    return ((long) BAD);
	}
	nptr = nptr->Next;
	if (node_idx > total_nodes)
	{
	    printf ("\nCan't match node index...over numbering!\n");
	    return ((long)BAD);
	}
	node_idx++;
     }

     return (node_idx);
}






/* given elem index find elem pointer */

MeshElem *
conv_elem_idx (MeshElem *head, long elem_idx)
{
     long ii;
     MeshElem *eptr;

     eptr = head;
     for (ii=1; ii<elem_idx; ii++)	  eptr = eptr->Next;

     return (eptr);
}




/* given element pointer find element index */
long
conv_elem_ptr (MeshElem *head, MeshElem *elem_ptr, long total_elem)
{
     long elem_idx;
     MeshElem *eptr;

     eptr = head;
     elem_idx = 1;
     while (eptr != elem_ptr)
     {
	if (eptr == NULL)
	{
	    printf ("\nCan't match elem index\n");
	    return ((long) BAD);
	}
	eptr = eptr->Next;
	if (elem_idx > total_elem)
	{
	    printf ("\nCan't match elem index...over numbering!\n");
	    return ((long)BAD);
	}
	elem_idx++;
     }

     return (elem_idx);
}



/* given line index find line pointer */

LineData *
conv_line_idx (LineData *head, long line_idx)
{
     int ii;
     LineData *lptr;

     lptr = head;
     for (ii=1; ii<line_idx; ii++)	  lptr = lptr->Next;

     return (lptr);
}




/* given line pointer find Line index */
long
conv_line_ptr (LineData *head, LineData *line_ptr, long total_lines)
{
     long line_idx;
     LineData *lptr;

     lptr = head;
     line_idx = 1;
     while (lptr != line_ptr)
     {
	if (lptr == NULL)
	{
	    printf ("\nCan't match line index\n");
	    return ((long) BAD);
	}
	lptr = lptr->Next;
	if (line_idx > total_lines)
	{
	    printf ("\nCan't match line index...over numbering!\n");
	    return ((long)BAD);
	}
	line_idx++;
     }

     return (line_idx);
}







int
free_bnode_list (BMeshNode *head, long num_nodes)
{
    long      ii;
    BMeshNode  *nptr, *prev_ptr;

    nptr = head->Prev;
    for (ii=0; ii<num_nodes; ii++)
    {
	 /* free MeshNode structure */
	 prev_ptr = nptr->Prev;
	 nptr->Next = NULL;
	 free ((char *) nptr);
	 nptr = prev_ptr;
    }
    head = NULL;

    return (OK);
}




int
free_node_list (MeshNode *head, long num_nodes)
{
    long      ii;
    MeshNode  *nptr, *prev_ptr;

    nptr = head->Prev;
    for (ii=0; ii<num_nodes; ii++)
    {
	    /* free adjacent link */
	    if (nptr->Fst_adj)
	    {
	        free_adj (nptr->Fst_adj);
	    }
	    if (nptr->Fst_adj_elem)
	    {
	        free_adj_elem (nptr->Fst_adj_elem);
	    }
	    /* free MeshNode structure */
	    prev_ptr = nptr->Prev;
	    nptr->Next = NULL;
	    free ((char *) nptr);
	    nptr = prev_ptr;
    }
    head = NULL;

    return (OK);
}



/* free single node strucure */
int
free_MeshNode (MeshNode *nptr)
{
	 /* free adjacent link */
	 if (nptr->Fst_adj)
	 {
	      free_adj (nptr->Fst_adj);
	 }
	 if (nptr->Fst_adj_elem)
	 {
	      free_adj_elem (nptr->Fst_adj_elem);
	 }
	 /* free MeshNode structure */
	 nptr->Fst_adj = NULL;
	 nptr->Num_adj = 0;
	 nptr->Fst_adj_elem = NULL;
	 nptr->Num_adj_elem = 0;
	 nptr->Prev = NULL;
	 nptr->Next = NULL;
	 free ((char *) nptr);
         return (OK);
}




/* free Adjacent link list */
int
free_adj (AdjList *ad_ptr)
{
    if (ad_ptr->ptr)
    {
	    free_adj (ad_ptr->ptr);
    }
    if (ad_ptr)     free ((char *) ad_ptr);

    return (OK);
}





/* free Adjacent node-elem link list */
int
free_adj_elem (AdjElem *ad_ptr)
{
    /* use a non-recursive version */
    /*
    if (ad_ptr->ptr)
    {
	    free_adj_elem (ad_ptr->ptr);
    }
    if (ad_ptr)     free ((char *) ad_ptr);
    */
    AdjElem *cur_ptr, *next_ptr;
    if (ad_ptr)
    {
        next_ptr = cur_ptr = ad_ptr;
        while (next_ptr)
        {
            next_ptr = cur_ptr->ptr;
            free ((char *)cur_ptr);
            cur_ptr = next_ptr;
        } 
    }
    return (OK);
}




int
free_elem_list (MeshElem *head, long num_elem)
{
    long      ii;
    MeshElem  *eptr, *prev_ptr;

    eptr = head->Prev;
    for (ii=0; ii<num_elem; ii++)
    {
	 /* free LineData structure */
	 prev_ptr = eptr->Prev;
	 eptr->Next = NULL;
	 free ((char *) eptr);
	 eptr = prev_ptr;
    }
    head = NULL;

    return (OK);
}




int
free_belem_list (BMeshElem *head, long num_elem)
{
    long      ii;
    BMeshElem  *eptr, *prev_ptr;

    eptr = head->Prev;
    for (ii=0; ii<num_elem; ii++)
    {
	 /* free LineData structure */
	 prev_ptr = eptr->Prev;
	 eptr->Next = NULL;
	 free ((char *) eptr);
	 eptr = prev_ptr;
    }
    head = NULL;

    return (OK);
}







/* free LineData strure list */
int
free_line_list (LineData *head, int num_elem)
{
    int 	i;
    LineData	*eptr, *prev_ptr;

    eptr = head->Prev;
    for (i=0; i<num_elem; i++)
    {
	 /* free MeshElem structure */
	 prev_ptr = eptr->Prev;
	 eptr->Next = NULL;
	 free ((char *) eptr);
	 eptr = prev_ptr;
    }
    head = NULL;

    return (OK);
}







/* free poly (double pointer)  LineData strure list */
int
free_polyline_list (LineData **head,  int *seg_in_poly, int num_poly)
{
    int 	i, j;
    LineData	*eptr, *prev_ptr;

    for (i=0; i<num_poly; i++)
    {
         eptr = head [i];
	 for (j=0; j<seg_in_poly[i]; j++)
	 {
	   /* free LineData structure */
	   prev_ptr = eptr->Prev;
	   eptr->Next = NULL;
	   free ((char *) eptr);
	   eptr = prev_ptr;
         }
	 head [i] = NULL;
    }
    free (head);
    head = NULL;

    return (OK);
}









int
alloc_error (char *str)
{
    if (str)
        printf ("\nUnable to allcate Memory - run out of memory at (%s). quit !!\n", str);

     exit (BAD);
     return (BAD);
}




int
debug_output (char *fout_name)
{
    int  j, k, num_p;
    long ii, kk, e1, e2, e3;
    REAL xx, yy, zz;
    FILE *fout;
    MeshNode **nnptr;
    AdjList  *adj_ptr;
    AdjElem  *adj_elem_ptr;

    if ((fout = fopen (fout_name, "wt")) == NULL)
    {
	printf ("\nCan't open output file : %s\n", fout_name);
	return (BAD);
    }

    fprintf (fout, "\n#REM  *** Output file (%s) ***\n", fout_name);
    fprintf (fout, "#MODEL_NAME %s\n", Model_name);
    fprintf (fout, "#NUMBERING %d\n", Numbering);
    fprintf (fout, "#INPUT_TYPE %d\n", Input_type);
    fprintf (fout, "#ANALY_TYPE %d\n", Analy_type);
    fprintf (fout, "#DIMENSION %d\n", Dimen);
    fprintf (fout, "#MESH_TYPE %d\n", Mesh_type);
    fprintf (fout, "#GLOBAL_SIZE %g\n", Global_size);
    fprintf (fout, "#BOUND_BOX %g %g %g %g %g %g\n", 
		   BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax);
    fprintf (fout, "#BDY_NODES %ld\n", Bdy_nodes);
    fprintf (fout, "#BDY_ELEM %ld\n", Bdy_elem);
    fprintf (fout, "#MESH_NODES %ld\n", Msh_nodes);
    fprintf (fout, "#MESH_ELEM %ld\n", Msh_elem);

    fprintf (fout, "#BDY_NODE_COOR %ld %d\n", Bdy_nodes, Dimen);

    Bdy_node_curt_ptr = Bdy_node_head_ptr;
    for (ii=0; ii<Bdy_nodes; ii++)
    {

	xx = Bdy_node_curt_ptr->Coor[X];
	yy = Bdy_node_curt_ptr->Coor[Y];
	zz = Bdy_node_curt_ptr->Coor[Z];
	fprintf (fout, "%8ld %10.4lf %10.4lf %10.4lf\n", ii+1,
	     xx, yy, zz);
	Bdy_node_curt_ptr = Bdy_node_curt_ptr->Next;
    }


    fprintf (fout, "#BDY_ELEM_LIST %ld    0\n", Bdy_elem);

    Bdy_elem_curt_ptr = Bdy_elem_head_ptr;
    for (ii=0; ii<Bdy_elem; ii++)
    {
	e1 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[0], Bdy_nodes);
	e2 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[1], Bdy_nodes);
	e3 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[2], Bdy_nodes);
	fprintf (fout, "%8ld %10ld %10ld %10ld\n", ii+1, e1, e2, e3);
	Bdy_elem_curt_ptr = Bdy_elem_curt_ptr->Next;
    }



    fprintf (fout, "#MESH_NODE_COOR %ld %d\n", Msh_nodes, Dimen);

    Msh_node_curt_ptr = Msh_node_head_ptr;
    for (ii=0; ii<Msh_nodes; ii++)
    {

	xx = Msh_node_curt_ptr->Coor[X];
	yy = Msh_node_curt_ptr->Coor[Y];
	zz = Msh_node_curt_ptr->Coor[Z];
    kk = Msh_node_curt_ptr->Mtrl;
	fprintf (fout, "%8ld %4d %10.4lf %10.4lf %10.4lf %8ld\n", ii+1,
		 Msh_node_curt_ptr->status, xx, yy, zz, kk);
	Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }



    fprintf (fout, "#MESH_ELEM_LIST %ld    0\n", Msh_elem);

    Msh_elem_curt_ptr = Msh_elem_head_ptr;
    for (ii=0; ii<Msh_elem; ii++)
    {
	switch (Msh_elem_curt_ptr->E_type)
	{
	    case TET4:
		    num_p = 4;
		    nnptr = Msh_elem_curt_ptr->Elem.tet4.NodePtr;
		    break;
	    case PYRAM5:
		    num_p = 5;
		    nnptr = Msh_elem_curt_ptr->Elem.pyr5.NodePtr;
		    break;
	    case PRISM6:
		    num_p = 6;
		    nnptr = Msh_elem_curt_ptr->Elem.prm6.NodePtr;
		    break;
	    case HEX8:
		    num_p = 8;
		    nnptr = Msh_elem_curt_ptr->Elem.hex8.NodePtr;
		    break;
	    case TRI6:
		    num_p = 6;
		    nnptr = Msh_elem_curt_ptr->Elem.tri6.NodePtr;
		    break;
	    default:
		    num_p = -1;
		    printf ("\nError...Unknown element type!\n");
		    return (BAD);
	}

	fprintf (fout, "%8ld ", ii+1);
	fprintf (fout, "%10d ", num_p);

	/* read in elem. node list and convert to MeshNode ptr. */
	for (j=0; j<num_p; j++)
	{
	    e1 = conv_node_ptr (Msh_node_head_ptr, nnptr[j], Msh_nodes);
	    fprintf (fout, "%10ld ", e1);
	}

	fprintf (fout, "\n");

	Msh_elem_curt_ptr = Msh_elem_curt_ptr->Next;
    }



    fprintf (fout, "#SP_NODES %d \n", Sp_nodes);

    Sp_node_curt_ptr = Sp_node_head_ptr;
    for (j=0; j<Sp_nodes; j++)
    {

	xx = Sp_node_curt_ptr->Coor[X];
	yy = Sp_node_curt_ptr->Coor[Y];
	zz = Sp_node_curt_ptr->Coor[Z];
	fprintf (fout, "%8d %4d %10.4lf %10.4lf %10.4lf\n", j+1,
		 Sp_node_curt_ptr->status, xx, yy, zz);
	Sp_node_curt_ptr = Sp_node_curt_ptr->Next;
    }



    fprintf (fout, "#SP_LINES %d    \n", Sp_elem);

    Sp_line_curt_ptr = Sp_line_head_ptr;
    for (j=0; j<Sp_elem; j++)
    {
	e1 = conv_node_ptr (Sp_node_head_ptr, Sp_line_curt_ptr->StPtr, Sp_nodes);
	e2 = conv_node_ptr (Sp_node_head_ptr, Sp_line_curt_ptr->EdPtr, Sp_nodes);
	fprintf (fout, "%8d %10ld %10ld\n", j+1, e1, e2);
	Sp_line_curt_ptr = Sp_line_curt_ptr->Next;
    }


    fprintf (fout, "#SP_POLY_NODE %d \n", Sp_poly_nodes);

    Spoly_node_curt_ptr = Spoly_node_head_ptr;
    for (j=0; j<Sp_poly_nodes; j++)
    {

	xx = Spoly_node_curt_ptr->Coor[X];
	yy = Spoly_node_curt_ptr->Coor[Y];
	zz = Spoly_node_curt_ptr->Coor[Z];
	fprintf (fout, "%8d %4d %10.4lf %10.4lf %10.4lf\n", j+1,
		 Spoly_node_curt_ptr->status, xx, yy, zz);
	Spoly_node_curt_ptr = Spoly_node_curt_ptr->Next;
    }



    fprintf (fout, "#SP_POLY_LINE %d    \n", Sp_poly_elem);

    Spoly_elem_curt_ptr = Spoly_elem_head_ptr;
    for (j=0; j<Sp_poly_elem; j++)
    {
	e1 = conv_node_ptr (Spoly_node_head_ptr, Spoly_elem_curt_ptr->StPtr, 
			    Sp_poly_nodes);
	e2 = conv_node_ptr (Spoly_node_head_ptr, Spoly_elem_curt_ptr->EdPtr, 
			    Sp_poly_nodes);
	fprintf (fout, "%8d %10ld %10ld\n", j+1, e1, e2);
	Spoly_elem_curt_ptr = Spoly_elem_curt_ptr->Next;
    }

    fprintf (fout, "#END_OF_FILE\n");


    /* print out the detail of the polyline */
    if (Sp_poly_elem != BAD ||Sp_poly_elem != 0)
    {
        for (j=0; j<Sp_poly_elem; j++)
	{
	    fprintf (fout, "\n************ Polyline No. %4d  **********\n", j+1);
	    Spoly_list_curt_ptr = Spoly_list_head_ptr[j];
	    for (k=0; k<Num_seg_in_poly[j]; k++)
	    {
	      e1 = conv_node_ptr (Spoly_node_head_ptr, 
				  Spoly_list_curt_ptr->StPtr, Sp_poly_nodes);
	      e2 = conv_node_ptr (Spoly_node_head_ptr, 
				  Spoly_list_curt_ptr->EdPtr, Sp_poly_nodes);
	      fprintf (fout, " %ld", e1);
	      Spoly_list_curt_ptr = Spoly_list_curt_ptr->Next;
	    }	
	    fprintf (fout, " %ld\n\n", e2);
	    
        }
	fprintf (fout, "\n\n");
    }

    /* print out node adjacent list for mesh */
    Msh_node_curt_ptr = Msh_node_head_ptr;

    fprintf (fout, "#MESH NODE ADJACENT LIST\n");
    for (ii=0; ii<Msh_nodes; ii++)
    {
     fprintf (fout, "No.%6ld  num_adj=%6d   ", ii+1, Msh_node_curt_ptr->Num_adj);
	adj_ptr = Msh_node_curt_ptr->Fst_adj;
	while (adj_ptr)
	{
	     e1 = conv_node_ptr (Msh_node_head_ptr, adj_ptr->idx, Msh_nodes);
	     fprintf (fout, "%6ld", e1);
	     adj_ptr = 	adj_ptr->ptr;
	}
	fprintf (fout, "\n");

	Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }


    /* print out node-elem. adjacent list for mesh */
    Msh_node_curt_ptr = Msh_node_head_ptr;

    fprintf (fout, "#MESH NODE-ELEMENT LIST\n");
    for (ii=0; ii<Msh_nodes; ii++)
    {
     fprintf (fout, "No.%6ld  num_adj_elem=%6d   ", ii+1, Msh_node_curt_ptr->Num_adj_elem);
	adj_elem_ptr = Msh_node_curt_ptr->Fst_adj_elem;
	while (adj_elem_ptr)
	{
	     e1 = conv_elem_ptr (Msh_elem_head_ptr, adj_elem_ptr->idx, Msh_elem);
	     fprintf (fout, "%6ld", e1);
	     adj_elem_ptr = 	adj_elem_ptr->ptr;
	}
	fprintf (fout, "\n");

	Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }




    fclose (fout);

    return (OK);
}





/* final mesh output */
int
final_output_wpi (void)
{
    char fout_name[128];
    int  j, num_p;
    long ii, e1, e2, e3, e4, num_interval=10000;
    REAL xx, yy, zz;
    FILE *fout;
    MeshNode **nnptr;


    printf ("\nOutput file name (out.nml): ");
    scanf  ("%s", fout_name);
  
    if ((fout = fopen (fout_name, "wt")) == NULL)
    {
	printf ("\nCan't open output file : %s\n", fout_name);
	return (BAD);
    }

    fprintf (fout, "\n#REM  *** final Mesh file (%s) ***\n", fout_name);
    fprintf (fout, "#MODEL_NAME %s\n", Model_name);
    /* fprintf (fout, "#NUMBERING %d\n", Numbering); */
    /* currently set output always with numbering */
    fprintf (fout, "#NUMBERING  1\n");
    fprintf (fout, "#INPUT_TYPE %d\n", Input_type);
    fprintf (fout, "#ANALY_TYPE %d\n", Analy_type);
    fprintf (fout, "#DIMENSION %d\n", Dimen);
    fprintf (fout, "#MESH_TYPE %d\n", Mesh_type);
    fprintf (fout, "#GLOBAL_SIZE %g\n", Global_size);
    fprintf (fout, "#BOUND_BOX %g %g %g %g %g %g\n", 
		   BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax);
    fprintf (fout, "#BDY_NODES %ld\n", Bdy_nodes);
    fprintf (fout, "#BDY_ELEM %ld\n", Bdy_elem);
    fprintf (fout, "#MESH_NODES %ld\n", Msh_nodes);
    fprintf (fout, "#MESH_ELEM %ld\n", Msh_elem);

    fprintf (fout, "#BDY_NODE_COOR %ld %d\n", Bdy_nodes, Dimen);

    Bdy_node_curt_ptr = Bdy_node_head_ptr;
    for (ii=0; ii<Bdy_nodes; ii++)
    {
        Bdy_node_curt_ptr->idx = ii+1;
	    xx = Bdy_node_curt_ptr->Coor[X];
	    yy = Bdy_node_curt_ptr->Coor[Y];
	    zz = Bdy_node_curt_ptr->Coor[Z];
	    fprintf (fout, "%8ld %10.4lf %10.4lf %10.4lf\n", ii+1,
	                xx, yy, zz);
	    Bdy_node_curt_ptr = Bdy_node_curt_ptr->Next;
    }


    fprintf (fout, "#BDY_ELEM_LIST %ld  %4d \n", Bdy_elem, Bdy_lst_type);
    if (Bdy_lst_type == BD3D)
    {
        Bdy_elem_curt_ptr = Bdy_elem_head_ptr;
        for (ii=0; ii<Bdy_elem; ii++)
        {
	        e1 = Bdy_elem_curt_ptr->Elem.tri3.NodePtr[0]->idx;
	        e2 = Bdy_elem_curt_ptr->Elem.tri3.NodePtr[1]->idx;
	        e3 = Bdy_elem_curt_ptr->Elem.tri3.NodePtr[2]->idx;
	        fprintf (fout, "%8ld %10ld %10ld %10ld\n", ii+1, e1, e2, e3);
	        Bdy_elem_curt_ptr = Bdy_elem_curt_ptr->Next;
        }
    }
    else if (Bdy_lst_type == BD3DMTRL)
    {
        Bdy_elem_curt_ptr = Bdy_elem_head_ptr;
        for (ii=0; ii<Bdy_elem; ii++)
        {
	        e1 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[0], Bdy_nodes);
	        e2 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[1], Bdy_nodes);
	        e3 = conv_bnode_ptr (Bdy_node_head_ptr, Bdy_elem_curt_ptr->Elem.tri3.NodePtr[2], Bdy_nodes);
	        fprintf (fout, "%8ld %10ld %10ld %10ld %4d %4d\n", ii+1, e1, e2, e3,
		            Bdy_elem_curt_ptr->Mtrl_in, Bdy_elem_curt_ptr->Mtrl_out);

	        Bdy_elem_curt_ptr = Bdy_elem_curt_ptr->Next;
        }
    }


    fprintf (fout, "#MESH_NODE_COOR %ld %d\n", Msh_nodes, Dimen);

    Msh_node_curt_ptr = Msh_node_head_ptr;
    for (ii=0; ii<Msh_nodes; ii++)
    {
	    xx = Msh_node_curt_ptr->Coor[X];
	    yy = Msh_node_curt_ptr->Coor[Y];
	    zz = Msh_node_curt_ptr->Coor[Z];
	    fprintf (fout, "%8ld%10.4lf %10.4lf %10.4lf\n", ii+1,
		            xx, yy, zz);
	    Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }



    fprintf (fout, "#MESH_ELEM_LIST %ld   1\n", Msh_elem);
    /* default as include output material code! (give user an option?)*/
    for (ii=0, Msh_elem_curt_ptr=Msh_elem_head_ptr; ii<Msh_elem; ii++, Msh_elem_curt_ptr=Msh_elem_curt_ptr->Next)
    {
	    if (!imod (ii, num_interval))
	    {
	        printf ("%ld elem. saved!\n", ii);
	    }
	    switch (Msh_elem_curt_ptr->E_type)
	    {
	        case TET4:
		        num_p = 4;
                e1 = (long)(Msh_elem_curt_ptr->Quli.Volumn);  /* (nnptr[0]->Fst_adj->wt); */
                e2 = (long)(Msh_elem_curt_ptr->Quli.Jmin);    /* (nnptr[1]->Fst_adj->wt); */
                e3 = (long)(Msh_elem_curt_ptr->Quli.Skew);    /* (nnptr[2]->Fst_adj->wt); */
                e4 = (long)(Msh_elem_curt_ptr->Quli.Warp);    /* (nnptr[3]->Fst_adj->wt); */
                fprintf (fout, "%8ld %10d %10ld %10ld %10ld %10ld %10d\n ", 
                    ii+1, num_p, e1, e2, e3, e4, Msh_elem_curt_ptr->Mtrl_in);
                continue;
                /* 
		        nnptr = Msh_elem_curt_ptr->Elem.tet4.NodePtr;
                */
		        break;
	        case PYRAM5:
		        num_p = 5;
		        nnptr = Msh_elem_curt_ptr->Elem.pyr5.NodePtr;
		        break;
	        case PRISM6:
		        num_p = 6;
		        nnptr = Msh_elem_curt_ptr->Elem.prm6.NodePtr;
		        break;
	        case HEX8:
		        num_p = 8;
		        nnptr = Msh_elem_curt_ptr->Elem.hex8.NodePtr;
		        break;
	        case TRI6:
		        num_p = 6;
		        nnptr = Msh_elem_curt_ptr->Elem.tri6.NodePtr;
		        break;
	        default:
		        num_p = -1;
		        printf ("\nError...Unknown element type!\n");
		        return (BAD);
	    }

	    fprintf (fout, "%8ld %10d", ii+1, num_p);

	    /* read in elem. node list and convert to MeshNode ptr. */
	    for (j=0; j<num_p; j++)
	    {
	        e1 = (long)(nnptr[j]->Fst_adj->wt);
	        fprintf (fout, "%10ld ", e1);
	    }

	    fprintf (fout, "%10d\n ",  Msh_elem_curt_ptr->Mtrl_in);

    }


    if (Sp_nodes != BAD)
    {
        fprintf (fout, "#SP_NODES %d \n", Sp_nodes);

        Sp_node_curt_ptr = Sp_node_head_ptr;
        for (j=0; j<Sp_nodes; j++)
        {
	        xx = Sp_node_curt_ptr->Coor[X];
	        yy = Sp_node_curt_ptr->Coor[Y];
	        zz = Sp_node_curt_ptr->Coor[Z];
	        fprintf (fout, "%8d %10.4lf %10.4lf %10.4lf\n", j+1,
		                xx, yy, zz);
	        Sp_node_curt_ptr = Sp_node_curt_ptr->Next;
        }
  
        /* No sp_node No sp_elem but the reverse may not always true !*/
        if (Sp_elem != BAD)
        {
            fprintf (fout, "#SP_LINES %d    \n", Sp_elem);

            Sp_line_curt_ptr = Sp_line_head_ptr;
            for (j=0; j<Sp_elem; j++)
            {
	            e1 = conv_node_ptr (Sp_node_head_ptr, Sp_line_curt_ptr->StPtr, Sp_nodes);
	            e2 = conv_node_ptr (Sp_node_head_ptr, Sp_line_curt_ptr->EdPtr, Sp_nodes);
	            fprintf (fout, "%8d %10ld %10ld\n", j+1, e1, e2);
	            Sp_line_curt_ptr = Sp_line_curt_ptr->Next;
            }
        }
    }


    if (Sp_poly_nodes != BAD)
    {
        fprintf (fout, "#SP_POLY_NODE %d \n", Sp_poly_nodes);

        Spoly_node_curt_ptr = Spoly_node_head_ptr;
        for (j=0; j<Sp_poly_nodes; j++)
        {
	        xx = Spoly_node_curt_ptr->Coor[X];
	        yy = Spoly_node_curt_ptr->Coor[Y];
	        zz = Spoly_node_curt_ptr->Coor[Z];
	        fprintf (fout, "%8d %10.4lf %10.4lf %10.4lf\n", j+1, xx, yy, zz);
	        Spoly_node_curt_ptr = Spoly_node_curt_ptr->Next;
        }


        if (Sp_poly_elem != BAD)
        {
            fprintf (fout, "#SP_POLY_LINE %d    \n", Sp_poly_elem);

            Spoly_elem_curt_ptr = Spoly_elem_head_ptr;
            for (j=0; j<Sp_poly_elem; j++)
            {
	            e1 = conv_node_ptr (Spoly_node_head_ptr, Spoly_elem_curt_ptr->StPtr, 
			                        Sp_poly_nodes);
	            e2 = conv_node_ptr (Spoly_node_head_ptr, Spoly_elem_curt_ptr->EdPtr, 
			                        Sp_poly_nodes);
	            fprintf (fout, "%8d %10ld %10ld\n", j+1, e1, e2);
	            Spoly_elem_curt_ptr = Spoly_elem_curt_ptr->Next;
            }
        }
    }
    fprintf (fout, "#END_OF_FILE\n");

    fclose (fout);

    return (OK);
}
