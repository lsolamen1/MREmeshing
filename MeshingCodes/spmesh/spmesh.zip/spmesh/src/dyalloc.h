/*fil**********************************************************************
	NAME:           dyalloc.h
	PROJECT:        ALL
	MODULE:         Dynamic memory allocation
	AUTHOR:         James Q. Zhang
	DATE:           Feb. 25, 1997.
	DESCRIPTION:    Header file
***************************************************************************/
#define TYPE_SIZE   size_t
#define ALLOC_TYPE  malloc
#define FREE_TYPE   free

float  *vector(TYPE_SIZE nl, TYPE_SIZE nh);                         /* float 1D array */
float  **matrix(TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);    /* float 2D array */
//float  **convert_matrix(float **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);       /* float 2D convert matrix array */
float  **submatrix(float **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch, TYPE_SIZE newrl, TYPE_SIZE newcl);
double *dvector(TYPE_SIZE nl, TYPE_SIZE nh);
double **dmatrix(TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
//double **convert_dmatrix(double **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
double **subdmatrix(double **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch, TYPE_SIZE newrl, TYPE_SIZE newcl);
int    *ivector(TYPE_SIZE nl, TYPE_SIZE nh);
int    **imatrix(TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
//int    **convert_imatrix(int **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
int    **subimatrix(int **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch, TYPE_SIZE newrl, TYPE_SIZE newcl);
void free_vector(float *v, TYPE_SIZE nl, TYPE_SIZE nh);
void free_dvector(double *v, TYPE_SIZE nl, TYPE_SIZE nh);
void free_ivector(int *v, TYPE_SIZE nl, TYPE_SIZE nh);
void free_matrix(float **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
void free_dmatrix(double **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
void free_imatrix(int **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
void free_submatrix(float **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
void free_subdmatrix(double **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
void free_subimatrix(int **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch);
//void free_convert_matrix();
//void free_convert_dmatrix();
//void free_convert_imatrix();
void nrerror (char error_text[]);
