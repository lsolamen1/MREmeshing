 
/*
  ************************************************************************
  *  spmesh.h :  Type definition for Specialty line type mesh            *
  *                                                                      *
  *  Qingyang Zhang                July. 28, 1996						 *
  ************************************************************************
*/

#define MEMORY_SAVE  
/*
 1. avoid to allocate a big junk of mem. 
    when doing mesh quality summarization. 
    and skip the warping!!
*/
#define NORMALIZE_DATA
/* to prevent extrem data */

/*#define RANDOM_VACTOR
   Using random line casting for line crossing */


/* needs:     basdefs.h modefs.h */

#define TRI3      3
#define TRI6     26
#define QUAD4    24
#define QUAD8    28     /* pay attention to 2D !! */
#define QUAD9    29
#define TET4      4
#define TET10    10
#define HEX8      8
#define HEX20    20
#define PYRAM5    5
#define PRISM6    6
#define PRISM15  15

/* for tetrahedra element refinement and kniting */
#define TET4_4    4
#define TET4_5    5
#define TET4_6    6
#define TET4_7    7
#define TET4_8    8
#define TET4_9    9
#define TET4_10   10

#define INTNODE   -8    /* internal node */
#define OUTNODE   -7    /* outter bound node, special check when doing smoothing */
#define NSURFNODE -6
#define INREFINE  -5    /* the node within the refining zone */
#define UNDONE    -4    /* unfitted BDY node (check spoper.c for new define) */
#define DONE      -3    /* Specialty node or fitted BDY node */
#define FIXED     -2    /* BDY node */
/* Ziji 1/7/99 */
#define ONSPBDY   -1    /* node on bdy and sp line, which can only be moved to bdy 
                           along sp line */
/* end of Ziji */
#define FREE       0
/* #define CONSTRAIN  if greater than zero the value is the index of speciaty line */

#define NODANGLE   0
#define HALFDANG   1
#define FULLDANG   2

#define OPENED_POLY  0
#define CLOSED_POLY  1

#define NOD1_MODE    1
#define NOD2_MODE    2


#define LOWTOL    1.E-4
#define HIGTOL    1.E-10

#define EXTRA     5.e20
#define XHUGE     1.e10
#define XLARGE    1.e7

/* Global size factor */
#define TET4_FACTOR   1.2
#define HEX8_FACTOR   1.42

#define NOFIT     -1
#define NATURE     0
#define FORCED     1

#define CANNOTFIT -1
#define UNFIT      0
#define FITTED     1
#define FITTED2   -2

#define OUTBOUND  0
#define INBOUND   1
#define ONPLANE   2
#define ONEDGE    3
#define NOTCROSS  4
#define PARALLEL  8888
#define COPLANE   9999

#define VOLRAT    1
#define VOLUME    2
#define ASPRAT    3
#define JACOB     4
#define SKWANG    5
#define WARPAGE   6

#define MIN_QUALITY   0.1 

#define MOVE_NO_BDY     0
#define MOVE_ELEM_BDY   1
#define MOVE_ADJ_BDY    2
#define MOVE_ALL_BDY    3

#define BD2D      2
#define BD3D      3
#define BD2DMTRL  12
#define BD3DMTRL  13

#define WHOLE      0
#define PART       1

#define FINAL_OUT  0
#define NUMER_OUT  1

/* building block type */
#define REGULAR_HEX   0
#define DELTA_HEX     1

#define MAX_REF_LEVEL 20

/* maximum materials and boundary interfaces */
#define MAX_FACE      20
#define MAX_MTRL_NUM  100


/* for influence zone conforming / smoothing (for elastic conforming )*/
#define BDY_LEVEL   9999
#define MAX_ADJACENT_NODES   400


/* the system can handle max. 100 distinct materials dependent on
   following definitions. Since it uses combination left/right 
   mtrls. to represent the node on boundary. so the node mtrl code 
   can greater than 100 (up to 99*10000 + 99*100) so it will need 
   a long integer type for material code
*/
/* for short integer max. mtrl 9 
#define NODE_MTRL     int
#define MTRL_IN_CODE  1000   
*/

/* for long integer max. mtrl 99 */ 
#define NODE_MTRL     long
#define MTRL_IN_CODE  10000 

#define MTRL_OUT_CODE 100
#define BDY_NODE_CODE 99

#define INITIAL_EXBDY  0
#define FINAL_EXBDY    1

#define DF_Q_HISTO   50
#define DF_V_HISTO   50
#define DF_A_HISTO   50
#define DF_J_HISTO   50
#define DF_S_HISTO   50
#define DF_W_HISTO   50

#define DF_Q_PIE     5
#define DF_V_PIE     5
#define DF_A_PIE     5
#define DF_J_PIE     5
#define DF_S_PIE     5
#define DF_W_PIE     5

#define ALL_MODE       0
#define CENTRAL_MODE   1
#define ONE_LEVEL_MODE 2


typedef struct t_meshnode MeshNode;
typedef struct t_bdynode  BMeshNode;
typedef struct t_adjlist  AdjList;
typedef struct t_adjelem  AdjElem;




/* line structure */
typedef struct t_linedata {
    MeshNode    *StPtr;        /* start node ptr */
    MeshNode    *EdPtr;        /* end node ptr */
    struct t_linedata   *Prev;
    struct t_linedata   *Next;
} LineData;




/* mesh distortion mesurement structure */
typedef struct t_quality {
    REAL    Qfactor;        /* mesh quality factor */
    REAL    Volumn;         /* the volume of the elem. */
    REAL    Asp;            /* aspect ratio  lmax / lmin */
    REAL    Jmin;           /* min Jacobian value */
    REAL    Skew;           /* screw angle */
    REAL    Warp;           /* Warping -- h/a  h: max. or ave. warping a: principle mesh size*/
    /* REAL    Lsize;           local principle size */
} Quality;





/* tri3 BDY elem structure */

typedef struct t_tri3 {
    BMeshNode *NodePtr[3];
    /* some mesh quality properties ? */
} Tri3;



/* tri3 elem structure */

typedef struct nt_tri3 {
    MeshNode *NodePtr[3];
    /* some mesh quality properties ? */
} NTri3;




/* tri6 elem structure */

typedef struct t_tri6 {
    MeshNode *NodePtr[6];
    /* some mesh quality properties ? */
} Tri6;




/* quad4 elem structure */

typedef struct t_quad4 {
    MeshNode *NodePtr[4];
    /* Quality  *Quli;   mesh distortion Dist = null -- no measurement */
} Quad4;





/* quad8 elem structure */

typedef struct t_quad8 {
    MeshNode *NodePtr[8];
    /* some mesh quality properties ? */
} Quad8;





/* quad9 elem structure */

typedef struct t_quad9 {
    MeshNode *NodePtr[9];
    /* some mesh quality properties ? */
} Quad9;






/* tet4 elem structure */

typedef struct t_tet4 {
    MeshNode *NodePtr[4];
    /* some mesh quality properties ? */
} Tet4;




/* tet10 elem structure */

typedef struct t_tet10 {
    MeshNode *NodePtr[10];
    /* some mesh quality properties ? */
} Tet10;





/* hex8 elem structure */

typedef struct t_hex8 {
    MeshNode *NodePtr[8];
    /* Quality  *Quli;   mesh distortion Dist = null -- no measurement */
} Hex8;




/* hex20 elem structure */

typedef struct t_hex20 {
    MeshNode *NodePtr[20];
} Hex20;




/* pyramid elem structure */

typedef struct t_pyramid5 {
    MeshNode *NodePtr[5];
    /* some mesh quality properties ? */
} Pyramid5;






/* prism elem structure */

typedef struct t_prism6 {
    MeshNode *NodePtr[6];
    /* some mesh quality properties ? */
} Prism6;





/* prism elem structure */

typedef struct t_prism15 {
    MeshNode *NodePtr[15];
} Prism15;



typedef union t_elem_union {
    NTri3       tri3;      /* linear triangle */
    Tet4        tet4;      /* linear tetrahedra */
    Tet10       tet10;     /* quad tetrahedra  */
    Pyramid5    pyr5;      /* linear pyramid */
    Prism6      prm6;      /* linear prism */
    Hex8        hex8;      /* linear brick */
    Tri6        tri6;      /* quadratic triangle */
} ElemData;


typedef struct t_elemtype   {
    int      E_type;        /* element type */
    int      attr;          /* attribute -- for hex8 it's the tpye --> txt */
                            /* for tet, it's a flag for refinement level ( > 0 ) */
                            /* which will be full refinement to 8 tets */
                            /* during the conforming use for unfit/..    */
    int      status;        /* count process times (rather than for element stradle > 0 (the num. of material)) */
    ElemData Elem;          /* union for primitive data */
    int      Mtrl_in;       /* material code inside the elem */
    int      Mtrl_out;      /* material code outside the elem */
    struct   t_elemtype *Prev;   /* element link list pointer to prev. */
    struct   t_elemtype *Next;   /* pointer to next. */
    Quality  Quli;          /* mesh quality */
} MeshElem;



typedef union t_belem_union {
    Tri3        tri3;      /* linear triangle */
} BElemData;


typedef struct t_belemtype  {
    BElemData Elem;             /* union for boundary patch data */
    int      ref_levlel;        /* the refinement level needed based on global size */
    int      Mtrl_in;           /* material code inside the elem */
    int      Mtrl_out;          /* material code outside the elem */
    REAL     xmin, ymin, zmin, xmax, ymax, zmax;/* BDY patch bounding box */
    struct   t_belemtype *Prev; /* element link list pointer to prev. */
    struct   t_belemtype *Next; /*    pointer to next. */
} BMeshElem;



struct t_adjlist {
    MeshNode    *idx;           /* node index */
    REAL        wt;             /* weight */
    AdjList     *ptr;
} ;


struct t_adjelem {
    MeshElem    *idx;       /* element index */
    REAL        wt;         /* weight */
    AdjElem     *ptr;
} ;


/* mesh node structure */
/* for the node on BDY the material code is defined as:
   node Mtrl = bdy Mtrl_inside * 1000 + bdy Mtrl_outside
   for single material region bdy node has a value of Mtrl = 1000.
*/ 

struct t_meshnode {
    Vec         Coor;           /* node coordinates */
    AdjList     *Fst_adj;       /* point to first node of adj. list */
    int         Num_adj;        /* number of adjacent nodes */
    AdjElem     *Fst_adj_elem;  /* point to first elem of adj. list */
    int         Num_adj_elem;   /* number of adjacent elements */
    long        Mtrl;           /* material code (region) the node sit into, use long type for bdy node rep.*/
    int         status;         /* node status: fixed,constrained,free,done, undone*/
    int         in_zone;        /* OK -- in refinement zone, else out of . */
    BMeshElem   *bdy_ptr;       /* a ptr to bdy tri_patch the node sit on if it is*/
                                /* modified 4/26/95 check initialization */
    /* REAL        curv_idx; */       /* curve index for numerical surface node */
    MeshNode    *Prev;          /* fixed-BDY node etc, constr-index to sp-line */
    MeshNode    *Next;          /* done-SP node etc. */
} ;



/* Boundary patch node structure */
struct t_bdynode {
    Vec         Coor;       /* node coordinates */
    long        idx;        /* for quick file output */
    BMeshNode   *Prev;      /* fixed-BDY node etc, constr-index to sp-line */
    BMeshNode   *Next;      /* done-SP node etc. */
};




typedef struct t_double_link {
    MeshNode    *nptr;
    REAL        len;
    REAL        weight;
    struct t_double_link  *Dad;
    struct t_double_link  *Prev;
    struct t_double_link  *Next;
} DOUBLE_LINK;



typedef struct t_node_info
{
    int  set;         /* set (Mtrl) = 1, 2 */
    int  status;
    NODE_MTRL  Mtrl;
    REAL ori_coor[3];
    REAL ori_quali;
    REAL mov_coor[3];
    REAL mov_quali;
    REAL mov_dist;
    REAL mov_dir[3];           
    BMeshElem *bdy_ptr;
} NodeInfo;



typedef struct t_spatch {
  int      patch_type;    /* TET4, HEX8 */
  MeshNode *NodePtr[3];
  unsigned int edge_access_num[4];
  long     elem_idx;
  int      mtrl_left;
  int      mtrl_right;
  struct t_spatch *Prev;
  struct t_spatch *Next;
} Spatch;



typedef struct t_nspnod_stru {
  long       id;
  long       node_idx;
  MeshNode   *node_ptr;
  struct t_nspnod_stru *Next;
} NSpnod;

