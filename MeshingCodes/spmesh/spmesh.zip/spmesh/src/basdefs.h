 
/*
  ************************************************************************
  *  basdefs.h :	   Basic type definition			                 *
  *									                                     *
  *  Qingyang Zhang				   Nov. 30, 1994	                     *
  ************************************************************************
*/
/* define it for unix! */
#define _MSWIN_ 

#ifdef _MSWIN_
#define PI	    3.14159265358979323844
#endif

#define DEG2RAD	    0.0174532925199433
#define RAD2DEG	    57.2957795130823
#define Ln10	    2.30258509299405

#define X	    0
#define Y	    1
#define Z	    2

/* Ziji 7/24/00, raise a new flag that can stop checking
   a hex when it was checked and done. */
//#define DONEREF -2
#define BAD	   -1
#define NONE    0
#define OK	    1

/*
	generic macros
*/

#define ABS(a)      (((a)<0)?(-(a)):(a))
#define FLOOR(a)	((a)>0?(int)(a):-(int)(a))
#define CEILING(a)	((a)==(int)(a)?(a):(a)>0?1+(int)(a):-(1+(int)(-a))
#define ROUND(a)	((a)>0?(int)((a)+0.5):-(int)(0.5-a))

#define MIN(a,b)	(((a)<(b))?(a):(b))
#define MAX(a,b)        (((a)>(b))?(a):(b))

#ifdef _NOLINUX_
#define MakeVector(x, y, z, v)		(v)[0]=(x);\
					(v)[1]=(y);\
					(v)[2]=(z);

#define VecNegate(a)	(a)[0]=(-(a)[0]);\
			(a)[1]=(-(a)[1]);\
			(a)[2]=(-(a)[2]);

#define VecDot(a,b)	((a)[0]*(b)[0]+(a)[1]*(b)[1]+(a)[2]*(b)[2])

#define VecLen(a)	(sqrt(VecDot(a,a)))

#define VecCopy(a,b)	(b)[0]=(a)[0];(b)[1]=(a)[1];(b)[2]=(a)[2];

#define VecAdd(a,b,c)	(c)[0]=(a)[0]+(b)[0];\
			(c)[1]=(a)[1]+(b)[1];\
			(c)[2]=(a)[2]+(b)[2]

#define VecSub(a,b,c)	(c)[0]=(a)[0]-(b)[0];\
			(c)[1]=(a)[1]-(b)[1];\
			(c)[2]=(a)[2]-(b)[2]

#define VecComb(A,a,B,b,c)	(c)[0]=(A)*(a)[0]+(B)*(b)[0];\
				(c)[1]=(A)*(a)[1]+(B)*(b)[1];\
				(c)[2]=(A)*(a)[2]+(B)*(b)[2]

#define VecScale(A,a,b)		(b)[0]=(A)*(a)[0];\
				(b)[1]=(A)*(a)[1];\
				(b)[2]=(A)*(a)[2]

#define VecAddS(A,a,b,c)	(c)[0]=(A)*(a)[0]+(b)[0];\
				(c)[1]=(A)*(a)[1]+(b)[1];\
				(c)[2]=(A)*(a)[2]+(b)[2]

#define VecMul(a,b,c)		(c)[0]=(a)[0]*(b)[0];\
				(c)[1]=(a)[1]*(b)[1];\
				(c)[2]=(a)[2]*(b)[2]

#define VecCross(a,b,c)		(c)[0]=(a)[1]*(b)[2]-(a)[2]*(b)[1];\
				(c)[1]=(a)[2]*(b)[0]-(a)[0]*(b)[2];\
				(c)[2]=(a)[0]*(b)[1]-(a)[1]*(b)[0]

#define VecZero(v)		(v)[0]=0.0;(v)[1]=0.0;v[2]=0.0

#define VecPrint(msg,v)		fprintf(stderr, "%s: %g %g %g\n", msg,\
					(v)[0],(v)[1],(v)[2])
#endif
                              
typedef char Name[80];

/* real type */
/* typedef float REAL */

/* double type */
typedef double	REAL;
typedef REAL	Vec[3];
typedef Vec		Point;
typedef Vec		Color;
typedef REAL	Matrix[4][4];
