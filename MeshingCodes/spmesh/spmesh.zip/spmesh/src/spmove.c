/*  
  ************************************************************************
  *  spmove.c : Mesh smoothing with simplifed spring model 	             *
  *									                                     *
  *  Qingyang Zhang				   Sept 26, 1995	                     *
  ************************************************************************
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

#define  OUTBOUND     0
#define  MULTIBOUND   1

#define  NOSPHERE    -1
#define  SPHERE       0
#define  HEMISPHERE   1

#define  NUM_LEVELS   3

/*
** External Functions
*/
extern NODE_MTRL nod_inout (REAL *d, REAL *e, BMeshElem *bdy_l_head,
		              long n_bdy_elem, BMeshElem **on_bdy_eptr, int db_flag);
extern NODE_MTRL nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, 
                      long n_bdy_elem, BMeshElem **on_bdy_eptr);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern int v_norm(REAL *vec, int n);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL v_dot(REAL *vec1, REAL *vec2, int n);
extern int line_tri_cross (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, 
                           REAL *r);
extern int is_dl_empty (DOUBLE_LINK *pole);
extern int create_dl_list (DOUBLE_LINK *pole);
extern int add_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, REAL wt, 
                        REAL len, DOUBLE_LINK *dad);
extern int append_dl_list (DOUBLE_LINK *pole, DOUBLE_LINK *new_dlptr);
extern int search_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, 
                           DOUBLE_LINK **dlptr);
extern DOUBLE_LINK *pop_dl_head (DOUBLE_LINK *pole);
extern int free_dl_list (DOUBLE_LINK *pole);
extern int alloc_error (char *str);


/*
** Local Functions
*/
int sp_move (BMeshNode *bdy_n_head, long bdy_num_node,
	        BMeshElem *bdy_l_head, long bdy_num_elem,
	        MeshNode *msh_n_head, long msh_num_node,
	        MeshElem *msh_l_head, long msh_num_elem,
	        MeshNode *base_nptr, REAL *new_loc, int num_level);
REAL half_band (BMeshElem *bdy_l_head, long bdy_num_elem, REAL *vec0,
		    REAL *mov_dir, REAL distance, int *hemi_sphere_flag);
REAL nearest_cross_bdy (REAL *d, REAL *e, BMeshElem *bdy_l_head, 
                long n_bdy_elem, BMeshElem **on_bdy_eptr, int check_type);
int  back_ori_node (MeshNode *msh_n_head, long msh_num_node);
int  adj_node_loc  (MeshNode *msh_n_head, long msh_num_node, REAL mov_distance);


/* 
    given a mesh model with a given node moving in direction mov_dir
    do smoothing in a simplified spring model
    num_level --- define an inflence zone. if =0 just node moving.
*/
int
sp_move (BMeshNode *bdy_n_head, long bdy_num_node,
	     BMeshElem *bdy_l_head, long bdy_num_elem,
	     MeshNode  *msh_n_head, long msh_num_node,
	     MeshElem  *msh_l_head, long msh_num_elem,
	     MeshNode  *base_nptr,  REAL *new_loc, int num_level)
{
    int       k, level, hemi_sphere_flag, re_flag=OK;
    long      ii;
    REAL      n_lvl, p;
    REAL      radius, len, vec0[3], vec1[3], mov_dir[3], distance, cos_ang, tmp_vec[3];
    MeshNode  *nptr, *cur_nptr;
    AdjList   *adj_ptr;
    DOUBLE_LINK  sp_nd_pole, pq_nd_pole, *cur_dlptr, *tmp_dlptr;


    if (num_level < 1) 
    {
        for (k=0; k<3; k++)
            base_nptr->Coor[k] = new_loc[k];
        
        return (OK);
    }

    /* define moving direction and distance */
    distance = v_rang (base_nptr->Coor, new_loc, 3);
    if (distance < HIGTOL)    return (0);

    v_make (base_nptr->Coor, new_loc, 3, mov_dir);
    v_norm (mov_dir, 3);

    /* move base node first So it will sit on a boundary patch or sp. line */
    for (k=0; k<3; k++)
    {
	    base_nptr->Coor[k] = base_nptr->Coor[k] + mov_dir[k] * distance;
    }
    /* base_nptr->status = FIXED; */


    /* find mesh nodes around base-node in given levels */
    level = num_level;
    
    /* initial node list */
    create_dl_list (&sp_nd_pole);

    /* set up to start seaching */
    cur_nptr = base_nptr;
    n_lvl = 0.;

    /* initial piority queue */
    create_dl_list (&pq_nd_pole);

    /* here borrow Double Link structure, and use weight field
	   as the level value on the node and len field define the
	   spring node status.
    */

    /* add in the source node to the (FIFO) queue */
    add_dl_list (&pq_nd_pole, cur_nptr, n_lvl, (REAL)cur_nptr->status, NULL);

    while (is_dl_empty (&pq_nd_pole) != OK)
    {
	   /* pop out a node from the queue */
	   cur_dlptr = pop_dl_head (&pq_nd_pole);

	   /* put node u into current set */
	   append_dl_list (&sp_nd_pole, cur_dlptr);

	   /* current node */
	   cur_nptr = cur_dlptr->nptr;
	   n_lvl = cur_dlptr->weight;
	   /* skip the node with level higher than expected */
	   if ((int)n_lvl >= level)
	   {
	      continue;
	   }
	   /* deal with each adjacent node of current node */
	   adj_ptr = cur_nptr->Fst_adj;
	   while (adj_ptr)
	   {
		    if (search_dl_list (&pq_nd_pole, adj_ptr->idx, &tmp_dlptr) != OK)
		    {   /* add the node into the queue */
			    add_dl_list (&pq_nd_pole, adj_ptr->idx, n_lvl+1,
					         (REAL) adj_ptr->idx->status, NULL);
		    }
	        adj_ptr = adj_ptr->ptr;
	   }
    }

    /* free piority queue (FIFO) */
    free_dl_list (&pq_nd_pole);

    for (k=0; k<3; k++)    vec0[k] = base_nptr->Coor[k];
    /* determin half bandwidth R */
    radius = half_band (bdy_l_head, bdy_num_elem, vec0, mov_dir, distance,
			            &hemi_sphere_flag);
    if (radius <= 0.0)
    {
	    re_flag = BAD;
        goto EXIT;
    }

    /* move nodes in region */
    nptr = msh_n_head;
    for (ii=0; ii<msh_num_node; ii++)
    {
	    if (nptr == base_nptr)  goto RE;
	    if (nptr->status == FIXED || nptr->status == DONE)   goto RE;
	    /* check node in region */
	    for (k=0; k<3; k++)     vec1[k] = nptr->Coor[k];
	    if ((len=v_rang(vec0, vec1, 3)) > radius)    goto RE;

	    /* in region.  check valid node for moving with given level ? */
        if (search_dl_list (&sp_nd_pole, nptr, &tmp_dlptr) != OK)  goto RE;

	    if (nptr->status > 0)
	    {
	        /* CONSTRAINED node the num. is the index of spline */
	        goto RE;   /* should be moved along the constraint */
	    }

	    /* find cosine ang between position vector and mov_dir */
	    v_make (vec0, vec1, 3, tmp_vec);
	    v_norm (tmp_vec, 3);
	    cos_ang = v_dot(mov_dir, tmp_vec, 3);

	    /*  move the node based on reference distance */
        p = (radius -  len)*(radius -  len) / (radius*radius);   /* move in sqare ratio */

	    if (((radius - len)/radius) < p) 
	            p = (radius - len)/radius;

	    len = p * distance;

	    for (k=0; k<3; k++)
	    {  
	        nptr->Coor[k] += fabs (cos_ang) * mov_dir[k] * len;  
	        /* nptr->Coor[k] += mov_dir[k] * len;  */
	    }
RE:     nptr = nptr->Next;
    }

EXIT:
    /* free mesh node list with given levels */
    free_dl_list (&sp_nd_pole);
    return (re_flag);
}


/* determin half bandwidth R.
   hemi_sphere_flag  =  0 ( sphere )  
		             =  1 ( hemi-spher in mov_direction )
                     = -1 ( hemi-spher in negtive of mov_direction )
*/
REAL
half_band (BMeshElem *bdy_l_head, long bdy_num_elem, REAL *vec0,
	        REAL *mov_dir, REAL distance, int *hemi_sphere_flag)
{
    int   k, db_flag=BAD;
    NODE_MTRL pos_in=0, neg_in=0;
    REAL  d[3], e[3], mid[3], pos_cross_len, neg_cross_len, radius, len;
    BMeshElem *bdy_patch_ptr;


    /* normalize direction vector */
    v_norm (mov_dir, 3);

    for (k=0; k<3; k++)    d[k] = vec0[k];

    len = BDxmax - BDxmin;
    if (len < (BDymax - BDymin))  len = BDymax - BDymin;
    if (len < (BDzmax - BDzmin))  len = BDzmax - BDzmin;

    /* shoot a ray in given direction */
    for (k=0; k<3; k++)
    {
		e[k] = d[k] + mov_dir[k] * 4 * len;
    }
    pos_cross_len = nearest_cross_bdy (d, e, bdy_l_head, bdy_num_elem,
				       &bdy_patch_ptr, MULTIBOUND);

    if (bdy_patch_ptr)
    {
		/* find crossing */
		/* check middle node status */
		for (k=0; k<3; k++)
			mid[k] = 0.25 * (d[k] + mov_dir[k] * pos_cross_len);

		if (Bdy_lst_type == BD3D)
		{   /* single material region */
			pos_in = nod_inout (mid, e, bdy_l_head, bdy_num_elem,
								&bdy_patch_ptr, db_flag);
		}
		else if (Bdy_lst_type == BD3DMTRL)
		{
			pos_in = nod_in_region (mid, e, bdy_l_head, bdy_num_elem,
								&bdy_patch_ptr);
		}
		else
		{
			printf ("\nUnkwon Type in function 'half_band'\n");
		}

    }

    /* shoot another ray in opposite direction */
    for (k=0; k<3; k++)
    {
		e[k] = d[k] - mov_dir[k] * 4 * len;
    }
    neg_cross_len = nearest_cross_bdy (d, e, bdy_l_head, bdy_num_elem,
									&bdy_patch_ptr, MULTIBOUND);
    if (bdy_patch_ptr)
    {
		/* find crossing */
		/* check middle node status */
		for (k=0; k<3; k++)
			mid[k] = 0.25 * (d[k] - mov_dir[k] * neg_cross_len);

		if (Bdy_lst_type == BD3D)
		{   /* single material region */
			neg_in = nod_inout (mid, e, bdy_l_head, bdy_num_elem,
								&bdy_patch_ptr, db_flag);
		}
		else if (Bdy_lst_type == BD3DMTRL)
		{
			neg_in = nod_in_region (mid, e, bdy_l_head, bdy_num_elem,
								&bdy_patch_ptr);
		}
		else
		{
			printf ("\nUnkwon Type in function 'half_band'\n");
		}
    }

    if (pos_in && neg_in)
    {
       /* sphere region */
       *hemi_sphere_flag = SPHERE;
       if (pos_cross_len > neg_cross_len)     radius = 0.5 * neg_cross_len;
       else                                   radius = 0.5 * pos_cross_len;
    }
    else if (pos_in==0 && neg_in==0)
    {
       /* singular point */
       *hemi_sphere_flag = NOSPHERE;
       /*
       printf ("\nWarning...Can't define effective zone for mesh node moving\n"); 
       */
       radius = (REAL)BAD;
    }
    else
    {
       /* hemi-sphere zone */
       *hemi_sphere_flag = HEMISPHERE;
       if (neg_in !=0)
       {
			radius = 0.5 * neg_cross_len;
			(*hemi_sphere_flag) *= -1;
       }
       else
			radius = 0.5 * pos_cross_len;
    }

    return (radius);
}


/* given a ray, find a nearest distance to cross boundary,
   check_type = OUTBOUND    find crossing with external boundary
   check_type = MULTIBOUND  find crossing with any material boundary
*/
REAL
nearest_cross_bdy (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
		            BMeshElem **on_bdy_eptr, int check_type)
{
    int  cross_type;
    long jj;
    REAL ray_xmin, ray_xmax, ray_ymin, ray_ymax, ray_zmin, ray_zmax;
    REAL a[3], b[3], c[3], r[3];
    REAL min_dist, dist;
    BMeshNode *n_1, *n_2, *n_3;
    BMeshElem *bdy_eptr;

    *on_bdy_eptr = NULL;
    min_dist = 1.e10;

    /* find the bounding box (limit) of the vector d --> e */
    ray_xmin = (d[X] < e[X]) ? d[X] : e[X];
    ray_xmax = (d[X] > e[X]) ? d[X] : e[X];
    ray_ymin = (d[Y] < e[Y]) ? d[Y] : e[Y];
    ray_ymax = (d[Y] > e[Y]) ? d[Y] : e[Y];
    ray_zmin = (d[Z] < e[Z]) ? d[Z] : e[Z];
    ray_zmax = (d[Z] > e[Z]) ? d[Z] : e[Z];

    bdy_eptr = bdy_l_head;
    for (jj=0; jj<n_bdy_elem; jj++)
    {
		if (check_type == OUTBOUND && Bdy_lst_type == BD3DMTRL)
		{
			/* for multi-material cross with external boundary */
			if (bdy_eptr->Mtrl_in != 0 && bdy_eptr->Mtrl_out != 0) goto CONT;
		}
		/* check bounding */
		if (ray_xmin > bdy_eptr->xmax || ray_xmax < bdy_eptr->xmin)   goto CONT;
		if (ray_ymin > bdy_eptr->ymax || ray_ymax < bdy_eptr->ymin)   goto CONT;
		if (ray_zmin > bdy_eptr->zmax || ray_zmax < bdy_eptr->zmin)   goto CONT;

		/* search for each boundary element */
		n_1 = bdy_eptr->Elem.tri3.NodePtr[0];
		n_2 = bdy_eptr->Elem.tri3.NodePtr[1];
		n_3 = bdy_eptr->Elem.tri3.NodePtr[2];

		/* define vector a, b, c */
		a[X] = n_1->Coor[X];
		a[Y] = n_1->Coor[Y];
		a[Z] = n_1->Coor[Z];

		b[X] = n_2->Coor[X] - a[X];
		b[Y] = n_2->Coor[Y] - a[Y];
		b[Z] = n_2->Coor[Z] - a[Z];

		c[X] = n_3->Coor[X] - a[X];
		c[Y] = n_3->Coor[Y] - a[Y];
		c[Z] = n_3->Coor[Z] - a[Z];

		/* cross checking */
		cross_type = line_tri_cross (d, e, a, b, c, r);

		if (cross_type == INBOUND || cross_type == ONEDGE)
		{
			dist = v_rang(d, r, 3);
			if (dist < min_dist && fabs (dist) > HIGTOL)
			{
				min_dist = dist;
				*on_bdy_eptr = bdy_eptr;
 			}
		}
CONT:	bdy_eptr = bdy_eptr->Next;
    }
    return (min_dist);
}



/* save original mesh node location in Global node list */
int
back_ori_node (MeshNode *msh_n_head, long msh_num_node)
{
    int  k;
    long ii;
    MeshNode *nptr;

    /* initialize */
    for (k=0; k<3; k++)   Ori_msh_nd_coor[k] = NULL;

    /* allocate space for node coord. */
    /*
    if (msh_num_node > 65534)
    {
	    printf ("\nMesh node number exceed bound!!!\n);
	    exit (-1);
    }
    */
    for (k=0; k<3; k++)
    {
	    Ori_msh_nd_coor[k] = (REAL *) malloc ((size_t) msh_num_node * sizeof (REAL));
	    if (Ori_msh_nd_coor[k] == NULL)   alloc_error ("spmove-1");
    }

    /* copy node coord. */
    nptr = msh_n_head;
    for (ii=0; ii<msh_num_node; ii++)
    {
	    for (k=0; k<3; k++)
	        Ori_msh_nd_coor[k][ii] = nptr->Coor[k];

	    nptr = nptr->Next;
    }

    return (OK);
}




/* adjust final node moving distance within given mov_distance */
int
adj_node_loc  (MeshNode *msh_n_head, long msh_num_node, REAL mov_distance)
{
    int  k;
    long ii;
    REAL dir[3];
    MeshNode *nptr;

    /* adjust node coord. */
    nptr = msh_n_head;
    for (ii=0; ii<msh_num_node; ii++)
    {
	    for (k=0; k<3; k++)   dir[k] = Ori_msh_nd_coor[k][ii];
        if (nptr->status == FIXED)     goto RE;
	    if (v_rang (nptr->Coor, dir, 3) > mov_distance)
	    {
	        for (k=0; k<3; k++)
		        dir[k] = nptr->Coor[k] - Ori_msh_nd_coor[k][ii];

	        v_norm (dir, 3);
	        for (k=0; k<3; k++)
		        nptr->Coor[k] = Ori_msh_nd_coor[k][ii] + dir[k] * mov_distance;
	    }
RE:	    nptr = nptr->Next;
    }

    /* free global node list */
    for (k=0; k<3; k++)
    {
	    if (Ori_msh_nd_coor[k])
	        free ((char *)Ori_msh_nd_coor[k]);
    }
    return (0);
}
