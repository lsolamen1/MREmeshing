/* 
  ************************************************************************
  *  Num_surf.c : Extract Numerical Material Boundary Surfaces           *   
  *                                                                      *
  *  Qingyang Zhang                           Jan. 1, 1997              *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>



#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

/*
** External Functions
*/
extern int set_elem_mtrl  (BMeshNode *bdy_n_head, long bdy_num_node,
            BMeshElem *bdy_l_head, long bdy_num_elem,
            MeshNode *msh_n_head, long msh_num_node,
            MeshElem *msh_l_head, long msh_num_elem);
extern int set_elem_mtrl_b  (BMeshNode *bdy_n_head, long bdy_num_node,
            BMeshElem *bdy_l_head, long bdy_num_elem,
            MeshNode *msh_n_head, long msh_num_node,
            MeshElem *msh_l_head, long msh_num_elem);

extern int nd_order(MeshNode *nptr, MeshNode **nnptr, int num_p);
extern int common_plane(MeshNode **plane_1, int num_p, MeshNode **plane_2, int sub_num_p);
extern int  free_belem_list (BMeshElem *head, long num_elem);
extern int alloc_error (char *str);
extern REAL v_angl3(REAL *vec1, REAL *vec2, int ideg, int n);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);

extern void ini_mat_surf (void);
extern int output_numerical_surf (int surf_num);
extern int search_mbdy_node (MeshNode *msh_n_head, long msh_num_node, int m_code);
extern int set_mnode_status (MeshNode *nptr, int m_code);
extern int num_patch_in_list (int intface_num, MeshNode **nod_ptr, int num_patch_node);
extern int collect_numerical_bdy (int interface_num, MeshNode *msh_n_head, 
         long msh_num_node, MeshElem *msh_l_head, long msh_num_elem,
         int m_code);
extern int free_patch (Spatch *adj_patch, long num_patch);
extern int add_patch_list (int interface_num, MeshNode **patch_node, int num_p,
                int mtrl_left, int mtrl_right, long elem_idx);
extern int surf_check (int ibface); 
extern unsigned int shave_tepee_elem (MeshElem *msh_l_head, long msh_num_elem, int mt_code);
extern REAL curv_index (MeshNode *nptr, int mtrl);

 
/*
** Local Functions
*/
int ext_num_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type);


#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))


extern BMeshElem   *CBFace, *Cur_cbptr;      /* current working BDY interface */
extern long        Num_patch_in_CBFace;      /* num. of tri-patch in working BDY face*/
 
  /* faces connected to given node  note that idx start form 1 */
  static int hex8_plnd[8][3][4] = {{{1, 2, 3, 4}, {1, 4, 8, 5}, {1, 5, 6, 2},},
                   {{2, 3, 4, 1}, {2, 6, 7, 3}, {2, 1, 5, 6},},
                   {{3, 4, 2, 1}, {3, 2, 6, 7}, {3, 7, 8, 4},},
                   {{4, 1, 2, 3}, {4, 8, 5, 1}, {4, 3, 7, 8},},
                   {{5, 1, 4, 8}, {5, 8, 7, 6}, {5, 6, 1, 2},},
                   {{6, 5, 7, 8}, {6, 7, 3, 2}, {6, 2, 1, 5},},
                   {{7, 6, 5, 8}, {7, 3, 2, 6}, {7, 8, 4, 3},},
                   {{8, 5, 1, 4}, {8, 7, 6, 5}, {8, 4, 3, 7}}};

  static int tet4_plnd[4][3][3] = {{{1, 3, 2}, {1, 2, 4}, {1, 4, 3},},
                   {{2, 1, 3}, {2, 4, 1}, {2, 3, 4},},
                   {{3, 2, 1}, {3, 4, 2}, {3, 1, 4},},
                   {{4, 1, 2}, {4, 2, 3}, {4, 3, 1}}};
                   
  /* faces in elem. face-node index note that idx start from 0 (!!)*/                
  static int tet4_face_idx[4][3] = {{0, 1, 3},
                                    {1, 2, 3},
                                    {2, 0, 3},
                                    {0, 2, 1}};

  static int hex8_face_idx[6][4] = {{0, 1, 2, 3},
                                    {2, 1, 5, 6},
                                    {5, 4, 7, 6},
                                    {0, 3, 7, 4},
                                    {2, 6, 7, 3},
                                    {0, 4, 5, 1}};

                   

/* extract numerical surfaces for given boundary interfaces */
int
ext_num_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type)
{
  int       ibface, k, m, mt_code, m_count, cur_midx, num_exbdy;  
  int       mtrl_region_code[MAX_MTRL_NUM], sequence; 
  unsigned int num_tepee;
  long      ii, kk, total_patch; // patch_idx;
  //double    xx, yy, zz;
  MeshNode  *nptr;
  //FILE      *fout;
  //Spatch    *pptr;
  
  /* set mtrl code for elements */
  /* it has been done on material classification
  set_elem_mtrl (bdy_n_head, bdy_num_node,
                 bdy_l_head, bdy_num_elem,
                 msh_n_head, msh_num_node,
                 msh_l_head, msh_num_elem); 
  
  set_elem_mtrl_b (bdy_n_head, bdy_num_node,
                    bdy_l_head, bdy_num_elem,
                    msh_n_head, msh_num_node,
                    msh_l_head, msh_num_elem);
  */
                 
  /* initialize --- it may already be done in iniglb */
  ini_mat_surf ();

  /* find total number of materials */ 
  Num_NFace = 0;
  Num_interface = 0;
  m_count = cur_midx = 0; 
  cur_midx = 0;
  for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
  
  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
  {   
      if (exbdy_type == FINAL_EXBDY)    nptr->status = FREE; /* initial */
      kk = nptr->Mtrl;
      if (kk < 0 || kk > MAX_MTRL_NUM-1)  continue;
      if (Mtrl_code[kk] == 0)   Mtrl_code[kk] = 1;
  } 
  
  for (k=1; k<MAX_MTRL_NUM; k++)
  {
      if (Mtrl_code[k])  Num_interface++;
  }
        
  printf ("\nFound %d Boundary Interfaces. \n", Num_interface);
  
  /* print out material region codes */
  printf ("\nMaterial Region Code: ");
  for (k=1; k<MAX_MTRL_NUM; k++)
  {
        if (Mtrl_code[k])   printf ("%3d ", k);
  }
  printf ("\n");
  do 
  {
      printf ("\nHow many boundary surfaces need be extracted [1-%d] :", 
                Num_interface);  
      scanf ("%d", &num_exbdy);
      /*if (num_exbdy < 0)   return (BAD);*/
   } while (num_exbdy <1);
   
   if (num_exbdy > Num_interface)
   {
       ibface = 0;
       sequence = 0;
       if (Num_interface > 1)
       {
        printf ("Material index fitting sequence\n   (lowest to highest = 0 / highest to lowest = 1) :");
        scanf ("%d", &sequence);
        if (sequence != 1)   sequence = 0;
       }

       if (sequence == 1)
       {
            for (k=MAX_MTRL_NUM-1; k>0; k--)
                if (Mtrl_code[k])  mtrl_region_code[ibface++] = k;  
       }
       else
       {
            for (k=1; k<MAX_MTRL_NUM; k++)
                if (Mtrl_code[k])  mtrl_region_code[ibface++] = k;  
       }
   } 
   else
   {
     ibface = 0; 
     for (m=0; m<num_exbdy; m++)
     {   
       do
       {  
           printf ("\nPlease input No. %3d material region code : ", ibface+1);
           scanf ("%d", &k);
           if (k > MAX_MTRL_NUM-1)  k = -1;
           if (k > 0)
               if (Mtrl_code[k]==0) k = -1;

       } while (k<1);
       mtrl_region_code[ibface++] = k;
     }
   }
 
   num_exbdy = ibface;

   /*  set node index for export numerical surface
       since a non-isolated node at least has one adj. node
       to accelerated the output, borrow the wt field of 
       first adj node structure to save a node index and note
       the idx needs long type but wt is a double type. use
       forced type convertion and this should not lose anything
    */
    for (ii=0, nptr=Msh_node_head_ptr; ii<Msh_nodes; ii++, nptr=nptr->Next)
    {
        if (nptr->Fst_adj == NULL)
            printf ("\nNull Adj. node list at node %ld\n", ii+1);
        else
            nptr->Fst_adj->wt = (double)(ii+1);
    }

    if (Numerical_surf == 1)
    {
        /* number of numerical surfaces to be fitted */
        fprintf (Main_file, "%d\n", num_exbdy);
    }
    
    /* Extract approximate Numerical Surface for BDY interfaces */
    for (ibface=0; ibface<num_exbdy; ibface++)
    {  
        /* material code for current BDY */
        mt_code = mtrl_region_code[ibface];     
        num_tepee = 0;

        /* search nodes on mtrl. bdy interfaces and tag them as NSURFNODE */
        if (search_mbdy_node (msh_n_head, msh_num_node, mt_code) == BAD)
        {   
            fprintf (Diag_file, "\nCan't extract material region %d!\n", mt_code);
            goto CON2;
        }  
     
        /* shave lone tepee element --- all four nodes are one boundary  
            set these element material code as its adjacent material 
        */
       
        /* num_tepee = shave_tepee_elem (msh_l_head, msh_num_elem, mt_code); */
    
        /* find curvture index for numerical boundary node */
        /*
        for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr = nptr->Next)
        {   
            if (nptr->status == NSURFNODE) 
                 nptr->curv_idx = curv_index (nptr, mt_code);
        } 
        */


        /* extract numerical boundary from tag nodes */
        if (collect_numerical_bdy (ibface, msh_n_head, msh_num_node, msh_l_head,
                                    msh_num_elem, mt_code) == BAD) 
        {  
            fprintf (Diag_file, "\nExtract No. %d material region failed!\n");
            goto CON2; 
        } 
                                     
        Num_NFace++;
        printf ("\nMtrl %d of BDY %d --> %ld of Patch in list!\n",
                mt_code, ibface, Num_patch_in_NFace[ibface]);

        /* debug checking on numerical surface */
        surf_check (ibface); 
        /* save numerical surface file */
        output_numerical_surf (ibface);
CON2:
        /* reset node status */
        
        for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr = nptr->Next)
        {
            if (nptr->status == NSURFNODE)    nptr->status = FREE;
        }
  }

  printf ("\n%d Numerical Surfaces being extracted.\n", Num_NFace);
  /* save as nml format disk file */
  /* total patches */
  total_patch = 0;
  for (ibface=0; ibface<Num_NFace; ibface++)
            total_patch += Num_patch_in_NFace[ibface];

  if (total_patch == 0)
      return (OK);
  

  /* export material boundary for examine */
  /*
  fout = fopen ("numsurf.nml", "w+t"); 
  if (fout == NULL)    return (0);

    fprintf (fout, "\n#REM  *** Numerical surface (BDY) patch file ****\n");
    fprintf (fout, "#REM (matsurf.nml) -- use mesh node list and extracted mesh elem patch\n");
    fprintf (fout, "#MODEL_NAME %s\n", Model_name);
    fprintf (fout, "#NUMBERING  1\n");
    fprintf (fout, "#INPUT_TYPE %d\n", Input_type);
    fprintf (fout, "#ANALY_TYPE %d\n", Analy_type);
    fprintf (fout, "#DIMENSION %d\n", Dimen);
    fprintf (fout, "#MESH_TYPE %d\n", Mesh_type);
    fprintf (fout, "#GLOBAL_SIZE %g\n", Global_size);
    fprintf (fout, "#BOUND_BOX %g %g %g %g %g %g\n", 
		            BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax);
    fprintf (fout, "#BDY_NODES %ld\n", Msh_nodes);
    fprintf (fout, "#BDY_ELEM %ld\n", total_patch);

    fprintf (fout, "\n#REM here use mesh node, so it may have extra nodes !!\n");
    fprintf (fout, "#BDY_NODE_COOR	 %ld    3\n", Msh_nodes); 

    //&&&  note that here borrowed the mesh node list as bdy list 
    Msh_node_curt_ptr = Msh_node_head_ptr;
    for (ii=0; ii<Msh_nodes; ii++)
    {
	    xx = Msh_node_curt_ptr->Coor[X];
	    yy = Msh_node_curt_ptr->Coor[Y];
	    zz = Msh_node_curt_ptr->Coor[Z];
	    fprintf (fout, "%10ld%10.4lf %10.4lf %10.4lf\n", ii+1,
		            xx, yy, zz);
	    Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }

  
  fprintf (fout, "#REM Tri-patch BDY elements\n");
  fprintf (fout, "#REM TITLE PARAMETERS: NUM_ELEM, TYPE(2D: 2 /3D: 3 /MTRL INCLUDE:12 or 13)\n");
  fprintf (fout, "#BDY_ELEM_LIST	%10ld  13\n", total_patch);

  patch_idx = 0;
  for (k=0; k<Num_NFace; k++)
  {
     if (Num_patch_in_NFace[k] > 0) 
     {
         for (ii=0, pptr=NFace_head[k]; ii<Num_patch_in_NFace[k]; ii++, pptr=pptr->Next)
         {  
             //&&& only for trianglar patch 
	         fprintf (fout, "%10ld %10ld %10ld %10ld %4d %4d\n", ++patch_idx,
                    (long)(pptr->NodePtr[0]->Fst_adj->wt),
                    (long)(pptr->NodePtr[1]->Fst_adj->wt),
                    (long)(pptr->NodePtr[2]->Fst_adj->wt), 
                    pptr->mtrl_left, pptr->mtrl_right);
         }
     }
  }

  fprintf (fout, "\n#END_OF_FILE\n");

  //&&& double check 
  if (total_patch != patch_idx)
      printf ("\nUnconsistent patch : %ld (%ld)\n", total_patch, patch_idx);
  
  fclose (fout);
  */

  return (OK);
}

