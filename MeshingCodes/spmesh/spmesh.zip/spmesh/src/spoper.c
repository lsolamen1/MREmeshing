
/*
  ************************************************************************
  *  spoper.c :	Operations for specialty node / line			         *
  *									                                     *
  *  Qingyang Zhang				   Jan. 3, 1995		                     *
  ************************************************************************
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

/* Ziji 1/5/98 in order to output specialty stuff to a new diag file */
extern FILE *fpzw;
/* end of Ziji */


/*
** External Functions
*/
extern long conv_node_ptr (MeshNode *head, MeshNode *node_ptr, long total_nodes);
extern LineData *conv_line_idx (LineData *head, long line_idx);
extern long conv_line_ptr (LineData *head, LineData *line_ptr, long total_lines);
extern int is_dl_empty (DOUBLE_LINK *pole);
extern int create_dl_list (DOUBLE_LINK *pole);
extern int add_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, REAL wt,
			REAL len, DOUBLE_LINK *dad);
extern int append_dl_list (DOUBLE_LINK *pole, DOUBLE_LINK *new_dlptr);
extern int search_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, DOUBLE_LINK **dlptr);
extern int cp_dl_list (DOUBLE_LINK *source_pole, DOUBLE_LINK *distin_pole);
extern DOUBLE_LINK *extract_min (DOUBLE_LINK *pole);
extern int back_dl_step (DOUBLE_LINK *pole);
extern int free_dl_list (DOUBLE_LINK *pole);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL loc_size (MeshNode *in_node);
extern int sp_move (BMeshNode *bdy_n_head, long bdy_num_node,
	     BMeshElem *bdy_l_head, long bdy_num_elem,
	     MeshNode *msh_n_head, long msh_num_node,
	     MeshElem *msh_l_head, long msh_num_elem,
	     MeshNode *base_nptr, REAL *new_loc, int num_level);

/* Ziji 1/20/99 */
extern int set_node_status_b (MeshNode *nptr);
extern int line_tri_cross (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);

/*
** Local Functions
*/
int set_fixed_bdy_node (BMeshNode *bdy_n_head, long bdy_num_node,
			MeshNode *msh_n_head, long msh_num_node);
int lap_soomth (MeshNode *msh_n_head, long msh_num_node, int soomth_class);
int constrain_soomth (MeshNode *node_ptr);
int fit_sp_node (MeshNode *msh_n_head, long n_msh_node,
		 MeshNode *sp_n_head,  int n_sp_node, REAL g_size);
int fit_sp_line (MeshNode *msh_n_head, long n_msh_node,
		 MeshElem *msh_l_head, long n_msh_elem,
		 MeshNode *sp_n_head,  int n_sp_node,
		 LineData *sp_l_head,  int n_sp_line, REAL g_size);
int fit_spoly_line (MeshNode *msh_n_head, long n_msh_node,
	     MeshElem *msh_l_head, long n_msh_elem,
	     MeshNode *spoly_n_head,  int n_spoly_node,
	     LineData *spoly_l_head,  int n_spoly_elem,
	     LineData **spoly_list_head, int *num_seg_poly, REAL g_size);
int find_endpnt (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
		 MeshNode **msh_n1_ptr, MeshNode **msh_n2_ptr,
		 MeshNode *msh_n_head, long num_msh_node);
int do_a_sp_line (MeshNode *msh_n_head, long n_msh_node,
		  MeshElem *msh_l_head, long n_msh_elem,
		  MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr,
		  REAL g_size, int dangle, int sp_line_idx);
/* Ziji 1/13/99 */
int do_a_sp_line_b (MeshNode *msh_n_head, long n_msh_node,
		  MeshElem *msh_l_head, long n_msh_elem,
		  MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr,
		  REAL g_size, int dangle, int sp_line_idx, DOUBLE_LINK *onsp);

int search_path (MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr, long n_msh_node,
		 REAL g_size, REAL *node_1, REAL *node_2, REAL length,
		 DOUBLE_LINK *opt_pole);
int node_process (REAL *node_1, REAL *node_2, REAL *node_3, REAL *node_4,
		  REAL length, REAL g_size, REAL *dist, REAL *len);
REAL cosine_ang (REAL *node_1, REAL *node_2, REAL *node_3, REAL *node_4);
REAL pt_to_line (REAL *node_1, REAL *node_2, REAL *node_3);
int Modify_pq (DOUBLE_LINK *pq_pole, MeshNode *cur_nptr,
	       REAL wt, REAL len, DOUBLE_LINK *dad_dlptr);
MeshNode * fit_fst_node_path (DOUBLE_LINK *path_pole, REAL *node_1, 
			      REAL *node_2, REAL length, int sp_line_idx);
MeshNode * fit_whole_path (DOUBLE_LINK *path_pole, REAL *node_1, REAL *node_2,
		              REAL length, int sp_line_idx);
int find_endpnt_spline (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
		    LineData *sp_list_head, MeshNode **msh_n1_ptr,
		    MeshNode **msh_n2_ptr, MeshNode *msh_n_head,
		    long num_msh_node, REAL g_sizes);
MeshNode * fix_a_node (MeshNode *sp_node, MeshNode * msh_n_head, 
		       long n_msh_node, REAL g_size);
MeshNode * match_sp_msh (MeshNode *sp_n1_ptr, MeshNode *msh_n_head, 
			 long n_msh_node);
int nod_in_line (MeshNode *msh_nptr, MeshNode *sp_n1_ptr,
		 MeshNode *sp_n2_ptr);
MeshNode * find_nd_online (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
		MeshNode *msh_n_head, long num_msh_node,
		REAL g_size, int nod_mode);
MeshNode * fit_start_node (MeshNode *nptr, MeshNode *sp_n1_ptr,
		MeshNode *sp_n2_ptr, REAL g_size);
int duplicate_node (MeshNode *nptr1, MeshNode *nptr2);

/* Ziji 1/20/99 */
int bdy_sp_move(MeshNode *node, MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
                BMeshNode *bdy_node_head, long bdy_num_node,
	            BMeshElem *bdy_elm_head, long bdy_num_elem);

/*
** Global Variables
*/



/*
** Local Variables
*/




/* set up fixed bdy in mesh node and node status */
int
set_fixed_bdy_node (BMeshNode *bdy_n_head, long bdy_num_node,
		    MeshNode *msh_n_head, long msh_num_node)
{
    long     ii, jj;
    double   tolerence, a, b, c;
    BMeshNode *bdy_cur_ptr;
    MeshNode  *msh_cur_ptr;

    if (bdy_n_head == NULL || msh_n_head == NULL)
/* Ziji 1/5/99	printf ("\nError... no bdy or msh data (NULL head ptr. in set_fixed bdy. node).\n"); */
	{
	printf ("\nError... no bdy or msh data (NULL head ptr. in set_fixed bdy. node).\n");
	fprintf(fpzw, "\n\n=====set_fixed_bdy-node:");
	fprintf (fpzw, "\nError... no bdy or msh data (NULL head ptr. in set_fixed bdy. node).\n");
	}

    msh_cur_ptr = msh_n_head;

    for (ii=0; ii<msh_num_node; ii++)
    {
	    bdy_cur_ptr = bdy_n_head;
	    for (jj=0; jj<bdy_num_node; jj++)
	    {
	        a =  (msh_cur_ptr->Coor[X] - bdy_cur_ptr->Coor[X]);
	        b =  (msh_cur_ptr->Coor[Y] - bdy_cur_ptr->Coor[Y]);
	        c =  (msh_cur_ptr->Coor[Z] - bdy_cur_ptr->Coor[Z]);
	        tolerence = sqrt (a*a + b*b + c*c);
	        if (tolerence < LOWTOL)
	        {
	            msh_cur_ptr->status = FIXED;
	            msh_cur_ptr->Coor[X] = bdy_cur_ptr->Coor[X];
	            msh_cur_ptr->Coor[Y] = bdy_cur_ptr->Coor[Y];
	            msh_cur_ptr->Coor[Z] = bdy_cur_ptr->Coor[Z];
	            break;
	        }
	        bdy_cur_ptr = bdy_cur_ptr->Next;
	    }
					    /* constrained node */
	    if (msh_cur_ptr->status != FIXED && msh_cur_ptr->status > 0
					 && msh_cur_ptr->status != DONE)
	    msh_cur_ptr->status = FREE;

	    msh_cur_ptr = msh_cur_ptr->Next;
    }

    return (OK);
}


/* Laplacian mesh node soomthing */
/* soomth_class define the number of times to repeat the Laplacian smooth */

int
lap_soomth (MeshNode *msh_n_head, long msh_num_node, int soomth_class)
{
    int      j, num_node;
    long     ii;
    double   xx, yy, zz;
    MeshNode *cur_ptr;
    AdjList  *adj_ptr;

    if (msh_n_head == NULL)
	printf ("\nError... no  msh data (NULL head ptr. in lap_smooth.\n");

    for (j=0; j<soomth_class; j++)
    {
	    cur_ptr = msh_n_head;

	    for (ii=0; ii<msh_num_node; ii++)
	    {
	        if (cur_ptr->Num_adj == 0)   continue;
	        if (cur_ptr->status >0)     /* constrained node */
	        {
		        constrain_soomth (cur_ptr);
		        continue;
	        }

	        switch (cur_ptr->status)
	        {
		        case FREE:
	            case UNDONE:
			        num_node = 0;
			        xx = yy = zz = 0.0;
			        adj_ptr = cur_ptr->Fst_adj;
			        while (adj_ptr)
			        {
			            xx += adj_ptr->idx->Coor[X];
			            yy += adj_ptr->idx->Coor[Y];
			            zz += adj_ptr->idx->Coor[Z];
			            num_node++;
			            adj_ptr = adj_ptr->ptr;
			        }
			        if (num_node == cur_ptr->Num_adj)
			        {  /* Do Laplacian Soomthing */
			            cur_ptr->Coor[X] = xx / (double)num_node;
			            cur_ptr->Coor[Y] = yy / (double)num_node;
			            cur_ptr->Coor[Z] = zz / (double)num_node;
			        }
			        else
			        {
			            printf ("\nWarning... Adjacent node incompatible!\n");
			        }

			        break;
		        case FIXED:
			        break;
		        case DONE:
			        break;
		        default:
		            printf ("\nWarning... Unknwon node status.\n");
	        }
	        cur_ptr = cur_ptr->Next;
	    }
    }
    return (OK);
}



/* smoothing with contrain of specity line */

int
constrain_soomth (MeshNode *node_ptr)
{
    int    num_node;
    double xc, yc, zc, xx, yy, zz, cos_sita, dist, tmp, length, u;
    double xx1, yy1, zz1, xx2, yy2, zz2, xx3, yy3, zz3;
    LineData *sp_lptr;
    AdjList  *adj_ptr;

    if (Sp_node_head_ptr == NULL || Sp_line_head_ptr == NULL)
    {
       printf ("\nWarning... Null constrains\n");
       return (BAD);
    }

    if (node_ptr)
    {
	    /* node coor. before smoothing */
	    xc = node_ptr->Coor[X];
	    yc = node_ptr->Coor[Y];
	    zc = node_ptr->Coor[Z];
    }
    else
    {
       printf ("\nError... Null node ptr. in constr. smooth!\n");
       return (BAD);
    }
    /* find the constrained specialty line / nodes for smoothing */
    sp_lptr = conv_line_idx (Sp_line_head_ptr, node_ptr->status);

    /* node 1 */
    xx1 = sp_lptr->StPtr->Coor[X];
    yy1 = sp_lptr->StPtr->Coor[Y];
    zz1 = sp_lptr->StPtr->Coor[Z];

    /* node 2 */
    xx2 = sp_lptr->EdPtr->Coor[X];
    yy2 = sp_lptr->EdPtr->Coor[Y];
    zz2 = sp_lptr->EdPtr->Coor[Z];

    /* do smoothing without constraint get node 3 */
    num_node = 0;
    xx3 = yy3 = zz3 = 0.0;
    adj_ptr = node_ptr->Fst_adj;
    while (adj_ptr)
    {
	    xx3 += adj_ptr->idx->Coor[X];
	    yy3 += adj_ptr->idx->Coor[Y];
	    zz3 += adj_ptr->idx->Coor[Z];
	    num_node++;
	    adj_ptr = adj_ptr->ptr;
    }

    if (num_node == node_ptr->Num_adj)
    {  /* Do Laplacian Soomthing */
	    xx3 = xx3 / (double)num_node;
	    yy3 = yy3 / (double)num_node;
	    zz3 = zz3 / (double)num_node;
    }
    else
    {
	    printf ("\nWarning...(con) Adjacent node incompatible!\n");
    }

    /* find cos angle and distance from node 3 to line node 1 and node 2 */
    length = sqrt ((xx2-xx1)*(xx2-xx1) + (yy2-yy1)*(yy2-yy1)
		    + (zz2-zz1)*(zz2-zz1));

    /* find distance from node 3 to line */
    /* borrow temp varibles */
    xx = (yy3-yy1)*(zz2-zz1) - (zz3-zz1)*(yy2-yy1);
    yy = (zz3-zz1)*(xx2-xx1) - (xx3-xx1)*(zz2-zz1);
    zz = (xx3-xx1)*(yy2-yy1) - (yy3-yy1)*(xx2-xx1);

    dist = sqrt (xx*xx + yy*yy + zz*zz) / length;

    /* find cosine sita */
    /* borrow temp varibles */
    xx = (xx3-xx1)*(xx2-xx1) + (yy3-yy1)*(yy2-yy1) + (zz3-zz1)*(zz2-zz1);
    yy = (xx3-xx1)*(xx3-xx1) + (yy3-yy1)*(yy3-yy1) + (zz3-zz1)*(zz3-zz1);
    zz = (xx2-xx1)*(xx2-xx1) + (yy2-yy1)*(yy2-yy1) + (zz2-zz1)*(zz2-zz1);
    tmp = sqrt (yy);     /* length for node 3 to node 1 */

    cos_sita = xx / sqrt (yy*zz);

    /* check for the soomth criteria */
    if (cos_sita <= 0.0)
    {
	    printf ("\nError...the smoothing will break the constraint!\n");
	    return (BAD);
    }

    if (dist > G_factor*loc_size (node_ptr))
    {        
	    printf ("\nWarning...the smoonthing will result in bad mesh quality!\n");      
    }

    /* find projected length of node 3 to node 1 */
    tmp = tmp * cos_sita;

    /* coefficent of projected node */
    u = tmp / length;

    if (u>=1.0)
    {
	    printf ("\nError...the smoothing will break the constraint!\n");
	    return (BAD);
    }

    /* find the node coor. smoothed with constraint */
    xx = xx1 + u*(xx2-xx1);
    yy = yy1 + u*(yy2-yy1);
    zz = zz1 + u*(zz2-zz1);

    /* find the distance moved along the constraint by smoothing */
    tmp = sqrt ((xx-xc)*(xx-xc) + (yy-yc)*(yy-yc) + (zz-zc)*(zz-zc));
    /* put more checking here. e.g. if (tmp > 0.3*length) then... */

    node_ptr->Coor[X] = xx;
    node_ptr->Coor[Y] = yy;
    node_ptr->Coor[Z] = zz;

    return (OK);
}



/* fitting specialty nodes */
int
fit_sp_node (MeshNode *msh_n_head, long n_msh_node,
	     MeshNode *sp_n_head,  int n_sp_node, REAL g_size)
{
    int i;
    long jj, num_nspnod=0, node_idx;
    REAL xsp, ysp, zsp, xmsh, ymsh, zmsh;
    REAL min_dist, dist, mov_pnt[3];
    MeshNode *msh_ptr, *sp_ptr, *act_ptr;
    NSpnod *spnod_head, *cur_spnod, *tmp_spnod;


    if (sp_n_head == NULL || msh_n_head == NULL)
    {
/* Ziji 1/5/99		    printf ("\nError...Null specialty node or mesh node list!\n"); */
	    printf ("\nError...Null specialty node or mesh node list!\n");
		fprintf(fpzw, "\n\n=====fit_sp_node:");
	    fprintf(fpzw, "\nError...Null specialty node or mesh node list!\n");
		return (BAD);
    }

    num_nspnod = 0;
    cur_spnod = spnod_head = NULL;
    sp_ptr = sp_n_head;

    for (i=0; i<n_sp_node; i++)
    {
	    if (sp_ptr->status == DONE)
	    {
	        sp_ptr = sp_ptr->Next;
	        continue;
	    }
	    xsp = sp_ptr->Coor[X];
	    ysp = sp_ptr->Coor[Y];
	    zsp = sp_ptr->Coor[Z];

	    msh_ptr = msh_n_head; 
	    /* initialization */
	    min_dist = 1.e10;
	    act_ptr = NULL;
	    for (jj=0; jj<n_msh_node; jj++)
	    {
	        if (msh_ptr->status != FIXED)
	        {
		        xmsh = msh_ptr->Coor[X];
		        ymsh = msh_ptr->Coor[Y];
		        zmsh = msh_ptr->Coor[Z];

		        dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			            +(zmsh-zsp)*(zmsh-zsp));

		        if (dist < min_dist)
		        {
		            min_dist = dist;
		            /* set active pointer */
		            act_ptr  = msh_ptr;
                    node_idx = jj+1;
		        }
	        }
	        else
	        {
	            /* for fixed point if near enough .... Done */
		        xmsh = msh_ptr->Coor[X];
		        ymsh = msh_ptr->Coor[Y];
		        zmsh = msh_ptr->Coor[Z];

		        dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			            +(zmsh-zsp)*(zmsh-zsp));
		        if (dist < HIGTOL)
		        {
		            sp_ptr->status = DONE;
		            goto CON;
		        }
	        }
	        msh_ptr = msh_ptr->Next;
	    }

	    if (act_ptr == NULL)
	    {
/* Ziji 1/5/99	        printf ("\nWarning...No mesh node can fit SP node (no.%d)\n", i+1);*/
	        printf ("\nWarning...No mesh node can fit SP node (no.%d)\n", i+1);
			fprintf(fpzw, "\n\n=====fit_sp_node:");
	        fprintf (fpzw, "\nWarning...No mesh node can fit SP node (no.%d)\n", i+1);
	    }
	    else if (min_dist > loc_size (act_ptr))
	    {
/* Ziji 1/5/99	        printf ("\nWarning...fitting distance greater than Local size. Skip it dist=%lf (local size = %lf !\n", min_dist, loc_size (act_ptr));
			printf( "\n SP node: %d,  mesh node: %d\n", i+1, node_idx); */
	        printf ("\nWarning...fitting distance greater than Local size. Skip it dist=%lf (local size = %lf !\n", min_dist, loc_size (act_ptr));
			printf( "\n SP node: %d,  mesh node: %d\n", i+1, node_idx);
			fprintf(fpzw, "\n\n=====fit_sp_node:");
	        fprintf(fpzw, "\nWarning...fitting distance greater than Local size. Skip it dist=%lf (local size = %lf !\n", min_dist, loc_size (act_ptr));
			fprintf(fpzw, "\n SP node: %d,  mesh node: %d\n", i+1, node_idx);
	    }
	    else
	    {
/* Ziji 1/6/99 */
			fprintf(fpzw, "\n mesh node %d, with coords: %lf, %lf, %lf\n", node_idx, act_ptr->Coor[X],
				           act_ptr->Coor[Y], act_ptr->Coor[Z]);
			fprintf(fpzw, " has been moved to sp node %d.\n", i+1);

	        /*
	        act_ptr->Coor[X] = xsp;
	        act_ptr->Coor[Y] = ysp;
	        act_ptr->Coor[Z] = zsp;
	        */
	        mov_pnt[X] = xsp;    mov_pnt[Y] = ysp;    mov_pnt[Z] = zsp;

	        sp_move (Bdy_node_head_ptr, Bdy_nodes, Bdy_elem_head_ptr, Bdy_elem, 
                     Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem,
		             act_ptr, mov_pnt, 0);

	        act_ptr->status  = FIXED;  /* a specialty node should be fixed */
	        /* lap_soomth (msh_n_head, n_msh_node, 3); */
	        sp_ptr->status = DONE;
            
            if (Numerical_surf == 1)
            {
                /* save specialty node info. */
                if (spnod_head==NULL)
                {
                    /* the first one */
                    spnod_head = (NSpnod *) malloc (sizeof (NSpnod));
                    if (spnod_head == NULL) 
                    {
                        printf ("\nCan't allocate memory for sp. head node!\n");
                        exit (-1);
                    }
                    spnod_head->Next = NULL;
                    cur_spnod = spnod_head;       
                }
                else
                {
                    cur_spnod->Next = (NSpnod *) malloc (sizeof (NSpnod));
                    if (cur_spnod->Next == NULL) 
                    {
                        printf ("\nCan't allocate memory for sp. head node!\n");
                        exit (-1);
                    }
                    cur_spnod = cur_spnod->Next;
                    cur_spnod->Next = NULL;
                }
                num_nspnod++;
                cur_spnod->id = i+1;            /* sp. node index */
                cur_spnod->node_idx = node_idx; /* mesh node index */
                cur_spnod->node_ptr = act_ptr;  /* mesh node pointer */
            }
	    }

CON:	sp_ptr = sp_ptr->Next;
    }

    if (Numerical_surf == 1)
    {
        /* write to specialty node fitting file */
        Spnod_file = fopen (Spnod_fname, "wt");
        if (Spnod_file == NULL)
        {
            printf ("Can't open numerical specialty node file. quit!");
            exit (-1);
        }
        fprintf (Spnod_file, "%ld\n", num_nspnod);
        for (jj=0, cur_spnod=spnod_head; jj<num_nspnod; jj++, cur_spnod=cur_spnod->Next)
        {
            fprintf (Spnod_file, "%8ld %8ld\n", cur_spnod->id, cur_spnod->node_idx);
        }
        fclose (Spnod_file);

        /* free memory space */
        cur_spnod = spnod_head;
        while (cur_spnod)
        {
            tmp_spnod = cur_spnod->Next;
            free ((char *) cur_spnod);
            cur_spnod = tmp_spnod;
        }
    }

    return (OK);
}




/* modify on specialty line algorithm on May 18, 1995
   previously, for searching an optimum path to fit the specialty line,
   it bypass the nodes with status of FIXED (those specialty node or 
   important corner nodes which control the shape of the geometry) and
   DONE (those nodes have been conformed to BDY which would be allowed 
   to move on the BDY or on a specialty line which would be allowed to
   move along the sp. line)
   
   Now, It's reasonable not to bypass the "DONE" node since both the
   specialty line and some "DONE" node may sit on same BDY surface. 
   It should allow those BDY node moving on BDY if the sp. line is 
   also on BDY. So currently the path searching just bypass FIXED node.

   the side effects are: for above setting, the sp. line should
         satisfies following conditions.
      1) a specialty line, if it is not on boundary, it should not be
         too close to boundary (within the distance less than global
	     element size) 
      2) two specialy lines which are not sequencailly connected should
         not be too closely together
*/


/* fitting specialty lines */
int
fit_sp_line (MeshNode *msh_n_head, long n_msh_node,
	         MeshElem *msh_l_head, long n_msh_elem,
	         MeshNode *sp_n_head,  int n_sp_node,
	         LineData *sp_l_head,  int n_sp_line, REAL g_size)
{
    int      i, dangle, line_idx;
    long     ii, jj;
    MeshNode *nptr;
    MeshNode *msh_n1_ptr, *msh_n2_ptr, *sp_n1_ptr, *sp_n2_ptr;
    LineData *sp_l_ptr;
    NSpnod   *tmp_fitnod;
/* Ziji 1/20/99 */
	DOUBLE_LINK onsp, *zwtmp;
	MeshNode *node;
	int      nstatus;

/*Ziji 1/20/99 */    /* initialization */
    create_dl_list (&onsp);

    /* get rid of compiler warning message */
    i = n_sp_node;

    if (sp_n_head == NULL || msh_n_head == NULL || sp_l_head == NULL)
    {
/* Ziji 1/5/99	    printf ("\nError...Null specialty node or mesh node list!\n"); */
	    printf ("\nError...Null specialty node or mesh node list!\n");
		fprintf(fpzw, "\n\n=====fit_sp_line:");
	    fprintf(fpzw,"\nError...Null specialty node or mesh node list!\n");
	    return (BAD);
    }

    /* preprocess ... */
    for (ii=0, nptr=msh_n_head; ii<n_msh_node; ii++, nptr=nptr->Next)
    {
        /* out node do not do smooth */
        if (nptr->status == OUTNODE)   nptr->status = DONE;
    }

    if (Numerical_surf == 1)
    {
        Splin_file = fopen (Splin_fname, "wt");
        if (Splin_file == NULL)
        {
            printf ("Can't open numerical specialty node file (%s). quit!\n", Splin_fname);
            exit (-1);
        }
        fprintf (Splin_file, "%d\n", n_sp_line);
    }

    sp_l_ptr = sp_l_head;
    dangle   = NODANGLE;

    for (i=0; i<n_sp_line; i++)
    {
        /* find specity line idx, for setting up the node status (constraint) */
	    line_idx = conv_line_ptr (sp_l_head, sp_l_ptr, n_sp_line);
        
/* Ziji 1/5/99        printf ("\nSpecialty line No. %d", i+1); */
        printf ("\nSpecialty line No. %d", i+1);
        fprintf (fpzw, "\nSpecialty line No. %d", i+1);

	    /* find corresponding endpoint in mesh nodes list */
	    sp_n1_ptr = sp_l_ptr->StPtr;
	    sp_n2_ptr = sp_l_ptr->EdPtr;
	    dangle = find_endpnt (sp_n1_ptr, sp_n2_ptr, &msh_n1_ptr, &msh_n2_ptr,
		                        msh_n_head, n_msh_node);
	    if (dangle == FULLDANG)
	    {
/* Ziji 1/5/99	        printf ("\nNo Endpoint in msh nodes matches the sp nodes!\n"); */
	        printf ("\nNo Endpoint in msh nodes matches the sp nodes!\n");
	        fprintf(fpzw,"\nNo Endpoint in msh nodes matches the sp nodes!\n");

            if (Numerical_surf == 1)
                fprintf (Splin_file, "%d      0\n", i+1);

	        goto GO;
	    }
	    else if (dangle == HALFDANG)
	    {
/* Ziji 1/5/99	        printf ("\nOnly one Endpoint matches the sp nodes!\n"); */
	        printf ("\nOnly one Endpoint matches the sp nodes!\n");
	        fprintf(fpzw, "\nOnly one Endpoint matches the sp nodes!\n");

            if (Numerical_surf == 1)
                fprintf (Splin_file, "%d      0\n", i+1);

	        goto GO;
	    }
	    else
	    {
            if (Numerical_surf == 1)
            {   /* initialize the fitting sequence list and set 
                    for first node 
                */
                Num_nfitnod = 0;
                Cur_fitnod = Fitnod_head = NULL;
                fprintf (Splin_file, "%d", i+1);

                Fitnod_head = (NSpnod *) malloc (sizeof (NSpnod));
                if (Fitnod_head == NULL) 
                {
                    printf ("\nCan't allocate memory for splin. head node!\n");
                    exit (-1);
                }
                Fitnod_head->Next = NULL;
                Cur_fitnod = Fitnod_head;       
                Num_nfitnod++;
                Cur_fitnod->id = i+1;                /* sp. line index */
                /* mesh node index */
                Cur_fitnod->node_idx = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
                Cur_fitnod->node_ptr = msh_n1_ptr;   /* mesh node pointer */
            }
	         
/* Ziji 1/13/99            do_a_sp_line (msh_n_head, n_msh_node, msh_l_head, n_msh_elem,
                          msh_n1_ptr, msh_n2_ptr, g_size, dangle, line_idx);
*/
        	/* initialize poles and stack */
	        free_dl_list (&onsp);
            do_a_sp_line_b (msh_n_head, n_msh_node, msh_l_head, n_msh_elem,
                          msh_n1_ptr, msh_n2_ptr, g_size, dangle, line_idx, &onsp);
        }

        if (Numerical_surf == 1)
        {   

            /* save to fitting nodal sequence file */
            for (jj=0, Cur_fitnod=Fitnod_head; jj<Num_nfitnod; jj++, Cur_fitnod=Cur_fitnod->Next)
            {
                fprintf (Splin_file, " %ld", Cur_fitnod->node_idx);
            }
            fprintf (Splin_file, "\n");

            /* free memory space */
            Cur_fitnod = Fitnod_head;
            while (Cur_fitnod)
            {
                tmp_fitnod = Cur_fitnod->Next;
                free ((char *) Cur_fitnod);
                Cur_fitnod = tmp_fitnod;
            }
        }

/* Ziji 1/20/99 */ /* move bdy nodes on sp line to bdy along sp line */
        if (!((onsp.Next == NULL)&&(onsp.Prev == NULL))) {
           zwtmp = onsp.Next;
           while (zwtmp)
           {
			 node = zwtmp->nptr;
			 nstatus = node->status;
			 if (nstatus!=FIXED) {
			   set_node_status_b (node);
			   if (node->status==OUTNODE) {
                 bdy_sp_move(node, sp_n1_ptr, sp_n2_ptr, Bdy_node_head_ptr, Bdy_nodes,
			                 Bdy_elem_head_ptr, Bdy_elem);
			     node->status = FIXED;
			   }
			   else node->status = nstatus;
			 }
             zwtmp = zwtmp->Next;
           }

/* debug purpose */		   
           fprintf(fpzw, "\nThe matl code of these node:\n");
           zwtmp = onsp.Next;
           while (zwtmp)
           {
			 fprintf(fpzw, "status:%d  material: %ld\n", zwtmp->nptr->status, zwtmp->nptr->Mtrl);
             zwtmp = zwtmp->Next;
           }
		}
/* end of Ziji */

GO:     sp_l_ptr = sp_l_ptr->Next;
    }

    if (Numerical_surf == 1)
        fclose (Splin_file);

/*Ziji 1/14/99 */
    free_dl_list (&onsp);

    return (OK);
}



/* fitting specialty polylines */
int
fit_spoly_line (MeshNode *msh_n_head,    long n_msh_node,
	            MeshElem *msh_l_head,    long n_msh_elem,
	            MeshNode *spoly_n_head,  int n_spoly_node,
	            LineData *spoly_l_head,  int n_spoly_elem,
	            LineData **spoly_list_head, int *num_seg_poly, REAL g_size)
{
    int i, j, dangle, line_idx, poly_mode;
    long    jj;
    MeshNode *msh_n1_ptr, *msh_n2_ptr, *last_msh_ptr, *term_msh_ptr;
    MeshNode *sp_n1_ptr, *sp_n2_ptr;
    LineData *spoly_l_ptr, *sp_list_ptr;
    NSpnod   *tmp_fitnod;

    /* get rid of compiler warning message */
    i = n_spoly_node;

    if (spoly_n_head == NULL || msh_n_head == NULL ||
	spoly_l_head == NULL || spoly_list_head == NULL )
    {
/*Ziji 1/6/99	    printf ("\nError...Null specialty poly. node or mesh node list!\n"); */
	    printf ("\nError...Null specialty poly. node or mesh node list!\n");
		fprintf(fpzw, "\n\n=====fit_spoly_line:");
	    fprintf(fpzw, "\nError...Null specialty poly. node or mesh node list!\n");

		return (BAD);
    }

    if (Numerical_surf == 1)
    {
        Spoly_file = fopen ("nspoly.dat", "wt");
        if (Spoly_file == NULL)
        {
            printf ("Can't open numerical specialty polyline Squence file. quit!");
            exit (-1);
        }
        fprintf (Spoly_file, "%d\n", n_spoly_elem);
    }

    spoly_l_ptr = spoly_l_head;
    dangle   = NODANGLE;

    for (i=0; i<n_spoly_elem; i++)
    {
        if (Numerical_surf == 1)
        {   /* initialize the fitting sequence list and set 
                for first node 
            */
            Num_nfitnod = 0;
            Cur_fitnod = Fitnod_head = NULL;
            fprintf (Spoly_file, "%d", i+1);

        }
	    /* find specity line idx, for setting up the node status(constraint) */
	    line_idx = conv_line_ptr (spoly_l_head, spoly_l_ptr, n_spoly_elem);
	    last_msh_ptr = NULL;

	    sp_list_ptr = spoly_list_head[i];
	    if (!duplicate_node (sp_list_ptr->StPtr, sp_list_ptr->Prev->EdPtr))
	    {  
	        poly_mode = OPENED_POLY;
	        /* fix end nodes */
	        last_msh_ptr = fix_a_node (sp_list_ptr->StPtr, msh_n_head, 
				                        n_msh_node, g_size);
	        term_msh_ptr = fix_a_node (sp_list_ptr->Prev->EdPtr, msh_n_head, 
				                        n_msh_node, g_size);

	        if (term_msh_ptr == NULL)
	        {
/* Ziji 1/6/99	            printf ("\nWarning...Terminate Node can't be fitted!\n"); */
	            printf ("\nWarning...Terminate Node can't be fitted!\n");
				fprintf(fpzw, "\n\n=====fit_spoly_line:");
	            fprintf(fpzw,"\nWarning...Terminate Node can't be fitted!\n");
	        }
	    }
	    else  
	    {
	        poly_mode = CLOSED_POLY;
	        /* find starting node */
	        last_msh_ptr = fix_a_node (sp_list_ptr->StPtr, msh_n_head,
				                    n_msh_node, g_size);
	        /* just fix one node  */
	    }

	    for (j=0; j<num_seg_poly[i]; j++)
	    {
	        /* determine corresponding endpoint in mesh nodes list
	            which fix end node for fit
	        */
	        msh_n1_ptr = NULL;
	        if (last_msh_ptr)    msh_n1_ptr = last_msh_ptr;
	        else    
            {
/* Ziji 1/6/99                printf ("\nWarning... NULL start point!!\n"); */
                printf ("\nWarning... NULL start point!!\n");
				fprintf(fpzw, "\n\n=====fit_spoly_line:");
                fprintf(fpzw,"\nWarning... NULL start point!!\n");
            }

	        sp_n1_ptr = sp_list_ptr->StPtr;
	        sp_n2_ptr = sp_list_ptr->EdPtr;
	        dangle = find_endpnt_spline (sp_n1_ptr, sp_n2_ptr, 
                            spoly_list_head[i], &msh_n1_ptr, &msh_n2_ptr,
		                    msh_n_head, n_msh_node, g_size);
	    
	        if (poly_mode == OPENED_POLY)
	        {
	            if (j ==  num_seg_poly[i] - 1)
	            {
		            /* the last segment */
		            if (msh_n2_ptr != term_msh_ptr)
		            {
		                if (term_msh_ptr == NULL)
		                {
/* ziji 1/6/99		                    printf("\nWarning...Terminate Node can't be fitted!\n"); */
		                    printf("\nWarning...Terminate Node can't be fitted!\n");
							fprintf(fpzw, "\n\n=====fit_spoly_line:");
		                    fprintf(fpzw,"\nWarning...Terminate Node can't be fitted!\n");
		                }
		                else
		                {
/* Ziji 1/6/99			                printf("\nAdjust terminate node of Open polyline!\n"); */
			                printf("\nAdjust terminate node of Open polyline!\n");
							fprintf(fpzw, "\n\n=====fit_spoly_line:");
			                fprintf(fpzw, "\nAdjust terminate node of Open polyline!\n");
			                msh_n2_ptr = term_msh_ptr;
		                }
		            }
	            }
	        }
	        if (dangle == FULLDANG)
	        {
/* Ziji 1/6/99		        printf ("\nNo Endpoint in msh nodes matches the spoly nodes!\n"); */
		        printf ("\nNo Endpoint in msh nodes matches the spoly nodes!\n");
				fprintf(fpzw, "\n\n=====fit_spoly_line:");
		        fprintf(fpzw, "\nNo Endpoint in msh nodes matches the spoly nodes!\n");
		        msh_n1_ptr = msh_n2_ptr = NULL;
		        goto CON;
	        }
	        else if (dangle == HALFDANG)
	        {
/* Ziji 1/6/99		        printf ("\nOnly one Endpoint matches the spoly nodes!\n"); */
		        printf ("\nOnly one Endpoint matches the spoly nodes!\n");
				fprintf(fpzw, "\n\n=====fit_spoly_line:");
		        fprintf(fpzw, "\nOnly one Endpoint matches the spoly nodes!\n");
		        msh_n2_ptr = NULL;

		        goto CON;
	        }
	        else
	        {
                if (Numerical_surf == 1 && Num_nfitnod == 0)
                {   /* first node */
                    Fitnod_head = (NSpnod *) malloc (sizeof (NSpnod));
                    if (Fitnod_head == NULL) 
                    {
                        printf ("\nCan't allocate memory for splin. head node!\n");
                        exit (-1);
                    }
                    Fitnod_head->Next = NULL;
                    Cur_fitnod = Fitnod_head;       
                    Num_nfitnod++;
                    Cur_fitnod->id = i+1;                /* sp. line index */
                    /* mesh node index */
                    Cur_fitnod->node_idx = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
                    Cur_fitnod->node_ptr = msh_n1_ptr;   /* mesh node pointer */

                }
                /* note that sp. polyline idx start from 1000 */
		        do_a_sp_line (msh_n_head, n_msh_node, msh_l_head, n_msh_elem,
			              msh_n1_ptr, msh_n2_ptr, g_size, dangle, line_idx+1000);
	        }

CON:	    
	        last_msh_ptr = msh_n2_ptr;
	        sp_list_ptr = sp_list_ptr->Next;
	    }

        if (Numerical_surf == 1)
        {   
            if (Num_nfitnod == 0)
                fprintf (Spoly_file, "      0\n");
            else
            {
                /* save to fitting nodal sequence file */
                for (jj=0, Cur_fitnod=Fitnod_head; jj<Num_nfitnod; jj++, Cur_fitnod=Cur_fitnod->Next)
                {
                    fprintf (Spoly_file, " %ld", Cur_fitnod->node_idx);
                }
                fprintf (Spoly_file, "\n");
            }

            /* free memory space */
            Cur_fitnod = Fitnod_head;
            while (Cur_fitnod)
            {
                tmp_fitnod = Cur_fitnod->Next;
                free ((char *) Cur_fitnod);
                Cur_fitnod = tmp_fitnod;
            }
        }
    	spoly_l_ptr = spoly_l_ptr->Next;
    }

    if (Numerical_surf == 1);
      fclose (Spoly_file);

    return (OK);
}





int
find_endpnt (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
	         MeshNode **msh_n1_ptr, MeshNode **msh_n2_ptr,
	         MeshNode *msh_n_head, long num_msh_node)
{
    long   ii, n1_flag=0, n2_flag=0;
    double xp1, yp1, zp1, xp2, yp2, zp2;
    double xm, ym, zm, dist;

    MeshNode *msh_nptr;

    if (sp_n1_ptr == NULL || sp_n2_ptr == NULL)
    {
/* Ziji 1/6/99	    printf ("\nError...NULL pointer for specialty nodes!\n"); */
	    printf ("\nError...NULL pointer for specialty nodes!\n");
		fprintf(fpzw, "\n\n=====find_endpnt:");
	    fprintf(fpzw, "\nError...NULL pointer for specialty nodes!\n");

	    return (FULLDANG);
    }

    xp1 = sp_n1_ptr->Coor[X];
    yp1 = sp_n1_ptr->Coor[Y];
    zp1 = sp_n1_ptr->Coor[Z];

    xp2 = sp_n2_ptr->Coor[X];
    yp2 = sp_n2_ptr->Coor[Y];
    zp2 = sp_n2_ptr->Coor[Z];

    msh_nptr = msh_n_head;
    for (ii=0; ii<num_msh_node; ii++)
    {
	    xm = msh_nptr->Coor[X];
	    ym = msh_nptr->Coor[Y];
	    zm = msh_nptr->Coor[Z];

	    if (n1_flag != OK)
	    {
	        dist = sqrt ((xm-xp1)*(xm-xp1) + (ym-yp1)*(ym-yp1)
		         + (zm-zp1)*(zm-zp1));
	        if (dist < LOWTOL)
	        {
		        n1_flag = OK;
		        *msh_n1_ptr = msh_nptr;
		        goto CON;
	        }
	    }

	    if (n2_flag != OK)
	    {
	        dist = sqrt ((xm-xp2)*(xm-xp2) + (ym-yp2)*(ym-yp2)
		         + (zm-zp2)*(zm-zp2));
	        if (dist < LOWTOL)
	        {
		        n2_flag = OK;
		        *msh_n2_ptr = msh_nptr;
		        goto CON;
	        }
	    }

	    if (n1_flag == OK && n2_flag == OK)     break;

CON:	msh_nptr = msh_nptr->Next;
    }

    if (n1_flag == OK && n2_flag != OK)         return (HALFDANG);
    else if (n2_flag == OK && n1_flag != OK)
    {
	    *msh_n1_ptr = *msh_n2_ptr;
	    *msh_n2_ptr = NULL;
	    return (HALFDANG);
    }
    else if (n1_flag == OK && n2_flag == OK)    return (NODANGLE);
    else                                        return (FULLDANG);
}



/* fit a specialty line */

int
do_a_sp_line (MeshNode *msh_n_head, long n_msh_node,
	            MeshElem *msh_l_head, long n_msh_elem,
	            MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr,
	            REAL g_size, int dangle, int sp_line_idx)
{
    int          status, fit_flag;
    long         idbg1, idbg2;
    REAL         node_1[3], node_2[3], length;
    DOUBLE_LINK  opt_pole;

    /* get rid of compiler warning messages */
    fit_flag = (int)msh_l_head;
    fit_flag = n_msh_elem;
    fit_flag = dangle;

    /* initialization */
    create_dl_list (&opt_pole);

    /* for debugging */
    idbg1 = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
    idbg2 = conv_node_ptr (Msh_node_head_ptr, msh_n2_ptr, Msh_nodes);
    
/* Ziji 1/5/99    printf ("\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2); */
    printf ("\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2);
    fprintf(fpzw, "\n\n=====do_a_sp_line:");
	fprintf (fpzw,"\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2);
    
    while (msh_n1_ptr != msh_n2_ptr)
    {
	    /* find nodes' coord. and the length of constraint needed be fit */
	    node_1[X] = msh_n1_ptr->Coor[X];
	    node_1[Y] = msh_n1_ptr->Coor[Y];
	    node_1[Z] = msh_n1_ptr->Coor[Z];

	    node_2[X] = msh_n2_ptr->Coor[X];
	    node_2[Y] = msh_n2_ptr->Coor[Y];
	    node_2[Z] = msh_n2_ptr->Coor[Z];

        /*
	    printf ("\nStart Node Coor: x=%8.4lf, y=%8.4lf, z=%8.4lf",
                   node_1[X], node_1[Y], node_1[Z]);

        printf ("\nEnd   Node Coor: x=%8.4lf, y=%8.4lf, z=%8.4lf\n",
                   node_2[X], node_2[Y], node_2[Z]);
	    */

	    length = sqrt ((node_2[X]-node_1[X])*(node_2[X]-node_1[X])
		      +(node_2[Y]-node_1[Y])*(node_2[Y]-node_1[Y])
		      +(node_2[Z]-node_1[Z])*(node_2[Z]-node_1[Z]));

	    /*
	    printf ("\nThe Length of the sp_line:  length = %8.4lf\n", length);
	    */

	    /* initialize poles and stack */
	    free_dl_list (&opt_pole);

	    /* search a optimum path for fitting */
	    fit_flag = search_path (msh_n1_ptr, msh_n2_ptr, n_msh_node, g_size,
			                    node_1, node_2, length, &opt_pole);

	    /* fit first node in path (or whole path) */
	    if (fit_flag == OK)
	    {

            /* msh_n1_ptr = fit_whole_path (&opt_pole, node_1, node_2,
					    length, sp_line_idx);
	        */	    
	        msh_n1_ptr = fit_fst_node_path (&opt_pole, node_1, node_2,
					                    length, sp_line_idx);

	        /* do smoothing */
	        lap_soomth (msh_n_head, n_msh_node, 1);
 
	        /* for debugging 
	        idbg1 = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
            */
            if (Numerical_surf == 1)
            {
                Cur_fitnod->Next = (NSpnod *) malloc (sizeof (NSpnod));
                if (Cur_fitnod->Next == NULL) 
                {
                    printf ("\nCan't allocate memory for splin. node!\n");
                    exit (-1);
                }
                Cur_fitnod = Cur_fitnod->Next;
                Cur_fitnod->Next = NULL;
                Num_nfitnod++;
                Cur_fitnod->id = -1;                /* middle point of a sp. line */
                /* mesh node index */
                Cur_fitnod->node_idx = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
                Cur_fitnod->node_ptr = msh_n1_ptr;   /* mesh node pointer */
            }
        }
	    else
	    {
/* Ziji 1/5/99	        printf ("\nCan't fit the sp line. \n"); */
	        printf ("\nCan't fit the sp line. \n");
		    fprintf(fpzw, "\n\n=====do_a_sp_line:");
	        fprintf(fpzw,"\nCan't fit the sp line. \n");

	        status = BAD;
            if (Numerical_surf == 1)
            {
                Cur_fitnod->Next = (NSpnod *) malloc (sizeof (NSpnod));
                if (Cur_fitnod->Next == NULL) 
                {
                    printf ("\nCan't allocate memory for splin. node!\n");
                    exit (-1);
                }
                Cur_fitnod = Cur_fitnod->Next;
                Cur_fitnod->Next = NULL;
                Num_nfitnod++;
                Cur_fitnod->id = -9999;        /* Terminated by failed to fit a sp. line */
                /* mesh node index */
                Cur_fitnod->node_idx = -9999;  
                Cur_fitnod->node_ptr = NULL;   /* mesh node pointer */
            }
	        goto EXIT;
	    }
    }

EXIT:
    /* make sure double link list is free before return */
    free_dl_list (&opt_pole);
    if (status == OK)    return (OK);
    else                 return (BAD);
}



/* fit a specialty line */

int
/* Ziji 1/13/99 */
do_a_sp_line_b (MeshNode *msh_n_head, long n_msh_node,
	            MeshElem *msh_l_head, long n_msh_elem,
	            MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr,
	            REAL g_size, int dangle, int sp_line_idx,
				DOUBLE_LINK *onsp)
{
    int          status, fit_flag;
    long         idbg1, idbg2;
    REAL         node_1[3], node_2[3], length;
    DOUBLE_LINK  opt_pole;

    /* get rid of compiler warning messages */
    fit_flag = (int)msh_l_head;
    fit_flag = n_msh_elem;
    fit_flag = dangle;

    /* initialization */
    create_dl_list (&opt_pole);

    /* for debugging */
    idbg1 = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
    idbg2 = conv_node_ptr (Msh_node_head_ptr, msh_n2_ptr, Msh_nodes);
    
/* Ziji 1/5/99    printf ("\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2); */
    printf ("\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2);
    fprintf(fpzw, "\n\n=====do_a_sp_line:");
	fprintf (fpzw,"\nFit a sp_line which have global mesh node: %ld --> %ld\n",
	            idbg1, idbg2);
    
    while (msh_n1_ptr != msh_n2_ptr)
    {
	    /* find nodes' coord. and the length of constraint needed be fit */
	    node_1[X] = msh_n1_ptr->Coor[X];
	    node_1[Y] = msh_n1_ptr->Coor[Y];
	    node_1[Z] = msh_n1_ptr->Coor[Z];

	    node_2[X] = msh_n2_ptr->Coor[X];
	    node_2[Y] = msh_n2_ptr->Coor[Y];
	    node_2[Z] = msh_n2_ptr->Coor[Z];

        /*
	    printf ("\nStart Node Coor: x=%8.4lf, y=%8.4lf, z=%8.4lf",
                   node_1[X], node_1[Y], node_1[Z]);

        printf ("\nEnd   Node Coor: x=%8.4lf, y=%8.4lf, z=%8.4lf\n",
                   node_2[X], node_2[Y], node_2[Z]);
	    */

	    length = sqrt ((node_2[X]-node_1[X])*(node_2[X]-node_1[X])
		      +(node_2[Y]-node_1[Y])*(node_2[Y]-node_1[Y])
		      +(node_2[Z]-node_1[Z])*(node_2[Z]-node_1[Z]));

	    /*
	    printf ("\nThe Length of the sp_line:  length = %8.4lf\n", length);
	    */

	    /* initialize poles and stack */
	    free_dl_list (&opt_pole);

	    /* search a optimum path for fitting */
	    fit_flag = search_path (msh_n1_ptr, msh_n2_ptr, n_msh_node, g_size,
			                    node_1, node_2, length, &opt_pole);

	    /* fit first node in path (or whole path) */
	    if (fit_flag == OK)
	    {

            /* msh_n1_ptr = fit_whole_path (&opt_pole, node_1, node_2,
					    length, sp_line_idx);
	        */	    
	        msh_n1_ptr = fit_fst_node_path (&opt_pole, node_1, node_2,
					                    length, sp_line_idx);

/* Ziji 1/20/99 */	        /* put node into current set */
	        if ((msh_n1_ptr!=NULL)&&(msh_n1_ptr->status!=FIXED)) {
				add_dl_list(onsp, msh_n1_ptr, 0., 0., NULL);
			}

	        /* do smoothing */
	        lap_soomth (msh_n_head, n_msh_node, 1);
 
	        /* for debugging 
	        idbg1 = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
            */
            if (Numerical_surf == 1)
            {
                Cur_fitnod->Next = (NSpnod *) malloc (sizeof (NSpnod));
                if (Cur_fitnod->Next == NULL) 
                {
                    printf ("\nCan't allocate memory for splin. node!\n");
                    exit (-1);
                }
                Cur_fitnod = Cur_fitnod->Next;
                Cur_fitnod->Next = NULL;
                Num_nfitnod++;
                Cur_fitnod->id = -1;                /* middle point of a sp. line */
                /* mesh node index */
                Cur_fitnod->node_idx = conv_node_ptr (Msh_node_head_ptr, msh_n1_ptr, Msh_nodes);
                Cur_fitnod->node_ptr = msh_n1_ptr;   /* mesh node pointer */
            }
        }
	    else
	    {
/* Ziji 1/5/99	        printf ("\nCan't fit the sp line. \n"); */
	        printf ("\nCan't fit the sp line. \n");
		    fprintf(fpzw, "\n\n=====do_a_sp_line:");
	        fprintf(fpzw,"\nCan't fit the sp line. \n");

	        status = BAD;
            if (Numerical_surf == 1)
            {
                Cur_fitnod->Next = (NSpnod *) malloc (sizeof (NSpnod));
                if (Cur_fitnod->Next == NULL) 
                {
                    printf ("\nCan't allocate memory for splin. node!\n");
                    exit (-1);
                }
                Cur_fitnod = Cur_fitnod->Next;
                Cur_fitnod->Next = NULL;
                Num_nfitnod++;
                Cur_fitnod->id = -9999;        /* Terminated by failed to fit a sp. line */
                /* mesh node index */
                Cur_fitnod->node_idx = -9999;  
                Cur_fitnod->node_ptr = NULL;   /* mesh node pointer */
            }
	        goto EXIT;
	    }
    }

EXIT:
    /* make sure double link list is free before return */
    free_dl_list (&opt_pole);

    if (status == OK)    return (OK);
    else                 return (BAD);
}


/* search a optimum path for fitting */
int
search_path (MeshNode *msh_n1_ptr, MeshNode *msh_n2_ptr, long n_msh_node,
	        REAL g_size, REAL *node_1, REAL *node_2, REAL length,
	        DOUBLE_LINK *opt_pole)
{
    int 	     num_node, status, idbg3, idbg4;
    REAL	     node_3[3], node_4[3], len, dist;
    DOUBLE_LINK  cur_pole, pq_pole, *cur_dlptr, *tmp_dlptr;
    MeshNode     *cur_nptr;
    AdjList      *adj_ptr;

    /* get rid of compiler warning messages */
    num_node = n_msh_node;
    dist     = g_size;

    /* initialization */
    create_dl_list (&cur_pole);       /* create a double link list */
    create_dl_list (&pq_pole);        /* create a priority queue */


    /* add in the source node to priority queue */
    add_dl_list (&pq_pole, msh_n1_ptr, 0., 0., NULL);

    while (is_dl_empty (&pq_pole) != OK)
    {
	    /* pop out a node from priority queue */
	    cur_dlptr = extract_min (&pq_pole);

	    /* put node u into current set */
	    append_dl_list (&cur_pole, cur_dlptr);

	    /* current node */
	    cur_nptr = cur_dlptr->nptr;

	    /* for debugging */
	    idbg3 = conv_node_ptr (Msh_node_head_ptr, cur_nptr, Msh_nodes);

	    /* reach node 2 : quit loop */
	    if (cur_nptr == msh_n2_ptr )	break;

	    /* current node Coord. */
	    node_3[X] = cur_nptr->Coor[X];
	    node_3[Y] = cur_nptr->Coor[Y];
	    node_3[Z] = cur_nptr->Coor[Z];

	    /* deal with each adjacent node of current node */
	    adj_ptr = cur_nptr->Fst_adj;
	    num_node = 0;
	    while (adj_ptr)
	    {
	        /* for debugging */
	        idbg4 = conv_node_ptr (Msh_node_head_ptr, adj_ptr->idx, Msh_nodes);

	        num_node++;

	        node_4[X] = adj_ptr->idx->Coor[X];
	        node_4[Y] = adj_ptr->idx->Coor[Y];
	        node_4[Z] = adj_ptr->idx->Coor[Z];

	        /* compute the distance and length w.r.t. the constraint */
	        status = node_process (node_1, node_2, node_3, node_4,
			                   length, g_size, &dist, &len);

	        /* modify: 05/09/1995.  don't skip because some FIXED 
		       or DONE nodes may already on
		       the specialty line. it could be count as
		       a passible path. just add a node status
	        checking in fit_fst_node or fit whole path function.
	        if a FIXED or DONE node meet, just don't change its coord.
               future work: late on DONE may allow to move along 
	        the specialty line
            */
	        /* check for free nodes, if not free and not end node (node 2) skip it	   */

	        if (status == OK)
	        {
	            if (adj_ptr->idx->status == FIXED /* || adj_ptr->idx->status == DONE */)
		        {
		            if (dist > LOWTOL)
		            {
		                /* FIXED node or DONE node is not on the specialty line */
		                adj_ptr = adj_ptr->ptr;
		                continue;
		            }
		        }
		        /* test the closed cycle in the graph */
		        if (search_dl_list (&cur_pole, adj_ptr->idx, &tmp_dlptr) != OK)
		        {   /* It is an acyclic graph */
		            /* modify priority queue: insertion if not exsit and weight, */
		            /*	dad relation */
		            Modify_pq (&pq_pole, adj_ptr->idx, dist, len, cur_dlptr);
		        }
	        }
	        adj_ptr = adj_ptr->ptr;
	    }

	    /* double check for adjacent node */
	    if (cur_nptr->Num_adj != num_node)
	        printf ("\nWarning... the num. of adj. node does't match!\n");
    }


    if (search_dl_list (&cur_pole, msh_n2_ptr, &cur_dlptr) == OK)
    {
       /* reach node 2: find the optimum path with reverse order (node2 -> node1) */
       /* for the tail node */
       do
       {
	        /* for debugging */
	        idbg4 = conv_node_ptr (Msh_node_head_ptr, cur_dlptr->nptr, Msh_nodes);

	        /* delink from cur_pole double link list */
	        if (cur_dlptr == cur_pole.Next && cur_dlptr == cur_pole.Prev)
	        {	/* the only one element in the list */
		        cur_pole.Next = cur_pole.Prev = NULL;
		        cur_pole.weight = 0.0;
	        }
	        else if (!cur_dlptr->Prev)
	        {	/* the first element */
		        cur_pole.Next = cur_dlptr->Next;
		        cur_dlptr->Next->Prev = NULL;
	        }
	        else if (!cur_dlptr->Next)
	        {	/* the last element */
		        cur_pole.Prev = cur_dlptr->Prev;
		        cur_dlptr->Prev->Next = NULL;
	        }
	        else
	        {
		        /* delink from cur_pole double link list */
		        cur_dlptr->Prev->Next = cur_dlptr->Next;
		        cur_dlptr->Next->Prev = cur_dlptr->Prev;
	        }

	        cur_dlptr->Prev = cur_dlptr->Next = NULL;

	        /* plug into opt_pole double link list : optimum path */
	        cur_dlptr->Next = opt_pole->Next;
	        if (cur_dlptr->Next)    cur_dlptr->Next->Prev = cur_dlptr;
	        opt_pole->Next = cur_dlptr;
	        if (!opt_pole->Prev)   opt_pole->Prev = cur_dlptr;	/* first in */

	        /* find parent node */
	        cur_dlptr = cur_dlptr->Dad;

       } while (cur_dlptr);     /* the source node has a null dad pionter */

       status = OK;
    }
    else
    {	/* no path was found */
	    status = BAD;
    }

    /* adjust the len field in the optimum path d-link, and let them to be the projecting len 
       of each segment on the sp_line. the origin value were the projecting len on the sp_line
       between start point to given point. This adjustment is for whole path fitting.
    */
    if (status == OK)
    {
        cur_dlptr = opt_pole->Prev;
	    do
	    {
	        cur_dlptr->len = cur_dlptr->len - cur_dlptr->Prev->len;
	        cur_dlptr = cur_dlptr->Prev;
	    } while (cur_dlptr != opt_pole->Next);
    }

    /* make sure double link list is free before return */
    free_dl_list (&pq_pole);
    free_dl_list (&cur_pole);
    return (status);
}




/* compute the distance and length w.r.t. the constraint */
int
node_process (REAL *node_1, REAL *node_2, REAL *node_3, REAL *node_4,
	          REAL length, REAL g_size, REAL *dist, REAL *len)
{
    REAL cos_sita, cos_garma, leng13;

    /* get rid of the compiler warning message */
    cos_sita = g_size;

    /* find cosine angle between two lines */
    cos_sita = cosine_ang (node_1, node_2, node_3, node_4);

    if (cos_sita <= 0.0)    return (BAD);   /* violate constraint */

    /* find cosine garma */
    cos_garma = cosine_ang (node_1, node_2, node_1, node_4);

    if (cos_garma <= 0.0)   return (BAD);   /* violate constraint (on node 1)*/

    /* find distance from node 4 to the constraint */
    *dist = pt_to_line (node_1, node_2, node_4);

    /* find projected length on the constraint */
    leng13 = sqrt ((node_4[X]-node_1[X])*(node_4[X]-node_1[X])
		    + (node_4[Y]-node_1[Y])*(node_4[Y]-node_1[Y])
		    + (node_4[Z]-node_1[Z])*(node_4[Z]-node_1[Z]));

    *len = leng13 * cos_garma;

    /* check with the constraint */
    if (*len > length + HIGTOL)    return (BAD);   /* violate constraint (on node 2)*/

    return (OK);
}



/* find cosine angle between two lines */
REAL
cosine_ang (REAL *node_1, REAL *node_2, REAL *node_3, REAL *node_4)
{
    REAL  nomi, deno;

    nomi = (node_2[X]-node_1[X])*(node_4[X]-node_3[X])
	     + (node_2[Y]-node_1[Y])*(node_4[Y]-node_3[Y])
	     + (node_2[Z]-node_1[Z])*(node_4[Z]-node_3[Z]);

    deno = (  (node_2[X]-node_1[X])*(node_2[X]-node_1[X])
	        + (node_2[Y]-node_1[Y])*(node_2[Y]-node_1[Y])
	        + (node_2[Z]-node_1[Z])*(node_2[Z]-node_1[Z]))
	     * (  (node_4[X]-node_3[X])*(node_4[X]-node_3[X])
	        + (node_4[Y]-node_3[Y])*(node_4[Y]-node_3[Y])
	        + (node_4[Z]-node_3[Z])*(node_4[Z]-node_3[Z]));

    if (deno < HIGTOL)   deno = HIGTOL;

    return (nomi / sqrt (deno));
}





/* find the distance from a given point to a line */
REAL
pt_to_line (REAL *node_1, REAL *node_2, REAL *node_3)
{
    REAL length, tmp1, tmp2, tmp3;

    /* find cos angle and distance from node 3 to line node 1 and node 2 */
    length = sqrt ((node_2[X]-node_1[X])*(node_2[X]-node_1[X])
		    + (node_2[Y]-node_1[Y])*(node_2[Y]-node_1[Y])
		    + (node_2[Z]-node_1[Z])*(node_2[Z]-node_1[Z]));

    tmp1 = (node_3[Y]-node_1[Y])*(node_2[Z]-node_1[Z])
	        - (node_3[Z]-node_1[Z])*(node_2[Y]-node_1[Y]);

    tmp1 *= tmp1;


    tmp2 = (node_3[Z]-node_1[Z])*(node_2[X]-node_1[X])
	        -(node_3[X]-node_1[X])*(node_2[Z]-node_1[Z]);

    tmp2 *= tmp2;


    tmp3 = (node_3[X]-node_1[X])*(node_2[Y]-node_1[Y])
	        -(node_3[Y]-node_1[Y])*(node_2[X]-node_1[X]);

    tmp3 *= tmp3;

    return (sqrt (tmp1+tmp2+tmp3) / length);

}




/* modify priority queue: insert if not exsit or (for exsited node)
 to find the shortest path by modifing the Dad relation based on the weight */
int
Modify_pq (DOUBLE_LINK *pq_pole, MeshNode *cur_nptr,
	        REAL wt, REAL len, DOUBLE_LINK *dad_dlptr)
{
    DOUBLE_LINK *cur_dlptr;

    /* search priority queue for current node */
    if (search_dl_list (pq_pole, cur_nptr, &cur_dlptr) == OK)
    {
	    /* the node is in the queue */
	    if (cur_dlptr->weight > (dad_dlptr->weight + wt))
	    {
	        /* find a shorter path */
	        cur_dlptr->weight = dad_dlptr->weight + wt;
	        cur_dlptr->Dad    = dad_dlptr;

	        if (cur_dlptr->len != len)
	        {
		        printf ("\nWarning...length doesn't match: %lf(old)  .vs. %lf\n",
			            cur_dlptr->len, len);
		        cur_dlptr->len = len;
	        }
	    }
    }
    else
    {   /* the node is not in the queue */
        add_dl_list (pq_pole, cur_nptr, dad_dlptr->weight + wt, len, dad_dlptr);
    }

    return (OK);
}




/* fit a node which following the start node as the optimum path */
MeshNode *
fit_fst_node_path (DOUBLE_LINK *path_pole, REAL *node_1, REAL *node_2,
		            REAL length, int sp_line_idx)
{
    int     num_level;
    long    msh_nod_num;
    REAL	u, mov_pnt[3];
    MeshNode	*cur_nptr;
    DOUBLE_LINK *cur_dlptr;

    if (path_pole->Next == path_pole->Prev)	    /* for debugging */
    {
/* Ziji 1/6/99	    printf ("\nError... Illeagel path!\n"); */
	    printf ("\nError... Illeagel path!\n");
		fprintf(fpzw, "\n\n=====fit_fst_node_path:");
	    fprintf(fpzw, "\nError... Illeagel path!\n");

	    return (NULL);
    }

    if (path_pole->Next->Next == path_pole->Prev)
    {
	    /* reach node 2: Done!*/
	    cur_nptr = path_pole->Prev->nptr;
	    
/* Ziji 1/6/99	    printf ("\nReach end point of sp_line No.%d...!\n", sp_line_idx); */
	    printf ("\nReach end point of sp_line No.%d...!\n", sp_line_idx);
		fprintf(fpzw, "\n\n=====fit_fst_node_path:");
	    fprintf(fpzw, "\nReach end point of sp_line No.%d...!\n", sp_line_idx);
    }
    else
    {	/* fit start from second node since first node is node 1 */
	    cur_dlptr = path_pole->Next->Next;
	    cur_nptr  = cur_dlptr->nptr;
	    /* parameter value (0-1) for the node prejection on the line */
	    u = cur_dlptr->len / length;

	    if (u <= 1.0 && u >= 0.0)
	    {
	        if (cur_nptr->status != FIXED /* && cur_nptr->status != DONE */)
	        {
	            /* move the node onto the constraint */
	            /*
	            cur_nptr->Coor[X] = node_1[X] + u*(node_2[X]-node_1[X]);
	            cur_nptr->Coor[Y] = node_1[Y] + u*(node_2[Y]-node_1[Y]);
	            cur_nptr->Coor[Z] = node_1[Z] + u*(node_2[Z]-node_1[Z]);
	            */
	            mov_pnt[X] = node_1[X] + u*(node_2[X]-node_1[X]);
	            mov_pnt[Y] = node_1[Y] + u*(node_2[Y]-node_1[Y]);
	            mov_pnt[Z] = node_1[Z] + u*(node_2[Z]-node_1[Z]);

                if (Numerical_surf == 1)    num_level = 3;
                else                        num_level = 0;
	            sp_move (Bdy_node_head_ptr, Bdy_nodes,
			                Bdy_elem_head_ptr, Bdy_elem,
			                Msh_node_head_ptr, Msh_nodes,
			                Msh_elem_head_ptr, Msh_elem,
			                cur_nptr, mov_pnt, num_level);

	            /*  currently sp. polyline node not allow to do
		            contraint. Note that  smooth sp. polyline index > 1000 
                */
	            if (sp_line_idx > 100)      cur_nptr->status = DONE;
	            else                        cur_nptr->status  = sp_line_idx;
	        }

	        /* for debug */
	        msh_nod_num = conv_node_ptr (Msh_node_head_ptr, cur_nptr,
					                     Msh_nodes);
/* Ziji 1/6/99	        printf ("\nFit mesh node No.%ld on sp_line No.%d... done!\n",
		            msh_nod_num, sp_line_idx); */
	        printf ("\nFit mesh node No.%ld on sp_line No.%d... done!\n",
		            msh_nod_num, sp_line_idx);
			fprintf(fpzw, "\n\n=====fit_fst_node_path:");
	        fprintf (fpzw, "\nFit mesh node No.%ld on sp_line No.%d... done!\n",
		            msh_nod_num, sp_line_idx);
			fprintf(fpzw, "\nThe node has status %d, and material %ld.\n", 
				          cur_nptr->status, cur_nptr->Mtrl);
	    }
	    else
	    {
/* Ziji 1/6/99	        printf ("\nError... Can't fit the constraint! u = %lf\n", u); */
	        printf ("\nError... Can't fit the constraint! u = %lf\n", u);
			fprintf(fpzw, "\n\n=====fit_fst_node_path:");
	        fprintf(fpzw,"\nError... Can't fit the constraint! u = %lf\n", u);
	    }
    }

    return (cur_nptr);
}








/* fit whole path  which following the start node as the optimum path */

MeshNode *
fit_whole_path (DOUBLE_LINK *path_pole, REAL *node_1, REAL *node_2,
		        REAL length, int sp_line_idx)
{
    REAL	u, nod1[3], mov_pnt[3];
    MeshNode	*cur_nptr;
    DOUBLE_LINK *cur_dlptr;

    if (path_pole->Next == path_pole->Prev)	    /* for debugging */
    {
/* Ziji 1/6/99	    printf ("\nError... Illeagel path!\n"); */
	    printf ("\nError... Illeagel path!\n");
		fprintf(fpzw, "\nfit_whole_path:");
	    fprintf(fpzw, "\nError... Illeagel path!\n");
	    return (NULL);
    }

    if (path_pole->Next->Next == path_pole->Prev)
    {
	    /* reach node 2: Done!*/
	    cur_nptr = path_pole->Prev->nptr;
	    /*
	    printf ("\nReach end point of sp_line No.%d... \n", sp_line_idx);
	    */
    }

    /* pass node_1 value to local varibles, so the outside won't be affected */
    nod1[X] = node_1[X];  nod1[Y] = node_1[Y];  nod1[Z] = node_1[Z];

    /* pointing to first node (specialty node!) */
    cur_dlptr = path_pole->Next;
    /* fit start from second node since first node is node 1 */

    while (cur_dlptr->Next != path_pole->Prev)
    {   /* haven't reach end point */
	    cur_dlptr = cur_dlptr->Next;
	    cur_nptr  = cur_dlptr->nptr;
	    /* parameter value (0-1) for the node prejection on the line */
	    u = cur_dlptr->len / length;
	    /*
	    printf ("\nThe Length of remaining to be fitted:  length = %8.4lf",
		        length);

	    printf ("\nThe Projecting Length of fit point: len = %8.4lf\n",
		        cur_dlptr->len);
	    */
	    if (u <= 1.0 && u >= 0.0)
	    {
	        if (cur_nptr->status != FIXED /* && cur_nptr->status != DONE */)
	        {
	            /* move the node onto the constraint */
	            /*
	            cur_nptr->Coor[X] = nod1[X] + u*(node_2[X]-nod1[X]);
	            cur_nptr->Coor[Y] = nod1[Y] + u*(node_2[Y]-nod1[Y]);
	            cur_nptr->Coor[Z] = nod1[Z] + u*(node_2[Z]-nod1[Z]);
	            */
	            mov_pnt[X] = node_1[X] + u*(node_2[X]-node_1[X]);
	            mov_pnt[Y] = node_1[Y] + u*(node_2[Y]-node_1[Y]);
	            mov_pnt[Z] = node_1[Z] + u*(node_2[Z]-node_1[Z]);

	            sp_move (Bdy_node_head_ptr, Bdy_nodes,
			            Bdy_elem_head_ptr, Bdy_elem,
			            Msh_node_head_ptr, Msh_nodes,
			            Msh_elem_head_ptr, Msh_elem,
			            cur_nptr, mov_pnt, 0);

	            cur_nptr->status  = sp_line_idx;
	        }

	        /* adjust length to be fitted */
	        length -= cur_dlptr->len;
	        nod1[X] = cur_nptr->Coor[X];
	        nod1[Y] = cur_nptr->Coor[Y];
	        nod1[Z] = cur_nptr->Coor[Z];

	        /* for debug */
	        /*
	        msh_nod_num = conv_node_ptr (Msh_node_head_ptr, cur_nptr,
					Msh_nodes);
	        printf ("\nFit mesh node No.%ld on sp_line No.%d... done!\n",
		            msh_nod_num, sp_line_idx);
	        */
	    }
	    else
	    {
/* Ziji 1/6/99	        printf ("\nError... Can't fit the constraint! u = %lf\n", u); */
	        printf ("\nError... Can't fit the constraint! u = %lf\n", u);
			fprintf(fpzw, "\nfit_whole_path:");
	        fprintf(fpzw, "\nError... Can't fit the constraint! u = %lf\n", u);
	    }
    }

    return (cur_nptr);
}






/* determine corresponding endpoint in mesh nodes list
	       which fix end node for fit
   return endpoint status:
*/
int
find_endpnt_spline (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
		    LineData *sp_list_head, MeshNode **msh_n1_ptr,
		    MeshNode **msh_n2_ptr, MeshNode *msh_n_head,
		    long num_msh_node, REAL g_size)
{
    long   n1_flag=0, n2_flag=0;

    MeshNode *msh_nptr;


    if (sp_n1_ptr == NULL || sp_n2_ptr == NULL)
    {
/* Ziji 1/6/99	    printf ("\nError...NULL pointer for specialty sp. nodes!\n"); */
	    printf ("\nError...NULL pointer for specialty sp. nodes!\n");
		fprintf(fpzw, "\n\n=====find_endpnt_spline:");
	    fprintf(fpzw, "\nError...NULL pointer for specialty sp. nodes!\n");
	    return (FULLDANG);
    }

    *msh_n2_ptr = NULL;

    /* first node available? */
    msh_nptr = *msh_n1_ptr;
    if (msh_nptr == NULL)
    {
       /* find a first node */
       msh_nptr = find_nd_online (sp_n1_ptr, sp_n2_ptr, msh_n_head,
		                            num_msh_node, g_size, NOD1_MODE);

       if (msh_nptr == NULL)    return (HALFDANG);
       else                     *msh_n1_ptr = msh_nptr;
    }

    /* check if first node within the constraint n1 -- n2 */
    if (nod_in_line (msh_nptr, sp_n1_ptr, sp_n2_ptr) == BAD)
    {
	    /* fit a start node which is the adjacent node of msh_nptr
	    if can't find that kind of node just force node msh_nptr
	    move to sp_n1_ptr.
	    */
	    msh_nptr = fit_start_node (msh_nptr, sp_n1_ptr, sp_n2_ptr, g_size); 
	    if (msh_nptr)
	    {
	        *msh_n1_ptr = msh_nptr;
	        n1_flag = OK;
	    }
	    else  return (HALFDANG);
    }
    else
	    n1_flag = OK;

    if (n1_flag == OK)  
         (*msh_n1_ptr)->status = FIXED; /* so avoid in node n2 use n1 again! */

    /* find a second node */
    msh_nptr = find_nd_online (sp_n1_ptr, sp_n2_ptr, msh_n_head,
		                        num_msh_node, g_size, NOD2_MODE);
    if (msh_nptr == NULL)   return (HALFDANG);
    else
    {
	    *msh_n2_ptr = msh_nptr;
	    n2_flag = OK;
    }


    if ((n1_flag == OK && n2_flag != OK) || (n1_flag != OK && n2_flag == OK))
          return (HALFDANG);
    else if (n1_flag == OK && n2_flag == OK)   return (NODANGLE);
    else                                       return (FULLDANG);

}





/* fix the near mesh node to given location if the distance is
   less than g_size
   if sucess return the pointer to the mesh node otherwise return NULL
*/
MeshNode * 
fix_a_node (MeshNode *sp_ptr, MeshNode * msh_n_head, long n_msh_node,
	    REAL g_size)
{
    long jj;
    REAL xsp, ysp, zsp, xmsh, ymsh, zmsh;
    REAL min_dist, dist, mov_pnt[3];
    MeshNode *msh_ptr, *act_ptr;


	if (sp_ptr->status == DONE)
	{
/* Ziji 1/6/99	    printf ("\nThe given node has been fixed!\n"); */
	    printf ("\nThe given node has been fixed!\n");
		fprintf(fpzw, "\n\n=====fix_a_node:");
	    fprintf(fpzw, "\nThe given node has been fixed!\n");
	    if ((msh_ptr=match_sp_msh (sp_ptr, msh_n_head, n_msh_node)) != NULL)
		    return (msh_ptr);
	    else
	        return (NULL);           
	}
	xsp = sp_ptr->Coor[X];
	ysp = sp_ptr->Coor[Y];
	zsp = sp_ptr->Coor[Z];

	msh_ptr = msh_n_head;
	/* initialization */
	min_dist = 1.e10;
	act_ptr = NULL;
	for (jj=0; jj<n_msh_node; jj++)
	{

	    if (msh_ptr->status != FIXED)
	    {
		    xmsh = msh_ptr->Coor[X];
		    ymsh = msh_ptr->Coor[Y];
		    zmsh = msh_ptr->Coor[Z];

		    dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			            +(zmsh-zsp)*(zmsh-zsp));

		    if (dist < min_dist)
		    {
		        min_dist = dist;
		        /* set active pointer */
		        act_ptr = msh_ptr;
		    }
	    }
	    else
	    {
	        /* for fixed point if near enough .... Done */
		    xmsh = msh_ptr->Coor[X];
		    ymsh = msh_ptr->Coor[Y];
		    zmsh = msh_ptr->Coor[Z];

		    dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			     +(zmsh-zsp)*(zmsh-zsp));

		    if (dist < HIGTOL)
		    {
		        sp_ptr->status = DONE;
		        return (msh_ptr);
		    }
	    }
	    msh_ptr = msh_ptr->Next;
	}

	if (act_ptr == NULL)
	{
/* Ziji 1/6/99	    printf ("\nWarning...No mesh node can fit SP node (no.)\n"); */
	    printf ("\nWarning...No mesh node can fit SP node (no.)\n");
		fprintf(fpzw, "\n\n=====fix_a_node:");
	    fprintf(fpzw, "\nWarning...No mesh node can fit SP node (no.)\n");
	}
	else if (min_dist > G_factor*loc_size (act_ptr))
	{
/* Ziji 1/6/99	    printf ("\nWarning...fitting distance greater than local size. Skip it !\n"); */
	    printf ("\nWarning...fitting distance greater than local size. Skip it !\n");
		fprintf(fpzw, "\n\n=====fix_a_node:");
	    fprintf(fpzw, "\nWarning...fitting distance greater than local size. Skip it !\n");

		return (NULL);
	}
	else
	{
	    /*
	    act_ptr->Coor[X] = xsp;
	    act_ptr->Coor[Y] = ysp;
	    act_ptr->Coor[Z] = zsp;
	    */
	    mov_pnt[X] = xsp;
	    mov_pnt[Y] = ysp;
	    mov_pnt[Z] = zsp;

	    sp_move (Bdy_node_head_ptr, Bdy_nodes,
			    Bdy_elem_head_ptr, Bdy_elem,
			    Msh_node_head_ptr, Msh_nodes,
			    Msh_elem_head_ptr, Msh_elem,
			    act_ptr, mov_pnt, 0);

	    act_ptr->status  = FIXED;  /* a specialty node should be fixed */
	    /* lap_soomth (msh_n_head, n_msh_node, 3); */
	    sp_ptr->status = DONE;
	}

	return (act_ptr);
}




/* given a node and find a matched mesh node */
MeshNode *
match_sp_msh (MeshNode *sp_n1_ptr, MeshNode *msh_n_head, long n_msh_node)
{

    long   ii, n1_flag=0;
    double xp1, yp1, zp1;
    double xm, ym, zm, dist;

    MeshNode *msh_nptr, *msh_n1_ptr;

    if (sp_n1_ptr == NULL)
    {
/* Ziji 1/6/99	    printf ("\nError...NULL pointer for specialty sp nodes!\n"); */
	    printf ("\nError...NULL pointer for specialty sp nodes!\n");
		fprintf(fpzw, "\n\n=====match_sp_msh:");
	    fprintf(fpzw, "\nError...NULL pointer for specialty sp nodes!\n");

	    return (NULL);
    }

    xp1 = sp_n1_ptr->Coor[X];
    yp1 = sp_n1_ptr->Coor[Y];
    zp1 = sp_n1_ptr->Coor[Z];

    msh_nptr = msh_n_head;
    for (ii=0; ii<n_msh_node; ii++)
    {
	    xm = msh_nptr->Coor[X];
	    ym = msh_nptr->Coor[Y];
	    zm = msh_nptr->Coor[Z];

	    dist = sqrt ((xm-xp1)*(xm-xp1) + (ym-yp1)*(ym-yp1)
		       + (zm-zp1)*(zm-zp1));
	    if (dist < LOWTOL)
	    {
	        n1_flag = OK;
	        msh_n1_ptr = msh_nptr;
	    }

	    msh_nptr = msh_nptr->Next;
    }

    if (n1_flag == OK)    return (msh_n1_ptr);
    else                  return (NULL);

}




/* check if the node msh_nptr is a middle node between sp_n1 and sp_n2
   if yes return OK (include on the node case) otherwise return BAD
*/
int
nod_in_line (MeshNode *msh_nptr, MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr)
{
    REAL node_1[3], node_2[3], node_4[3];
    REAL cos_garma, length, len14;

    node_1[X] = sp_n1_ptr->Coor[X];
    node_1[Y] = sp_n1_ptr->Coor[Y];
    node_1[Z] = sp_n1_ptr->Coor[Z];

    node_2[X] = sp_n2_ptr->Coor[X];
    node_2[Y] = sp_n2_ptr->Coor[Y];
    node_2[Z] = sp_n2_ptr->Coor[Z];

    node_4[X] = msh_nptr->Coor[X];
    node_4[Y] = msh_nptr->Coor[Y];
    node_4[Z] = msh_nptr->Coor[Z];

    if ((len14=v_rang(node_1, node_4, 3)) < LOWTOL)
		return (OK); /* on left node */

    if (v_rang(node_2, node_4, 3) < LOWTOL)   return (OK); /* on right node */

    /* find cosine garma */
    cos_garma = cosine_ang (node_1, node_2, node_1, node_4);

    if (cos_garma <= 0.0)   return (BAD); /* violate constraint (on node 1)*/

    /* find distance from node 4 to the constraint */
    if (pt_to_line (node_1, node_2, node_4) > LOWTOL)
		return (BAD);     /*  not on the line */

    /* check with the constraint */
    length = v_rang(node_1, node_2, 3);
    if ((len14*cos_garma) > length + HIGTOL)
	return (BAD); /* violate constraint (on node 2)*/

    /* then the node is within the constraint */
    return (OK);

}



/* given constraint nodes sp_n1_ptr & sp_n2_ptr to find a mesh
	node which is near to node 1 or node 2 and move it onto the
	constraint
*/
MeshNode *
find_nd_online (MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
		MeshNode *msh_n_head, long num_msh_node,
		REAL g_size, int nod_mode)
{
    int      flag;
    long     jj;
    REAL     node_1[3], node_2[3], node_4[3], length;
    REAL     xmsh, ymsh, zmsh, xsp, ysp, zsp, min_dist, dist, dist_p;
    REAL     min_len, len, u, mov_pnt[3];
    MeshNode *sp_ptr, *msh_ptr, *act_ptr, *act_2_ptr;



    node_1[X] = sp_n1_ptr->Coor[X];
    node_1[Y] = sp_n1_ptr->Coor[Y];
    node_1[Z] = sp_n1_ptr->Coor[Z];

    node_2[X] = sp_n2_ptr->Coor[X];
    node_2[Y] = sp_n2_ptr->Coor[Y];
    node_2[Z] = sp_n2_ptr->Coor[Z];

    length = v_rang(node_1, node_2, 3);

    if (nod_mode == NOD2_MODE)  sp_ptr = sp_n2_ptr;
    else			            sp_ptr = sp_n1_ptr;

    xsp = sp_ptr->Coor[X];
    ysp = sp_ptr->Coor[Y];
    zsp = sp_ptr->Coor[Z];

    msh_ptr = msh_n_head;
    /* initialization */
    min_dist = 1.e10;
    act_ptr = act_2_ptr = NULL;
    for (jj=0; jj<num_msh_node; jj++)
    {

	    if (msh_ptr->status != FIXED)
	    {
	        xmsh = msh_ptr->Coor[X];
	        ymsh = msh_ptr->Coor[Y];
	        zmsh = msh_ptr->Coor[Z];

	        dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			        +(zmsh-zsp)*(zmsh-zsp));

	        if (dist < min_dist)
	        {
		        /* set secondary active ptr which is the nearest
		        mesh node to the sp.poly node. it may not satisfy
		        the constraint. 
		        */
	            min_dist = dist;
	            act_2_ptr = msh_ptr;
		        node_4[X] = xmsh;
		        node_4[Y] = ymsh;
		        node_4[Z] = zmsh;

		        flag = node_process (node_1, node_2, node_1, node_4,
					                length, g_size, &dist_p, &len);
		        if (flag == OK && dist < G_factor*loc_size (msh_ptr))
		        {
		            /* set first active pointer, which satisfy the
		            the constraint
		            */
		            act_ptr = msh_ptr;
		            min_len = len;
		    }
	    }
	}
	else
	{
	    /* for fixed point if near enough .... Done */
	    xmsh = msh_ptr->Coor[X];
	    ymsh = msh_ptr->Coor[Y];
	    zmsh = msh_ptr->Coor[Z];

	    dist = sqrt ((xmsh-xsp)*(xmsh-xsp) + (ymsh-ysp)*(ymsh-ysp)
			    +(zmsh-zsp)*(zmsh-zsp));
	    if (dist < LOWTOL)
	    {
		    sp_ptr->status = DONE;
		    return (msh_ptr);
	    }
	}
	msh_ptr = msh_ptr->Next;
    }

    if (act_ptr == NULL)
    {
/* ziji 1/6/99	    printf ("\nWarning...No mesh node can fit SPoly node\n"); */
	    printf ("\nWarning...No mesh node can fit SPoly node\n");
		fprintf(fpzw, "\n\n=====find_nd_online:");
	    fprintf(fpzw, "\nWarning...No mesh node can fit SPoly node\n");
	    /* in this case the secondary active node could be a choice
	   force it to be a solution
	    */
	    if (act_2_ptr)
	    {
	        if (min_dist > G_factor*loc_size (act_2_ptr))
	        {
/* ziji 1/6/99	            printf ("\nWarning...Fitting distance greater than L_size!\n"); */
	            printf ("\nWarning...Fitting distance greater than L_size!\n");
				fprintf(fpzw, "\n\n=====find_nd_online:");
	            fprintf(fpzw, "\nWarning...Fitting distance greater than L_size!\n");
	            return (NULL);
	        }
/* Ziji 1/6/99	        printf ("\nForce it to  fit SPoly node\n"); */
	        printf ("\nForce it to  fit SPoly node\n");
			fprintf(fpzw, "\n\n=====find_nd_online:");
	        fprintf(fpzw, "\nForce it to  fit SPoly node\n");
	        /*
	        act_2_ptr->Coor[X] = xsp;
	        act_2_ptr->Coor[Y] = ysp;
	        act_2_ptr->Coor[Z] = zsp;
	        */
	        mov_pnt[X] = xsp;
	        mov_pnt[Y] = ysp;
	        mov_pnt[Z] = zsp;

	        sp_move (Bdy_node_head_ptr, Bdy_nodes,
			        Bdy_elem_head_ptr, Bdy_elem,
			        Msh_node_head_ptr, Msh_nodes,
			        Msh_elem_head_ptr, Msh_elem,
			        act_2_ptr, mov_pnt, 0);

	        act_2_ptr->status  = DONE;
	        sp_ptr->status = DONE;
	        act_ptr = act_2_ptr;
	    }
    }
    else
    {
	    /* find parameter u */
	    u = min_len /length;
	    /* move the node onto the constraint project to the line seg. */
	    /*
	    act_ptr->Coor[X] = node_1[X] + u*(node_2[X] - node_1[X]);
	    act_ptr->Coor[Y] = node_1[Y] + u*(node_2[Y] - node_1[Y]);
	    act_ptr->Coor[Z] = node_1[Z] + u*(node_2[Z] - node_1[Z]);
	    */
	    mov_pnt[X] = node_1[X] + u*(node_2[X] - node_1[X]);
	    mov_pnt[Y] = node_1[Y] + u*(node_2[Y] - node_1[Y]);
	    mov_pnt[Z] = node_1[Z] + u*(node_2[Z] - node_1[Z]);

	    sp_move (Bdy_node_head_ptr, Bdy_nodes,
			        Bdy_elem_head_ptr, Bdy_elem,
			        Msh_node_head_ptr, Msh_nodes,
			        Msh_elem_head_ptr, Msh_elem,
			        act_ptr, mov_pnt, 0);

	    act_ptr->status  = DONE; /* a specialty sp node should not be fixed */
	    /* lap_soomth (msh_n_head, n_msh_node, 3); */
	    sp_ptr->status = DONE;
    }

    return (act_ptr);
}



/* fit a start node which is the adjacent node of msh_nptr
	if can't find that kind of node just force node msh_nptr
	move to sp_n1_ptr.
*/


MeshNode *
fit_start_node (MeshNode *nptr, MeshNode *sp_n1_ptr,
		        MeshNode *sp_n2_ptr, REAL g_size)
{
    int      i, flag;
    REAL     node_1[3], node_2[3], node_4[3], length;
    REAL     min_dist, dist_p, mov_pnt[3];
    REAL     min_len, len, u;
    MeshNode *msh_ptr, *act_ptr;
    AdjList  *adptr;


    node_1[X] = sp_n1_ptr->Coor[X];
    node_1[Y] = sp_n1_ptr->Coor[Y];
    node_1[Z] = sp_n1_ptr->Coor[Z];

    node_2[X] = sp_n2_ptr->Coor[X];
    node_2[Y] = sp_n2_ptr->Coor[Y];
    node_2[Z] = sp_n2_ptr->Coor[Z];

    length = v_rang(node_1, node_2, 3);

    min_dist = 1.e10;
    act_ptr = NULL;

    adptr = nptr->Fst_adj;
    for (i=0; i<nptr->Num_adj; i++)
    {
	    msh_ptr = adptr->idx;

	    node_4[X] = msh_ptr->Coor[X];
	    node_4[Y] = msh_ptr->Coor[Y];
	    node_4[Z] = msh_ptr->Coor[Z];

	    flag = node_process (node_1, node_2, node_1, node_4,
			            length, g_size, &dist_p, &len);
	    if (msh_ptr->status != FIXED)
	    {
	        if (flag == OK && dist_p < G_factor*loc_size (msh_ptr) && 
                        dist_p < min_dist)
	        {
		        min_dist = dist_p;
		        /* set active pointer */
		        act_ptr = msh_ptr;
		        min_len = len;
	        }
	    }
	    else
	    {   /* fixed node on the constraint */
	        if (flag == OK && dist_p < LOWTOL)  return (msh_ptr);
	    }
	    adptr = adptr->ptr;
    }



    if (act_ptr == NULL)
    {
/* Ziji 1/6/99	    printf ("\nWarning...can't fit start SPoly node..\n"); */
	    printf ("\nWarning...can't fit start SPoly node..\n");
		fprintf(fpzw, "\n\n=====fit_start_node:");
	    fprintf(fpzw, "\nWarning...can't fit start SPoly node..\n");
	    if (nptr->status != FIXED)
	    {
	        node_4[X] = nptr->Coor[X];
	        node_4[Y] = nptr->Coor[Y];
	        node_4[Z] = nptr->Coor[Z];
	        if (v_rang(node_1, node_4, 3) < G_factor*loc_size (nptr))
	        {
/* ziji 1/6/99		        printf ("\nForce to fit it!\n"); */
		        printf ("\nForce to fit it!\n");
				fprintf(fpzw, "\n\n=====fit_start_node:");
		        fprintf(fpzw, "\nForce to fit it!\n");
		        /*
		        nptr->Coor[X] = node_1[X];
		        nptr->Coor[Y] = node_1[Y];
		        nptr->Coor[Z] = node_1[Z];
		        */
		        mov_pnt[X] = node_1[X];
		        mov_pnt[Y] = node_1[Y];
		        mov_pnt[Z] = node_1[Z];

		        sp_move (Bdy_node_head_ptr, Bdy_nodes,
			            Bdy_elem_head_ptr, Bdy_elem,
			            Msh_node_head_ptr, Msh_nodes,
			            Msh_elem_head_ptr, Msh_elem,
			            nptr, mov_pnt, 0);

		        nptr->status = DONE;
		        act_ptr = nptr;
	        }
	    }
    }
    else
    {
	    /* find parameter u */
	    u = min_len /length;
	    /* move the node onto the constraint project to the line seg. */
	    /*
	    act_ptr->Coor[X] = node_1[X] + u*(node_2[X] - node_1[X]);
	    act_ptr->Coor[Y] = node_1[Y] + u*(node_2[Y] - node_1[Y]);
	    act_ptr->Coor[Z] = node_1[Z] + u*(node_2[Z] - node_1[Z]);
	    */
	    mov_pnt[X] = node_1[X] + u*(node_2[X] - node_1[X]);
	    mov_pnt[Y] = node_1[Y] + u*(node_2[Y] - node_1[Y]);
	    mov_pnt[Z] = node_1[Z] + u*(node_2[Z] - node_1[Z]);

	    sp_move (Bdy_node_head_ptr, Bdy_nodes,
			    Bdy_elem_head_ptr, Bdy_elem,
			    Msh_node_head_ptr, Msh_nodes,
			    Msh_elem_head_ptr, Msh_elem,
			    act_ptr, mov_pnt, 0);


	    act_ptr->status  = DONE; /* a specialty sp node should not be fixed */
	    /* lap_soomth (msh_n_head, n_msh_node, 3); */
	    /* sp_ptr->status = DONE; */
    }

    return (act_ptr);

}




/* check duplicated node if yes return OK otherwise return BAD */
int 
duplicate_node (MeshNode *nptr1, MeshNode *nptr2)
{
    REAL node_1[3], node_2[3];

    node_1[X] = nptr1->Coor[X];
    node_1[Y] = nptr1->Coor[Y];
    node_1[Z] = nptr1->Coor[Z];

    node_2[X] = nptr2->Coor[X];
    node_2[Y] = nptr2->Coor[Y];
    node_2[Z] = nptr2->Coor[Z];

    if (v_rang (node_1, node_2, 3) < LOWTOL)   return (OK);
    else                                       return (0);


}


/* Ziji 1/20/99 */
/* move bdy node, which is also on a sp line, to bdy along the sp line */
int bdy_sp_move(MeshNode *node, MeshNode *sp_n1_ptr, MeshNode *sp_n2_ptr,
                BMeshNode *bdy_node_head, long bdy_num_node,
	            BMeshElem *bdy_elm_head, long bdy_num_elem)
{
	BMeshElem *belm;
	int       i, j, intrs;
	double    nd[3], sp1[3], sp2[3], a[3], b[3], c[3], cand[3], dist;
	double    pnt[3], ds;

	for (i=0; i<3; i++) {
		sp1[i] = sp_n1_ptr->Coor[i];
		sp2[i] = sp_n2_ptr->Coor[i];
		nd[i] = node->Coor[i];
	}

    dist = 1.e20;
	belm = bdy_elm_head;
	for (i=0; i<bdy_num_elem; i++)
	{
/* find if the patch has valid intersection with the sp line */
          for (j=0; j<3; j++) {
			  a[j] = belm->Elem.tri3.NodePtr[0]->Coor[j];
			  b[j] = belm->Elem.tri3.NodePtr[1]->Coor[j] - a[j];
			  c[j] = belm->Elem.tri3.NodePtr[2]->Coor[j] - a[j];
		  }
          intrs = line_tri_cross (sp1, sp2, a, b, c, pnt);
		  if ((intrs==INBOUND)||(intrs==ONEDGE)) {
/* calculate the distance between the intersection point and the candidate */
			  ds = 0.;
			  for (j=0; j<3; j++) ds += (pnt[j]-nd[j])*(pnt[j]-nd[j]);
			  if (ds<dist) {
/* closer, record in substitution array */
				  dist = ds;
				  for (j=0; j<3; j++) cand[j] = pnt[j];
			  }
		  }
		  else if (intrs==ONPLANE) {
			  node->status = FIXED;
              fprintf(fpzw, "\n\n===== bdy_sp_move:\n");
	          fprintf(fpzw, "mesh node with coordinates %lf %lf %lf\n", node->Coor[0],node->Coor[1],node->Coor[2]);
	          fprintf(fpzw, "  is on a bdy patch.\n");
              fprintf(fpzw, "The sp line is from %lf, %lf, %lf\n", sp1[0], sp1[1], sp1[2]);
	          fprintf(fpzw, "  to %lf, %lf, %lf\n", sp2[0], sp2[1], sp2[2]);
			  return (OK);
		  }
		belm = belm->Next;
	}

	if (dist==1.e20) return (BAD);

	fprintf(fpzw, "\n\n===== bdy_sp_move:\n");
	fprintf(fpzw, "mesh node with coordinates %lf %lf %lf\n", node->Coor[0],node->Coor[1],node->Coor[2]);
	fprintf(fpzw, "  has been moved to coordinates %lf %lf %lf\n\n", cand[0],cand[1],cand[2]);
	fprintf(fpzw, "The sp line is from %lf, %lf, %lf\n", sp1[0], sp1[1], sp1[2]);
	fprintf(fpzw, "  to %lf, %lf, %lf\n", sp2[0], sp2[1], sp2[2]);

    for (j=0; j<3; j++) node->Coor[j] = cand[j];
	node->status = FIXED;
	
	return (OK);
}
