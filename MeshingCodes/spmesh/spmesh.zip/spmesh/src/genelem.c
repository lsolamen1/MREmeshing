  
/*
  ************************************************************************
  *  genelem.c :     Generate brick/tets  element for the model          *
  *									                                     *
  *  Qingyang Zhang				   March. 31, 1995	                     *
  ************************************************************************
*/

#include <stdio.h>
#include <math.h>
#include <malloc.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"


/* define global varibles */
#include "defglb.h"

#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))

/*
** External Functions
*/
extern int alloc_error (char *str);
extern int mk_adjlist(MeshNode *n_head,long num_node, MeshElem *e_head, long num_elem); 
extern REAL tri_inscribed_r (REAL *nod_1, REAL *nod_2, REAL *nod_3);


/*
** Local Functions
*/
int gen_elem (BMeshNode *bdy_n_head, long bdy_num_node,
              BMeshElem *bdy_l_head, long bdy_num_elem,
              MeshNode **msh_n_head, long *msh_num_node,
              MeshElem **msh_l_head, long *msh_num_elem,
              REAL *g_size);
int create_hex8_elem (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
       long *g_el_num, MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type);
int create_delta_elem (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
       long *g_el_num, MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type);
int create_tet4_in_hex (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
       long *g_el_num, MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type);
int create_tet4_in_delta (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
                          long *g_el_num, MeshNode **nd_idx_ptr, 
                          long *glb_loc_map, int tet_type);


/* generate uniform brick element for the model defined by BDY data */
int
gen_elem (BMeshNode *bdy_n_head, long bdy_num_node,
	   BMeshElem *bdy_l_head, long bdy_num_elem,
	   MeshNode **msh_n_head, long *msh_num_node,
	   MeshElem **msh_l_head, long *msh_num_elem,
       REAL *g_size)
{
  REAL bxmin, bymin, bzmin, bxmax, bymax, bzmax;
  REAL min_size, max_size, act_size, dx, dy, dz;
  REAL *ruler_x, *ruler_y, *ruler_z;
  REAL x_size, y_size, z_size, sin60, shift_x, shift_y;
  REAL act_bd_xmin, act_bd_xmax, act_bd_ymin, act_bd_ymax;
  REAL act_bd_zmin, act_bd_zmax;
  long ii, g_nd_num, g_el_num, glb_loc_map[9];
  int  i, j, k, nx, ny, nz, tmp_nx, elem_type, tet_type, break_pattern=0;
  int  row_type;
  MeshElem *msh_l_curt_ptr;
  BMeshElem *beptr;
  BMeshNode *n_1, *n_2, *n_3;
  MeshNode *msh_n_curt_ptr, *nptr, **nd_idx_ptr;

  min_size = 1.e10;
  max_size = -1.e10;

  bxmin = BDxmin;   bymin = BDymin;   bzmin = BDzmin;
  bxmax = BDxmax;   bymax = BDymax;   bzmax = BDzmax;

#ifdef NORMALIZE_DATA
      /* since the bdy data has been normalized, but user should
         see the original size 
      */
    bxmin = bxmin / Norm_scale + Norm_orig[X];
    bymin = bymin / Norm_scale + Norm_orig[Y];
    bzmin = bzmin / Norm_scale + Norm_orig[Z];
    bxmax = bxmax / Norm_scale + Norm_orig[X];
    bymax = bymax / Norm_scale + Norm_orig[Y];
    bzmax = bzmax / Norm_scale + Norm_orig[Z];
#endif
  printf ("\n****** Bounding Box **********");
  printf ("\nXmin = %10.5lf, Ymin = %10.5lf, Zmin = %10.5lf", 
             bxmin, bymin, bzmin);
  printf ("\nXmax = %10.5lf, Ymax = %10.5lf, Zmax = %10.5lf\n", 
             bxmax, bymax, bzmax);

  /* find minimum and maximum inscribed circle diameters
     for BDY trianglar patch, the minimum value is a gauge
     to keep the detail described by BDY data won't be lost
     when the brick elements are generated
  */

  beptr = bdy_l_head;
  for (ii=0; ii<bdy_num_elem; ii++)
  {
    n_1 = beptr->Elem.tri3.NodePtr[0];
    n_2 = beptr->Elem.tri3.NodePtr[1];
    n_3 = beptr->Elem.tri3.NodePtr[2];

    act_size = 2. * tri_inscribed_r (n_1->Coor, n_2->Coor, n_3->Coor);

    if (act_size < min_size)       min_size = act_size;
    if (act_size > max_size)       max_size = act_size;
    beptr = beptr->Next;
  }

#ifdef NORMALIZE_DATA
      /* since the bdy data has been normalized, but user should
         see the original size 
      */
      min_size /= Norm_scale;
      max_size /= Norm_scale;
#endif
  /* determin active size (global size) to generate brick elem. */

/* Ziji Wu, 8/23/99  do
  {
      printf ("\nInput Element Type ((with cube building block)= 4 \n                    (with deltahedral block  )= 8) : "); */
	  printf("\n *** Currently, cube is not supported! Please always select 1 ***");
      printf ("\nInput Element Type (0 = (cube building block)\n                    1 = (deltahedral block)) : ");
      /* printf ("\nInput Element Type (4-node Tets= 4/ 8-node Brick= 8) : ");*/
      scanf ("%d", &elem_type);
/* Ziji Wu, 8/23/99 */
	  elem_type = HEX8;
/* Ziji Wu, 8/23/99      switch (elem_type)
      {
         case TET4:  G_factor = TET4_FACTOR; 
*/	             /*
                     printf ("\nPattern (0= Cube / 1= Deltahedraron) : ");
                     scanf  ("%d", &break_pattern);  
		         */
/* Ziji Wu, 8/23/99	             break_pattern = 0;
	             break; */                 /* set global size factor */
/* Ziji Wu, 8/23/99         case HEX8:  G_factor = HEX8_FACTOR; */
	             /* offer a choice for distored cube */
/* Ziji Wu, 8/23/99	             printf ("\n*** use Tetrahedron elem as final elem. pick 1! ***");
                 printf ("\n*** Cube does not support! Please always choose 1 ***");
                 printf ("\nPattern (0= Cube / 1= Deltahedraron) : ");
                 scanf  ("%d", &break_pattern); 
*/                 break_pattern = 1;     /* hard code it to deltahedron */
/* Ziji Wu, 8/23/99	             if (break_pattern == 1)    G_factor = TET4_FACTOR;
	             else                       G_factor = HEX8_FACTOR;
                 break;
         default:elem_type = 0;
      }
*/
      /*
      printf ("\nSet node moving factor (0.0-1.5)? [-1: default setting= %lf]: ", G_factor);
      scanf ("%lf", &mov_factor);
      if (mov_factor >= 0.0)    G_factor = mov_factor;
      */

/* Ziji Wu, 8/23/99
  } while (!elem_type);
*/

  /* set global */
  Build_blk_type = break_pattern == 1 ? DELTA_HEX : REGULAR_HEX;

  if (break_pattern == 1)
  {  /* deltahedran type  */
      printf ("\nInput Delta Size  [min:%10.5lf -- max:%10.5lf]: ",
	      min_size, max_size);
      scanf ("%lf", &act_size);

#ifdef NORMALIZE_DATA
      act_size *= Norm_scale;
#endif
       /* define increment in axis directions */
      sin60 = sin (60*DEG2RAD);

      /* 
      x_size = act_size;
      y_size = act_size * sin60;
      */
      
      /*z_size = act_size * sqrt (2./3.); */ /* sqrt (1 - (4./9.)*sin60*sin60); */
      
      /* to map to cube compatable */
      z_size = act_size;

      /* adjust active mesh size based on z_size to well fine bound in z direction */

      /* adjust the bounding box size to add one more level material buffer */
      /* make sure add same offset on cube case !!! */
      BDxmin -= act_size;      
      BDxmax += act_size;      
      BDymin -= act_size;
      BDymax += act_size;
      BDzmin -= act_size;
      BDzmax += act_size;


      /* find number of interval in z directions */
      nz = (int)((BDzmax - BDzmin)/z_size + 0.5);
      z_size = (BDzmax - BDzmin)/(REAL)nz;

      /* find real act_size */
      act_size = z_size / sqrt (2./3.);

      x_size = act_size;
      y_size = act_size * sin60;

      shift_x = 0.5 * x_size;
      shift_y = (1./3.) * act_size * sin60;

      /* define extended active bounding */
      act_bd_xmin = BDxmin - 1.0 * act_size;            /* try 1.5 ? */
      act_bd_xmax = BDxmax + 1.5 * act_size;
      act_bd_ymin = BDymin - (1./3.) * sin60 * act_size;  /* try 2/3 ? */
      act_bd_ymax = BDymax + (1./3.) * sin60 * act_size;
      act_bd_zmin = BDzmin;
      act_bd_zmax = BDzmax;

      /* find number of interval in x, y, z directions */
      dx = (act_bd_xmax - act_bd_xmin)/x_size - 
           (int)((act_bd_xmax - act_bd_xmin)/x_size);
      if (dx < 0.5)
	     nx = (int)((act_bd_xmax - act_bd_xmin)/x_size + 0.5)+1;
      else
         nx = (int)((act_bd_xmax - act_bd_xmin)/x_size + 0.5);

      dy = (act_bd_ymax - act_bd_ymin)/y_size - 
           (int)((act_bd_ymax - act_bd_ymin)/y_size);

      if (dy < 0.5)
	     ny = (int)((act_bd_ymax - act_bd_ymin)/y_size + 0.5)+1;
      else
         ny = (int)((act_bd_ymax - act_bd_ymin)/y_size + 0.5);

      /*
      dz = (act_bd_zmax - act_bd_zmin)/z_size - 
           (int)((act_bd_zmax - act_bd_zmin)/z_size);
      if (dz < 0.5)
	    nz = (int)((act_bd_zmax - act_bd_zmin)/z_size + 0.5)+1;
      else
         nz = (int)((act_bd_zmax - act_bd_zmin)/z_size + 0.5);
      */

      /* find number of nodes will be deployed in x, y, z directions */
      nx++;  ny++; nz++;

      printf ("\nIncrement : dx = %10.5lf, dy = %10.5lf, dz = %10.5lf\n", 
                             x_size, y_size, z_size);
      printf ("\nNodes in Axis direction: nx = %10d, ny = %10d, nz = %10d\n", 
                             nx, ny, nz);


      /* generate node coordinates for the deployed nodes */
      /* the new allocated array index start from 1 !! */
      nd_idx_ptr = (MeshNode **) malloc (sizeof (MeshNode *)*(nx*ny*nz+1));

      ruler_x = (REAL *) malloc (sizeof (REAL)*(nx+1));
      ruler_y = (REAL *) malloc (sizeof (REAL)*(ny+1));
      ruler_z = (REAL *) malloc (sizeof (REAL)*(nz+1));
      if (!ruler_x || !ruler_y || !ruler_z || !nd_idx_ptr)   alloc_error ("genelem-1");

      ruler_x[1] = act_bd_xmin;
      for (i=2; i<=nx; i++)    ruler_x[i] = ruler_x[i-1] + x_size;

      ruler_y[1] = act_bd_ymin;
      for (i=2; i<=ny; i++)    ruler_y[i] = ruler_y[i-1] + y_size;

      ruler_z[1] = act_bd_zmin;
      for (i=2; i<=nz; i++)    ruler_z[i] = ruler_z[i-1] + z_size;
      g_nd_num = 0;
      for (k=1; k<=nz; k++)
      {
	    for (j=1; j<=ny; j++)
        {
	        for (i=1; i<=nx; i++)
	        {
	            nptr = (MeshNode *) malloc (sizeof (MeshNode));

	            if (!nptr)	alloc_error ("genelem-2");
	            else
	            {
		            nptr->Fst_adj = NULL;
		            nptr->Num_adj = 0;
		            nptr->Fst_adj_elem = NULL;
		            nptr->Num_adj_elem = 0;
		            nptr->Mtrl = BAD;
		            nptr->status = nptr->in_zone = 0;
		            nptr->Prev = NULL;
		            nptr->Next = NULL;
	            }

	            if (g_nd_num == 0)
	            {  /* first node */
		            msh_n_curt_ptr = *msh_n_head = nptr;
	            }
	            else
	            {
		            /* set node link */
		            msh_n_curt_ptr->Next = nptr;
		            nptr->Prev = msh_n_curt_ptr;
		            msh_n_curt_ptr = nptr;
	            }

	            /* add shift here ! */
	            nptr->Coor[X] = ruler_x[i] - shift_x*imod(j+1,2) 
                                           + shift_x*imod(k+1,2);
	            nptr->Coor[Y] = ruler_y[j] + shift_y * imod (k+1, 2);
	            nptr->Coor[Z] = ruler_z[k];
	            nd_idx_ptr[g_nd_num+1] = nptr;
	            g_nd_num++;
	        }
        }
      }

    /* close the link */
    nptr->Next = *msh_n_head;
    (*msh_n_head)->Prev = nptr;

    /* pass total num. of nodes to global */
    *msh_num_node = g_nd_num;

    free ((char *)ruler_x);
    free ((char *)ruler_y);
    free ((char *)ruler_z);
    
  }
  else
  {   
      /* cubic type */
      printf ("\nInput Mesh Size  [min:%10.5lf -- max:%10.5lf]: ",
	      min_size, max_size);
      scanf ("%lf", &act_size);

#ifdef NORMALIZE_DATA
      act_size *= Norm_scale;
#endif

      /* find number of interval in x, y, z directions */
      nx = (int)((BDxmax - BDxmin)/act_size + 0.5);
      ny = (int)((BDymax - BDymin)/act_size + 0.5);
      nz = (int)((BDzmax - BDzmin)/act_size + 0.5);

      /* the length of the interval in x, y, z directions */
      dx = (BDxmax - BDxmin)/(REAL)nx;
      dy = (BDymax - BDymin)/(REAL)ny;
      dz = (BDzmax - BDzmin)/(REAL)nz;

      /* find number of nodes will be deployed in x, y, z directions */
      nx++;  ny++; nz++;

      printf ("\ndx = %10.5lf, dy = %10.5lf, dz = %10.5lf", dx, dy, dz);
      printf ("\nnx = %10d, ny = %10d, nz = %10d\n", nx, ny, nz);

      /* generate node coordinates for the deployed nodes */
      /* the new allocated array index start from 1 !! */
      nd_idx_ptr = (MeshNode **) malloc (sizeof (MeshNode *)*(nx*ny*nz+1));

      ruler_x = (REAL *) malloc (sizeof (REAL)*(nx+1));
      ruler_y = (REAL *) malloc (sizeof (REAL)*(ny+1));
      ruler_z = (REAL *) malloc (sizeof (REAL)*(nz+1));
      if (!ruler_x || !ruler_y || !ruler_z || !nd_idx_ptr)   alloc_error ("genelem-3");

      ruler_x[1] = BDxmin;
      for (i=2; i<=nx; i++)    ruler_x[i] = ruler_x[i-1] + dx;

      ruler_y[1] = BDymin;
      for (i=2; i<=ny; i++)    ruler_y[i] = ruler_y[i-1] + dy;

      ruler_z[1] = BDzmin;
      for (i=2; i<=nz; i++)    ruler_z[i] = ruler_z[i-1] + dz;
      g_nd_num = 0;
      for (k=1; k<=nz; k++)
      {
	    for (j=1; j<=ny; j++)
        {
	        for (i=1; i<=nx; i++)
	        {
	            nptr = (MeshNode *) malloc (sizeof (MeshNode));

	            if (!nptr)	alloc_error ("genelem-4");
	            else
	            {
		            nptr->Fst_adj = NULL;
		            nptr->Num_adj = 0;
		            nptr->Fst_adj_elem = NULL;
		            nptr->Num_adj_elem = 0;
		            nptr->Mtrl = BAD;
		            nptr->status = nptr->in_zone = 0;
		            nptr->Prev = NULL;
		            nptr->Next = NULL;
	            }

	            if (g_nd_num == 0)
	            {  /* first node */
		            msh_n_curt_ptr = *msh_n_head = nptr;
	            }
	            else
	            {
		            /* set node link */
		            msh_n_curt_ptr->Next = nptr;
		            nptr->Prev = msh_n_curt_ptr;
		            msh_n_curt_ptr = nptr;
	            }
	            nptr->Coor[X] = ruler_x[i];
	            nptr->Coor[Y] = ruler_y[j];
	            nptr->Coor[Z] = ruler_z[k];
	            nd_idx_ptr[g_nd_num+1] = nptr;
	            g_nd_num++;
	        }
        }
      }

      /* close the link */
      nptr->Next = *msh_n_head;
      (*msh_n_head)->Prev = nptr;

      /* pass total num. of nodes to global */
      *msh_num_node = g_nd_num;

      free ((char *)ruler_x);
      free ((char *)ruler_y);
      free ((char *)ruler_z);
  }
  

    printf ("\nDone On Node Deployment!\n");

    /* generate elements */
    /* add an attribute (int) to elem struct!! */

    if (break_pattern == 1)
    {  /* deltahedran type.  note that i, j, k index start from 1 */
        g_el_num = 0;
        for (k=1; k<nz; k++)
        {
            for (j=1; j<ny; j++)
            {
	            if (imod (j, 2) == 1)    
	            {
	                tmp_nx = nx - 1;        /* odd  row */
	                row_type = 0;           /* no shift row */
	            }
                else 
                {                    
                    tmp_nx = nx;            /* even row */
                    row_type = 1;           /* shifted row */
	            }
	            for (i=1; i<tmp_nx; i++)
	            {
	                /* set global and local node relation. the idx of glb_loc_map
                        start from 1 to following the convention of the node 
                        numbering. 
	                */
	                if (imod (k, 2) == 1) 
	                {  /* odd layer */
	                    tet_type = 1;       /* type I: regular coord. direction */
	                    if (row_type == 0)
		                {  /* no shift row */
		                    glb_loc_map[1] = nx*ny*(k-1)+nx*(j-1)+i+1;
		                    glb_loc_map[2] = nx*ny*(k-1)+nx*(j  )+i+2;
		                    glb_loc_map[3] = nx*ny*(k  )+nx*(j  )+i+2;
		                    glb_loc_map[4] = nx*ny*(k  )+nx*(j-1)+i+1;
		                    glb_loc_map[5] = nx*ny*(k-1)+nx*(j-1)+i;
		                    glb_loc_map[6] = nx*ny*(k-1)+nx*(j  )+i+1;
		                    glb_loc_map[7] = nx*ny*(k  )+nx*(j  )+i+1;
		                    glb_loc_map[8] = nx*ny*(k  )+nx*(j-1)+i;
		   
		                }
                        else
		                {  /* shifted row */
		                    glb_loc_map[1] = nx*ny*(k-1)+nx*(j-1)+i+1;
		                    glb_loc_map[2] = nx*ny*(k-1)+nx*(j  )+i+1;
		                    glb_loc_map[3] = nx*ny*(k  )+nx*(j  )+i+1;
		                    glb_loc_map[4] = nx*ny*(k  )+nx*(j-1)+i+1;
		                    glb_loc_map[5] = nx*ny*(k-1)+nx*(j-1)+i;
		                    glb_loc_map[6] = nx*ny*(k-1)+nx*(j  )+i;
		                    glb_loc_map[7] = nx*ny*(k  )+nx*(j  )+i;
		                    glb_loc_map[8] = nx*ny*(k  )+nx*(j-1)+i;
		   
                        }
	                }
	                else
	                {  /* even layer */
	                    tet_type = 2;       /* type II: rotated coord. direction */
	                    if (row_type == 0)
		                {  /* no shift row */
		                    glb_loc_map[1] = nx*ny*(k-1)+nx*(j  )+i+1;
		                    glb_loc_map[2] = nx*ny*(k-1)+nx*(j-1)+i;
		                    glb_loc_map[3] = nx*ny*(k  )+nx*(j-1)+i;
		                    glb_loc_map[4] = nx*ny*(k  )+nx*(j  )+i+1;
		                    glb_loc_map[5] = nx*ny*(k-1)+nx*(j  )+i+2;
		                    glb_loc_map[6] = nx*ny*(k-1)+nx*(j-1)+i+1;
		                    glb_loc_map[7] = nx*ny*(k  )+nx*(j-1)+i+1;
		                    glb_loc_map[8] = nx*ny*(k  )+nx*(j  )+i+2;
		                }
                        else
		                {  /* shifted row */

		                    glb_loc_map[1] = nx*ny*(k-1)+nx*(j  )+i;
		                    glb_loc_map[2] = nx*ny*(k-1)+nx*(j-1)+i;
		                    glb_loc_map[3] = nx*ny*(k  )+nx*(j-1)+i;
		                    glb_loc_map[4] = nx*ny*(k  )+nx*(j  )+i;
		                    glb_loc_map[5] = nx*ny*(k-1)+nx*(j  )+i+1;
		                    glb_loc_map[6] = nx*ny*(k-1)+nx*(j-1)+i+1;
		                    glb_loc_map[7] = nx*ny*(k  )+nx*(j-1)+i+1;
		                    glb_loc_map[8] = nx*ny*(k  )+nx*(j  )+i+1;
		   
                        }

	                }

                    switch (elem_type)
	                {
	                    case TET4: 
	                        create_tet4_in_delta (msh_l_head, &msh_l_curt_ptr, 
                                 &g_el_num, nd_idx_ptr, glb_loc_map, tet_type);
                            break;
		                case HEX8: 
			                create_delta_elem (msh_l_head, &msh_l_curt_ptr, 
                                 &g_el_num, nd_idx_ptr, glb_loc_map, tet_type);
                            break;
                        default: printf("\nError: Unknown elem. type(gen_elem)\n");
                            return (BAD);
	                }

	            }
            }
        }


        printf ("\nTotal element Number: %8ld; \n", g_el_num);
        /* close the link */
        msh_l_curt_ptr->Next = *msh_l_head;
        (*msh_l_head)->Prev = msh_l_curt_ptr;
    }
    else
    {  /* cube type */
        g_el_num = 0;
        for (k=1; k<nz; k++)
        {
            for (j=1; j<ny; j++)
            {
	            for (i=1; i<nx; i++)
	            {
	                /* set global and local node relation. the idx of glb_loc_map
                        start from 1 to following the convention of the node 
                        numbering. Currently for 8-node brick (node1-node8).
                        it can also be broken to 4-node tets according the type
                        (I or II) of the tets
                    */
               
	                glb_loc_map[1] = nx*ny*(k-1)+nx*(j-1)+i+1;
	                glb_loc_map[2] = nx*ny*(k-1)+nx*(j  )+i+1;
	                glb_loc_map[3] = nx*ny*(k  )+nx*(j  )+i+1;
	                glb_loc_map[4] = nx*ny*(k  )+nx*(j-1)+i+1;
	                glb_loc_map[5] = nx*ny*(k-1)+nx*(j-1)+i;
	                glb_loc_map[6] = nx*ny*(k-1)+nx*(j  )+i;
	                glb_loc_map[7] = nx*ny*(k  )+nx*(j  )+i;
	                glb_loc_map[8] = nx*ny*(k  )+nx*(j-1)+i;

	                /* determine the type of brick which will be breaken to tet. */
                    if((i+j+k)/2 == ((double)(i+j+k)/2.)) tet_type = 2; /* mod(*) =0 */
                    else                                  tet_type = 1;

                    switch (elem_type)
	                {
	                    case TET4: create_tet4_in_hex (msh_l_head, &msh_l_curt_ptr, 
                                 &g_el_num, nd_idx_ptr, glb_loc_map, tet_type);
                            break;
		                case HEX8: create_hex8_elem (msh_l_head, &msh_l_curt_ptr, 
                                 &g_el_num, nd_idx_ptr, glb_loc_map, tet_type);
                            break;
                        default: printf("\nError: Unknown elem. type(gen_elem)\n");
                            return (BAD);
	                }
	            }
            }
        }


        printf ("\nTotal element Number: %8ld; \n", g_el_num);
        /* close the link */
        msh_l_curt_ptr->Next = *msh_l_head;
        (*msh_l_head)->Prev = msh_l_curt_ptr;
    }
 

    /* pass total num. of elem.s to global */
    *msh_num_elem = g_el_num;

    free ((char *)nd_idx_ptr);

    *g_size = act_size;

    printf ("\nDone On Creating Element!\n");

    /* create node adjacent list ! */
    if (*msh_n_head != NULL)
      mk_adjlist (*msh_n_head, *msh_num_node, *msh_l_head, *msh_num_elem);

    printf ("\nDone On Creating Node adjacent list!\n");
    /* determine node attribute (material code and in/out) */


    /* eliminate the element outside of the BDY */

  return (OK);
}




/* create 8-node brick element */
int
create_hex8_elem (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
        long *g_el_num, MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type)
{

  MeshElem *eptr;
  MeshNode **nnptr;



    /* allocate memory for brick element */
    eptr = (MeshElem *) malloc (sizeof (MeshElem));
    if (!eptr)	alloc_error ("genelem-5");
    else
    {  
        eptr->E_type = HEX8;
		eptr->attr = tet_type;             
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
    }
    if (*g_el_num == 0)
    {  /* first elem */
		*msh_l_curt_ptr = *msh_l_head = eptr;
    }
    else
    {
		/* set elem. link */
		(*msh_l_curt_ptr)->Next = eptr;
		eptr->Prev = *msh_l_curt_ptr;
		*msh_l_curt_ptr = eptr;
    }
    nnptr = eptr->Elem.hex8.NodePtr;
    nnptr[0] = nd_idx_ptr[glb_loc_map[1]];
    nnptr[1] = nd_idx_ptr[glb_loc_map[2]];
    nnptr[2] = nd_idx_ptr[glb_loc_map[3]];
    nnptr[3] = nd_idx_ptr[glb_loc_map[4]];
    nnptr[4] = nd_idx_ptr[glb_loc_map[5]];
    nnptr[5] = nd_idx_ptr[glb_loc_map[6]];
    nnptr[6] = nd_idx_ptr[glb_loc_map[7]];
    nnptr[7] = nd_idx_ptr[glb_loc_map[8]];

    (*g_el_num)++;

    return (OK);
}






/* create 8-node deltahedron element */
int
create_delta_elem (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
        long *g_el_num, MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type)
{

  MeshElem *eptr;
  MeshNode **nnptr;



    /* allocate memory for brick element */
    eptr = (MeshElem *) malloc (sizeof (MeshElem));
    if (!eptr)	alloc_error ("genelem-6");
    else
    {  
        eptr->E_type = HEX8;
        /*  odd layer : 1 (type I:  regular coord.  
            even layer: 2 (type II: rotated coord.  
        */ 
		eptr->attr = tet_type;  
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
    }
    if (*g_el_num == 0)
    {  /* first elem */
		*msh_l_curt_ptr = *msh_l_head = eptr;
    }
    else
    {
		/* set elem. link */
		(*msh_l_curt_ptr)->Next = eptr;
		eptr->Prev = *msh_l_curt_ptr;
		*msh_l_curt_ptr = eptr;
    }
    nnptr = eptr->Elem.hex8.NodePtr;
    nnptr[0] = nd_idx_ptr[glb_loc_map[1]];
    nnptr[1] = nd_idx_ptr[glb_loc_map[2]];
    nnptr[2] = nd_idx_ptr[glb_loc_map[3]];
    nnptr[3] = nd_idx_ptr[glb_loc_map[4]];
    nnptr[4] = nd_idx_ptr[glb_loc_map[5]];
    nnptr[5] = nd_idx_ptr[glb_loc_map[6]];
    nnptr[6] = nd_idx_ptr[glb_loc_map[7]];
    nnptr[7] = nd_idx_ptr[glb_loc_map[8]];

    (*g_el_num)++;

    return (OK);
}









/* create five 4-node tets in a brick elem. region (given 8-node) */
int
create_tet4_in_hex (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, long *g_el_num, 
                  MeshNode **nd_idx_ptr, long *glb_loc_map, int tet_type)
{

  MeshElem *eptr;
  MeshNode **nnptr;
  
  int      i;
  /* given 8 nodes (local index 1-8) to break down into 5 tets according 
     to tet type 
  */
  static int type_I[5][4] = { {1, 3, 6, 8},
		                      {1, 3, 2, 6},
                              {1, 6, 5, 8}, 
                              {1, 4, 3, 8}, 
                              {3, 7, 6, 8}, 
                            };

  static int type_II[5][4] = { {2, 5, 4, 7},
		                       {1, 4, 2, 5},
                               {2, 6, 5, 7}, 
                               {2, 4, 3, 7}, 
                               {4, 7, 5, 8}, 
                            };
/*
  if (tet_type == 1)  idx = type_I;
  else                idx = type_II;
*/

  for (i=0; i<5; i++)
  {
              /* allocate memory for tetrahedra element */
    eptr = (MeshElem *) malloc (sizeof (MeshElem));
    if (!eptr)	alloc_error ("genelem-7");
    else
    {  
        eptr->E_type = TET4;
		eptr->attr = 0;             
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
    }

    if (*g_el_num == 0)
    {  /* first elem */
		*msh_l_curt_ptr = *msh_l_head = eptr;
    }
    else
    {
		/* set elem. link */
		(*msh_l_curt_ptr)->Next = eptr;
		eptr->Prev = *msh_l_curt_ptr;
		*msh_l_curt_ptr = eptr;
    }
    nnptr = eptr->Elem.tet4.NodePtr;
    if (tet_type == 1)
    {
	    nnptr[0] = nd_idx_ptr[glb_loc_map[type_I[i][0]]];
	    nnptr[1] = nd_idx_ptr[glb_loc_map[type_I[i][1]]];
	    nnptr[2] = nd_idx_ptr[glb_loc_map[type_I[i][2]]];
	    nnptr[3] = nd_idx_ptr[glb_loc_map[type_I[i][3]]];
    }
    else
    {
	    nnptr[0] = nd_idx_ptr[glb_loc_map[type_II[i][0]]];
	    nnptr[1] = nd_idx_ptr[glb_loc_map[type_II[i][1]]];
	    nnptr[2] = nd_idx_ptr[glb_loc_map[type_II[i][2]]];
	    nnptr[3] = nd_idx_ptr[glb_loc_map[type_II[i][3]]];
    }

    (*g_el_num)++;
  }	     
    

  return (OK);
}








/* create six 4-node tets in a deltahedra. region (given 8-node) */
int
create_tet4_in_delta (MeshElem **msh_l_head, MeshElem **msh_l_curt_ptr, 
                      long *g_el_num, MeshNode **nd_idx_ptr, 
                      long *glb_loc_map, int tet_type)
{

  MeshElem *eptr;
  MeshNode **nnptr;
  
  int      i;
  /* given 8 nodes (local index 1-8) to break down into six tets  */
  static int type_I[6][4] = { {1, 6, 5, 8},
		                      {2, 7, 4, 3},
                              {1, 7, 8, 4}, 
                              {1, 2, 7, 4}, 
                              {1, 8, 7, 6}, 
                              {1, 7, 2, 6}, 
                            };


  for (i=0; i<6; i++)
  {
        /* allocate memory for tetrahedra element */
	    eptr = (MeshElem *) malloc (sizeof (MeshElem));
	    if (!eptr)	alloc_error ("genelem-8");
	    else
	    {  
            eptr->E_type = TET4;
		    eptr->attr = 0;             
		    eptr->Mtrl_in = BAD;
		    eptr->Mtrl_out = BAD;
		    eptr->Prev = NULL;
		    eptr->Next = NULL;
	    }

	    if (*g_el_num == 0)
	    {  /* first elem */
		    *msh_l_curt_ptr = *msh_l_head = eptr;
	    }
	    else
	    {
		    /* set elem. link */
		    (*msh_l_curt_ptr)->Next = eptr;
		    eptr->Prev = *msh_l_curt_ptr;
		    *msh_l_curt_ptr = eptr;
	    }
	    nnptr = eptr->Elem.tet4.NodePtr;

	    nnptr[0] = nd_idx_ptr[glb_loc_map[type_I[i][0]]];
	    nnptr[1] = nd_idx_ptr[glb_loc_map[type_I[i][1]]];
	    nnptr[2] = nd_idx_ptr[glb_loc_map[type_I[i][2]]];
	    nnptr[3] = nd_idx_ptr[glb_loc_map[type_I[i][3]]];

       (*g_el_num)++;
    }	     
    

    return (OK);
}

















