 
/*
  ************************************************************************
  *  modefs.h :		 Modeler type definition			 *
  *									 *
  *  Qingyang Zhang				   Nov. 30, 1994	 *
  ************************************************************************
*/

/* Should include :
   basdefs.h
*/





/* cone structure */
typedef struct t_conedata {
	Vec 		cone_base;
	REAL		cone_base_radius;
	Vec		cone_apex;
	REAL		cone_apex_radius;
} ConeData;


/* Node structure */
typedef struct t_nodedata {
	Vec    Node;
	struct t_nodedata	*Prev;
	struct t_nodedata	*Next;
} NodeData;



/* ploygon structure */

typedef struct t_polydata {
	int	 npoints;
	NodeData *NodePtr;
	Vec	poly_normal;
} PolygonData;





/* ring structure */

typedef struct t_ringdata {
	Vec	ring_center;
	Vec	ring_normal;
	REAL	min_radius;
	REAL	max_radius;	/* ??actually store squared values ? No ?*/
} RingData;




/* sphere structure */

typedef struct t_spheredata {
	Vec	 sph_center;
	REAL	 sph_radius;	 /* actually store 1/radius */
	REAL	 sph_radius2;	 /* radius squared */
} SphereData;




/* tri patch structure */


typedef struct t_patchdata {
	NodeData *NodePtr[3];
	NodeData *NodeNormPtr[3];
	Vec	 Flatnorm;	/* place to store normal for tri-flat */
} TriData;





typedef union PrimUnion {
	PolygonData	Poly;
	ConeData	Cone;
	SphereData	Sphere;
	TriData		Tripat;
	RingData	Ring;
} PrimData;


typedef struct PrimType {
	int	 PrimType;	   /* primititive type */
	int	 BoolType;	   /* boolean type for set operation */
	PrimData Prim;		   /* union for primitive data */
	Matrix	 PrimMat;	   /* transforming matrix for primitive */
	struct	 PrimType *Prev;   /* primitive link list --- currently */
	struct	 PrimType *Next;   /*	it should be implemented in CSG tree */
} PRIMITIVE;			   /*	in the future !!!   */




typedef struct TransformType {
	REAL Scale;
	REAL DX;
	REAL DY;
	REAL DZ;
	REAL RotX;
	REAL RotY;
	REAL RotZ;
} TransForm;



typedef struct SurfaceType {
	Color	diff;		       /* diffuse */
	Color	spec;		       /* specular (reflected) */
	Color	amb;		       /* ambient */
	REAL	shine;		       /* specular spot exponent */
	Color	cshine;		       /* spec spot color */
	Color	trans;		       /* transparency */
	REAL	ior;		       /* index of refraction */
	REAL	fuzz;		       /* surface fuzz */
	int	texture;	       /* texture type */
} SurfData;



typedef struct ObjectType {
	int ID;
	unsigned     int Visible;
	SurfData     Surface;	    /* using pointer ?? not now */
	int	     num_prim;	    /* number of primitive */
	PRIMITIVE    *PrimTreePtr;	/* Primitive tree Ptr */
	TransForm    TransObj;	    /* Transform Parameters for Obj. */
	Matrix	     ObjMat;	    /* transform matrix for object */
	struct ObjectType *Prev;    /* object link list        */
	struct ObjectType *Next;
} ObjectData;






typedef struct mt_light {
	Vec	position;
	Vec	dir;
	Color	color;
	REAL	radius;	     /* radius/spherical, max_angle/spotlight */
	REAL	min_angle,	 /* angles for spot lights */
		max_angle;
	int	type;		/* what type is this? */
	int	illum;		/* how does the light fall off? ??*/
	int	flag;	      /* noshadows? nospec? */
	int	samples;	      /* num samples for spherical light ??*/
	struct mt_light	*next;	/* next light in list */
} M_Light;				       /* for modeler */

typedef struct mt_viewpoint {
	Vec	view_from;
	Vec	view_at;
	Vec	view_up;
	REAL	view_angle_x;
	REAL	view_angle_y;
	REAL	view_aspect;
	Matrix	vw_matrix;	  /* transforming matrix to view 1 */
} M_Viewpoint;					  /* for modeler */

typedef struct mt_camera {
	int	projection;	/* prospective:   / iso palle? */
	Vec	lens_i,		/* vectors across lens */
		lens_j;
	REAL	aperture,	/* radius of lens */
		focal_length;   /* how far away are we focussed */
	int	samples;	/* num samples for non-pinhole camera */
} M_Camera;

/*
	Clipping
*/

#define C_PLANE         (0x01)
#define C_SPHERE        (0x02)
#define C_CONE          (0x04)
#define C_INSIDE        (0x10)

typedef struct mt_clip {
	Vec	 center,
		 normal,
		 apex, base;
	REAL	 radius1, radius2, length;
	int	 type;
	struct	 mt_clip	 *next;
} M_Clip;

typedef struct mt_global_clip {
	M_Clip			 *clip;
	struct mt_global_clip	 *next;
} M_GlobalClip;




/* Boolean type is conflicting with Xt/Intrincis header file */

typedef struct SceneType {
	char FileName[81];
	int	      Render_type;	     /* Rendering Type : Wire/Ray */
	M_Viewpoint   Viewpt;
	M_Camera      Camera;
	int	      Num_light;
	M_Light       *LightListPtr;
	int	      Num_Clip; 	     /* ?? */
	M_GlobalClip  *GlobalClipPtr;	     /* ?? */
	int	      Num_Obj;		     /* Number of Object */
	ObjectData    *ObjListPtr;	     /* Object Link list Ptr */


	/* following are undecided members */
	int Start;			 /* ??? */
	int Stop;			 /* ??? */
	float Aspect;			 /* ??? */
	char Projection[32];		 /* ??? */
	Color Ambient;	/* ??? */
	Color Background;	 /* ??? */
	REAL Haze;
	char AntiAlias[32];
	int Threshold;
	REAL Aperture;
/*
	Boolean Jitter;
	Boolean NoShadows;
	Boolean NoExpTrans;
	Boolean Caustics;
*/
	int Depth;
} SceneData;

