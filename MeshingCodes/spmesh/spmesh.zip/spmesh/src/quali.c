/*
  ************************************************************************
  *  quali.c :     Mesh quality assessment                               *
  *                                                                      *
  *  Qingyang Zhang                Jan. 22, 1995                         *
  ************************************************************************
*/
#include <stdio.h>
#include <math.h>
#include <malloc.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

/*
** External Functions
*/
extern REAL sg_csp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
extern REAL sg_isp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL sg_ang(REAL *v, REAL *p1, REAL *p2, REAL *p3, int n);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern void v_cros(REAL *vec1, REAL *vec2, REAL *prod);
extern REAL v_dot(REAL *vec1, REAL *vec2, int n);
extern int v_norm(REAL *vec, int n);
extern int alloc_error (char *str);



/*
** Local Functions
*/
int mesh_assess (MeshElem *msh_l_head, long n_msh_elem,
                int jcb_flag, int vol_flag, int asp_flag,
                int skw_flag, int warp_flag, int qua_flag);
int  find_jacob (MeshElem *eptr);
REAL tet4_jacob (MeshNode **nnPtr);
REAL hex8_jacob (MeshNode **nnPtr);
void normal_coor (REAL *x, REAL *y, REAL *z, int st_idx, int end_idx);
int  find_volumn (MeshElem *eptr);
REAL tet4_volumn (MeshNode **nnPtr);
REAL tet4_vol (REAL *x, REAL *y, REAL *z);
REAL hex8_volumn (MeshNode **nnPtr);
int  find_aspect_ratio (MeshElem *eptr);
REAL tet4_asp (MeshNode **nnPtr);
REAL hex8_asp (MeshNode **nnPtr);
int  find_qulity (MeshElem *eptr);
int  find_skew_angle (MeshElem *eptr);
REAL tet4_skew (MeshNode **nnPtr);
REAL hex8_skew (MeshNode **nnPtr);
int  find_warpage (MeshElem *eptr);
REAL hex8_warp (MeshNode **nnPtr);
REAL quad_warp (REAL *p0, REAL *p1, REAL *p2, REAL *p3);
REAL elem_assess (MeshElem *eptr, int qulity_type);
REAL volumn_ratio (MeshElem *eptr);
REAL avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type);
int  quality_summary (MeshElem *msh_l_head, long n_msh_elem,
                    int jcb_flag, int vol_flag, int asp_flag,
                    int skw_flag, int warp_flag, int qua_flag);
void sort_slots (REAL *value, MeshElem *msh_l_head, long num_elem, REAL val_min, REAL val_max,
                    long *histo_slots, int num_histo_slot,
                    long *pie_slots, int num_pie_slot, 
                    double *pie_val_min, double *pie_val_max);
int  out_mesh_quali (MeshElem *msh_l_head, long n_msh_elem, char *fname);


/* define min-max pie chart slots. Notice that the value set 
   for Volumn are dummies because volumn of the element is not unity */
static double Qpie_val_min[DF_Q_PIE] = {0.00, 0.05, 0.15, 0.32, 0.45};
static double Qpie_val_max[DF_Q_PIE] = {0.05, 0.15, 0.32, 0.45, 1.00};
static double Vpie_val_min[DF_Q_PIE] = {0.00, 0.20, 0.40, 0.60, 0.80};
static double Vpie_val_max[DF_Q_PIE] = {0.20, 0.40, 0.60, 0.80, 1.00};
static double Apie_val_min[DF_Q_PIE] = {0.00, 0.20, 0.40, 0.60, 0.80};
static double Apie_val_max[DF_Q_PIE] = {0.20, 0.40, 0.60, 0.80, 1.00};
static double Jpie_val_min[DF_Q_PIE] = {0.00, 0.05, 0.15, 0.32, 0.45};
static double Jpie_val_max[DF_Q_PIE] = {0.05, 0.15, 0.32, 0.45, 1.00};
static double Spie_val_min[DF_Q_PIE] = {0.00, 0.40, 0.50, 0.65, 0.80};
static double Spie_val_max[DF_Q_PIE] = {0.40, 0.50, 0.65, 0.80, 1.00};
static double Wpie_val_min[DF_Q_PIE] = {0.00, 0.20, 0.40, 0.60, 0.80};
static double Wpie_val_max[DF_Q_PIE] = {0.20, 0.40, 0.60, 0.80, 1.00};

/* mesh quality assessment */
int
mesh_assess (MeshElem *msh_l_head, long n_msh_elem, 
            int jcb_flag, int vol_flag,  int asp_flag, 
            int skw_flag, int warp_flag, int qua_flag)
{
    long      ii;
    MeshElem  *cur_eptr;

    /* initialization */
    cur_eptr = msh_l_head;
    for (ii=0; ii<n_msh_elem; ii++)
    {
      /* temperary initialization (-999. means undefined) */
      cur_eptr->Quli.Qfactor = -999.;
      cur_eptr->Quli.Volumn = -999.;
      cur_eptr->Quli.Asp = -999.;
      cur_eptr->Quli.Jmin = -999.;
      cur_eptr->Quli.Skew = -999.;
      cur_eptr->Quli.Warp = -999.;
      /* cur_eptr->Quli.Lsize = -999.;  */
      cur_eptr = cur_eptr->Next;
    }

    /* assess jacobian determinent for each element */
    if (jcb_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find jacobian */
        find_jacob (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }


    /* assess volumn for each element */
    if (vol_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find volumn */
        find_volumn (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }


    /* assess aspect_ratio for each element */
    if (asp_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find aspect_ratio */
        find_aspect_ratio (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }


    /* access solid angle (skew angle) for each elem */
    if (skw_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find skew angle for each element */
        find_skew_angle (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }

    /* access element face warpage for each elem */
    if (warp_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find warping for each element */
        find_warpage (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }


    /* access the quality measurement of the elem */
    if (qua_flag)
    {
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
        /* find quality */
        find_qulity (cur_eptr);
        cur_eptr = cur_eptr->Next;
      }
    }

    /* Summary of mesh qualities */
    quality_summary (msh_l_head, n_msh_elem, jcb_flag, vol_flag, asp_flag,
                    skw_flag, warp_flag, qua_flag);

    /* out_mesh_quali (msh_l_head, n_msh_elem, "meshquli.out");  */


    return (OK);
}




/* find jacobian for given element */
int
find_jacob (MeshElem *eptr)
{

    switch (eptr->E_type)
    {
        case TET4:
           eptr->Quli.Jmin = tet4_jacob (eptr->Elem.tet4.NodePtr);
           break;
        case HEX8:
           eptr->Quli.Jmin = hex8_jacob (eptr->Elem.hex8.NodePtr);
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);

    }

    return (OK);
}




/* find jacobian for tetrahedra mesh element */
REAL
tet4_jacob (MeshNode **nnPtr)
{
    int   num_e, i, k;
    REAL  a1, a2, a3, b1, b2, b3, c1, c2, c3;
    REAL  x[5], y[5], z[5], tet_jaco;
    REAL  lmax, vmax, vec0[3], vec1[3], len;

  static REAL tet_factor = 1.414213562 / 12.;
  static int e_tet4_idx[6][2] = { {0, 1},  /* !! index start from 0 */
                  {1, 2},
                  {2, 0},
                  {3, 0},
                  {3, 1},
                  {3, 2}};




    /* node coordinates */
    /* the convention to define a tet: the first three node define a vector
       direction and points to the 4th node.
    */

    x[1] = nnPtr[0]->Coor[X];
    y[1] = nnPtr[0]->Coor[Y];
    z[1] = nnPtr[0]->Coor[Z];

    x[2] = nnPtr[1]->Coor[X];
    y[2] = nnPtr[1]->Coor[Y];
    z[2] = nnPtr[1]->Coor[Z];

    x[3] = nnPtr[2]->Coor[X];
    y[3] = nnPtr[2]->Coor[Y];
    z[3] = nnPtr[2]->Coor[Z];

    x[4] = nnPtr[3]->Coor[X];
    y[4] = nnPtr[3]->Coor[Y];
    z[4] = nnPtr[3]->Coor[Z];

    /* the convention to define a tet: the first three node define a vector
       direction and points off the 4th node. currently, the code generate
       tets with this convention.
    */
    /*
    x[1] = nnPtr[0]->Coor[X];
    y[1] = nnPtr[0]->Coor[Y];
    z[1] = nnPtr[0]->Coor[Z];

    x[3] = nnPtr[1]->Coor[X];
    y[3] = nnPtr[1]->Coor[Y];
    z[3] = nnPtr[1]->Coor[Z];

    x[2] = nnPtr[2]->Coor[X];
    y[2] = nnPtr[2]->Coor[Y];
    z[2] = nnPtr[2]->Coor[Z];

    x[4] = nnPtr[3]->Coor[X];
    y[4] = nnPtr[3]->Coor[Y];
    z[4] = nnPtr[3]->Coor[Z];
    */

    /* normal_coor (x, y, z, 1, 4);  */
    a1 = (y[1]-y[3])*(z[2]-z[3]) - (y[2]-y[3])*(z[1]-z[3]);
    a2 = (y[2]-y[3])*(z[4]-z[3]) - (y[4]-y[3])*(z[2]-z[3]);
    a3 = (y[4]-y[3])*(z[1]-z[3]) - (y[1]-y[3])*(z[4]-z[3]);

    b1 = (x[2]-x[3])*(z[1]-z[3]) - (x[1]-x[3])*(z[2]-z[3]);
    b2 = (x[4]-x[3])*(z[2]-z[3]) - (x[2]-x[3])*(z[4]-z[3]);
    b3 = (x[1]-x[3])*(z[4]-z[3]) - (x[4]-x[3])*(z[1]-z[3]);

    c1 = (x[1]-x[3])*(y[2]-y[3]) - (x[2]-x[3])*(y[1]-y[3]);
    c2 = (x[2]-x[3])*(y[4]-y[3]) - (x[4]-x[3])*(y[2]-y[3]);
    c3 = (x[4]-x[3])*(y[1]-y[3]) - (x[1]-x[3])*(y[4]-y[3]);
    /*
    a4 = -(a1+a2+a3);           
    b4 = -(b1+b2+b3);
    c4 = -(c1+c2+c3);
    */

    /* 
       Jacobian value of tet is six times its volume   V = 1/6 * J 
       use the longest size of tet. to find its pecfect tet's volume
       V = 1.414/12. * len^3    to make unity jacobian for tet element
    */

    /* return (((x[4]-x[3])*a1+(y[4]-y[3])*b1+(z[4]-z[3])*c1)/2.); */
    /* double check */

    tet_jaco = (x[4]-x[3])*a1+(y[4]-y[3])*b1+(z[4]-z[3])*c1;/* should 6*Vtet */

    lmax = -1.e10;
    num_e = 6;
    /* find max. (character) length of the element */
    for (i=0; i<num_e; i++)
    {
        for (k=0; k<3; k++)
        {
          vec0[k] = nnPtr[e_tet4_idx[i][0]]->Coor[k];
          vec1[k] = nnPtr[e_tet4_idx[i][1]]->Coor[k];
        }
        len = v_rang(vec0, vec1, 3);
        if (len > lmax)   lmax = len;
    }

   vmax = lmax*lmax*lmax;
   
   /* unify jacobian */

   tet_jaco = tet_jaco / (6 * tet_factor * vmax);

   return (tet_jaco); 

}




/* find jacobian for brick mesh element */
REAL
hex8_jacob (MeshNode **nnPtr)
{
     int  i, j;
     REAL x[9], y[9], z[9], n[9];  /* index: 1--8 for portable reason */
     REAL r, s, t, a11, a12, a13, jacob;
     REAL jmax, jmin, w1, w2, w3, w4;
     REAL dnr[9], dns[9], dnt[9];
     REAL value[8][3] = { { 1,  1,  1},
              {-1,  1,  1},
              {-1, -1,  1},
              { 1, -1,  1},
              { 1,  1, -1},
              {-1,  1, -1},
              {-1, -1, -1},
              { 1, -1, -1} 
            };

     jmax = -1.e10;
     jmin =  1.e10;

     for (i=0; i<8; i++)
     {
        x[i+1] = nnPtr[i]->Coor[X];
        y[i+1] = nnPtr[i]->Coor[Y];
        z[i+1] = nnPtr[i]->Coor[Z];
     }

     normal_coor (x, y, z, 1, 8);

     /* for different r, s, t [-1, +1] */
     for (j=0; j<8; j++)
     {
        r = value[j][0];
        s = value[j][1];
        t = value[j][2];

        n[1] = (1+r)*(1+s)*(1+t)/8.;
        n[2] = (1-r)*(1+s)*(1+t)/8.;
        n[3] = (1-r)*(1-s)*(1+t)/8.;
        n[4] = (1+r)*(1-s)*(1+t)/8.;
        n[5] = (1+r)*(1+s)*(1-t)/8.;
        n[6] = (1-r)*(1+s)*(1-t)/8.;
        n[7] = (1-r)*(1-s)*(1-t)/8.;
        n[8] = (1+r)*(1-s)*(1-t)/8.;

        /* derivative of shape functions */
        dnr[1] =  (1+s)*(1+t)/8.;
        dnr[2] = -(1+s)*(1+t)/8.;
        dnr[3] = -(1-s)*(1+t)/8.;
        dnr[4] =  (1-s)*(1+t)/8.;
        dnr[5] =  (1+s)*(1-t)/8.;
        dnr[6] = -(1+s)*(1-t)/8.;
        dnr[7] = -(1-s)*(1-t)/8.;
        dnr[8] =  (1-s)*(1-t)/8.;

        dns[1] =  (1+r)*(1+t)/8.;
        dns[2] =  (1-r)*(1+t)/8.;
        dns[3] = -(1-r)*(1+t)/8.;
        dns[4] = -(1+r)*(1+t)/8.;
        dns[5] =  (1+r)*(1-t)/8.;
        dns[6] =  (1-r)*(1-t)/8.;
        dns[7] = -(1-r)*(1-t)/8.;
        dns[8] = -(1+r)*(1-t)/8.;

        dnt[1] =  (1+r)*(1+s)/8.;
        dnt[2] =  (1-r)*(1+s)/8.;
        dnt[3] =  (1-r)*(1-s)/8.;
        dnt[4] =  (1+r)*(1-s)/8.;
        dnt[5] = -(1+r)*(1+s)/8.;
        dnt[6] = -(1-r)*(1+s)/8.;
        dnt[7] = -(1-r)*(1-s)/8.;
        dnt[8] = -(1+r)*(1-s)/8.;

        w1 = 0;
        for (i=1; i<=8; i++)  w1 += dns[i]*y[i];
        w2 = 0;
        for (i=1; i<=8; i++)  w2 += dnt[i]*z[i];
        w3 = 0;
        for (i=1; i<=8; i++)  w3 += dns[i]*z[i];
        w4 = 0;
        for (i=1; i<=8; i++)  w4 += dnt[i]*y[i];
        a11 = w1*w2 - w3*w4;

        w1 = 0;
        for (i=1; i<=8; i++)  w1 += dns[i]*z[i];
        w2 = 0;
        for (i=1; i<=8; i++)  w2 += dnt[i]*x[i];
        w3 = 0;
        for (i=1; i<=8; i++)  w3 += dns[i]*x[i];
        w4 = 0;
        for (i=1; i<=8; i++)  w4 += dnt[i]*z[i];
        a12 = w1*w2 - w3*w4;

        w1 = 0;
        for (i=1; i<=8; i++)  w1 += dns[i]*x[i];
        w2 = 0;
        for (i=1; i<=8; i++)  w2 += dnt[i]*y[i];
        w3 = 0;
        for (i=1; i<=8; i++)  w3 += dns[i]*y[i];
        w4 = 0;
        for (i=1; i<=8; i++)  w4 += dnt[i]*x[i];
        a13 = w1*w2 - w3*w4;

        w1 = 0;
        for (i=1; i<=8; i++)  w1 += dnr[i]*x[i];

        w2 = 0;
        for (i=1; i<=8; i++)  w2 += dnr[i]*y[i];

        w3 = 0;
        for (i=1; i<=8; i++)  w3 += dnr[i]*z[i];

        jacob = a11*w1 + a12*w2 +a13*w3;

        if (jacob < jmin)    jmin = jacob;
        if (jacob > jmax)    jmax = jacob;

    }

    /* for normalized mesh elem. its Jacobian should less than 1.
       but for this case (un-normalized elem.) it could great than 1.
    */

    /* if (jmax > 1.0)  printf ("\nElem. Jacobian = %10.4g\n", jmax); */
    return (jmin/0.125);
}



/* normalize the dimension */
void
normal_coor (REAL *x, REAL *y, REAL *z, int st_idx, int end_idx)
{
  int  i;
  REAL xmin, xmax, ymin, ymax, zmin, zmax, xlen, ylen, zlen, glen;

  xmin = ymin = zmin =  1.e10;
  xmax = ymax = zmax = -1.e10;

  /* find bounding box */
  for (i=st_idx; i<=end_idx; i++)
  {
    if (x[i] < xmin)  xmin = x[i];
    if (x[i] > xmax)  xmax = x[i];
    if (y[i] < ymin)  ymin = y[i];
    if (y[i] > ymax)  ymax = y[i];
    if (z[i] < zmin)  zmin = z[i];
    if (z[i] > zmax)  zmax = z[i];
  }
  /* find max. length of the box */
  xlen = xmax - xmin;
  glen = xlen;
  ylen = ymax - ymin;
  if (ylen > glen) glen = ylen;
  zlen = zmax - zmin;
  if (zlen > glen) glen = zlen;

  /* normalize to an unit cube */
  for (i=st_idx; i<=end_idx; i++)
  {
    x[i] = (x[i] - xmin) / glen;
    y[i] = (y[i] - ymin) / glen;
    z[i] = (z[i] - zmin) / glen;
  }

  
  return;
}






/* find volumn for given element */
int
find_volumn (MeshElem *eptr)
{

    switch (eptr->E_type)
    {
        case TET4:
           eptr->Quli.Volumn = tet4_volumn (eptr->Elem.tet4.NodePtr);
           break;
        case HEX8:
           eptr->Quli.Volumn = hex8_volumn (eptr->Elem.hex8.NodePtr);
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);

    }

    return (OK);
}



/* find volumn for tetrahedra mesh element */
REAL
tet4_volumn (MeshNode **nnPtr)
{
   int  i;
   REAL x[4], y[4], z[4];

   for (i=0; i<4; i++)
   {
     x[i] = nnPtr[i]->Coor[X];
     y[i] = nnPtr[i]->Coor[Y];
     z[i] = nnPtr[i]->Coor[Z];
   }

   return (tet4_vol (x, y, z));

}



/* given the coor. of 4 nodes find volumn of tet */
REAL
tet4_vol (REAL *x, REAL *y, REAL *z)
{
  REAL volumn;

  volumn = ((x[3]-x[0])*((y[3]-y[1])*(z[3]-z[2])-(y[3]-y[2])*(z[3]-z[1]))
       +(x[3]-x[2])*((y[3]-y[0])*(z[3]-z[1])-(y[3]-y[1])*(z[3]-z[0]))
       +(x[3]-x[1])*((y[3]-y[2])*(z[3]-z[0])-(y[3]-y[0])*(z[3]-z[2])))/6.;

  return (volumn);
}




/* find volumn for brick mesh element */
REAL
hex8_volumn (MeshNode **nnPtr)
{
  int  i, j;
  REAL volumn=0, x[4], y[4], z[4];

  /* given 8 nodes (local index 1-8) to break down into 5 tets according
     to tet type, here use type I breaking */
  static int type_I[5][4] = { {1, 3, 6, 8},
                  {1, 3, 2, 6},
                  {1, 6, 5, 8},
                  {1, 4, 3, 8},
                  {3, 7, 6, 8},
                };

  for (i=0; i<5; i++)
  {
     for (j=0; j<4; j++)
     {
        x[j] = nnPtr[type_I[i][j]-1]->Coor[X];
        y[j] = nnPtr[type_I[i][j]-1]->Coor[Y];
        z[j] = nnPtr[type_I[i][j]-1]->Coor[Z];
     }
     volumn += tet4_vol (x, y, z);
  }


  return (volumn);

}




/* find aspect ratio for given element */
int
find_aspect_ratio (MeshElem *eptr)
{

    switch (eptr->E_type)
    {
        case TET4:
           eptr->Quli.Asp = tet4_asp (eptr->Elem.tet4.NodePtr);
           break;
        case HEX8:
           eptr->Quli.Asp = hex8_asp (eptr->Elem.hex8.NodePtr);
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);
            return (BAD);

    }

    return (OK);
}



/* find aspect ratio (inscribed sphere raduis to circumsphere redius) */
REAL
tet4_asp (MeshNode **nnPtr)
{
    int  k;
    REAL pnt1[3], pnt2[3], pnt3[3], pnt4[3], pcen_in[3], pcen_curcum[3];
    REAL in_rad, circum_rad, asp_ratio;

    /* pass the coord. of the nodes of tetrahedra */
    for (k=0; k<3; k++) pnt1[k] = nnPtr[0]->Coor[k];
    for (k=0; k<3; k++) pnt2[k] = nnPtr[1]->Coor[k];
    for (k=0; k<3; k++) pnt3[k] = nnPtr[2]->Coor[k];
    for (k=0; k<3; k++) pnt4[k] = nnPtr[3]->Coor[k];

    /* find inscribed radius */
    in_rad     = sg_isp(pnt1, pnt2, pnt3, pnt4, pcen_in);
    /* find circumscribed radius */
    circum_rad = sg_csp(pnt1, pnt2, pnt3, pnt4, pcen_curcum);
    /* define aspect radio. times three make it unity */

    if (fabs (circum_rad) < HIGTOL)  return (0);
    asp_ratio = 3. * in_rad / circum_rad;

    return (asp_ratio);
}


/* find aspect ratio (the shortest to longest edges */
REAL
hex8_asp (MeshNode **nnPtr)
{
  int   i, k;
  REAL  len, lmin, lmax, vec0[3], vec1[3];
  static int e_hex8_idx[12][2] = { {0, 1},  /* !! index start from 0 */
                   {1, 2},
                   {2, 3},
                   {3, 0},
                   {4, 5},
                   {5, 6},
                   {6, 7},
                   {7, 4},
                   {0, 4},
                   {1, 5},
                   {2, 6},
                   {3, 7}};

  lmin =  1.e10;
  lmax = -1.e10;
  for (i=0; i<12; i++)
  {
    for (k=0; k<3; k++)
    {
        vec0[k] = nnPtr[e_hex8_idx[i][0]]->Coor[k];
        vec1[k] = nnPtr[e_hex8_idx[i][1]]->Coor[k];
    }
    len = v_rang(vec0, vec1, 3);
    if (len < lmin)   lmin = len;
    if (len > lmax)   lmax = len;
  }

  return (lmin / lmax);

}


/* determine the mesh quality :
  currently using volumn ratio from 0--1 (=1 perfect element) */
int
find_qulity (MeshElem *eptr)
{
    int      i, k, num_e;
    REAL     lmax, len, vmax, vec0[3], vec1[3];
    MeshNode **nnPtr;
    static REAL tet_factor = 12./1.414213562;
    static int e_tet4_idx[6][2] = { {0, 1},  /* !! index start from 0 */
                  {1, 2},
                  {2, 0},
                  {3, 0},
                  {3, 1},
                  {3, 2}};

  static int e_hex8_idx[12][2] = { {0, 1},  /* !! index start from 0 */
                   {1, 2},
                   {2, 3},
                   {3, 0},
                   {4, 5},
                   {5, 6},
                   {6, 7},
                   {7, 4},
                   {0, 4},
                   {1, 5},
                   {2, 6},
                   {3, 7}};

    lmax = -1.e10;

    switch (eptr->E_type)
    {
        case TET4:
           nnPtr = eptr->Elem.tet4.NodePtr;
           num_e = 6;
           /* find max. (character) length of the element */
           for (i=0; i<num_e; i++)
           {
                for (k=0; k<3; k++)
                {
                    vec0[k] = nnPtr[e_tet4_idx[i][0]]->Coor[k];
                    vec1[k] = nnPtr[e_tet4_idx[i][1]]->Coor[k];
                }
                len = v_rang(vec0, vec1, 3);
                if (len > lmax)   lmax = len;
           }

           /* eptr->Quli.Lsize = lmax; */
           vmax = lmax*lmax*lmax;
           if (eptr->Quli.Volumn == -999.)
           {
                printf ("\nError... Element Volumn Undefined!\n");
                return (BAD);
           }
           eptr->Quli.Qfactor = tet_factor * eptr->Quli.Volumn / vmax;
           break;
        case HEX8:
           nnPtr = eptr->Elem.hex8.NodePtr;
           num_e = 12;
           /* find max. (character) length of the element */
           for (i=0; i<num_e; i++)
           {
               for (k=0; k<3; k++)
               { 
                    vec0[k] = nnPtr[e_hex8_idx[i][0]]->Coor[k];
                    vec1[k] = nnPtr[e_hex8_idx[i][1]]->Coor[k];
               }
               len = v_rang(vec0, vec1, 3);
               if (len > lmax)   lmax = len;
           }

           /* eptr->Quli.Lsize = lmax;   */
           vmax = lmax*lmax*lmax;
           if (eptr->Quli.Volumn == -999.)
           {
                printf ("\nError... Element Volumn Undefined!\n");
                return (BAD);
           }
           eptr->Quli.Qfactor = eptr->Quli.Volumn / vmax;
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);
            return (BAD);

    }

    return (OK);

}


/* find solid angle (skew angle) */
int
find_skew_angle (MeshElem *eptr)
{
    switch (eptr->E_type)
    {
        case TET4:
           eptr->Quli.Skew = tet4_skew (eptr->Elem.tet4.NodePtr);
           break;
        case HEX8:
           eptr->Quli.Skew = hex8_skew (eptr->Elem.hex8.NodePtr);
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);
            return (BAD);

    }

    return (OK);
}


/* find solid angle for tetrahedra elements */
REAL
tet4_skew (MeshNode **nnPtr)
{
  int  i, j;
  REAL solid_ang, min_ang, v[3], p1[3], p2[3], p3[3];
  static int idx[4][4] = {  {0, 1, 2, 3},
                            {1, 2, 3, 0},
                            {2, 3, 0, 1},
                            {3, 0, 1, 2}}; 


  min_ang = 1.e10;
  for (i=0; i<4; i++)
  {
    for (j=0; j<3; j++)
    {
       v[j]  = nnPtr[idx[i][0]]->Coor[j];
       p1[j] = nnPtr[idx[i][1]]->Coor[j];
       p2[j] = nnPtr[idx[i][2]]->Coor[j];
       p3[j] = nnPtr[idx[i][3]]->Coor[j];
    }
    solid_ang = sg_ang(v, p1, p2, p3, 3); 
    if (solid_ang < min_ang)  min_ang = solid_ang;
  }
  return (min_ang/180.);   /* normorlize */

}



/* find solid angle for brick elements */
REAL
hex8_skew (MeshNode **nnPtr)
{
  int  i, j;
  REAL solid_ang, min_ang, v[3], p1[3], p2[3], p3[3];
  static int idx[8][4] = { {0, 1, 3, 4},
               {1, 5, 2, 0},
               {2, 1, 6, 3},
               {3, 2, 7, 0},
               {4, 0, 5, 7},
               {5, 1, 6, 4}, 
               {6, 7, 5, 2},
               {7, 4, 3, 6}}; 


  min_ang = 1.e10;
  for (i=0; i<8; i++)
  {
    for (j=0; j<3; j++)
    {
       v[j]  = nnPtr[idx[i][0]]->Coor[j];
       p1[j] = nnPtr[idx[i][1]]->Coor[j];
       p2[j] = nnPtr[idx[i][2]]->Coor[j];
       p3[j] = nnPtr[idx[i][3]]->Coor[j];
    }
    solid_ang = sg_ang(v, p1, p2, p3, 3);
    if (solid_ang < min_ang)  min_ang = solid_ang;
  }
  return (min_ang/270.);

}



/* find element face warpage for element */
int
find_warpage (MeshElem *eptr)
{
    switch (eptr->E_type)
    {
        case TET4:

           break;
        case HEX8:
           eptr->Quli.Warp = hex8_warp (eptr->Elem.hex8.NodePtr);
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);
            return (BAD);

    }

    return (OK);
}





/* find face warpage for brick elements */
REAL
hex8_warp (MeshNode **nnPtr)
{
  int  i, j;
  REAL max_warp, face_warp, p0[3], p1[3], p2[3], p3[3];
  static int face_idx[6][4] = { {0, 1, 2, 3},   /* node_index (0-7) */
                                {4, 5, 6, 7},
                                {0, 1, 5, 4}, 
                                {3, 2, 6, 7},
                                {1, 2, 6, 5},
                                {0, 3, 7, 4}};


  max_warp = -1.e10;
  for (i=0; i<6; i++)
  { /* for each face */
    for (j=0; j<3; j++)
    {
       p0[j] = nnPtr[face_idx[i][0]]->Coor[j];
       p1[j] = nnPtr[face_idx[i][1]]->Coor[j];
       p2[j] = nnPtr[face_idx[i][2]]->Coor[j];
       p3[j] = nnPtr[face_idx[i][3]]->Coor[j];
    }
    face_warp = quad_warp (p0, p1, p2, p3);

    /* printf ("\nface_warp = %12.6lf\n", face_warp); */
    if (max_warp < face_warp)  max_warp = face_warp;
  }
  return (max_warp);

}





/* find face warpage for quadratic element (plane in 3D space) */
REAL
quad_warp (REAL *p0, REAL *p1, REAL *p2, REAL *p3)
{
  int  i, id0, id1, id2, id3;
  REAL *pp[4], warp, sum_warp, len, sum_len;
  REAL vec1[3], vec2[3], vec3[3], norm[3];

  pp[0] = p0;  pp[1] = p1;  pp[2] = p2;  pp[3] = p3;

  sum_warp = 0.;
  sum_len  = 0.;
  /* find the warping for each possible set of plane and test point */
  for (i=0; i<4; i++)
  {
    id0 = i;
    id1 = (int)(fmod((double)(id0+1), 4.)+0.5);
    id2 = (int)(fmod((double)(id1+1), 4.)+0.5);
    id3 = (int)(fmod((double)(id2+1), 4.)+0.5);

    /* find the length of the edge */
    len = v_rang (pp[id0], pp[id1], 3);
    sum_len += len;
    /*find warping for point pp[id3] against plane pp[id0], pp[id1], pp[id2]*/
    /* make two vectors */
    v_make (pp[id1], pp[id0], 3, vec1);
    v_make (pp[id1], pp[id2], 3, vec2);
    /* determine a plane (normal vector) with these two vectors */
    v_cros(vec1, vec2, norm);
    v_norm(norm, 3);
    v_make (pp[id3], pp[id1], 3, vec3);
    warp = fabs (v_dot(vec3, norm, 3));

    if (warp < HIGTOL)   return (0.);  /* four points co-plane */

    sum_warp += warp;

    /* print out for debugging */
    /* printf ("i=%1d:  warp = %16.10lf,  len = %16.10lf;\n", i, warp, len);  */
  }
  /* find average warpage */
  warp = sum_warp / 4.;
  len  = sum_len  / 4.;

  warp /= len;


  return (warp);
}




/* mesh quality summary */
int
quality_summary (MeshElem *msh_l_head, long n_msh_elem,
                 int jcb_flag, int vol_flag, int asp_flag,
                 int skw_flag, int warp_flag, int qua_flag)
{
    int       k;
    long      ii;
    REAL      *quali_value=NULL, det_pie;
    MeshElem  *cur_eptr;

#ifndef MEMORY_SAVE 
    /* allocate working space */
    quali_value = (REAL *)malloc (sizeof (REAL) * n_msh_elem);
    if (!quali_value)   
    {
        ii = sizeof (REAL) * n_msh_elem;
	    printf ("\nCan't allocate a big chunk memory (%ld)\n Ignore quality summary information!\n",
		ii);
        return (-1);
    }
#endif

    /* summary of jacobian determinent */
    if (jcb_flag && n_msh_elem)
    {
      Jaco_mean = 0.;
      Jaco_min  =  1.e10;
      Jaco_max  = -1.e10;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
#ifndef MEMORY_SAVE 
            quali_value[ii] =  cur_eptr->Quli.Jmin;
#else
            cur_eptr->Quli.Warp = cur_eptr->Quli.Jmin;
#endif
            Jaco_mean += cur_eptr->Quli.Jmin;
            if (cur_eptr->Quli.Jmin < Jaco_min)   Jaco_min = cur_eptr->Quli.Jmin;
            if (cur_eptr->Quli.Jmin > Jaco_max)   Jaco_max = cur_eptr->Quli.Jmin;
            cur_eptr = cur_eptr->Next;
      }
      
      /* find mean value */
      Jaco_mean /= n_msh_elem;

      /* sort data and fill the slots of histogram and pie chart */
      sort_slots (quali_value, msh_l_head, n_msh_elem, Jaco_tick_min, Jaco_tick_max,
                    Jaco_histo_slots, num_Jaco_histo_slot,
                    Jaco_pie_slots, num_Jaco_pie_slot,
                    Jpie_val_min, Jpie_val_max);
    }


    /* summary of volumn */
    if (vol_flag && n_msh_elem)
    {
      V_mean = 0.;
      V_min  =  1.e10;
      V_max  = -1.e10;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
#ifndef MEMORY_SAVE
        quali_value[ii] =  cur_eptr->Quli.Volumn;
#else
        cur_eptr->Quli.Warp = cur_eptr->Quli.Volumn;
#endif
        V_mean += cur_eptr->Quli.Volumn;
        if (cur_eptr->Quli.Volumn < V_min)   V_min = cur_eptr->Quli.Volumn;
        if (cur_eptr->Quli.Volumn > V_max)   V_max = cur_eptr->Quli.Volumn;
        cur_eptr = cur_eptr->Next;
      }

      /* find mean value */
      V_mean /= n_msh_elem;
      /* sort data and fill the slots of histogram and pie chart */
      V_tick_min = V_min;   /* Volumn is not unity !! */
      V_tick_max = V_max;

      k = DF_Q_PIE;
      det_pie = (V_max - V_min) / (REAL)k;
      for (k=0; k<DF_Q_PIE; k++)
      {
           Vpie_val_min[k] = V_min + k * det_pie;
           Vpie_val_max[k] = V_min + (k+1) * det_pie;
      }

      sort_slots (quali_value, msh_l_head, n_msh_elem, V_tick_min, V_tick_max,
                    V_histo_slots, num_V_histo_slot,
                    V_pie_slots, num_V_pie_slot,
                    Vpie_val_min, Vpie_val_max);
    }



    /* summary of aspect_ratio determinent */
    if (asp_flag && n_msh_elem)
    {
      Asp_mean = 0.;
      Asp_min  =  1.e10;
      Asp_max  = -1.e10;
      Msh_elem_minq_ptr = NULL;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
#ifndef MEMORY_SAVE
        quali_value[ii] =  cur_eptr->Quli.Asp;
#else
        cur_eptr->Quli.Warp = cur_eptr->Quli.Asp;
#endif
        Asp_mean += cur_eptr->Quli.Asp;
        if (cur_eptr->Quli.Asp < Asp_min)   
        {
            Asp_min = cur_eptr->Quli.Asp;
            Msh_elem_minq_ptr = cur_eptr;
        }
        if (cur_eptr->Quli.Asp > Asp_max)   Asp_max = cur_eptr->Quli.Asp;
        cur_eptr = cur_eptr->Next;
      }
      
      /* find mean value */
      Asp_mean /= n_msh_elem;   
      /* sort data and fill the slots of histogram and pie chart */
      sort_slots (quali_value, msh_l_head, n_msh_elem, Asp_tick_min, Asp_tick_max,
                Asp_histo_slots, num_Asp_histo_slot,
                Asp_pie_slots, num_Asp_pie_slot,
                Apie_val_min, Apie_val_max);
    }


    /* summary of  solid angle (skew angle) */
    if (skw_flag && n_msh_elem)
    {
      Skw_mean = 0.;
      Skw_min  =  1.e10;
      Skw_max  = -1.e10;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
#ifndef MEMORY_SAVE
        quali_value[ii] =  cur_eptr->Quli.Skew;
#else
        cur_eptr->Quli.Warp = cur_eptr->Quli.Skew;
#endif
        Skw_mean += cur_eptr->Quli.Skew;
        if (cur_eptr->Quli.Skew < Skw_min)   Skw_min = cur_eptr->Quli.Skew;
        if (cur_eptr->Quli.Skew > Skw_max)   Skw_max = cur_eptr->Quli.Skew;
        cur_eptr = cur_eptr->Next;
      }

      /* find mean value */
      Skw_mean /= n_msh_elem;
      /* sort data and fill the slots of histogram and pie chart */
      sort_slots (quali_value, msh_l_head, n_msh_elem, Skw_tick_min, Skw_tick_max,
                Skw_histo_slots, num_Skw_histo_slot,
                Skw_pie_slots, num_Skw_pie_slot,
                Spie_val_min, Spie_val_max);
    }


#ifndef MEMORY_SAVE
    /* if defining MEMORY_SAVE, skip warping checking */
    /* summary of warpage */
    if (warp_flag && n_msh_elem)
    {
      Warp_mean = 0.;
      Warp_min  =  1.e10;
      Warp_max  = -1.e10;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
            if (cur_eptr->E_type == TET4)  quali_value[ii] = 0.;
            else                           quali_value[ii] =  cur_eptr->Quli.Warp;
            Warp_mean += quali_value[ii];
            if (quali_value[ii] < Warp_min)   Warp_min = quali_value[ii];
            if (quali_value[ii] > Warp_max)   Warp_max = quali_value[ii];
            cur_eptr = cur_eptr->Next;
      }

      /* find mean value */
      Warp_mean /= n_msh_elem;
      /* sort data and fill the slots of histogram and pie chart */
      sort_slots (quali_value, msh_l_head, n_msh_elem, Warp_tick_min, Warp_tick_max, 
                  Warp_histo_slots, num_Warp_histo_slot,
                  Warp_pie_slots, num_Warp_pie_slot,
                  Wpie_val_min, Wpie_val_max);
    }

#endif



    /* summary of quality measurement of the elem */
    if (qua_flag && n_msh_elem)
    {
      Q_mean = 0.;
      Q_min  =  1.e10;
      Q_max  = -1.e10;
      cur_eptr = msh_l_head;
      for (ii=0; ii<n_msh_elem; ii++)
      {
#ifndef MEMORY_SAVE
        quali_value[ii] =  cur_eptr->Quli.Qfactor;
#else
        cur_eptr->Quli.Warp = cur_eptr->Quli.Qfactor;
#endif
        Q_mean += cur_eptr->Quli.Qfactor;
        if (cur_eptr->Quli.Qfactor < Q_min)   Q_min = cur_eptr->Quli.Qfactor;
        if (cur_eptr->Quli.Qfactor > Q_max)   Q_max = cur_eptr->Quli.Qfactor;
        cur_eptr = cur_eptr->Next;
      }
      
      /* find mean value */
      Q_mean /= n_msh_elem;   
      /* sort data and fill the slots of histogram and pie chart */
      sort_slots (quali_value, msh_l_head, n_msh_elem, Q_tick_min, Q_tick_max,
                  Q_histo_slots, num_Q_histo_slot,
                  Q_pie_slots, num_Q_pie_slot,
                  Qpie_val_min, Qpie_val_max);
    }


#ifndef MEMORY_SAVE
  /* free working space */
  free ((char *)quali_value);
#endif

  return (OK);
}




/* sort data and count the number of data fall in each slot */
void
sort_slots (REAL *value, MeshElem *msh_l_head, long num_elem, REAL val_min, 
            REAL val_max, long *histo_slots, int num_histo_slot, 
            long *pie_slots, int num_pie_slot, double *pie_val_min,
            double *pie_val_max)
{
  int  j, ok_flag;
  long ii;
  REAL det_histo, det_pie, low_lim, up_lim;

#ifdef MEMORY_SAVE
  MeshElem  *cur_eptr;
#endif

#ifdef MEMORY_SAVE
  if (value)    printf ("Warning... value <> NULL for Memory Saving mode!\n");
#else
  if (value==NULL) printf ("Error... value ==NULL for Regular Mode!\n");
#endif

  /* initialization */
  for (j=0; j<num_histo_slot; j++)   histo_slots[j] = 0;
  for (j=0; j<num_pie_slot; j++)     pie_slots[j]   = 0;

  /* find Delta */
  det_histo = (val_max - val_min) / (REAL)num_histo_slot;
  det_pie   = (val_max - val_min) / (REAL)num_pie_slot;

  /* sorting the data */
#ifdef MEMORY_SAVE
  cur_eptr = msh_l_head;
#endif

  for (ii=0; ii<num_elem; ii++)
  {
    /* data value out-limit */
#ifndef MEMORY_SAVE
    if (value[ii] < val_min)
#else
    if (cur_eptr->Quli.Warp < val_min)
#endif
    {
      histo_slots[0]++;
      pie_slots[0]++;
      goto CON;  /* continue; */
    }

#ifndef MEMORY_SAVE
    if (value[ii] > val_max)
#else
    if (cur_eptr->Quli.Warp > val_max)
#endif
    {
      histo_slots[num_histo_slot - 1]++;
      pie_slots[num_pie_slot - 1]++;
      goto CON;   /* continue; */
    }

    ok_flag = BAD;
    /* sort for histogram */
    for (j=0; j<num_histo_slot; j++)
    {
      low_lim = val_min + j * det_histo - HIGTOL;
      up_lim  = val_min + (j+1) * det_histo + HIGTOL;

#ifndef MEMORY_SAVE
      if (value[ii] < low_lim || value[ii] > up_lim)                      continue;
#else
      if (cur_eptr->Quli.Warp < low_lim || cur_eptr->Quli.Warp > up_lim)  continue;
#endif
      else
      {
        ok_flag = OK;
        histo_slots[j]++;
        break;
      }
    }

    if (ok_flag != OK)
       printf ("\nWarnging...Element %ld histo sort undone!\n", ii);


    ok_flag = BAD;
    /* sort for pie chart */
    for (j=0; j<num_pie_slot; j++)
    {
      /* use non-even slot for pie chart
      low_lim = val_min + j * det_pie - HIGTOL;
      up_lim  = val_min + (j+1) * det_pie + HIGTOL;
      */
      low_lim = pie_val_min[j] - HIGTOL;
      up_lim  = pie_val_max[j] + HIGTOL;
     
#ifndef MEMORY_SAVE
      if (value[ii] < low_lim || value[ii] > up_lim)                      continue;
#else
      if (cur_eptr->Quli.Warp < low_lim || cur_eptr->Quli.Warp > up_lim)  continue;
#endif
      else
      {
        ok_flag = OK;
        pie_slots[j]++;
        break;
      }
    }
    if (ok_flag != OK)
       printf ("\nWarnging...Element %ld pie sort undone!\n", ii);

CON: ;
#ifdef MEMORY_SAVE
    cur_eptr = cur_eptr->Next; 
#endif

  }
  /* convert pie chart data to angles */


  return;
}



/* check quality for given element
   return related qulity
*/
REAL
elem_assess (MeshElem *eptr, int qulity_type)
{
    int  elem_type = eptr->E_type;
    REAL q_value = -9999;

    switch (qulity_type)
    {
        case VOLRAT:
            q_value = volumn_ratio (eptr);
            break;
        case VOLUME:
            switch (elem_type)
            {
                case TET4:
                    q_value = tet4_volumn (eptr->Elem.tet4.NodePtr);
                    break;
                case HEX8:
                    q_value = hex8_volumn (eptr->Elem.hex8.NodePtr);
                    break;
            }
            break;
        case ASPRAT:
            switch (elem_type)
            {
                case TET4:
                    q_value = tet4_asp (eptr->Elem.tet4.NodePtr);
                    break;
                case HEX8:
                    q_value = hex8_asp (eptr->Elem.hex8.NodePtr);
                    break;
            }
            break;
        case JACOB:
            switch (elem_type)
            {
                case TET4:
                    q_value = tet4_jacob (eptr->Elem.tet4.NodePtr);
                    break;
                case HEX8:
                    q_value = hex8_jacob (eptr->Elem.hex8.NodePtr);
                    break;
            }
            break;
        case SKWANG:
            switch (elem_type)
            {
                case TET4:
                    q_value = tet4_skew (eptr->Elem.tet4.NodePtr);
                    break;
                case HEX8:
                    q_value = hex8_skew (eptr->Elem.hex8.NodePtr);
                    break;
            }
            break;
        case WARPAGE:
            switch (elem_type)
            {
                case TET4:
                    q_value = 0.0;
                    break;
                case HEX8:
                    q_value = hex8_warp (eptr->Elem.hex8.NodePtr);
                    break;
            }
            break;
        default:
            printf ("\nWarning...Unknown qulity type (%d)\n", qulity_type);
    }
    return (q_value);
}



/* determine the mesh volumn retio
  currently using volumn ratio from 0--1 (=1 perfect element) */
REAL
volumn_ratio (MeshElem *eptr)
{
    int      i, k, num_e;
    REAL     lmax, len, vmax, vec0[3], vec1[3], q_ratio;
    MeshNode **nnPtr;
    static REAL tet_factor = 12./1.414213562;
    static int e_tet4_idx[6][2] = { {0, 1},  /* !! index start from 0 */
                  {1, 2},
                  {2, 0},
                  {3, 0},
                  {3, 1},
                  {3, 2}};

    static int e_hex8_idx[12][2] = { {0, 1},  /* !! index start from 0 */
                   {1, 2},
                   {2, 3},
                   {3, 0},
                   {4, 5},
                   {5, 6},
                   {6, 7},
                   {7, 4},
                   {0, 4},
                   {1, 5},
                   {2, 6},
                   {3, 7}};

    lmax = -1.e10;

    switch (eptr->E_type)
    {
        case TET4:
           nnPtr = eptr->Elem.tet4.NodePtr;
           num_e = 6;
           /* find max. (character) length of the element */
           for (i=0; i<num_e; i++)
           {
                for (k=0; k<3; k++)
                {
                    vec0[k] = nnPtr[e_tet4_idx[i][0]]->Coor[k];
                    vec1[k] = nnPtr[e_tet4_idx[i][1]]->Coor[k];
                }
                len = v_rang(vec0, vec1, 3);
                if (len > lmax)   lmax = len;
           }
           vmax = lmax*lmax*lmax;
           q_ratio = tet_factor * tet4_volumn (nnPtr) / vmax;
           break;
        case HEX8:
           nnPtr = eptr->Elem.hex8.NodePtr;
           num_e = 12;
           /* find max. (character) length of the element */
           for (i=0; i<num_e; i++)
           {
               for (k=0; k<3; k++)
               {
                    vec0[k] = nnPtr[e_hex8_idx[i][0]]->Coor[k];
                    vec1[k] = nnPtr[e_hex8_idx[i][1]]->Coor[k];
               }
               len = v_rang(vec0, vec1, 3);
               if (len > lmax)   lmax = len;
           }
           vmax = lmax*lmax*lmax;
           q_ratio = hex8_volumn (nnPtr) / vmax;
           break;
        default:
            printf ("\nWarning...Unknown elem. type (%3d)!\n", eptr->E_type);
            return (-9999);

    }

    return (q_ratio);

}

/*
   node related element qulity --- average quality of adjacent elements
   return min. jacob of adjacent element because jacob should be controled
   not to be less equal zero!
*/
REAL
avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type)
{
    int  num_elm = 0;
    REAL avg = 0., min_jacob = 1., jb;
    MeshElem *eptr;
    AdjElem *aeptr;

    aeptr = nptr->Fst_adj_elem;
    while (aeptr)
    {
        num_elm++;
        eptr = aeptr->idx;
        avg += elem_assess (eptr, qulity_type);
        jb = elem_assess (eptr, JACOB);
        if (jb < min_jacob)   min_jacob = jb;
        aeptr = aeptr->ptr;
    }
    /* find average */
    if (num_elm == nptr->Num_adj_elem)
    {
        if (num_elm)
            avg = avg / num_elm; 
        else
            printf ("\nZero adj. elem at the given node.\n");
    }
    else
            printf ("\nWarning... Adjacent element num. did not match %d (%d)!\n",
                num_elm, nptr->Num_adj_elem);

    *avg_q = avg;

    return (min_jacob);

}






/* print mesh quality parameters to output file */
int
out_mesh_quali (MeshElem *msh_l_head, long n_msh_elem, char *fname)
{
    int  j;
    FILE *qfout;

    MeshNode **nnptr;   // *nptr, 

    
    /* output file for debugging */

    
    long ii=0;
    //MeshElem *cur_eptr;
    
    
    qfout = fopen (fname, "wt");
    if (!qfout)
    {
        printf ("Can't open file %s  for output!\n", fname);
        return (BAD);
    }

    /*
    fprintf (qfout, "  No.      Qfactor    Volumn      Asp    Jacob(min)    Skew      Warpage\n");
    
    cur_eptr = msh_l_head;
    for (ii=0; ii<n_msh_elem; ii++)
    {
       
      fprintf (qfout, "%5ld %10.4g %16.10g %10.4g %10.4g %10.4g %10.4g\n",
            ii+1, cur_eptr->Quli.Qfactor, cur_eptr->Quli.Volumn,
            cur_eptr->Quli.Asp, cur_eptr->Quli.Jmin,
            cur_eptr->Quli.Skew, cur_eptr->Quli.Warp);
      
      cur_eptr = cur_eptr->Next;
    }
    */
    fprintf (qfout, "  No.      Aspect Ratio\n");
    fprintf (qfout, "%5ld %10.4g\n", ii+1, Msh_elem_minq_ptr->Quli.Asp);
    fprintf (qfout, "  Element Node Coor:\n");
    nnptr = Msh_elem_minq_ptr->Elem.tet4.NodePtr;
    for (j=0; j<4; j++)
    {
        fprintf (qfout, "   %4d %10.4g %10.4g %10.4g\n", j+1,
            nnptr[j]->Coor[X], nnptr[j]->Coor[Y], nnptr[j]->Coor[Z]); 
    }

    fprintf (qfout, "\n\n******* Summary of Mesh Qualities *******\n");
    fprintf (qfout, "\nOverall Mean Quality    [0-1]      : %16.10lf", Q_mean);
    fprintf (qfout, "\n****** Sub-items *******\n");
    fprintf (qfout, "Mean Element Volumn [%16.10lf -%16.10lf] : %16.10lf\n", 
         V_min, V_max, V_mean);
    fprintf (qfout, "Mean Jacobian       [%16.10lf -%16.10lf] : %16.10lf\n", 
         Jaco_min, Jaco_max, Jaco_mean);
    fprintf (qfout, "Mean Aspect Ratio   [%16.10lf -%16.10lf] : %16.10lf\n",
         Asp_min, Asp_max, Asp_mean);
    fprintf (qfout, "Mean Solid Angle    [%16.10lf -%16.10lf] : %16.10lf\n",
         Skw_min, Skw_max, Skw_mean);
    fprintf (qfout, "Mean Warpage        [%16.10lf -%16.10lf] : %16.10lf\n",
         Warp_min, Warp_max, Warp_mean);

    fprintf (qfout, "\n\n********* Pie Chart Data ***********\n");
    fprintf (qfout, "\n ********* Mesh Quality **********\n");
    for (j=0; j<num_Q_pie_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Q_pie_slots[j]);

    fprintf (qfout, "\n ********* Element Volumn **********\n");
    for (j=0; j<num_V_pie_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, V_pie_slots[j]);

    fprintf (qfout, "\n ********* Aspect Ratio **********\n");
    for (j=0; j<num_Asp_pie_slot; j++)
        fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Asp_pie_slots[j]);

    fprintf (qfout, "\n ********* Jacobian  **********\n");
    for (j=0; j<num_Jaco_pie_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Jaco_pie_slots[j]);

    fprintf (qfout, "\n ********* Solid Angle **********\n");
    for (j=0; j<num_Skw_pie_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Skw_pie_slots[j]);

#ifndef MEMORY_SAVE 
    fprintf (qfout, "\n ********* Warpage **********\n");
    for (j=0; j<num_Warp_pie_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Warp_pie_slots[j]);
#endif    

    fprintf (qfout, "\n\n********* Histogram Data ***********\n");
    fprintf (qfout, "\n ********* Mesh Quality **********\n");
    for (j=0; j<num_Q_histo_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Q_histo_slots[j]);

    fprintf (qfout, "\n ********* Element Volumn **********\n");
    for (j=0; j<num_V_histo_slot; j++)
        fprintf (qfout, "Slot %3d ------ %ld\n", j+1, V_histo_slots[j]);

    fprintf (qfout, "\n ********* Aspect Ratio **********\n");
    for (j=0; j<num_Asp_histo_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Asp_histo_slots[j]);

    fprintf (qfout, "\n ********* Jacobian  **********\n");
    for (j=0; j<num_Jaco_histo_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Jaco_histo_slots[j]);

    fprintf (qfout, "\n ********* Solid Angle **********\n");
    for (j=0; j<num_Skw_histo_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Skw_histo_slots[j]);

#ifndef MEMORY_SAVE    
    fprintf (qfout, "\n ********* Warpage **********\n");
    for (j=0; j<num_Warp_histo_slot; j++)
    fprintf (qfout, "Slot %3d ------ %ld\n", j+1, Warp_histo_slots[j]);
#endif

    fclose (qfout); 

    return (OK);
}


