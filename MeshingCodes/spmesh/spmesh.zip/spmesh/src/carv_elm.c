/*  
  ************************************************************************
  *  carv_elm.c : Carve out element with high connectivity and remesh it *
  *									 *
  *  Qingyang Zhang				   July 16, 1995	 *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>



#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"


/*
** External Functions
*/



/*
** Local Functions
*/

long remove_hi_conn (MeshNode **msh_n_head, long *msh_num_node,
		    MeshElem **msh_l_head, long *msh_num_elem,
		    int max_adj);
int extract_bdy (MeshNode *nptr, AdjElem *fst_adj_elem, int num_adj_elem,
	         MeshNode **bdy_node, int *num_bdy_node,
	         int bdy_conn[100][3], int *num_bdy_elem);
int node_count (MeshNode *nptr, MeshNode **bdy_node, int *n_node);



/*
** Global Variables
*/



/*
** Local Variables
*/


/*
   Carve out the element with high connectivity to a mesh
   node and output a closed local boundary tri-path
   (a node list and bdy connectivity) for remeshing
   Here use same node structure (MeshNode) for carved out 
   BDY. and Mesh node since it has only limited node number
   for carved out.
   ----- for TET4 element ------
   return: the number of high connective elements
*/

long
remove_hi_conn (MeshNode **msh_n_head, long *msh_num_node,
		MeshElem **msh_l_head, long *msh_num_elem,
		int max_adj)
{
    char      fnod[80], felmbd[80], fnodbd[80], str_num[80];
    FILE      *fout;
    int       k, num_bdy_node, num_bdy_elem, flag, sign, dec;
    int       bdy_conn[100][3];
    long      ii, tmp_node_num, tmp_elem_num, num_hi_conn=0;
    REAL      xx, yy, zz;
    MeshNode  *nptr, *tmp_n_head;
    MeshNode  *bdy_node[300];
    MeshElem  *tmp_l_head;

    tmp_node_num = *msh_num_node;
    tmp_elem_num = *msh_num_elem;
    tmp_n_head   = *msh_n_head;
    tmp_l_head   = *msh_l_head;

    nptr = tmp_n_head;
    for (ii=0; ii< *msh_num_node; ii++)
    {
	if (nptr->Num_adj_elem > max_adj)
	{
	    /* high connectivity */
	    flag = extract_bdy (nptr, nptr->Fst_adj_elem, nptr->Num_adj_elem,
			 bdy_node, &num_bdy_node, bdy_conn, &num_bdy_elem);
	    if (flag==OK)
	    {
	       num_hi_conn++;

	       /* call 3D delauney local meshing */

               /* for testing dump first 10  node files and boundary files.
                  for delauney 3d code.
                  Now the node file and bdy node file are the same, but
                  node file could be changed late on to add some middle
                  nodes.
               */

               if (num_hi_conn > 10)   goto CON;

               /* create node file */
               strcpy (fnod, "testnd");
               strcpy (str_num, fcvt ((double)num_hi_conn, 1, &dec, &sign)); 
               strcat (fnod, str_num);
               strcat (fnod, ".nod");
               fout = fopen (fnod, "w+t");

	       /* no middle node */
               
               fprintf (fout, "     1      %d\n", num_bdy_node);
               for (k=0; k<num_bdy_node; k++)
               {
                   xx = bdy_node[k]->Coor[X];
                   yy = bdy_node[k]->Coor[Y];
                   zz = bdy_node[k]->Coor[Z];
                   fprintf (fout, "%8d %12.6lf %12.6lf %12.6lf\n", 
                            k+1, xx, yy, zz); 
               }
               

	       /* with original middle node at the end */
	       /*
               fprintf (fout, "     1      %d\n", num_bdy_node+1);
               for (k=0; k<num_bdy_node; k++)
               {
                   xx = bdy_node[k]->Coor[X];
                   yy = bdy_node[k]->Coor[Y];
                   zz = bdy_node[k]->Coor[Z];
                   fprintf (fout, "%8d %12.6lf %12.6lf %12.6lf\n", 
                            k+1, xx, yy, zz); 
               }
               xx = nptr->Coor[X];
               yy = nptr->Coor[Y];
               zz = nptr->Coor[Z];
	       */

               fprintf (fout, "%8d %12.6lf %12.6lf %12.6lf\n", 
                            num_bdy_node+1, xx, yy, zz); 
 	       

               fclose (fout);

               /* create boundary node file */
               strcpy (fnodbd, "testbd");
               strcpy (str_num, fcvt ((double)num_hi_conn, 1, &dec, &sign)); 
               strcat (fnodbd, str_num);
               strcat (fnodbd, ".nod");
               fout = fopen (fnodbd, "w+t");
               fprintf (fout, "     1      %d\n", num_bdy_node);
               for (k=0; k<num_bdy_node; k++)
               {
                   xx = bdy_node[k]->Coor[X];
                   yy = bdy_node[k]->Coor[Y];
                   zz = bdy_node[k]->Coor[Z];
                   fprintf (fout, "%8d %12.6lf %12.6lf %12.6lf\n", 
                            k+1, xx, yy, zz); 
               }
               fclose (fout);

               /* create boundary elem file */
               strcpy (felmbd, "testbd");
               strcpy (str_num, fcvt ((double)num_hi_conn, 1, &dec, &sign)); 
               strcat (felmbd, str_num);
               strcat (felmbd, ".elm");
               fout = fopen (felmbd, "w+t");
               fprintf (fout, "1    3    0   %d\n", num_bdy_elem);
               for (k=0; k<num_bdy_elem; k++)
               {
                   fprintf (fout, "%8d %8d %8d %8d\n", k+1,  
                       bdy_conn[k][0]+1,  bdy_conn[k][1]+1, bdy_conn[k][2]+1); 
               }
               fclose (fout);

	       /* merge the local mesh to Global mesh */

	       /* fix node connectivity and mesh connectivity */
	    }
	}

CON:	nptr = nptr->Next;
    }

    *msh_num_node = tmp_node_num;
    *msh_num_elem = tmp_elem_num;
    *msh_n_head   = tmp_n_head;
    *msh_l_head   = tmp_l_head;

    return (num_hi_conn);
}





/* given central node with high connectivity and extract a closed
   tri-patch bdy surface
*/
int
extract_bdy (MeshNode *nptr, AdjElem   *fst_adj_elem, int num_adj_elem,
	     MeshNode **bdy_node, int *num_bdy_node,
	     int bdy_conn[100][3], int *num_bdy_elem)
{
    int i, j, k, n_node=0, n_elem=0, done_flag, patch_idx[3];
    MeshNode **nnptr;
    MeshElem *eptr;
    AdjElem  *aeptr;

    static int elm_nd_idx [4][3] = { {1, 3, 2},
				     {0, 2, 3},
				     {0, 3, 1},
				     {0, 1, 2} };

    /* serach elements adjacent to given node */
    aeptr = fst_adj_elem;
    for (i=0; i<num_adj_elem; i++)
    {
	done_flag = BAD;
	eptr = aeptr->idx;
	nnptr = eptr->Elem.tet4.NodePtr;
	for (j=0; j<4; j++)
	{
	    if (nptr == nnptr[j])
	    {
	        /* found the vertex (central node) which is jth node in elem.*/
		done_flag = OK;
		break;
	    }
	}

	if (done_flag == OK)
	{
	   /* fill node list and return the node index */
	   for (k=0; k<3; k++)
	      patch_idx[k] = node_count (nnptr[elm_nd_idx [j][k]],
					 bdy_node, &n_node);
	   for (k=0; k<3; k++)  bdy_conn[n_elem][k] = patch_idx[k];
	   n_elem++;
	   if (n_elem > 100)
	   {
		printf ("\nWarning... Total elem. num great than 100! \n");
		return (BAD);
	   }
	}
	else
	    printf ("\nWarning...Can't match node in the element!\n");

	aeptr = aeptr->ptr;
    }

    *num_bdy_node = n_node;
    *num_bdy_elem = n_elem;

    return (OK);
}



/* fill node list and return node index */
int
node_count (MeshNode *nptr, MeshNode **bdy_node, int *n_node)
{
    int i;

    for (i=0; i < *n_node; i++)
	if (nptr == bdy_node[i])   return (i);

    if (*n_node > 299)
    {
	printf ("\nWarning... Total num. of node great than 300!\n");
	return (*n_node);
    }
    bdy_node[*n_node] = nptr;
    return ( (*n_node)++ );
}






