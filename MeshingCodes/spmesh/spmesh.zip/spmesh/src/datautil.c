  
/*
  ************************************************************************
  *  datautil.c :     Data Operation utility routine			 *
  *									 *
  *  Qingyang Zhang				   Jan. 10, 1995	 *
  ************************************************************************
*/


#include <stdio.h>
#include <malloc.h>
#include <math.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"
#include "adt.h"




/*
** External Functions
*/
extern int	alloc_error (char *str);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);


/*
** Local Functions
*/
int is_dl_empty (DOUBLE_LINK *pole);
int create_dl_list (DOUBLE_LINK *pole);
int add_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, REAL wt, REAL len, DOUBLE_LINK *dad);
int append_dl_list (DOUBLE_LINK *pole, DOUBLE_LINK *new_dlptr);
int search_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, DOUBLE_LINK **dlptr);
int cp_dl_list (DOUBLE_LINK *source_pole, DOUBLE_LINK *distin_pole);
DOUBLE_LINK *extract_min (DOUBLE_LINK *pole);
DOUBLE_LINK *pop_dl_head (DOUBLE_LINK *pole);
int back_dl_step (DOUBLE_LINK *pole);
int free_dl_list (DOUBLE_LINK *pole);
STACKCELL *create_stack (STACKCELL *top);
struct stackinfo pop (STACKCELL **top);
int push (STACKCELL **top, struct stackinfo value);
int is_empty (STACKCELL *top);
int free_stack (STACKCELL **top);
REAL loc_size (MeshNode *in_node);


/* create a double link list */
int
create_dl_list (DOUBLE_LINK *pole)
{
    pole->Prev = pole->Next = pole->Dad = NULL;
    pole->nptr = NULL;
    pole->weight = pole->len = 0.0;
    return (OK);
}



/* test empty double link list */
int
is_dl_empty (DOUBLE_LINK *pole)
{
    if (pole->Next == NULL && pole->Prev == NULL)
	return (OK);
    else
	return (0);

}







/* add into double link list at tail assign a new memory */
int
add_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, REAL wt, REAL len,
	     DOUBLE_LINK *dad)
{
    DOUBLE_LINK *dl_cell;

    dl_cell = (DOUBLE_LINK *) malloc (sizeof (DOUBLE_LINK));
    if (!dl_cell)   alloc_error ("datautil-1");
    else
    {
	dl_cell->nptr   = nptr;
	dl_cell->weight = wt;
	dl_cell->len    = len;
	dl_cell->Dad    = dad;

	/* set up the link */
	if (pole->Prev != NULL || pole->Next != NULL)
	{
	    pole->Prev->Next = dl_cell;    /* attach to end of the list */
	    dl_cell->Prev   = pole->Prev;
	    dl_cell->Next   = NULL;
	    pole->Prev      = dl_cell;     /* new node is the last one */
	}
	else
	{
	    /* empty link list */
	    /* new node is the first one */
	    pole->Prev = pole->Next = dl_cell;
	    dl_cell->Prev = dl_cell->Next = NULL;
	    pole->weight = 0.0;

	}
	/* find sum of the weight of the double link list */
	pole->weight += wt;
    }
    return (OK);
}


/* add into double link list at tail using existed memory */
int
append_dl_list (DOUBLE_LINK *pole, DOUBLE_LINK *new_dlptr)
{

    if (!new_dlptr)
    {
	printf ("\nError... Null ptr. can't append !\n");
	return (BAD);
    }
    else
    {
	/* set up the link */
	if (pole->Prev != NULL || pole->Next != NULL)
	{   /* append to end of list and new node is the last one */
	    pole->Prev->Next = new_dlptr;
	    new_dlptr->Prev  = pole->Prev;
	    new_dlptr->Next  = NULL;
	    pole->Prev       = new_dlptr;
	}
	else
	{
	    /* empty link list  new node becomes the first one */
	    pole->Prev = pole->Next = new_dlptr;
	    new_dlptr->Prev = new_dlptr->Next = NULL;
	}
	/* find sum of the weight of the double link list */
    }
    return (OK);
}

/* search double link list */
int
search_dl_list (DOUBLE_LINK *pole, MeshNode *nptr, DOUBLE_LINK **dlptr)
{
    DOUBLE_LINK *cur_dlptr;

    *dlptr = NULL;
    if (pole->Next == NULL || pole->Prev == NULL)
    {   /* empty list */
	return (BAD);
    }

    cur_dlptr = pole->Next;
    /* search the list until reaching the last one */
    while (cur_dlptr)
    {
	if (cur_dlptr->nptr == nptr)
	{   /* find the node in the list */
	    *dlptr = cur_dlptr;
	    return (OK);
	}
	cur_dlptr = cur_dlptr->Next;
    }

    return (0);
}


/* copy double link list */
int
cp_dl_list (DOUBLE_LINK *source_pole, DOUBLE_LINK *distin_pole)
{
    DOUBLE_LINK *cur_dlptr;

    /* initialize distination pole */
    free_dl_list (distin_pole);

    /* empty source list */
    if (source_pole->Next == NULL || source_pole->Prev == NULL)   return (OK);

    /* copy nodes */
    cur_dlptr = source_pole->Next;
    while (cur_dlptr)
    {
	add_dl_list (distin_pole, cur_dlptr->nptr,
		     cur_dlptr->weight, cur_dlptr->len, cur_dlptr->Dad);
	cur_dlptr = cur_dlptr->Next;
    }

    return (OK);
}


/* extract the node with minimum weight in the list and maintain the list */
DOUBLE_LINK *
extract_min (DOUBLE_LINK *pole)
{
    REAL        min_wt;
    DOUBLE_LINK *cur_dlptr, *opt_dlptr;

    min_wt    = 1.e10;
    opt_dlptr = NULL;

    if (pole->Next == NULL || pole->Prev == NULL)
    {   /* empty list NULL pointer retured */
	    return (opt_dlptr);
    }

    cur_dlptr = pole->Next;

    while (cur_dlptr)
    {
	    if (cur_dlptr->weight < min_wt)
	    {
	        min_wt = cur_dlptr->weight;
	        opt_dlptr = cur_dlptr;
	    }
	    cur_dlptr = cur_dlptr->Next;
    }

    /* reset up the link */

    if (opt_dlptr)
    {   /* find a min. node */
	    if (opt_dlptr == pole->Next && opt_dlptr == pole->Prev)
	    {    /* the only one element in the list */
	        pole->Next = pole->Prev = NULL;
	        pole->weight = 0.0;
	    }
	    else if (!opt_dlptr->Prev)
	    {    /* the first element */
	        pole->Next = opt_dlptr->Next;
	        opt_dlptr->Next->Prev = NULL;
	    }
	    else if (!opt_dlptr->Next)
	    {    /* the last element */
	        pole->Prev = opt_dlptr->Prev;
	        opt_dlptr->Prev->Next = NULL;
	    }
	    else
	    {
	        /* cut off the node from the list */
	        opt_dlptr->Prev->Next = opt_dlptr->Next;
	        opt_dlptr->Next->Prev = opt_dlptr->Prev;
	    }

	    /* the node with min weight becomes a dangling node */
	    opt_dlptr->Next = opt_dlptr->Prev = NULL;
    }

    return (opt_dlptr);

}

/* Pop out a node from the head of the double link list */


DOUBLE_LINK *pop_dl_head (DOUBLE_LINK *pole)
{
    DOUBLE_LINK *cur_dlptr;

    cur_dlptr = NULL;

    if (pole->Next == NULL || pole->Prev == NULL)
    {   /* empty list NULL pointer retured */
	return (cur_dlptr);
    }

    cur_dlptr = pole->Next;
    pole->Next = cur_dlptr->Next;
    if (pole->Next == NULL)
    {  /* empty list */
       pole->Prev = NULL;
    }
    else
    {  /* set next node to be the first node in the list */
       cur_dlptr->Next->Prev = NULL;
    }

    return (cur_dlptr);


}



/* backup one step in double link list at tail */
int
back_dl_step (DOUBLE_LINK *pole)
{
    DOUBLE_LINK *dlptr;

    dlptr = pole->Prev;
    if (!dlptr)
    {
	printf ("\nEmpty double link list ! \n");
	return (BAD);
    }
    pole->Prev = dlptr->Prev;
    pole->weight -= dlptr->weight;
    if (!pole->Prev)
    {   /* empty double link list, set up the pole */
	pole->Next = NULL;
	pole->weight = 0.0;
    }
    else
    {
	pole->Prev->Next = NULL;
    }
    free ((char *) dlptr);

    return (OK);
}


/* free double link list */
int
free_dl_list (DOUBLE_LINK *pole)
{
    DOUBLE_LINK *cur_dlptr, *tmp_dlptr;

    if (pole->Next == NULL || pole->Prev == NULL)
    {
	pole->weight = 0.;
	return (OK);
    }

    cur_dlptr = pole->Next;
    while (cur_dlptr)
    {
	tmp_dlptr = cur_dlptr->Next;
	free ((char *) cur_dlptr);
	cur_dlptr = tmp_dlptr;
    }

    /* set up the pole */
    pole->Next = pole->Prev = NULL;
    pole->weight = 0.;

     return (OK);
}





/* create stack */
STACKCELL *
create_stack (STACKCELL *top)
{
    top = NULL;
    return (top);
}


/* pop */
struct stackinfo
pop (STACKCELL **top)
{
    struct stackinfo value;
    STACKCELL *p;

    value = (*top)->info;
    p = (*top)->stptr;
    free ((char *) (*top));
    *top = p;
    return (value);
}


/* push */
int
push (STACKCELL **top, struct stackinfo value)
{
    STACKCELL *p;

    p = (STACKCELL *) malloc  (sizeof (STACKCELL));
    if (!p)           alloc_error ("datautil-2");
    else
    {
	p->info  = value;
	p->stptr = *top;
	*top     = p;
	return (OK);
    }
    return (BAD);
}

/* is_empty */
int
is_empty (STACKCELL *top)
{
    if   (top == NULL)    return (OK);
    else                  return (0);
}


/* free_stack */
int
free_stack (STACKCELL **top)
{
     STACKCELL *p;

     while (*top != NULL)
     {
	 p = (*top)->stptr;
	 free ((char *) (*top));
	 *top = p;
     }
     return (OK);

}




/* find local size near a node */
REAL
loc_size (MeshNode *in_node)
{
    int  num_node = 0, k;
    REAL avg = 0., a[3], b[3];
    MeshNode *nptr;
    AdjList *anptr;

    for (k=0; k<3; k++)        a[k] = in_node->Coor[k];

    anptr = in_node->Fst_adj;
    while (anptr)
    {
	    num_node++;
	    nptr = anptr->idx;
	    for (k=0; k<3; k++)     b[k] = nptr->Coor[k];
	    avg += v_rang(a, b, 3);
	    anptr = anptr->ptr;
    }
    /* find average */
    if (num_node == in_node->Num_adj)
    {
	    if (num_node)
	        avg = avg / num_node;
    }
    else
	    printf ("\nWarning... Adjacent node num. did not match %d (%d)[datautil/loc_size]!\n",
		            num_node, nptr->Num_adj);
    return (avg);
}




