 
/*
  ************************************************************************
  *  defglb.h :	 define global varible					 *
  *									 *
  *  Qingyang Zhang				   Dec. 29, 1994	 *
  ************************************************************************
*/

/* needs:     basdefs.h modefs.h spmesh.h */



/* Global varibles for the system	*/
#ifdef MAIN_MOD

FILE   *Diag_file;     /* diagnostic file */
FILE   *Main_file;     /* main file to hold global name list */
FILE   *Spnod_file;    /* numerical specialty node file */
FILE   *Splin_file;    /* numerical specialty line sequence file */
FILE   *Spoly_file;    /* numerical sp. polyline sequence file */
FILE   *Nodmo_file;    /* Global volume node motion status file */
char   Diag_fname[]  = "spmesh.log";
char   Main_fname[]  = "mesh.sup";
char   Spnod_fname[] = "nspnod.dat";
char   Splin_fname[] = "nsplin.dat";
char   Spoly_fname[] = "nspoly.dat";
char   Nodmo_fname[] = "spmesh.log";
char   Input_name[80];
char   Model_name[80];
int    Numbering;	/* 1: nodes & elements list start w/ numbering */
int    Input_type;
int    Analy_type;
int    Dimen;
int    Mesh_type;
REAL   Global_size, G_factor, Norm_scale;
REAL   Norm_orig[3];
REAL   BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax; /* bounding box */
REAL   Ref_dist;
long   Bdy_nodes, Bdy_elem, Msh_nodes, Msh_elem;
int    Bdy_lst_type, Msh_lst_type;
int    Sp_nodes, Sp_elem;
int    Sp_poly_nodes, Sp_poly_elem;
int    Num_bc1, Num_bc2, Num_bc3;
char   Batch_fname[80];
FILE   *Batch_in;
int    Num_file_batch;
int    Cur_num_file_read;
int    Ref_batch_flag;
int    Numerical_surf;
int    Max_auto_ref_level;
/* added by Ziji, 4/16/99 */
int    autoref_ignore_adj_bdy;
int    autoref_ignore_same_mtrl_bdy;
/* end of Ziji */

int    Build_blk_type;     /* REGULAR_HEX : 0 / DELTA_HEX : 1 */
REAL   *Ori_msh_nd_coor[3];
/*
#define MAX_MTRL_NUM 100

   The index of array is the material code,
   the content of the array element records
   the intersection times with the boundary
   which will be used to determine the material
   region the tested node sit in.
   Mtrl_code[0] -- represent the outside of the
   object.
*/
 NODE_MTRL Mtrl_code[MAX_MTRL_NUM];

/* for mesh database */

BMeshNode *Bdy_node_head_ptr;
BMeshNode *Bdy_node_curt_ptr;
BMeshElem *Bdy_elem_head_ptr;   /* Trianglar patch boundary surface */
BMeshElem *Bdy_elem_curt_ptr;

MeshNode *Msh_node_head_ptr;
MeshNode *Msh_node_curt_ptr;
MeshElem *Msh_elem_head_ptr;   /* Mesh elemen: 3D tet hex ...	*/
MeshElem *Msh_elem_curt_ptr;
MeshElem *Msh_elem_minq_ptr;

MeshNode *Sp_node_head_ptr;
MeshNode *Sp_node_curt_ptr;
LineData *Sp_line_head_ptr;    /* the nodes of Specialty line have to be */
LineData *Sp_line_curt_ptr;    /* Specialty nodes */

/* specialty polyline header information */
MeshNode *Spoly_node_head_ptr;
MeshNode *Spoly_node_curt_ptr;
LineData *Spoly_elem_head_ptr;
LineData *Spoly_elem_curt_ptr;
/* detail list of each specialty polyline */
int      *Num_seg_in_poly;
LineData **Spoly_list_head_ptr;
LineData *Spoly_list_curt_ptr;
/* refinement node level pointer for hex8 type */
MeshNode *Ref_level_head[MAX_REF_LEVEL];
MeshNode *Ref_level_tail[MAX_REF_LEVEL];
long      Level_tail_num[MAX_REF_LEVEL];

int         Num_interface;            /* num. of interface in the model */
            /* interface mtrl. code [0][*] left [1][*]- right */
int         BFace_mtrl[2][MAX_FACE];  
int         Num_NFace;                /* num. of Numerical surfaces */
int         Min_ref_level;            /* the minimal refinement level for boundary element */
int         Max_ref_level;            /* the maximum refinement level for match all bdy. element */
int         User_ref_level;           /* User defined refinement level under auto mode */
Spatch      *NFace_head[MAX_FACE];    /* Numerical Fitted Face */
long        Num_patch_in_NFace[MAX_FACE]; /* num. of face in each numerical surface */

/* for Numerical Specialty line node sequence */
long    Num_nfitnod;
NSpnod  *Cur_fitnod;
NSpnod  *Fitnod_head;

/* for mesh quality */
REAL Q_mean, V_mean, Asp_mean, Jaco_mean, Skw_mean, Warp_mean;
REAL Q_min, V_min, Asp_min, Jaco_min, Skw_min, Warp_min;
REAL Q_max, V_max, Asp_max, Jaco_max, Skw_max, Warp_max;
REAL Q_tick_min, V_tick_min, Asp_tick_min, Jaco_tick_min, 
     Skw_tick_min, Warp_tick_min;
REAL Q_tick_max, V_tick_max, Asp_tick_max, Jaco_tick_max, 
     Skw_tick_max, Warp_tick_max;
int  num_Q_histo_slot,  num_V_histo_slot,  num_Asp_histo_slot,  
     num_Jaco_histo_slot, num_Skw_histo_slot, num_Warp_histo_slot;
int  num_Q_pie_slot,  num_V_pie_slot,  num_Asp_pie_slot,  
     num_Jaco_pie_slot, num_Skw_pie_slot, num_Warp_pie_slot;
long  *Q_histo_slots, *V_histo_slots, *Asp_histo_slots, *Jaco_histo_slots,
      *Skw_histo_slots, *Warp_histo_slots; 
long  *Q_pie_slots, *V_pie_slots, *Asp_pie_slots, *Jaco_pie_slots, 
      *Skw_pie_slots, *Warp_pie_slots; 

#else		   /* */

extern FILE   *Diag_file;
extern FILE   *Main_file;     /* main file to hold global name list */
extern FILE   *Spnod_file;    /* numerical specialty node file */
extern FILE   *Splin_file;    /* numerical specialty line sequence file */
extern FILE   *Spoly_file;    /* numerical sp. polyline sequence file */
extern FILE   *Nodmo_file;    /* Global volume node motion status file */
extern char   Diag_fname[];
extern char   Main_fname[];
extern char   Spnod_fname[];
extern char   Splin_fname[];
extern char   Spoly_fname[];
extern char   Nodmo_fname[];
extern char   Input_name[80];
extern char   Model_name[80];
extern int    Numbering;	/* 1: nodes & elements list start w/ numbering */
extern int    Input_type;
extern int    Analy_type;
extern int    Dimen;
extern int    Mesh_type;
extern REAL   Global_size, G_factor, Norm_scale; /* normalizing scale */
extern REAL   Norm_orig[3];
extern REAL   BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax; /* bounding box */
extern REAL   Ref_dist;
extern long   Bdy_nodes, Bdy_elem, Msh_nodes, Msh_elem;
extern int    Bdy_lst_type, Msh_lst_type;
extern int    Sp_nodes, Sp_elem;
extern int    Sp_poly_nodes, Sp_poly_elem;
extern int    Num_bc1, Num_bc2, Num_bc3;
extern char   Batch_fname[120];
extern FILE   *Batch_in;
extern int    Num_file_batch;
extern int    Cur_num_file_read;
extern int    Ref_batch_flag;
extern int    Numerical_surf;
extern int    Max_auto_ref_level;
/* added by Ziji, 4/16/99 */
extern int    autoref_ignore_adj_bdy;
extern int    autoref_ignore_same_mtrl_bdy;
/* end of Ziji */

extern int    Build_blk_type;     /* REGULAR_HEX : 0 / DELTA_HEX : 1 */
extern REAL   *Ori_msh_nd_coor[3];
extern NODE_MTRL Mtrl_code[MAX_MTRL_NUM];

/* for mesh database */
extern BMeshNode *Bdy_node_head_ptr;
extern BMeshNode *Bdy_node_curt_ptr;
extern BMeshElem *Bdy_elem_head_ptr;   /* Trianglar patch boundary surface */
extern BMeshElem *Bdy_elem_curt_ptr;

extern MeshNode *Msh_node_head_ptr;
extern MeshNode *Msh_node_curt_ptr;
extern MeshElem *Msh_elem_head_ptr;   /* Mesh elemen: 3D tet hex ...	*/
extern MeshElem *Msh_elem_curt_ptr;
extern MeshElem *Msh_elem_minq_ptr;

extern MeshNode *Sp_node_head_ptr;
extern MeshNode *Sp_node_curt_ptr;
extern LineData *Sp_line_head_ptr; /* the nodes of Specialty line have to be */
extern LineData *Sp_line_curt_ptr;    /* Specialty nodes */

/* specialty polyline header information */
extern MeshNode *Spoly_node_head_ptr;
extern MeshNode *Spoly_node_curt_ptr;
extern LineData *Spoly_elem_head_ptr;
extern LineData *Spoly_elem_curt_ptr;
/* detail list of each specialty polyline */
extern int      *Num_seg_in_poly;
extern LineData **Spoly_list_head_ptr;
extern LineData *Spoly_list_curt_ptr;
/* refinement node level pointer for hex8 type */
extern MeshNode *Ref_level_head[MAX_REF_LEVEL];
extern MeshNode *Ref_level_tail[MAX_REF_LEVEL];
extern long      Level_tail_num[MAX_REF_LEVEL];

extern int         Num_interface;      /* num. of interface in the model */
            /* interface mtrl. code [0][*] left [1][*]- right */
extern int         BFace_mtrl[2][MAX_FACE];  
extern int         Num_NFace;                /* num. of Numerical surfaces */
extern int         Min_ref_level;            /* the minimal refinement level for boundary element */
extern int         Max_ref_level;            /* the maximum refinement level for match all bdy. element */
extern int         User_ref_level;           /* User defined refinement level under auto mode */
extern Spatch      *NFace_head[MAX_FACE];    /* Numerical Fitted Face */
extern long        Num_patch_in_NFace[MAX_FACE]; /* num. of face in each numerical surface */

/* for Numerical Specialty line node sequence */
extern long    Num_nfitnod;
extern NSpnod  *Cur_fitnod;
extern NSpnod  *Fitnod_head;

/* for mesh quality */
extern REAL Q_mean, V_mean, Asp_mean, Jaco_mean, Skw_mean, Warp_mean;
extern REAL Q_min, V_min, Asp_min, Jaco_min, Skw_min, Warp_min;
extern REAL Q_max, V_max, Asp_max, Jaco_max, Skw_max, Warp_max;
extern REAL Q_tick_min, V_tick_min, Asp_tick_min, Jaco_tick_min, 
            Skw_tick_min, Warp_tick_min;
extern REAL Q_tick_max, V_tick_max, Asp_tick_max, Jaco_tick_max, 
            Skw_tick_max, Warp_tick_max;
extern int  num_Q_histo_slot,  num_V_histo_slot,  num_Asp_histo_slot,  
	    num_Jaco_histo_slot, num_Skw_histo_slot, num_Warp_histo_slot;
extern int  num_Q_pie_slot,  num_V_pie_slot,  num_Asp_pie_slot,  
            num_Jaco_pie_slot, num_Skw_pie_slot, num_Warp_pie_slot;
extern long  *Q_histo_slots, *V_histo_slots, *Asp_histo_slots, 
             *Jaco_histo_slots, *Skw_histo_slots, *Warp_histo_slots; 
extern long  *Q_pie_slots, *V_pie_slots, *Asp_pie_slots, *Jaco_pie_slots, 
             *Skw_pie_slots, *Warp_pie_slots; 

#endif		   /* */
