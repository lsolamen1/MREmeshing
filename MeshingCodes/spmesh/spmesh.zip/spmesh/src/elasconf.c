/* 
  ************************************************************************
  *  elasconf.c : Elastic Conforming for Tetrahedron Mesh	             *
  *									                                     *
  *  Qingyang Zhang				   April 7, 1996	                     *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

#include "dyalloc.h"
#include "elasmth.h"

/* define global varibles */
#include "defglb.h"

#define  imod(x,y)  (int)(fmod((REAL)(x), (REAL)(y)))
#define GetRandom( min, max ) ((rand() % (int)(((max) + 1) - (min))) + (min))

#define MTRL1   0
#define MTRL2   1
#define BDY12   3
#define NOMOV   4

#define ITERATION_TIMES 5
#define MAX_SM_ITER     5
#define CONFORM_TIMES   3

/* for elastic fit */
#define INFLUENT_ZONE_LEVEL_ELASTIC 3
#define NOT_BC       0
#define BCI         1
#define BCII        2
#define FIX_BC      3

/* to save process time, just pick unusual number here */
#define INCLUDED_ITEM 6543
#define EXCLUDED_ITEM 3456


/*
** External Functions
*/
extern int influence_zone (MeshElem *eptr, int zone_level, MeshNode **z_list, int *zlist_node_status);
extern int set_node_mask (MeshElem *eptr, MeshNode **z_list, int num_inzone, int bdy_sm_type, int *buf_mask);
extern int create_node_set_buffer (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, 
           int mtrl_code, int quali_type, NodeInfo *node_buf, int *num_set_1, int *num_set_2, 
           REAL *ave_dist1, REAL *ave_dist2, REAL *loc_size_1, REAL *loc_size_2);
extern int alloc_error (char *str);
extern REAL avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type);


/*
** Local Functions
*/
int elastic_node_mask (MeshElem *eptr, MeshNode **z_list, int *zlist_node_status,
                   int num_inzone, int bdy_sm_type, int *buf_mask);
int elas_smooth (int num_node, MeshNode **zlist, int *mask,
                 int num_elem, MeshElem **z_elist, int swap_orient_flag,
                 int num_type1, REAL *xbase, REAL *ybase, REAL *zbase, 
                 int quali_type, REAL min_quali);
int local_zone_index (MeshNode **zlist, int num_node, MeshNode *nptr);

void dalloc_glob  (void);
void release_glob (void);
void initial(void);
int  build (int num_type1, REAL *x_bc1, REAL *y_bc1, REAL *z_bc1);
void plnstr (void);

void cross (double *a, double *b, double *c);
extern int iccgluc (double *a,  int n,     int *ia,   int *ja,   double *af, double *b,
		     double *x,  double *r, double *p, double *s, double tol, 
		     int maxits, int *its,   int *info);
extern int axpy (double *a, int n, int *ia, int *ja, int i, int js, int je, 
          double t, double *y);
extern int saxpy2 (int n, double da, double *dx, int incx, double *dy, int incy);
extern int slot (int *ia, int *ja, int irow, int jcol, int nodcon);
extern int collapse (int *ia, int *ja, int n, int nodcon);
extern int insert (double t, double *a, int n, int *ia, int *ja, int i, int j, int k);
extern int locate (double *a, int n, int *ia, int *ja, int i, int j, int *k);
extern int mmult (double *a, int n, int *ia, int *ja, double *b, double *x, int job);
extern int putsum (double t, double *a, int n, int *ia, int *ja, int i, int j);
extern int cgres (double *a, int n, int *ia, int *ja, double *x, double *b, double *r);
extern int ssol (double *a, int n, int *ia, int *ja, double *b, int job);
extern int saxpy (int n, double sa, double *sx, int incx, double *sy, int incy);
extern int scopy (int n, double *sx, int incx, double *sy, int incy);
extern double sdot (int n, double *sx, int incx, double *sy, int incy);
extern int isamax (int n, double *sx, int incx);
extern int sprsrowzap1 (double *qv, int *iq,  int i, int mxiq, int mxjq);
extern int kay1 (int i, int j, int *iq, int *jq, int mxiq, int mxjq);


/*
** Global Variables
*/
long    Num_elastic_fit;
long    Num_elastic_undone;
MeshElem *Zone_elist[5*MAX_ADJACENT_NODES];
extern MeshNode *Zone_list[MAX_ADJACENT_NODES]; /* dynamic alloc. */
extern int Zone_node_status[MAX_ADJACENT_NODES];
extern REAL  Max_size;

/*
** Local Variables
*/ 



/* elastic conforming: the boundary layer --- 
    node_level_count = INFLUENT_ZONE_LEVEL_ELASTIC - 1
*/
int
elastic_conform_tet4 (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, int mtrl_code,
                NodeInfo *node_buf, REAL ave_dist1, REAL ave_dist2, REAL loc_size_1, REAL loc_size_2, 
                int num_set_1, int num_set_2, int quali_type, REAL min_quali)
{
    int     j, k, undone=0, done_flag, flag, idx;
    int     num_mov, mov_mtrl, *buf_mask, zone_level; 
    int     num_node_inzone, num_elem_inzone;
    long    ii;
    REAL    *buf_x, *buf_y, *buf_z, x_base[4], y_base[4], z_base[4];
    MeshNode  **nnptr;
    MeshElem  *eptr;

    /* define influence zone */
    zone_level   = INFLUENT_ZONE_LEVEL_ELASTIC;
    num_node_inzone = influence_zone (cur_eptr, zone_level, Zone_list, Zone_node_status);

    /* allocate buffer and pass node coord. */
    buf_x = (REAL *) malloc ((unsigned) num_node_inzone * sizeof (REAL));
    buf_y = (REAL *) malloc ((unsigned) num_node_inzone * sizeof (REAL));
    buf_z = (REAL *) malloc ((unsigned) num_node_inzone * sizeof (REAL));
    buf_mask = (int *) malloc ((unsigned) num_node_inzone * sizeof (int));
    
    if (!buf_x || !buf_y || !buf_z || !buf_mask)
        alloc_error ("elasconf-1");

    for (k=0; k<num_node_inzone; k++)
    {
        buf_x[k] = Zone_list[k]->Coor[0];
        buf_y[k] = Zone_list[k]->Coor[1];
        buf_z[k] = Zone_list[k]->Coor[2];
    }

    /* set node mask: NOT_BC=can be move   FIX_BC=don't move */
    elastic_node_mask (cur_eptr, Zone_list, Zone_node_status, num_node_inzone, 
                        MOVE_ELEM_BDY, buf_mask); 

    /* to accelerate the process on recognition of elem. in zone 
        here to use the 'in_zone' field of node structure.
    */
    /*
    for (ii=0, nptr=Msh_node_head_ptr; ii<Msh_nodes; ii++, nptr=nptr->Next)
        nptr->in_zone = 0;
    */

    for (k=0; k<num_node_inzone; k++)
        Zone_list[k]->in_zone = INCLUDED_ITEM;

    flag = create_node_set_buffer (bdy_l_head, bdy_num_elem, cur_eptr, 
                 mtrl_code, quali_type, node_buf, &num_set_1, &num_set_2, 
                 &ave_dist1, &ave_dist2, &loc_size_1, &loc_size_2);

    if (flag == BAD)        
    {
        undone = 1;
        done_flag = BAD;
        goto EX2; /* can't create buffer */
    }
    else if (flag == OK)    
    {
        undone = 0;
        done_flag = OK;
        goto EX2;  /* all set */
    }

    if (ave_dist1 < ave_dist2)
    {
        num_mov = num_set_1;
	    mov_mtrl = MTRL1;
    }
    else
    {
        num_mov = num_set_2;
	    mov_mtrl = MTRL2;
    }

    /* note that the first four nodes in the Zone_list is the nodes of
        the base element and the nodes to be moved will be passed firtst
        which will be the type I node while processing in elastic code
    */
    /* set new coordinates for base element */    
    idx = 0;
    for (k=0; k<4; k++)
    {
        if (node_buf[k].set == mov_mtrl)
        {
            x_base[idx] = node_buf[k].mov_coor[X];
            y_base[idx] = node_buf[k].mov_coor[Y];
            z_base[idx] = node_buf[k].mov_coor[Z];
            idx++;

            /* special treatment on base element */
            buf_mask[k] = BCI;
        }
    }

    /*
    for (k=0; k<4; k++)
    {
        if (node_buf[k].set != mov_mtrl)
        {   
            // either un-moving set or bdy nodes 
            x_base[idx] = node_buf[k].ori_coor[X];
            y_base[idx] = node_buf[k].ori_coor[Y];
            z_base[idx] = node_buf[k].ori_coor[Z];
            idx++;
        }
    }
    */

    num_elem_inzone = 0;
    for (ii=0, eptr=Msh_elem_head_ptr; ii<Msh_elem; ii++, eptr=eptr->Next)
    {
        nnptr = eptr->Elem.tet4.NodePtr;
        flag = 1;
        for (k=0; k<4; k++)
        {
            if (nnptr[k]->in_zone != INCLUDED_ITEM)
            {
                flag = 0;
                break;
            }
        }
        if (flag)
        {
            Zone_elist[num_elem_inzone] = eptr;
            Zone_elist[num_elem_inzone++]->attr = INCLUDED_ITEM;
        }
    }

    /* double check on the consistency of the boundary nodes */
    /* for debugging purpose */
    for (k=0; k<num_node_inzone; k++)
        Zone_list[k]->in_zone = EXCLUDED_ITEM;
    
    for (j=0; j<num_elem_inzone; j++)
    {
        nnptr = Zone_elist[j]->Elem.tet4.NodePtr;
        for (k=0; k<4; k++)
            nnptr[k]->in_zone = INCLUDED_ITEM;
    }
    flag = 0;
    for (j=0; j<num_node_inzone; j++)
    {
        if (Zone_list[j]->in_zone == EXCLUDED_ITEM)
        {
            flag = 1;
            for (k=j+1; k<num_node_inzone; k++)
            {
                Zone_list[k-1] = Zone_list[k];
                Zone_node_status[k-1] = Zone_node_status[k];
                buf_x[k-1] = buf_x[k];
                buf_y[k-1] = buf_y[k];
                buf_z[k-1] = buf_z[k];
                buf_mask[k-1] = buf_mask[k];
            }
            num_node_inzone--;
        }
    }

    flag = elas_smooth (num_node_inzone, Zone_list, buf_mask,
                        num_elem_inzone, Zone_elist, 1, 
                        num_mov, x_base, y_base, z_base, quali_type, min_quali);
   
    if (flag == BAD)        
    {
        undone = 1;
        done_flag = BAD; 
    }
    else if (flag == OK)    
    {
        undone = 0;
        done_flag = OK;
    }
    else
    {
        undone = 1;
        done_flag = BAD;
    }
            
    if (undone)
    {
        /* restore original coord. */
        for (k=0; k<num_node_inzone; k++)
        {
             Zone_list[k]->Coor[0] = buf_x[k];
             Zone_list[k]->Coor[1] = buf_y[k];
             Zone_list[k]->Coor[2] = buf_z[k];
        }
    }
    else
    {
        /* good move! set bdy pointer */
    }

EX2:
    /* reset */
    for (k=0; k<num_node_inzone; k++)
        Zone_list[k]->in_zone = EXCLUDED_ITEM;

    for (k=0; k<num_elem_inzone; k++)
        Zone_elist[k]->attr = EXCLUDED_ITEM;

    /* free buffer */
    free ((char *)buf_x);
    free ((char *)buf_y);
    free ((char *)buf_z);
    free ((char *)buf_mask);


    return (done_flag);
}

/* Set node mask as the boundary node moving mode 
 */
int 
elastic_node_mask (MeshElem *eptr, MeshNode **z_list, int *zlist_node_status,
                   int num_inzone, int bdy_sm_type, int *buf_mask)
{
    int      i, num_p;
    long     kk;

    switch (eptr->E_type)
    {
	    case TET4:
		    num_p = 4;
		    break;
	    case HEX8:
		    num_p = 8;
		    break;
	    default:
		    fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		    return (BAD);
    }

    /* find nodes need be smoothing */
    for (i=0; i<num_p; i++)
    {
        /* for base elem. nodes, allow bdy node to move (but not outbound nodes) */
        if (z_list[i]->status == OUTNODE) 
        {
            if (z_list[i]->Mtrl < BDY_NODE_CODE)
            {
                buf_mask[i] = NOT_BC; /* ??? DO more testing */
            }
            else
                buf_mask[i] = FIX_BC; 

            continue;  /* skip outbound nodes */
        }

        buf_mask[i] = NOT_BC;
        if (z_list[i]->Mtrl > BDY_NODE_CODE)
        {
            if (bdy_sm_type==MOVE_ELEM_BDY || bdy_sm_type==MOVE_ALL_BDY)
            {
                z_list[i]->Mtrl = z_list[i]->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */ 
                if (z_list[i]->status == DONE)     z_list[i]->status = FREE;
                if (z_list[i]->Mtrl < 0 || z_list[i]->Mtrl > MAX_MTRL_NUM-1)
                {
                    fprintf (Diag_file, "\nWarning...problem mtrl %d!\n", z_list[i]->Mtrl);
                }
            }
            else 
            {
                buf_mask[i] = FIX_BC;
                continue;
            }
        }
    }

    for (i=num_p-1; i<num_inzone; i++)
    {
        /* start from level 1 -- adjacent nodes */
        if (zlist_node_status[i] == INFLUENT_ZONE_LEVEL_ELASTIC - 1 ||
            zlist_node_status[i] == BDY_LEVEL)
        {
            /* influence zone boundary */
            buf_mask[i] = FIX_BC;
            continue;
        }

        if (z_list[i]->status == OUTNODE)
        {
            buf_mask[i] = FIX_BC;
            continue; 
        }

        buf_mask[i] = NOT_BC;
        if (z_list[i]->Mtrl > BDY_NODE_CODE)
        {
            if (bdy_sm_type==MOVE_ADJ_BDY || bdy_sm_type==MOVE_ALL_BDY)
            {
                z_list[i]->Mtrl = z_list[i]->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */
                if (z_list[i]->status == DONE)     z_list[i]->status = FREE;
                if (z_list[i]->Mtrl < 0 || z_list[i]->Mtrl > MAX_MTRL_NUM-1)
                {
                    kk = z_list[i]->Mtrl;
                    fprintf (Diag_file, "\nWarning...problem mtrl %ld!\n", kk);
                }
            }
            else
            {
                buf_mask[i] = FIX_BC;
                continue;    /* skip adj. bdy node */
            }
        }
    }

    /* consistency checking */
    for (i=0; i<num_inzone; i++)
    {
        if ((z_list[i]->status == DONE || z_list[i]->Mtrl > BDY_NODE_CODE)
            && buf_mask[i] == NOT_BC)
                fprintf (Diag_file, "\nProblem node!!\n");
    }
    return (OK);
}


/* return the local zone node index (start from 1) */
int
local_zone_index (MeshNode **zlist, int num_node, MeshNode *nptr)
{
    int k, idx=-1;

    for (k=0; k< num_node; k++)
    {
        if (zlist[k] == nptr)
        {
            idx = k + 1;
            break;
        }
    }
    if (idx == -1)
    {
        printf ("Can't match local zone node index !!!\n");
        idx = 1;
    }
    return (idx);
}



/* following are the elastic code */

/* elastic smoothing: note that all the type I nodes are in the from 
    of the list
*/
int
elas_smooth (int num_node, MeshNode **zlist, int *mask,
             int num_elem, MeshElem **z_elist, int swap_orient_flag,
             int num_type1, REAL *xbc1, REAL *ybc1, REAL *zbc1, 
             int quali_type, REAL min_quali)
{
    int     i, j, k, flag;
    double  node_quli, min_jacob; 
    MeshNode **nnptr;

    /* pre-processing to determine the elements in the zone */

    /* set global for elastic solver */
    nn = num_node;
    ne = num_elem;  
    MXN  = num_node + 2;/* a) start from 1; b) extra space for finding distance */
    MXN3 = 3 * MXN;
    MXE  = num_elem + 1;
    MXIQ = MXN3;
    MXJQ = MXN3 * MXNSI;

    /* allocate global varibles */
    dalloc_glob ();    

    /*  get the input information first --- index start from 1 !!!*/
    /* pass nodal coordinates */
    for (k=1; k<=nn; k++)
    {
        x[k] = zlist[k-1]->Coor[X];
        y[k] = zlist[k-1]->Coor[Y];
        z[k] = zlist[k-1]->Coor[Z];
        
        if (mask[k-1]==BCI) 
            jbn[k] = 1;     /* type I boundary node */
        else if (mask[k-1]==FIX_BC) 
            jbn[k] = 3;     /* fixed bdy nodes */
        else
            jbn[k] = 0;     /* no bc */
    }

    /* pass the element: swap connectivity ? */
    for (j=1; j<=ne; j++)
    {
        nnptr = z_elist[j-1]->Elem.tet4.NodePtr;
        /* match local node indices */
        in[1][j] = local_zone_index (zlist, num_node, nnptr[0]);
        if (swap_orient_flag)
        {
            in[2][j] = local_zone_index (zlist, num_node, nnptr[2]);
            in[3][j] = local_zone_index (zlist, num_node, nnptr[1]);
        }
        else
        {
            in[2][j] = local_zone_index (zlist, num_node, nnptr[1]);
            in[3][j] = local_zone_index (zlist, num_node, nnptr[2]);
        }
        in[4][j] = local_zone_index (zlist, num_node, nnptr[3]);

        /* hard code mtrl code to 1 */
        mtrl[j] = 1;
    }

    /* initialize all parameters */
    initial ();

    /* main program formulation in terms of displacement */
    flag = build (num_type1, xbc1, ybc1, zbc1);
    
    if (flag == OK)
    {
        /* dump results */
        for (i=1; i<=nn; i++)
        {   
	        zlist[i-1]->Coor[X] = x[i];
	        zlist[i-1]->Coor[Y] = y[i];
	        zlist[i-1]->Coor[Z] = z[i];
        }

        /* check mesh quality */
        for (k=0; k<num_node; k++)
        {
            min_jacob=avg_quli (zlist[k], &node_quli, quali_type);
	        if (min_jacob < LOWTOL || node_quli < min_quali)
            {
                flag = BAD;
                break;
            }

        }
    }

    /* for debugging: write deformed node file */
    /*
    printf (" Enter a 1 to save deformed output (0=skip): ");
	scanf ("%d", &ians);
	if (ians == 1) 
    {
G30:    printf ("Enter deformed node file name: ");
	    scanf ("%s", filnam);

        if ((outf = fopen (filnam, "wt")) == NULL) goto G30;
        else
        {
	        fprintf (outf, "   1  %8d\n", nn);
	        for (i=1; i<=nn; i++)
            {
	            fprintf (outf, "%8d %16.6lf  %16.6lf  %16.6lf\n",
                        i, x[i], y[i], z[i]);
            }
        }
	    fclose (outf);
    }
	   
    end of simulation 
    */
    /* printf ("Stress Program has completed normally.\n"); */
    
    release_glob ();

    return (flag);
}



void
dalloc_glob (void)
{
    /* two dimensional arrays */
    stiff = dmatrix(1, 12, 1, 12);
    b     = dmatrix(1,  6, 1, 12);
    t     = dmatrix(1, 12, 1,  6);
    cds   = dmatrix(1,  3, 1,  4);
    bt    = dmatrix(1, 12, 1,  6);

    in    = imatrix(1, MXNPE, 1, MXE);
    
    /* one dimensional arrays */
    
    x     = dvector(1, MXN);
    y     = dvector(1, MXN);
    z     = dvector(1, MXN);
    
    rhs   = dvector(1, MXN3);
    guess = dvector(1, MXN3);
    qv    = dvector(1, MXJQ);
    ccg1  = dvector(1, MXIQ);
    ccg2  = dvector(1, MXIQ);
    ccg3  = dvector(1, MXIQ);
    ccg4  = dvector(1, MXJQ);
    
    mtrl  = ivector(1, MXE);
    jbn   = ivector(1, MXN);
    iq    = ivector(1, MXIQ);
    jq    = ivector(1, MXJQ);
    return;
}






void
release_glob (void)
{
    /* two dimensional arrays */
    free_dmatrix (stiff, 1, 12, 1, 12);
    free_dmatrix (b    , 1,  6, 1, 12);
    free_dmatrix (t    , 1, 12, 1,  6);
    free_dmatrix (cds  , 1,  3, 1,  4);
    free_dmatrix (bt   , 1, 12, 1,  6);

    free_imatrix (in   , 1, MXNPE, 1, MXE);
    /* one dimensional arrays */
    
    free_dvector (x    , 1, MXN);
    free_dvector (y    , 1, MXN);
    free_dvector (z    , 1, MXN);
    
    free_dvector (rhs  , 1, MXN3);
    free_dvector (guess, 1, MXN3);
    free_dvector (qv   , 1, MXJQ);
    free_dvector (ccg1 , 1, MXIQ);
    free_dvector (ccg2 , 1, MXIQ);
    free_dvector (ccg3 , 1, MXIQ);
    free_dvector (ccg4 , 1, MXJQ);

    free_ivector (mtrl , 1, MXE);
    free_ivector (jbn  , 1, MXE);
    free_ivector (iq   , 1, MXIQ);
    free_ivector (jq   , 1, MXJQ);

    return;
}





/* initialize all parameters */
void
initial (void)
{
    int     i;
    int     j, k, m, ix, iy, iz, ii, jj, jx, jy, jz, ik, nmtrl;
    double  prefix, e, p, v1, v2;

    nn3 = NDOF*nn;

    /*  sparse matrix initialization -  call pointers routine
        first zero out arrays that are used in solver
    */
    for (i=1; i<=MXIQ; i++)
    {
	   iq[i]   = 0;
	   ccg1[i] = 0.0;
	   ccg2[i] = 0.0;
	   ccg3[i] = 0.0;
    }
	
    for (i=1; i<=MXJQ; i++)
    {
	    jq[i]   = 0;
	    qv[i]   = 0.0;
		ccg4[i] = 0.0;
    }


    /*   second, create an address location and pointer based on the
      element list - node i is connected to node j's (x, y, and z)
      components etc.
    */

	for (i=1; i<=ne; i++)
    {
	    for (j=1; j<=4; j++)
        {
		    ii = in[j][i];
		    iz = 3*ii;
		    iy = iz-1;
		    ix = iy - 1;
		    for (k=1; k<=4; k++)
            {
		        jj = in[k][i];
		        jz = 3*jj;
		        jy = jz-1;
		        jx = jy - 1;
		        slot(iq,jq,ix,jx,MXNSI);
		        slot(iq,jq,ix,jy,MXNSI);
		        slot(iq,jq,ix,jz,MXNSI);
		        slot(iq,jq,iy,jx,MXNSI);
		        slot(iq,jq,iy,jy,MXNSI);
		        slot(iq,jq,iy,jz,MXNSI);
		        slot(iq,jq,iz,jx,MXNSI);
		        slot(iq,jq,iz,jy,MXNSI);
		        slot(iq,jq,iz,jz,MXNSI);
            }
        }
    }
    /*   third, eliminate blank spaces in the original array locations  */
	collapse (iq, jq, nn3, MXNSI);

    /*Note that currently only handle uniform (one) material case ! */

    elas_max = 0.0;
    nmtrl = 1;

	for (ik=1; ik<=nmtrl; ik++)
    {
        m = 1;
        e = 1.e3;
	    p = 0.3;
        v1 = p/(1.-p);
	    v2 = (1.-2*p)/(2.*(1-p));
 	    prefix = (e*(1-p))/( (1+p)*(1-2*p));
        elas_max = elas_max > e ? elas_max : e;

        c[1][1][m] = 1.0;
  	    c[1][2][m] = v1;
 	    c[1][3][m] = v1;
	    c[1][4][m] = 0.0;
	    c[1][5][m] = 0.0;
	    c[1][6][m] = 0.0;
 	 
 	    c[2][2][m] = 1.;
 	    c[2][3][m] = v1;
	    c[2][4][m] = 0.0;
	    c[2][5][m] = 0.0;
	    c[2][6][m] = 0.0;
 	  
 	    c[3][3][m] = 1.0;
	    c[3][4][m] = 0.0;
	    c[3][5][m] = 0.0;
	    c[3][6][m] = 0.0;
	  
	    c[4][4][m] = v2;
	    c[4][5][m] = 0.0;
	    c[4][6][m] = 0.0;
	  
	    c[5][5][m] = v2;
	    c[5][6][m] = 0.0;
	  
	    c[6][6][m] = v2;

        for (i=2; i<=6; i++)
            for (j=1; j<=i-1; j++)
	             c[i][j][m] = c[j][i][m];

	    for (k=1; k<=6; k++)
	        for (j=1; j<=6; j++)
	            c[k][j][m] = prefix*c[k][j][m];
    }


}
	  


/* if not convergent return BAD -- no solution return */
int 
build (int num_type1, REAL *x_bc1, REAL *y_bc1, REAL *z_bc1)
{
    int     num_bc1_node, num_bc3_node, i, ii, ix, iy, iz;
    int     itmax, info, its;
	double  cgtol;

    /*  rebuild entire stiffness matrix */
    plnstr ();

    /* back substitute for new positions */
    for (i=1; i<=nn3; i++)
    {
        ii = kay1(i, i, iq, jq, MXIQ, MXJQ);
	    if(qv[ii] == 0.)
	        printf ("==> i = %d, qv[ii] = %lf\n", i, qv[ii]);

        rhs[i] = 0.0;
    }
     
    /*  apply type 1 bc  */
    num_bc1_node = 0;
    num_bc3_node = 0;
	for (i=1; i<=nn; i++)
    {
        if(jbn[i] == 1)       
        {
    	    iz = NDOF * i;
	        iy = iz - 1;
	        ix = iy - 1;

            /*  for iterative solver  */
            sprsrowzap1 (qv, iq, iz, MXIQ, MXJQ); 
		    ii = kay1 (iz, iz, iq, jq, MXIQ, MXJQ);
		    qv[ii] = 1.0;
		    sprsrowzap1 (qv, iq, iy, MXIQ, MXJQ);
		    ii = kay1 (iy, iy, iq, jq, MXIQ, MXJQ);
	        qv[ii] = 1.0;
		    sprsrowzap1 (qv, iq, ix, MXIQ, MXJQ);
		    ii = kay1 (ix, ix, iq, jq, MXIQ, MXJQ);
		    qv[ii] = 1.0;

            /* apply rhs using the target node coord. */
	        rhs[iz] = x_bc1[num_bc1_node]; 
	        rhs[iy] = y_bc1[num_bc1_node]; 
	        rhs[ix] = z_bc1[num_bc1_node]; 
            num_bc1_node++;
        }
        else if (jbn[i] == 3)
        {
            /* fixed nodes */
    	    iz = NDOF * i;
	        iy = iz - 1;
	        ix = iy - 1;

            /*  for iterative solver  */
            sprsrowzap1 (qv, iq, iz, MXIQ, MXJQ); 
		    ii = kay1 (iz, iz, iq, jq, MXIQ, MXJQ);
		    qv[ii] = 1.0;
		    sprsrowzap1 (qv, iq, iy, MXIQ, MXJQ);
		    ii = kay1 (iy, iy, iq, jq, MXIQ, MXJQ);
	        qv[ii] = 1.0;
		    sprsrowzap1 (qv, iq, ix, MXIQ, MXJQ);
		    ii = kay1 (ix, ix, iq, jq, MXIQ, MXJQ);
		    qv[ii] = 1.0;

            /* apply rhs using the original coord. */
	        rhs[iz] = x[i]; 
	        rhs[iy] = y[i]; 
	        rhs[ix] = z[i]; 
            num_bc3_node++;
        }
    }

	/* printf ("Number of Type I  BC <nodes> : %d\n", num_bc1_node); 
       printf ("Number of Fixed node         : %d\n", num_bc3_node); 
    */
    /* solve the iterative system. */
	cgtol = 1.0e-10;
	itmax = nn3/10;
	info = 0;
    /* set initial guess value */
	for (i=1; i<=nn; i++)
    {
	   iz = 3*i;
	   iy = iz-1;
	   ix = iy-1;
	   guess[iz] = z[i];
	   guess[iy] = y[i];
	   guess[ix] = x[i];
    }
    
    /* solve the system */
    iccgluc (qv, nn3, iq, jq, ccg4, rhs, guess, ccg1, ccg2, ccg3, cgtol,
            itmax, &its, &info);

    /* check the result */
    if (info == -999)
    {
        /* the result is not convergent */
        return (BAD);
    }

    /* pass the results 
    for (i=1; i<=nn3; i++)
	   rhs[i] = guess[i];
    */
    
    /* dummp the result */
    for (i=1; i<=nn; i++)
    {
	    iz = 3*i;
	    iy = iz-1;
	    ix = iy-1;

	    x[i] = guess[ix];
	    y[i] = guess[iy];
	    z[i] = guess[iz];
    }
    

    return (OK);
}





/*  this subroutine builds the linearized equations of elasticity lhs matrix */

void
plnstr (void)
{   
    int     i, i1, i2, i3, i4, ii, ij, j, k, l, ix, iy, iz;
    int     irowx, irowy, irowz, jx, jy, jz, jj, jcolx, jcoly, jcolz;
    double  dj, ans;
    

    /*    initialize the lhs matrix:    */
	for (i=1; i<=iq[nn3+1]-1; i++)
	    qv[i] = 0.0;

    for (l=1; l<=ne; l++)
    {
        i1 = in[1][l];
        i2 = in[2][l];
        i3 = in[3][l];
	    i4 = in[4][l];
	    ba[1] = (y[i2]-y[i4])*(z[i3]-z[i4])-(y[i3]-y[i4])*(z[i2]-z[i4]);
        ba[2] = (y[i3]-y[i4])*(z[i1]-z[i4])-(y[i1]-y[i4])*(z[i3]-z[i4]);
	    ba[3] = (y[i1]-y[i4])*(z[i2]-z[i4])-(y[i2]-y[i4])*(z[i1]-z[i4]);
	    ba[4] = -( ba[1] + ba[2] + ba[3] );
	   
	    bb[1] = (x[i3]-x[i4])*(z[i2]-z[i4])-(x[i2]-x[i4])*(z[i3]-z[i4]);
	    bb[2] = (x[i1]-x[i4])*(z[i3]-z[i4])-(x[i3]-x[i4])*(z[i1]-z[i4]);
	    bb[3] = (x[i2]-x[i4])*(z[i1]-z[i4])-(x[i1]-x[i4])*(z[i2]-z[i4]);
	    bb[4] = -( bb[1] + bb[2] + bb[3] );
	   
	    bc[1] = (x[i2]-x[i4])*(y[i3]-y[i4])-(x[i3]-x[i4])*(y[i2]-y[i4]);
	    bc[2] = (x[i3]-x[i4])*(y[i1]-y[i4])-(x[i1]-x[i4])*(y[i3]-y[i4]);
	    bc[3] = (x[i1]-x[i4])*(y[i2]-y[i4])-(x[i2]-x[i4])*(y[i1]-y[i4]);
	    bc[4] = -( bc[1] + bc[2] + bc[3] );
	   
	    dj=(x[i1]-x[i4])*ba[1]+(y[i1]-y[i4])*bb[1]+(z[i1]-z[i4])*bc[1];
	   
        /*  formulate derivitive matrix B(6x3*node) */
        for (i=1; i<=6; i++)
	        for (j=1; j<=12; j++)
                b[i][j] = 0.0;

        for (ii=0; ii<=3; ii++)
        {
	        ij = 3*ii;
		    b[1][1+ij] = ba[1+ii]/dj;
		    b[2][2+ij] = bb[1+ii]/dj;
		    b[3][3+ij] = bc[1+ii]/dj;
		    b[4][1+ij] = b[2][2+ij];
		    b[4][2+ij] = b[1][1+ij];
		    b[5][2+ij] = b[3][3+ij];
		    b[5][3+ij] = b[2][2+ij];
		    b[6][1+ij] = b[3][3+ij];
		    b[6][3+ij] = b[1][1+ij];
        }

        /*  create B(Transpose)    */
	    for (j=1; j<=12; j++)
	        for (k=1; k<=6; k++)
		        bt[j][k] = b[k][j];

        /*   compute B(Transpose)*C     */
	    for (j=1; j<=12; j++)
        {
	        for (k=1; k<=6; k++)
            {
		        ans = 0.0;
		        for (i=1; i<=6; i++)
                {
		            ans = ans + bt[j][i]*c[i][k][mtrl[l]];
                }
		        t[j][k] = ans;
            }
        }
	   

        /*    compute B(Transpose)*C*B     */
	    for (j=1; j<=12; j++)
        {
	        for (k=1; k<=12; k++)
            {
		        ans = 0.0;
		        for (i=1; i<=6; i++)
                {
		            ans = ans + t[j][i]*b[i][k];
                }
		        stiff[j][k] = ans*(dj/6.0);
            }
        }

        /*  assemble global stiffness matrix   */
        for (i=1; i<=4; i++)
        {
	        iz = 3*i;
	        iy = iz-1;
		    ix = iy-1;
            ii = in[i][l];
            irowz = 3*ii;
		    irowy = irowz - 1;
            irowx = irowy - 1;
            for (j=1; j<=4; j++)
            {
		        jz = 3*j;
		        jy = jz - 1;
		        jx = jy - 1;
                jj = in[j][l];
		        jcolz = 3*jj;
                jcoly = jcolz - 1;
                jcolx = jcoly - 1;	 

                /*iterative solver section */
		        putsum(stiff[ix][jx],qv,nn3,iq,jq,irowx,jcolx);
		        putsum(stiff[ix][jy],qv,nn3,iq,jq,irowx,jcoly);
		        putsum(stiff[ix][jz],qv,nn3,iq,jq,irowx,jcolz);
		 
		        putsum(stiff[iy][jx],qv,nn3,iq,jq,irowy,jcolx);
		        putsum(stiff[iy][jy],qv,nn3,iq,jq,irowy,jcoly);
		        putsum(stiff[iy][jz],qv,nn3,iq,jq,irowy,jcolz);
		 
		        putsum(stiff[iz][jx],qv,nn3,iq,jq,irowz,jcolx);
		        putsum(stiff[iz][jy],qv,nn3,iq,jq,irowz,jcoly);
		        putsum(stiff[iz][jz],qv,nn3,iq,jq,irowz,jcolz);

            }
        }
    }

    return;
}	  


