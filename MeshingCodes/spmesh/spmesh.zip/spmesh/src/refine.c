  
/*
  ********************************************************************
  *  refine.c : Mesh refinement and rebuild element connectivity	 *
  *									                                 *
  *  Qingyang Zhang				   May 24, 1995	                     *
  ********************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#define READ_LINE

#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"


/* strategy for refinement:

   1. Define refinement zones: Given a surface which is defined by a 
      triangle patch list and Given a distance to the surface.
      the surface could be the boundary surface or a user defined
      surface.

   2. Test all mesh nodes to determine those nodes within refinement
      zone and set up a flag of refinement, All the element related
      flaged node are tagged as the element to be fully refined (will
      be broken into 8 smaller tets). New nodes created by promotion
      will be inserted into tail end of node link list.

   3. Promote all the elements sharring at least two nodes with tagged 
      element (include tagged itself) to 10 node tetrahedra element by
      inserting new nodes. A tagged element is the one which at least 
      has one node within the refinement zones.

      since in element structure MeshElem, it has a union for all type 
      of mesh elements, the promotion is simply changging the elem.
      type and inserting new nodes or filling with NULL pointer if the
      new element does not really include 10 nodes.

      for speed up the process, move all promoted element to the tail
      of the element link list and set up a pointer to first promoted
      element in the list, which indicates all the elements from first
      pointer to tail element are promoted elements.

      addtional check for promoted tets and see if it needs add extra
      nodes for breaking down and knitting consideration.

   4. Break down 10 node tet into 4 node tets. Old 10 node tet will
      be deleted and New tets will inserted into tail end.

      Breaking patterns:

      I)  tagged elements (real 10 node tet): break into 8 sub-tets.

      II) untagged elem. with knitting checking:
	  a) 10 real nodes:
	  b) 9  real nodes:  -> 10 nodes
	  c) 8  real nodes:  -> 10 nodes
	  d) 7  real nodes:  if 3 mid node not on same face -> 10 nodes
	  e) 6  real nodes:  if 2 mid node on same face     -> 7  nodes
	  f) 5  real nodes:  if in bad condition            -> 6  nodes
	  g) 4  real nodes:  just change tet. type back to TET4.
      III) after knitting check:
	  a) 10 real nodes:   break into 8 tets.
	  b) 7  real nodes:   break into 4 tets.
	  c) 6  real nodes:   break into 4 tets.
	  d) 5  real nodes:   break into 2 tets.
      
   5. rebulid element connectivities.


*/


/*
** External Functions
*/
extern int nod_inout (REAL *d, REAL *e, BMeshElem *bdy_l_head, 
                      long n_bdy_elem, BMeshElem **on_bdy_eptr, int db_flag);
extern int  tri_patch_bound (BMeshNode **nnptr, double *xmin, double *ymin, 
               double *zmin, double *xmax, double *ymax, double *zmax);
extern void tri_patch_box (REAL *xmin, REAL *ymin, REAL *zmin,
		    REAL *xmax, REAL *ymax, REAL *zmax,
		    MeshElem *bdy_l_head, long n_bdy_elem);
extern REAL pnt2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *pnt);
extern int free_adj_elem (AdjElem *ad_ptr);
extern int mk_adjlist(MeshNode *n_head,long num_node, MeshElem *e_head, long num_elem);
extern int free_adj (AdjList *ad_ptr);
extern int free_adj_elem (AdjElem *ad_ptr);
extern int free_bnode_list (BMeshNode *head, long num_node);
extern int free_belem_list (BMeshElem *head, long num_elem);
extern int free_node_list (MeshNode *head, long num_node);
extern int free_elem_list (MeshElem *head, long num_elem);
extern MeshNode *conv_node_idx (MeshNode *head, long node_idx);
extern BMeshNode *conv_bnode_idx (BMeshNode *head, long node_idx);
extern int alloc_error (char *str);
extern int debug_check  (char *title);
extern int normalize_def_bdy_nodes (BMeshNode *head_bnptr, long num_bdy_node, 
                            BMeshElem *head_beptr, long num_bdy_elem);
extern int random_shoot_full (double *st_pnt, double *ed_pnt);


/*
** Local Functions
*/
int ref_bdy_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
		   MeshNode **msh_n_head, long *num_mesh_nd,
		   MeshElem **msh_l_head, long *num_mesh_el);
int tag_refine_zone (BMeshElem *bdy_l_head, long bdy_num_elem,
		     MeshNode *msh_n_head, long *num_mesh_nd,
		     MeshElem *msh_l_head, long *num_mesh_el);
int check_ref_zone (MeshNode *nptr, BMeshElem *surf_l_head,
		    long surf_num_elem, REAL ref_dist);
int tag_associate_elem (MeshNode *nptr, int ref_level);
int match_nodes (MeshNode **nnptr1, MeshNode **nnptr2);
int check_mid_coor (MeshNode **nnptr, int j1, int j2, int jmid);
void initial_txt4_10 (MeshNode **nnptr);
long insert_nodes (MeshNode *msh_n_head, long *num_mesh_nd,
		   MeshElem *msh_l_head, long num_elem, int ref_level);
int match_edge (MeshNode *nptr1, MeshNode *nptr2,
		MeshNode **sub_nnptr, int *sub_mid_index) ;
void check_knit (MeshNode *msh_n_head, long *num_mesh_nd,
		 MeshElem *msh_l_head, long num_elem, int ref_level);
int find_tet_pattern (MeshElem *eptr);
int process_tet4_6 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
int process_tet4_7 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
int process_tet4_8 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
int process_tet4_9 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
void add_a_mid (MeshNode *msh_n_head, long *num_mesh_nd, MeshNode **nnptr,
		int nd_idx_1, int nd_idx_2, int mid_idx);
void free_adj_lists (MeshNode *head, long num_nodes);
int refine_tets (MeshElem **msh_l_head, long *num_mesh_el,
		  AdjElem *ref_list, long num_ref);
int refine_tet10 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
int refine_tet7 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
int refine_tet6 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
int refine_tet5 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
MeshElem * create_an_elem (MeshElem **msh_l_head, long *num_mesh_el);
void free_a_elem (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
int read_ref_region (char *fname, BMeshNode **xbdy_n_head, long *xbdy_num_node,
		     BMeshElem **xbdy_l_head, long *xbdy_num_elem);
int rd_xbdy_node (FILE *fp, BMeshNode **xbdy_n_head, long bdy_nodes, int numbering);
int rd_xbdy_elem (FILE *fp, BMeshNode *xbdy_n_head, BMeshElem **xbdy_l_head, 
		  long bdy_elem, int numbering);
MeshNode ** tet4_2_tet10 (MeshElem *eptr);
MeshNode ** tet10_2_tet4 (MeshElem *eptr);


/*
** Global Variables
*/
extern REAL Max_size;

/*
** Local Variables
*/
    int static mid_num [4][4] = { {0, 4, 6, 7},
			      {4, 0, 5, 8},
			      {6, 5, 0, 9},
			      {7, 8, 9, 0} };
    int static vtx_num [6][2] = { {0, 1},
			      {1, 2},
			      {2, 0},
			      {0, 3},
			      {1, 3},
			      {2, 3} };

AdjElem   *Ref_elm_list, *Last_ref_elm;
long      Num_ref_elm, New_msh_node;



int
ref_bdy_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
	            MeshNode **msh_n_head, long *num_mesh_nd,
	            MeshElem **msh_l_head, long *num_mesh_el)
{
  int  flag, num_adj_elm, max_num_adjelem;
  long ii, num_node;
  MeshNode *nptr;

  /* initialization */
  Ref_elm_list = Last_ref_elm = NULL;
  Num_ref_elm  = New_msh_node = 0;

  /* define refinement zone and tag nodes and element for refining */
  flag = tag_refine_zone (bdy_l_head, bdy_num_elem,
		   *msh_n_head, num_mesh_nd, *msh_l_head, num_mesh_el);
  if (flag == BAD)   return (BAD);

  /* refine elements */
  refine_tets (msh_l_head, num_mesh_el, Ref_elm_list, Num_ref_elm);
  /* make sure:
     1. the element type be set back to TET4 before create
	adj. lists. since it can't handle TET10
     2. free adj. list before rebuild the lists.
     3. free refinement list after refinement.
  */
  /* refinement --- Break TET10 into TET4 */

  /* free refinment element list */
  free_adj_elem (Ref_elm_list);

  /* free adjlist first */
  free_adj_lists (*msh_n_head, *num_mesh_nd);
  /* creat adjlist */
  mk_adjlist (*msh_n_head, *num_mesh_nd, *msh_l_head, *num_mesh_el);

  /* check maximum node-elem. connectivity */
  max_num_adjelem = 0;
  nptr = *msh_n_head;
  num_node =  *num_mesh_nd;
  for (ii=0; ii<num_node; ii++)
  {
      num_adj_elm = nptr->Num_adj_elem;
      if (num_adj_elm >max_num_adjelem) max_num_adjelem = num_adj_elm; 
      nptr = nptr->Next;
  }

  printf ("\nMax. number of adjacent elem. connected to node : %d\n",  
             max_num_adjelem);

  return (0);

}






/* define refinement zone and tag nodes and element for refining
   the function is designed not just for physical boundary, but
   currently only support for the refinement zone along BDY.
*/
int
tag_refine_zone (BMeshElem *bdy_l_head, long bdy_num_elem,
		     MeshNode *msh_n_head, long *num_mesh_nd,
		     MeshElem *msh_l_head, long *num_mesh_el)
{
  REAL bxmin, bymin, bzmin, bxmax, bymax, bzmax;
  char ref_fname[80];
  int  option, in_zone, ref_level, flag=0;
  long ii, num_node, num_elem, xbdy_num_node, xbdy_num_elem;
  REAL distance;
  MeshNode  *nptr;
  MeshElem  *eptr;
  BMeshNode *xbdy_n_head;
  BMeshElem *xbdy_l_head;


  num_node = *num_mesh_nd;
  num_elem = *num_mesh_el;

  /* find max. size of the object */
  Max_size = BDxmax - BDxmin;
  if (Max_size < BDymax - BDymin)  Max_size = BDymax - BDymin;
  if (Max_size < BDzmax - BDzmin)  Max_size = BDzmax - BDzmin;

  for (;;)
  {
    if (Ref_batch_flag == BAD)
    {
        printf("\nRefinement Based on(0= No refine / 1= Along BDY/ 2= along Given/ Region / 3= Inside Given Region / 4= Batch) : ");
        scanf ("%d", &option);
       
        /* for batch refining mode */
        if (option == 4)
        {
            /* read in batch file name */
            printf ("\nInput Batch File Name: ");
            scanf  ("%s", Batch_fname);
          
            if ((Batch_in = fopen (Batch_fname, "rt")) == NULL)
            {
	            printf ("\nError...File %s not found!\n", Batch_fname);
                continue;
            }  
            else
            {
                Ref_batch_flag = OK;
	            fscanf (Batch_in, "%d", &Num_file_batch);
                fscanf (Batch_in, "%s %d %lf", ref_fname, &option, &distance);

#ifdef NORMALIZE_DATA
	    distance *= Norm_scale;
#endif

                Ref_dist = distance;
                Cur_num_file_read++;
	    }
        }
    }
    else 
    {
        /* in Batch refining mode */
        if (Num_file_batch > Cur_num_file_read) 
        {
            fscanf (Batch_in, "%s %d %lf", ref_fname, &option, &distance);

#ifdef NORMALIZE_DATA
	    distance *= Norm_scale;
#endif
            Ref_dist = distance;
            Cur_num_file_read++;
        }
        else 
        {
            Ref_batch_flag = BAD; 
            Num_file_batch = Cur_num_file_read = 0;
	        option = 0;
        }
      
    }

    if (option < 0 || option > 4)  
    {
        if (Ref_batch_flag == OK)  break; 
        else                        continue;
    }
    if (option == 0)     return (BAD);
    if (option == 1)
    {
      if (Ref_batch_flag == BAD)
      {
                bxmin = BDxmin;     bymin = BDymin;     bzmin = BDzmin;
                bxmax = BDxmax;     bymax = BDymax;     bzmax = BDzmax;

#ifdef NORMALIZE_DATA
            /* since the bdy data has been normalized, but user should
            see the original size 
            */
            bxmin = bxmin / Norm_scale + Norm_orig[X];
            bymin = bymin / Norm_scale + Norm_orig[Y];
            bzmin = bzmin / Norm_scale + Norm_orig[Z];
            bxmax = bxmax / Norm_scale + Norm_orig[X];
            bymax = bymax / Norm_scale + Norm_orig[Y];
            bzmax = bzmax / Norm_scale + Norm_orig[Z];
#endif
	    printf ("\nGlobal Bounding Box: ");
	    printf ("\nxmin = %8.4lf;    xmax = %8.4lf;",   bxmin, bxmax);
	    printf ("\nymin = %8.4lf;    ymax = %8.4lf;",   bymin, bymax);
	    printf ("\nzmin = %8.4lf;    zmax = %8.4lf;\n", bzmin, bzmax);

	    printf ("\nInput the distance to BDY (define refinement zone): ");
	    scanf  ("%lf", &distance);

#ifdef NORMALIZE_DATA
	    distance *= Norm_scale;
#endif

	    Ref_dist = distance;
      }


      /* initial and element attributes checking  */
      eptr = msh_l_head;
      for (ii=0; ii<num_elem; ii++)
      {
	    eptr->attr = 0;
	    if (eptr->E_type != TET4)
	    {
	        printf ("\nWarning elem. No.%ld type is not a TET4!\n", ii);
	    }
          eptr = eptr->Next;
      }

      ref_level = 1;
      nptr = msh_n_head;
      for (ii=0; ii<num_node; ii++)
      {
	    in_zone = check_ref_zone (nptr, bdy_l_head, bdy_num_elem, distance);
	    if (in_zone == OK)
	    {
	        nptr->in_zone = OK;
	        /* tag refining elements which attached to the node and the
	        elements adjacend to tagged elem. with at least 2 sharing nodes
	        */
	        if (tag_associate_elem (nptr, ref_level) == BAD)
	        {
	            printf ("\nThere is an error in tagging refining element\n") ;
	            flag = BAD;
	        }
	    }
	    else
	    {
	        nptr->in_zone = BAD;
	    }

	    nptr = nptr->Next;
      }
      break;
    }

    if (option == 2 || option == 3)
    {
      if (Ref_batch_flag == BAD)
      {
	    /* read in tri-patch region file */
	    printf ("\nInput Refining region definition file :");
	    scanf  ("%s", ref_fname);
      }

      /* initialization */
      xbdy_num_node = xbdy_num_elem = 0;
      xbdy_n_head = NULL;
      xbdy_l_head = NULL;
      /* read_ref_region (ref_fname, ...)  */
      if (read_ref_region (ref_fname, &xbdy_n_head, &xbdy_num_node, &xbdy_l_head,
			   &xbdy_num_elem) == BAD)
	  return (BAD);

#ifdef NORMALIZE_DATA
      normalize_def_bdy_nodes (xbdy_n_head, xbdy_num_node, xbdy_l_head,
			                    xbdy_num_elem);
#endif
      

      if (option == 2)
      {
	    if (Ref_batch_flag == BAD)
	    {
	        printf ("\nInput the distance to XBDY (define refinement zone): ");
	        scanf  ("%lf", &distance);

#ifdef NORMALIZE_DATA
	        distance *= Norm_scale;
#endif

	        Ref_dist = distance;
	    }
      }
      else
      {
        /* 
            option == 3 case
	        equal zero or negative  means refine the inside of the region 
            Note that : user should responsible for a closed surface input
        */
	    Ref_dist = distance = 0.;
      }

      /* initial and element attributes checking  */
      eptr = msh_l_head;
      for (ii=0; ii<num_elem; ii++)
      {
	    eptr->attr = 0;
	    if (eptr->E_type != TET4)
	    {
	        printf ("\nWarning elem. No.%ld type is not a TET4!\n", ii);
	    }
        eptr = eptr->Next;
      }

      ref_level = 1;
      nptr = msh_n_head;
      for (ii=0; ii<num_node; ii++)
      {
	    in_zone = check_ref_zone (nptr, xbdy_l_head, xbdy_num_elem, distance);
	    if (in_zone == OK)
	    {
	        nptr->in_zone = OK;
	        /* tag refining elements which attached to the node and the
	            elements adjacend to tagged elem. with at least 2 sharing nodes
	        */
	        if (tag_associate_elem (nptr, ref_level) == BAD)
	        {
	            printf ("\nThere is an error in tagging refining element\n") ;
	            flag = BAD;
	        }
	    }
	    else
	    {
	        nptr->in_zone = BAD;
	    }
	    nptr = nptr->Next;
      }

      if (xbdy_n_head)
	    free_bnode_list (xbdy_n_head, xbdy_num_node);

      if (xbdy_l_head)
	    free_belem_list (xbdy_l_head, xbdy_num_elem);

      break;
    }
  }

  /* insert nodes for refining elements and associated elements */
  New_msh_node = insert_nodes (msh_n_head, num_mesh_nd,
			                msh_l_head, num_elem, ref_level);


  /* check element with knitting condition and create a
	 element list to be refined
  */
  check_knit (msh_n_head, num_mesh_nd, msh_l_head, num_elem, ref_level);

  return (flag);
}





/* Check the distance from given surface patch to test node
   if the node to surface distance is less than given distance
   the node is in refining zone, then return OK otherwise is BAD
*/
int
check_ref_zone (MeshNode *nptr, BMeshElem *surf_l_head,
		long surf_num_elem, REAL ref_dist)
{
      int  k, db_flag=BAD;
      long ii;
      REAL pnt[3], dist, min_dist, d[3], e[3], xlen, ylen;
      BMeshElem *septr, *bdy_patch_ptr;

      /* pass node coordinates and initialization */
      for (k=0; k<3; k++)
      {
	    d[k] = nptr->Coor[k];
      }

      if (ref_dist < HIGTOL)
      {
	/* check in-out refine inside */
        /* maximum ray cast distant */
        xlen = 4. * (BDxmax - BDxmin);
        ylen = 4. * (BDymax - BDymin);

	    /* end node */
#ifdef RANDOM_VACTOR
        random_shoot_full (d, e);
#else
	    e[X] = d[X] + xlen;
	    e[Y] = d[Y];
	    e[Z] = d[Z];
#endif
	    /* determin node in-out */
	    if (nod_inout (d, e, surf_l_head, surf_num_elem, 
                           &bdy_patch_ptr, db_flag) == 0)
                return (BAD);   /* outside region */
            else
                return (OK);   /* in (or on) the region */
      }

  /* along the Given region */
  min_dist = 1.e10;

  septr = surf_l_head;
  for (ii=0; ii<surf_num_elem; ii++)
  {
    /* box checking with bdy. patch */
    if (d[X]+ref_dist < septr->xmin || d[X]-ref_dist > septr->xmax)  goto G0;
    if (d[Y]+ref_dist < septr->ymin || d[Y]-ref_dist > septr->ymax)  goto G0;
    if (d[Z]+ref_dist < septr->zmin || d[Z]-ref_dist > septr->zmax)  goto G0;

    /* find closest distance to surface patches */
    dist = pnt2bdy (nptr, septr, pnt);  /* pnt --- dummy */
    if (dist < min_dist)
    {
      min_dist = dist;
    }

G0: septr = septr->Next;
  }

    /* check inbound */
    if (min_dist < ref_dist)    return (OK);
    else                        return (BAD);

}






/* tag the elements attached to node and those element sharing at least
   two nodes with tagged elements
*/
int
tag_associate_elem (MeshNode *nptr, int ref_level)
{
  int       i;
  MeshElem  *eptr, *sub_eptr;
  AdjElem   *aeptr, *sub_aeptr;
  MeshNode **nnptr, **sub_nnptr;

  /* pass pointer for adj. elem. list */
  aeptr = nptr->Fst_adj_elem;
  if (aeptr == NULL)
  {
    printf ("\nNull Fst_adj_elem (in tag_associate_elem)\n");
    return (BAD);
  }
  /*
   1.promote the element in elem. adj. list up to TET10 and set elem.
     attribute to be ref_level.
   2.promote those elements which sharing edge with element tagged w.
     ref_level. to TET10 but do not change its attribute, these elem.
     are not element to be refined but the related element to transeint
     to rest of elements in the model.
  */
    while (aeptr)
    {
	    eptr = aeptr->idx;
	    /* tag element to be refined */
	    if (eptr->E_type != TET10)
	    {
	        eptr->attr   = ref_level;
	        nnptr = tet4_2_tet10 (eptr);
	    }

	    nnptr = eptr->Elem.tet10.NodePtr;
	    /* suppose the refinement is from low level to high level.
	        so it keep as current heightest level
	    */
	    if (eptr->attr < ref_level) eptr->attr = ref_level;

	    /* check associated elements */
	    for (i=0; i<4; i++)
	    {
	        if (nnptr[i] == nptr) continue; /* same node -- skip */
	        sub_aeptr = nnptr[i]->Fst_adj_elem;
	        while (sub_aeptr)
	        {
		        sub_eptr = sub_aeptr->idx;
		        if (eptr == sub_eptr)
		        {
		            sub_aeptr = sub_aeptr->ptr;
		            continue;
		        }
		        /* see if already promoted to TXT10 */
		        if (sub_eptr->E_type == TET10)  goto CON0;
		        /* find match nodes */
		        sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
		        /* if share at least two nodes, promote it to TXT10 */
		        if (match_nodes (nnptr, sub_nnptr) > 1)
		        {
		            /* share at least two nodes */
		            tet4_2_tet10 (sub_eptr);
		        }

CON0:		    sub_aeptr = sub_aeptr->ptr;
	        }
	    }

	    aeptr = aeptr->ptr;
    }

  return (OK);
}



/* find how many sharing nodes of two elements */
int
match_nodes (MeshNode **nnptr1, MeshNode **nnptr2)
{
    int num_share = 0, i, j;

    for (i=0; i<4; i++)
    {
	if (nnptr1[i])
	{
		for (j=0; j<4; j++)
		{
		    if (nnptr2[j])
			if (nnptr1[i] == nnptr2[j])  num_share++;
		}
	}
    }
    return (num_share);
}


void
initial_txt4_10 (MeshNode **nnptr)
{
    int   i;

    for (i=4; i<10; i++)    nnptr[i] = NULL;

    return;
}



/* insert nodes into promoted elements, return: number of nodes
   being added.
*/
long
insert_nodes (MeshNode *msh_n_head, long *num_mesh_nd,
	      MeshElem *msh_l_head, long num_elem, int ref_level)
{
    int      k, m, j1, j2, jmid, sub_mid;
    long     ii, num_new_node=0;
    MeshElem  *eptr, *sub_eptr;
    AdjElem   *sub_aeptr;
    MeshNode **nnptr, *nptr, **sub_nnptr;

    eptr = msh_l_head;
    for (ii=0; ii<num_elem; ii++)
    {
	    if (eptr->E_type == TET10 && eptr->attr == ref_level)
	    {   /* complete refined element */
	        nnptr = eptr->Elem.tet10.NodePtr;
	        /* promoted element with ref_level */
	        for (k=0; k<6; k++)
	        {
		        /* pass base node indices */
		        j1 = vtx_num[k][0];   j2 = vtx_num[k][1];

		        /* middle insertion node index */
		        jmid = mid_num [j1][j2];
		        if (nnptr[jmid])
		        {   /* already done, check middle node coord.*/
		            if (check_mid_coor (nnptr, j1, j2, jmid) == BAD)
		            printf ("\nError...Wrong Mid. node Coord.!\n");
		            continue;
		        }
		        /* otherwise insert a middle node */
		        /* allocate memory for new node */
		        nnptr[jmid] = (MeshNode *) malloc (sizeof (MeshNode));
		        if (!nnptr[jmid])	alloc_error ("refine-1");
		        else
		        {
		            nptr = nnptr[jmid];
		            nptr->Fst_adj = NULL;
		            nptr->Num_adj = 0;
		            nptr->Fst_adj_elem = NULL;
		            nptr->Num_adj_elem = 0;
		            nptr->status  = 0;
		            nptr->in_zone = 0;
		            nptr->Mtrl = BAD;
		            nptr->Prev = NULL;
		            nptr->Next = NULL;
		        }
		        /* set up links to node list in tail */
		        nptr->Next = msh_n_head;
		        nptr->Prev = msh_n_head->Prev;
		        msh_n_head->Prev->Next = nptr;
		        msh_n_head->Prev = nptr;

		        /* compute middle node coordinates */
		        for (m=0; m<3; m++)
		        {
		            nnptr[jmid]->Coor[m] =
		                0.5 * (nnptr[j1]->Coor[m] + nnptr[j2]->Coor[m]);
		        }
		        num_new_node++;
		        (*num_mesh_nd)++;

		        /* check associated element */
		        sub_aeptr = nnptr[j1]->Fst_adj_elem;
		        while (sub_aeptr)
		        {
		            sub_eptr = sub_aeptr->idx;
		            if (eptr == sub_eptr)
		            {
		                sub_aeptr = sub_aeptr->ptr;
		                continue;
		            }
		            /* see if is a elem. promoted to TET10 */
		            if(sub_eptr->E_type==TET10)
		            {
			            /* find match nodes */
			            sub_nnptr = sub_eptr->Elem.tet10.NodePtr;
			            /* if share common edge */
			            if (match_edge (nnptr[j1], nnptr[j2], sub_nnptr,
					            &sub_mid) == OK)
			            {
			                if (sub_nnptr[sub_mid] == NULL)
			                {
				                sub_nnptr[sub_mid] = nnptr[jmid];
			                }
			                else if (sub_nnptr[sub_mid] != nnptr[jmid])
			                {
				                printf ("\nWarning...Middle node conflicting (insert nodes!\n");
			                }
			            }
		            }
		            sub_aeptr = sub_aeptr->ptr;
		        }
	        }
	    }
	    eptr = eptr->Next;
    }

    return (num_new_node);
}


/* check shared edge of two elements and middle node index */
int
match_edge (MeshNode *nptr1, MeshNode *nptr2,
	    MeshNode **sub_nnptr, int *sub_mid_index)
{
    int  k, i1=BAD, i2=BAD;

    /* check node 1 */
    for (k=0; k<4; k++)
	if (sub_nnptr[k] == nptr1)
	{
	    i1 = k;
	    break;
	}

    /* check node 2 */
    for (k=0; k<4; k++)
	if (sub_nnptr[k] == nptr2)
	{
	    i2 = k;
	    break;
	}

    if (i1 != BAD && i2 != BAD)
    {
	if ((i1<0 || i1>3) || (i2<0 || i2>3) || i1==i2)
	{
	    printf ("\nWarning... Sub_elem index messed up\n");
	}
	else
	{
	    /* found common edge */
	    *sub_mid_index = mid_num [i1][i2];
	    return (OK);
	}
    }

    return (BAD);
}

/* check middle node coordinates */
int
check_mid_coor (MeshNode **nnptr, int j1, int j2, int jmid)
{
  int  k;
  REAL v;

  for (k=0; k<3; k++)
  {
      v = 0.5 * (nnptr[j1]->Coor[k] + nnptr[j2]->Coor[k]);
      if (fabs (nnptr[jmid]->Coor[k] - v) > LOWTOL)
	    return (BAD);
  }

  return (OK);
}




/*
	check element with knitting condition and create a
	 element list to be refined
*/

void
check_knit (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *msh_l_head,
	    long num_elem, int ref_level)
{
    int     new_promote, new_node, elem_pattern;
    long    tet4_num, tet5_num, tet6_num, tet7_num, tet8_num, tet9_num;
    long    tet_level_num, tet10_num;
    long    ii, dbg_num;
    MeshElem  *eptr;
    AdjElem   *aeptr;

    /* create initial refinement list */
    eptr = msh_l_head;
    for (ii=0; ii<num_elem; ii++)
    {
	    if (eptr->E_type == TET10)
	    {
	        aeptr = (AdjElem *) malloc (sizeof (AdjElem));
            if (!aeptr) alloc_error ("refine-2"); 
	        aeptr->idx = eptr;
	        aeptr->ptr = NULL;
	        if (Ref_elm_list == NULL && Num_ref_elm == 0)
	        {
	            /* first element to be refined */
	            Ref_elm_list = Last_ref_elm = aeptr;
	        }
	        else
	        {
	            Last_ref_elm->ptr = aeptr;
	            Last_ref_elm      = aeptr;
	        }
	        Num_ref_elm++;
	    }
	    eptr = eptr->Next;
    }

    /* checking break down conditions for promoted element.
       if it doesn't match break down pattern then add mid
       nodes to match the pattern. This is an iteration
       process since the new promotion may chance the refine-
       ment list. So the process will be finished until there
       is no new promotion happened. That means, for final
       pattern, only have 10, 7, 6, 5 (may be 4?) nodes TET10
       left.
       Attention: The refinement list will be kept expand
       during process. Don't be suprise.
    */
    if (Ref_elm_list == NULL)
    {
       printf ("\nNULL refinement list !!\n");
       return;
    }
    for (;;)
    {
       new_promote = BAD;
       new_node    = 0;
       dbg_num     = 0;

       /* for debug */
       tet4_num    = 0;
       tet5_num    = 0;
       tet6_num    = 0;
       tet7_num    = 0;
       tet8_num    = 0;
       tet9_num    = 0;
       tet10_num    = 0;
       tet_level_num = 0;

       aeptr = Ref_elm_list;
       while (aeptr)
       {
	        dbg_num++;
	        eptr = aeptr->idx;
	        if (eptr->E_type == TET10 && eptr->attr != ref_level)
	        {
	            /* if the tet is ref_level, it means it's already 10 node tet */
	            /* find element pattern */
	            elem_pattern = find_tet_pattern (eptr);

	            switch (elem_pattern)
	            {
	                case TET4_4:
                        tet4_num++;
	                    printf ("\nUn-promoted element!!\n");
			            break;
	                case TET4_5:
			            /* generally,  all set. but may check if needs
			                insert a mid-node on oppesite edge.
			            */
                        tet5_num++;
			            break;
	                case TET4_6:
			            /* if two mid-node do not on same face leave as
			                6 node pattern, otherwise raise to 7 node.
			            */
                        tet6_num++;
			            if (process_tet4_6 (msh_n_head, num_mesh_nd, eptr)
			                            == OK)
			            {
				            new_promote = OK;
				            new_node++;
			            }
			            break;
	                case TET4_7:
			            /* if three mid-node do not on same face raise
			                to 10 node tet, otherwise leave it as 7 node.
			                pattern.
			            */
                        tet7_num++;
			            if (process_tet4_7 (msh_n_head, num_mesh_nd, eptr)
			                                == OK)
			            {
				            new_promote = OK;
				            new_node += 3;
			            }
			            break;
	                case TET4_8:
                        tet8_num++;
			            /* promote to 10 nodes tet10 */
			            /* add two mid-node. first. */
			            process_tet4_8 (msh_n_head, num_mesh_nd, eptr);
			            new_node += 2;
			            new_promote = OK;
			            break;
	                case TET4_9:
                        tet9_num++;
			            /* add one more mid-node up to 10 node tet10 */
			            process_tet4_9 (msh_n_head, num_mesh_nd, eptr);
			            new_node++;
			            new_promote = OK;
			            break;
	                case TET4_10:
			            /* all set for complete break down */
                        tet10_num++;
			            break;
	                default:
		                printf ("\nWarning...Unknown promoted type!!\n");

	            }
	        }
	        else if (eptr->E_type == TET10 && eptr->attr == ref_level)
	        {
	            tet_level_num++;
	        }  
	     
	        aeptr = aeptr->ptr;
        }

        /* double checking for debug */
       if (dbg_num != Num_ref_elm)
	        printf ("\nThe num. of refined elements did not match: dbg=%8ld (%8ld)\n",
		            dbg_num, Num_ref_elm);

       if (new_promote == BAD && new_node == 0)   break;

    }

    /* for debug */
    printf ("\nTotal Num_ref_elm                = %ld", Num_ref_elm);
    printf ("\nIn refinement Zone tet_level_num = %ld", tet_level_num);
    printf ("\nNum. of Tet4 (should be 0)       = %ld", tet4_num);
    printf ("\nNum. of Tet5                     = %ld", tet5_num);
    printf ("\nNum. of Tet6                     = %ld", tet6_num);
    printf ("\nNum. of Tet7                     = %ld", tet7_num);
    printf ("\nNum. of Tet8 (should be 0)       = %ld", tet8_num);
    printf ("\nNum. of Tet9 (should be 0)       = %ld", tet9_num);
    printf ("\nNum. of Tet10                    = %ld\n", tet10_num);
    return;
}




/* find element pattern by checking the num. of non NULL node */
int
find_tet_pattern (MeshElem *eptr)
{
    int      i, num_node=0;
    MeshNode **nnptr;

    nnptr = eptr->Elem.tet10.NodePtr;
    for (i=0; i<10; i++)
    {
	if (nnptr[i])  num_node++;
    }

    return (num_node);
}






/* process 6 real node tetrahedra for knitting */
int
process_tet4_6 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr)
{
    int      i, j[3], k, nd_idx_1, nd_idx_2, mid_idx=0, itemp;
    MeshNode **nnptr;

    nnptr = eptr->Elem.tet10.NodePtr;


    /* check if two middle on opposite */
    k = 0;
    for (i=4; i<10; i++)
    {
	if (nnptr[i] != NULL)
	{
	   j[k++] = i;
	   /* if (k==2)  break; */
	}
    }

    if (k != 2)
    {
	printf ("\nError...middle nodes not equal 2 in process_tet4_6:\n" );
	return (BAD);
    }
    /* cases for two middle nodes on opposite edge */
    /* indices group: (4, 9) (5, 7) (6, 8) */
    /* sort indices in ascendent  */
    if (j[0] > j[1])
    {
	itemp = j[0];
	j[0] = j[1];
	j[1] = itemp;
    }

    if ((j[0]==4 && j[1]==9) || (j[0]==5 && j[1]==7) || (j[0]==6 && j[1]==8))
    {
	/* two middle nodes on opposite edge. don't modify it */
	return (BAD);
    }

    /* find middle node index which is on same plane with the other two mid. nodes */
    /* cases for three middle nodes on same plane.  remeber j[0] <j[1] ! */
    /* indices group: (4, 7, 8) (5, 8, 9) (6, 7, 9) (4, 5, 6)  */
    if (j[0] == 4)
    {
	if (j[1] == 7)      mid_idx = 8;
	else if (j[1] == 8) mid_idx = 7;
	else if (j[1] == 5) mid_idx = 6;
	else if (j[1] == 6) mid_idx = 5;
	else  printf ("\nWrong index: j[0] = %d; j[1] = %d;\n", j[0], j[1]);
    }
    else if (j[0] == 5)
    {
	if (j[1] == 6)        mid_idx = 4;
	else if (j[1] == 8)   mid_idx = 9;
	else if (j[1] == 9)   mid_idx = 8;
	else  printf ("\nWrong index: j[0] = %d; j[1] = %d;\n", j[0], j[1]);
    }
    else if (j[0] == 6)
    {
	if (j[1] == 7)      mid_idx = 9;
	else if (j[1] == 9) mid_idx = 7;
	else  printf ("\nWrong index: j[0] = %d; j[1] = %d;\n", j[0], j[1]);
    }
    else if (j[0] == 7)
    {
	if (j[1] == 8)        mid_idx = 4;
	else if (j[1] == 9)   mid_idx = 6;
	else  printf ("\nWrong index: j[0] = %d; j[1] = %d;\n", j[0], j[1]);
    }
    else if (j[0] == 8)
    {
	if (j[1] == 9)   mid_idx = 5;
	else  printf ("\nWrong index: j[0] = %d; j[1] = %d;\n", j[0], j[1]);
    }
    else 
    {
        printf ("\nWrong mid idx in process_tet4_6; mid_idx = %d", mid_idx);
    }	
    /* pass base node indices */
    nd_idx_1 = vtx_num[mid_idx - 4][0];
    nd_idx_2 = vtx_num[mid_idx - 4][1];

    /* insert a middle node on the edge nd_idx_1, nd_idx_2 */
    add_a_mid (msh_n_head, num_mesh_nd, nnptr, nd_idx_1, nd_idx_2, mid_idx);


    return (OK);
}





/* process 7 real node tetrahedra for knitting */
int
process_tet4_7 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr)
{
    int      i, j[3], k, nd_idx_1, nd_idx_2, mid_idx, itemp;
    MeshNode **nnptr;

    nnptr = eptr->Elem.tet10.NodePtr;


    /* check if three middle on same plane */
    k = 0;
    for (i=4; i<10; i++)
    {
	if (nnptr[i] != NULL)
	{
	   j[k++] = i;
	   /* if (k==3)  break; */
	}
    }

    if (k != 3)
    {
	printf ("\nError...middle nodes not equal 3 in process_tet4_7:\n" );
	return (BAD);
    }
    /* cases for three middle nodes on same plane */
    /* indices group: (4, 7, 8) (5, 8, 9) (6, 7, 9) (4, 5, 6)  */
    /* sort indices in ascendent with insertion sort */
    for (i=0; i<3; i++)
    {
	itemp = j[i];
	for (k=i; k>0; k--)
	{
	  if (j[k-1] > itemp)
	  {
	     j[k] = j[k-1];
	  }
	  else
	     break;
	}
	j[k] = itemp;
    }


    if ((j[0]==4 && j[1]==7 && j[2]==8) ||
	(j[0]==5 && j[1]==8 && j[2]==9) ||
	(j[0]==6 && j[1]==7 && j[2]==9) ||
	(j[0]==4 && j[1]==5 && j[2]==6))
    {
	/* three middle nodes on same place. don't modify it */
	return (BAD);
    }

    /* for debug 
    printf ("\nProcess_tet4_7: j[0] = %3d; j[1] = %3d; j[2] = %3d;\n", 
	    j[0], j[1], j[2]);

    */

    /* otherwise add three more middle nodes up to complete 10 node TET10 */
    k = 0;
    for (i=0; i<10; i++)
    {
	if (nnptr[i] == NULL)
	{
	   j[k++] = i;
	   /* if (k==3)  break; */
	}
    }

    if (k != 3)
    {
	printf ("\nError...NULL nodes not equal 3 in process_tet4_7:\n" );
	return (BAD);
    }
    /* for debugging */
    if (j[0]<4 || j[1]<4 || j[2]<4)
    {
	printf ("\nError...problem index in process_tet4_7:\n" );
	return (BAD);
    }

    for (i=0; i<3; i++)
    {
	mid_idx = j[i];
	/* pass base node indices */
	nd_idx_1 = vtx_num[mid_idx - 4][0];
	nd_idx_2 = vtx_num[mid_idx - 4][1];

	/* insert a middle node on the edge nd_idx_1, nd_idx_2 */
	add_a_mid (msh_n_head, num_mesh_nd, nnptr, nd_idx_1, nd_idx_2, mid_idx);
    }


    return (OK);
}





/* process 8 real node tetrahedra for knitting */
int
process_tet4_8 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr)
{
    int      i, j[2], k=0, nd_idx_1, nd_idx_2, mid_idx;
    MeshNode **nnptr;

    nnptr = eptr->Elem.tet10.NodePtr;

    for (i=0; i<10; i++)
    {
	if (nnptr[i] == NULL)
	{
	   j[k++] = i;
	   /* if (k==2)  break;  */
	}
    }

    if (k != 2)
    {
	printf ("\nError...NULL nodes not equal 2 in process_tet4_8:\n" );
	return (BAD);
    }
    /* for debugging */
    if (j[0]<4 || j[1]<4)
    {
	printf ("\nError...problem index in process_tet4_8:\n" );
	return (BAD);
    }

    for (i=0; i<2; i++)
    {
	mid_idx = j[i];
	/* pass base node indices */
	nd_idx_1 = vtx_num[mid_idx - 4][0];
	nd_idx_2 = vtx_num[mid_idx - 4][1];

	/* insert a middle node on the edge nd_idx_1, nd_idx_2 */
	add_a_mid (msh_n_head, num_mesh_nd, nnptr, nd_idx_1, nd_idx_2, mid_idx);
    }

    return (OK);
}





/* process 9 real node tetrahedra for knitting */
int
process_tet4_9 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr)
{
    int      i, nd_idx_1, nd_idx_2, mid_idx, k=0;
    MeshNode **nnptr;

    nnptr = eptr->Elem.tet10.NodePtr;

    for (i=0; i<10; i++)
    {
	if (nnptr[i] == NULL)   
	{
	  k++;
	  mid_idx = i;
	  /* break; */
	}
    }

    /* for debugging */
    if (i<4 || k != 1)
    {
	printf ("\nError...problem index in process_tet4_9: i = %d\n", i);
	return (BAD);
    }

    /* mid_idx = i; */
    /* pass base node indices */
    nd_idx_1 = vtx_num[mid_idx - 4][0];
    nd_idx_2 = vtx_num[mid_idx - 4][1];

    /* insert a middle node on the edge nd_idx_1, nd_idx_2 */
    add_a_mid (msh_n_head, num_mesh_nd, nnptr, nd_idx_1, nd_idx_2, mid_idx);

    return (OK);
}




/* add a middle node on edge (nd_idx_1, nd_idx_2) and check its associate
   elements if it's a TET4 element, promote it to TET10 and add it to
   refinement list.
*/
void
add_a_mid (MeshNode *msh_n_head, long *num_mesh_nd, MeshNode **nnptr,
	   int nd_idx_1, int nd_idx_2, int mid_idx)
{
    int      m, sub_mid;
    AdjElem  *aeptr, *sub_aeptr;
    MeshElem *sub_eptr;
    MeshNode *nptr, **sub_nnptr;

    /* allocate memory for new node */
    nnptr[mid_idx] = (MeshNode *) malloc (sizeof (MeshNode));
    if (!nnptr[mid_idx])	alloc_error ("refine-3");
    else
    {
	nptr = nnptr[mid_idx];
	nptr->Fst_adj = NULL;
	nptr->Num_adj = 0;
	nptr->Fst_adj_elem = NULL;
	nptr->Num_adj_elem = 0;
	nptr->status  = 0;
	nptr->in_zone = 0;
	nptr->Mtrl = BAD;
	nptr->Prev = NULL;
	nptr->Next = NULL;
    }
    /* set up links to node list in tail */
    nptr->Next = msh_n_head;
    nptr->Prev = msh_n_head->Prev;
    msh_n_head->Prev->Next = nptr;
    msh_n_head->Prev = nptr;

    /* compute middle node coordinates */
    for (m=0; m<3; m++)
    {
	nnptr[mid_idx]->Coor[m] = 0.5 * (nnptr[nd_idx_1]->Coor[m]
				+ nnptr[nd_idx_2]->Coor[m]);
    }
    (*num_mesh_nd)++;

    /* check associated element */

    sub_aeptr = nnptr[nd_idx_1]->Fst_adj_elem;
    while (sub_aeptr)
    {
	sub_eptr = sub_aeptr->idx;

	if (sub_eptr->E_type == TET4)
	{
	   /* it is an unpromoted element */
	   sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
	}
	else if (sub_eptr->E_type == TET10)
	{
	    sub_nnptr = sub_eptr->Elem.tet10.NodePtr;
	}
	else
	{
	     printf ("\nWrong elem type to be refined!\n");
	     goto CON3;
	}

	/* check common edge */
	if (match_edge (nnptr[nd_idx_1], nnptr[nd_idx_2],
					sub_nnptr, &sub_mid) == OK)
	{
	    if (sub_eptr->E_type == TET4)
	    {
		/* has a common edge, promote it to TET10 */
		sub_nnptr = tet4_2_tet10 (sub_eptr);
		/* add it to refinement list */
		aeptr = (AdjElem *) malloc (sizeof (AdjElem));
		if (!aeptr)    alloc_error ("refine-4");
		aeptr->idx = sub_eptr;
		aeptr->ptr = NULL;
		if (Ref_elm_list == NULL && Num_ref_elm == 0)
		{
		   /* impossible for this case! just for debugging */
		   printf ("\nSomething wrong... in refinement list.\n");
		   /* first element to be refined */
		   Ref_elm_list = Last_ref_elm = aeptr;
		}
		else
		{
		   Last_ref_elm->ptr = aeptr;
		   Last_ref_elm      = aeptr;
		}
		Num_ref_elm++;
	    }


	    sub_nnptr[sub_mid] = nnptr[mid_idx]; /* debug: assign anyway */
            /*
	    if (sub_nnptr[sub_mid] == NULL)
	    {
		sub_nnptr[sub_mid] = nnptr[mid_idx];
	    }
            else if (sub_nnptr[sub_mid] != nnptr[mid_idx])
             	printf ("\nWarning...Middle node conflicting (in add a mid)!\n");

            */
	}

CON3:	sub_aeptr = sub_aeptr->ptr;
    }


    return;
}



/* refine elements tagged as 10 node TET10 */
int
refine_tets (MeshElem **msh_l_head, long *num_mesh_el,
	      AdjElem *ref_list, long num_ref)
{
    int       elem_pattern;
    long      num_elem;
    MeshElem  *eptr;
    AdjElem   *aeptr;

    num_elem = *num_mesh_el;
    aeptr = ref_list;
    while (aeptr)
    {
	eptr = aeptr->idx;
	elem_pattern = find_tet_pattern (eptr);
	switch (elem_pattern)
	{
	    case TET4_4:
			printf ("\nUnrefined element (tet4)!!\n");
			tet10_2_tet4 (eptr);
			break;
	    case TET4_5:
			/* break into two tet4 */
			refine_tet5 (eptr, msh_l_head, num_mesh_el);
			num_elem++;
			break;
	    case TET4_6:
			/* break into four tet4 */
			refine_tet6 (eptr, msh_l_head, num_mesh_el);
			num_elem += 3;
			break;
	    case TET4_7:
			/* break into four tet4 */
			refine_tet7 (eptr, msh_l_head, num_mesh_el);
			num_elem += 3;
			break;
	    case TET4_10:
			/* all set for complete break down to 8 tet4 */
			refine_tet10 (eptr, msh_l_head, num_mesh_el);
			num_elem += 7;
			break;
	    default:
		     printf ("\nWarning...Unknown pattern to break down!!\n");

	}

	aeptr = aeptr->ptr;
    }


    /* doubly check */
    if (num_elem != *num_mesh_el)
       printf ("\nWarning... Number of element didn't match after refinement\n");

    return (OK);
}


/* break into 8 tets */
int
refine_tet10 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el)
{
    int      i, j;
    MeshElem *sub_eptr;
    MeshNode **nnptr, **sub_nnptr;
    static tet1_8_idx [8][4] = { {0, 4, 6, 7},
				 {1, 8, 5, 4},
				 {2, 6, 5, 9},
				 {3, 9, 8, 7},
				 {6, 9, 7, 4},
				 {5, 8, 9, 4},
				 {6, 5, 9, 4},
				 {4, 7, 8, 9} };

    nnptr = eptr->Elem.tet10.NodePtr;
    for (i=0; i<8; i++)
    {
	sub_eptr = create_an_elem (msh_l_head, num_mesh_el);
	sub_eptr->E_type = TET4;
	sub_eptr->attr = eptr->attr;    /* refinement level */
	sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
	for (j=0; j<4; j++)
	{
	    sub_nnptr[j] = nnptr[tet1_8_idx [i][j]];
	}
    }
    /* free base (parent) element */
    tet10_2_tet4 (eptr);
    free_a_elem (eptr, msh_l_head, num_mesh_el);

    return (OK);
}



/* break into 4 tets */
int
refine_tet7 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el)
{
    int      i, j, k, m[3], itemp;
    MeshElem *sub_eptr;
    MeshNode **nnptr, **sub_nnptr;
    static tet7_4_idx [4][8][4] =
	{ { {5, 8, 9, 0}, {0, 9, 3, 8}, {1, 8, 5, 0}, {0, 2, 9, 5} },
	  { {6, 9, 7, 1}, {0, 6, 7, 1}, {1, 9, 2, 6}, {1, 3, 9, 7} },
	  { {7, 8, 4, 2}, {0, 2, 7, 4}, {1, 8, 2, 4}, {2, 3, 7, 8} },
	  { {4, 5, 6, 3}, {0, 6, 3, 4}, {1, 3, 5, 4}, {2, 5, 3, 6} } };

    nnptr = eptr->Elem.tet10.NodePtr;

    /* find the three middle on same plane */
    k = 0;
    for (i=4; i<10; i++)
    {
	if (nnptr[i] != NULL)
	{
	   m[k++] = i;
	   if (k==3)  break;
	}
    }

    if (k != 3)
    {
	printf ("\nError...middle nodes not equal 3 in refine_tet7:\n" );
	return (BAD);
    }
    /* cases for three middle nodes on same plane */
    /* indices group: (4, 7, 8) (5, 8, 9) (6, 7, 9) (4, 5, 6)  */
    /* sort indices in ascendent with insertion sort */
    for (i=0; i<3; i++)
    {
	itemp = m[i];
	for (k=i; k>0; k--)
	{
	  if (m[k-1] > itemp)
	  {
	     m[k] = m[k-1];
	  }
	  else
	     break;
	}
	m[k] = itemp;
    }

    /* find the pattern to break down */
    if (m[0]==4 && m[1]==7 && m[2]==8)       k = 2;
    else if (m[0]==5 && m[1]==8 && m[2]==9)  k = 0;
    else if (m[0]==6 && m[1]==7 && m[2]==9)  k = 1;
    else if (m[0]==4 && m[1]==5 && m[2]==6)  k = 3;
    else
    {
	printf ("\nError... No pattern match in refine_tet7!\n");
	return (BAD);
    }


    for (i=0; i<4; i++)
    {
	sub_eptr = create_an_elem (msh_l_head, num_mesh_el);
	sub_eptr->E_type = TET4;
	sub_eptr->attr = eptr->attr;    /* refinement level */
	sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
	for (j=0; j<4; j++)
	{
	    sub_nnptr[j] = nnptr[tet7_4_idx [k][i][j]];
	}
    }
    /* free base (parent) element */
    tet10_2_tet4 (eptr);
    free_a_elem (eptr, msh_l_head, num_mesh_el);

    return (OK);
}



/* break into 4 tets */
int
refine_tet6 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el)
{
    int      i, j, k, m[2], itemp;
    MeshElem *sub_eptr;
    MeshNode **nnptr, **sub_nnptr;
    static tet6_4_idx [3][4][4] =
	{ { {4, 9, 1, 2}, {9, 4, 1, 3}, {4, 9, 0, 3}, {9, 4, 0, 2} },
	  { {5, 7, 2, 0}, {7, 5, 2, 3}, {5, 7, 1, 3}, {7, 5, 1, 0} },
	  { {6, 8, 0, 1}, {8, 6, 0, 3}, {6, 8, 2, 3}, {8, 6, 2, 1} } };

    nnptr = eptr->Elem.tet10.NodePtr;
    /* check if two middle on opposite */
    k = 0;
    for (i=4; i<10; i++)
    {
	if (nnptr[i] != NULL)
	{
	   m[k++] = i;
	   if (k==2)  break;
	}
    }

    if (k != 2)
    {
	printf ("\nError...middle nodes not equal 2 in refine_tet6:\n" );
	return (BAD);
    }
    /* sort indices in ascendent  */
    if (m[0] > m[1])
    {
	itemp = m[0];
	m[0] = m[1];
	m[1] = itemp;
    }


    /* cases for two middle nodes on opposite edge */
    /* indices group: (4, 9) (5, 7) (6, 8) */

    if (m[0]==4 && m[1]==9)       k = 0;
    else if (m[0]==5 && m[1]==7)  k = 1;
    else if (m[0]==6 && m[1]==8)  k = 2;
    else
    {
	printf ("\nError... No pattern match in refine_tet7!\n");
	return (BAD);
    }



    for (i=0; i<4; i++)
    {
	sub_eptr = create_an_elem (msh_l_head, num_mesh_el);
	sub_eptr->E_type = TET4;
	sub_eptr->attr = eptr->attr;    /* refinement level */
	sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
	for (j=0; j<4; j++)
	{
	    sub_nnptr[j] = nnptr[tet6_4_idx [k][i][j]];
	}
    }
    /* free base (parent) element */
    tet10_2_tet4 (eptr);
    free_a_elem (eptr, msh_l_head, num_mesh_el);

    return (OK);
}



/* break into 2 tets */
int
refine_tet5 (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el)
{
    int      i, j, k, done_flag=BAD;
    MeshElem *sub_eptr;
    MeshNode **nnptr, **sub_nnptr;
    static tet5_2_idx [6][2][4] = { {{0, 2, 3, 4}, {2, 1, 3, 4}},
				    {{1, 3, 5, 0}, {2, 5, 3, 0}},
				    {{2, 3, 6, 1}, {0, 6, 3, 1}},
				    {{0, 2, 7, 1}, {2, 3, 7, 1}},
				    {{1, 8, 2, 0}, {2, 8, 3, 0}},
				    {{2, 1, 9, 0}, {1, 3, 9, 0}}};

    nnptr = eptr->Elem.tet10.NodePtr;
    for (k=4; k<10; k++)
    {
	if (nnptr[k])
	{
	    done_flag = OK;
	    break;
	}
    }
    if (done_flag != OK)
	printf ("\nError...tet5 node pattern didn't match!!\n");

    /* match pattern */
    k -= 4;

    for (i=0; i<2; i++)
    {
	sub_eptr = create_an_elem (msh_l_head, num_mesh_el);
	sub_eptr->E_type = TET4;
        sub_eptr->attr = eptr->attr;    /* refinement level */
	sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
	for (j=0; j<4; j++)
	{
	    sub_nnptr[j] = nnptr[tet5_2_idx [k][i][j]];
	}
    }
    /* free base (parent) element */
    tet10_2_tet4 (eptr);
    free_a_elem (eptr, msh_l_head, num_mesh_el);

    return (OK);
}


/* create an element and add to tail of the elem. list */
MeshElem *
create_an_elem (MeshElem **msh_l_head, long *num_mesh_el)
{
     int      i;
     MeshElem *eptr;
     MeshNode **nnptr;

	    /* allocate for elem */
	    eptr = (MeshElem *) malloc (sizeof (MeshElem));
	    if (!eptr)	alloc_error ("refine-5");
	    else
	    {
		eptr->attr = 0;
/* added by Ziji Wu, 9/7/99 */
		eptr->status = 0;
/* end of Ziji */
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
                nnptr = eptr->Elem.tet10.NodePtr;
                for (i=0; i<10; i++) nnptr[i] = NULL;
	    }

	    /* link to tail of the elem list */
	    eptr->Prev = (*msh_l_head)->Prev;
	    eptr->Next = *msh_l_head;
	    (*msh_l_head)->Prev->Next = eptr;
	    (*msh_l_head)->Prev = eptr;
	    (*num_mesh_el)++;
    return (eptr);
}









void
free_a_elem (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el)
{
    /* late on two cases may add into checking
       1. only one element in the list (head itself) head->Next = head->Prev = NULL
       2. only two elements in the list head->Next == head->Prev
    */
    if (eptr == *msh_l_head)
    {
	/* It's first (head) element */
	eptr->Prev->Next = eptr->Next;
	eptr->Next->Prev = eptr->Prev;
	*msh_l_head = eptr->Next;
    }
    else
    {
	eptr->Prev->Next = eptr->Next;
	eptr->Next->Prev = eptr->Prev;
    }

    (*num_mesh_el)--;
    free ((char *) eptr);
    eptr = NULL;
    return;
}







/* free adjacent node and element list */
void
free_adj_lists (MeshNode *head, long num_nodes)
{
    int       count;
    long      debug_num = 0;
    MeshNode  *nptr;
    AdjList   *anptr, *an_next;
    AdjElem   *aeptr, *ae_next;

    nptr = head; 

    do
    {
      debug_num++;
      count = 0;

      if (nptr == NULL) 
        return ;

      anptr = nptr->Fst_adj;
      while (anptr)
      {
	    count++;
	    an_next = anptr->ptr;
        free ((char *)anptr);
	    anptr = an_next;
      }
      if (count == nptr->Num_adj)
      {
	    nptr->Fst_adj = NULL;
        nptr->Num_adj = 0;
      }
      else
      {
	    printf ("\nWarning...node adj. not match n = %d (%d)", 
                  count, nptr->Num_adj);
      }
      
      count = 0;
      aeptr = nptr->Fst_adj_elem;
      while (aeptr)
      {
	    count++;
	    ae_next = aeptr->ptr;
        free ((char *)aeptr);
	    aeptr = ae_next;
      }
      if (count == nptr->Num_adj_elem)
      {
	    nptr->Fst_adj_elem = NULL;
        nptr->Num_adj_elem = 0;
      }
      else
      {
	    printf ("\nWarning...elem. adj. not match n = %d (%d)", 
                  count, nptr->Num_adj_elem);
      }

      nptr = nptr->Next;
    } while (nptr != head);

    if (debug_num != num_nodes)
       printf ("\nTotal number of nodes didn't match debug_num = %ld (%ld)!\n", debug_num, num_nodes);

    /*
    for (ii=0; ii<num_nodes; ii++)
    {
	    if (nptr->Fst_adj)
	    {
	      free_adj (nptr->Fst_adj);
	      nptr->Num_adj = 0;
	    }
	    if (nptr->Fst_adj_elem)
	    {
	      free_adj_elem (nptr->Fst_adj_elem);
	      nptr->Num_adj_elem = 0;
	    }
	    nptr = nptr->Next;
    }
    */

    return;
}



/* read in user defined refinement region */
int
read_ref_region (char *fname, BMeshNode **xbdy_n_head, long *xbdy_num_node,
		     BMeshElem **xbdy_l_head, long *xbdy_num_elem)
{
    char line[256];
    int  numbering;
    long num_x_elem, num_x_node;
    FILE *fp;

    if ((fp = fopen (fname, "r")) == NULL) {
	printf ("\nCan't open input file : %s\n", fname);
	return (BAD);
    }

#ifdef READ_LINE
        if (fgets(line, 256, fp))
        {
            sscanf (line, "%d %ld %ld", &numbering, &num_x_node, &num_x_elem);
        }
#else
        fscanf (fp, "%d %ld %ld", &numbering, &num_x_node, &num_x_elem);
#endif

    if (numbering == 1)    numbering = OK;
    else                   numbering = BAD;

    rd_xbdy_node (fp, xbdy_n_head, num_x_node, numbering);
    rd_xbdy_elem (fp, *xbdy_n_head, xbdy_l_head, num_x_elem, numbering);

    *xbdy_num_node = num_x_node;
    *xbdy_num_elem = num_x_elem;

    return (OK);
}








/* read in user defined boundary nodes */
int
rd_xbdy_node (FILE *fp, BMeshNode **xbdy_n_head, long bdy_nodes, int numbering)
{
    char line[256];
    long ii, ldummy;
    BMeshNode *nptr, *cur_ptr;

    /* first node */
    (*xbdy_n_head)  = (BMeshNode *) malloc (sizeof (BMeshNode));
    if (!(*xbdy_n_head))   alloc_error ("refine-6");
    else
    {
        (*xbdy_n_head)->Prev = NULL;
	    (*xbdy_n_head)->Next = NULL;
    }

    nptr = cur_ptr = (*xbdy_n_head);

    if (numbering == OK)
    {
#ifdef READ_LINE
        if (fgets(line, 256, fp))
        {
            sscanf (line, "%ld %lf %lf %lf", &ldummy,
	            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
        }
#else
	    fscanf (fp, "%ld %lf %lf %lf", &ldummy,
	            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
#endif        
    }
    else
    {
#ifdef READ_LINE
        if (fgets(line, 256, fp))
        {
            sscanf (line, "%lf %lf %lf",
	            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
        }
#else
	    fscanf (fp, "%lf %lf %lf",
	            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
#endif
    }

    /* 2 to last node */
    for (ii=1; ii<bdy_nodes; ii++)
    {
	    nptr = (BMeshNode *) malloc (sizeof (BMeshNode));
	    if (!nptr)	alloc_error ("refine-7");
	    else
	    {
	        nptr->Prev = NULL;
	        nptr->Next = NULL;
	    }

	    /* set node link */
	    cur_ptr->Next = nptr;
	    nptr->Prev = cur_ptr;

	    cur_ptr = nptr;

	    /* read in node coordinates */
	    if (Numbering == OK)
	    {
#ifdef READ_LINE
            if (fgets(line, 256, fp))
            {
                sscanf (line, "%ld %lf %lf %lf", &ldummy,
	                &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
            }
#else
	        fscanf (fp, "%ld %lf %lf %lf", &ldummy,
		            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
#endif
	    }
	    else
	    {
#ifdef READ_LINE
            if (fgets(line, 256, fp))
            {
                sscanf (line, "%lf %lf %lf",
	                &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
            }
#else
	        fscanf (fp, "%lf %lf %lf",
		            &nptr->Coor[X], &nptr->Coor[Y], &nptr->Coor[Z]);
#endif
	    }
    }

    /* close the link */
    nptr->Next = (*xbdy_n_head);
    (*xbdy_n_head)->Prev = nptr;

    return (OK);

}



/* read in user defined boundary elements */
int
rd_xbdy_elem (FILE *fp, BMeshNode *xbdy_n_head, BMeshElem **xbdy_l_head, 
	      long bdy_elem, int numbering)
{
    char        line[256];
    long        ii, ldummy, lnum_1, lnum_2, lnum_3;
    BMeshElem   *eptr, *cur_eptr;


    /* first elem */
    (*xbdy_l_head) = (BMeshElem *) malloc (sizeof (BMeshElem));
    if (!(*xbdy_l_head))   alloc_error ("refine-8");
    else
	{
	    (*xbdy_l_head)->Prev = NULL;
	    (*xbdy_l_head)->Next = NULL;
	    (*xbdy_l_head)->Mtrl_in = BAD;
	    (*xbdy_l_head)->Mtrl_out = BAD;
    }

	eptr = cur_eptr = (*xbdy_l_head);

	if (numbering == OK)
    {
#ifdef READ_LINE
        if (fgets(line, 256, fp))
        {
            sscanf (line, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
        }
#else
	    fscanf (fp, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
#endif

	    eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (xbdy_n_head, lnum_1);
	    eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (xbdy_n_head, lnum_2);
	    eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (xbdy_n_head, lnum_3);
    }
    else
    {
#ifdef READ_LINE
        if (fgets(line, 256, fp))
        {
            sscanf (line, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
        }
#else
	    fscanf (fp, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
#endif 

	    eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (xbdy_n_head, lnum_1);
	    eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (xbdy_n_head, lnum_2);
	    eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (xbdy_n_head, lnum_3);
    }

    tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 

    /* 2 to last elem */
    for (ii=1; ii<bdy_elem; ii++)
    {
	    eptr = (BMeshElem *) malloc (sizeof (BMeshElem));
	    if (!eptr)	alloc_error ("refine-9");
	    else
	    {
	        eptr->Mtrl_in = BAD;
	        eptr->Mtrl_out = BAD;
	        eptr->Prev = NULL;
	        eptr->Next = NULL;
	    }

	    /* set node link */
	    cur_eptr->Next = eptr;
	    eptr->Prev = cur_eptr;

	    cur_eptr = eptr;

	    if (numbering == OK)
	    {
#ifdef READ_LINE
            if (fgets(line, 256, fp))
            {
                sscanf (line, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
            }
#else
	        fscanf (fp, "%ld %ld %ld %ld", &ldummy, &lnum_1, &lnum_2, &lnum_3);
#endif

	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (xbdy_n_head, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (xbdy_n_head, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (xbdy_n_head, lnum_3);
	    }
	    else
	    {
#ifdef READ_LINE
            if (fgets(line, 256, fp))
            {
                sscanf (line, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
            }
#else
	        fscanf (fp, "%ld %ld %ld", &lnum_1, &lnum_2, &lnum_3);
#endif

	        eptr->Elem.tri3.NodePtr[0]=conv_bnode_idx (xbdy_n_head, lnum_1);
	        eptr->Elem.tri3.NodePtr[1]=conv_bnode_idx (xbdy_n_head, lnum_2);
	        eptr->Elem.tri3.NodePtr[2]=conv_bnode_idx (xbdy_n_head, lnum_3);
	    }
        tri_patch_bound (eptr->Elem.tri3.NodePtr, &eptr->xmin, &eptr->ymin,
                       &eptr->zmin, &eptr->xmax, &eptr->ymax, &eptr->zmax); 

    }

    /* close the link */
    eptr->Next = (*xbdy_l_head);
    (*xbdy_l_head)->Prev = eptr;

    return (OK);
}






/* change tet4 element to tet10 element */
MeshNode ** 
tet4_2_tet10 (MeshElem *eptr)
{
    int       i;
    MeshNode *NodePtr[10], **nnptr; 
    
    for (i=0; i<10; i++)   NodePtr[i] = NULL;
    nnptr = eptr->Elem.tet4.NodePtr;
    for (i=0; i<4; i++)    NodePtr[i] = nnptr[i];
    eptr->E_type = TET10;
    nnptr = eptr->Elem.tet10.NodePtr;
    for (i=0; i<10; i++)   nnptr[i] = NodePtr[i];
    return (nnptr);
}




MeshNode ** 
tet10_2_tet4 (MeshElem *eptr)
{
    int       i;
    MeshNode *NodePtr[10], **nnptr; 
    
    for (i=0; i<10; i++)   NodePtr[i] = NULL;
    nnptr = eptr->Elem.tet10.NodePtr;
    for (i=0; i<4; i++)    NodePtr[i] = nnptr[i];
    for (i=0; i<10; i++)   nnptr[i] = NodePtr[i];
    eptr->E_type = TET4;
    nnptr = eptr->Elem.tet4.NodePtr;
    for (i=0; i<4; i++)    nnptr[i] = NodePtr[i];
    return (nnptr);

}






