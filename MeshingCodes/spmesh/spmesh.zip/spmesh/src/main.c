    
/*
  ************************************************************************
  *  main.c :	Main routine for 3D mesh generation			             *
  *									                                     *
  *  Qingyang Zhang				   Dec. 29, 1994	                     *
  ************************************************************************
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <math.h>

#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"
/* Ziji 102298 */
#include "time.h"
/* end of Ziji */

#define MAIN_MOD

/* for wpi unix */ 
/* Ziji 10/21/98 #define _XWINDOW_ */

/* Ziji 1/5/98 in order to output specialty stuff to a new diag file */
FILE *fpzw;
/* end of Ziji */

/* Ziji 9/7/99 in order to output comforming stuff to a new diag file */
FILE *fpzw2;
/* end of Ziji */

#define DEFAULT_SCALE_FACTOR    1.0
#define DEFAULT_AUTO_REF_LEVEL  0

/* define global varibles */
#include "defglb.h"

/*
** External Functions
*/

extern int init_glb (int do_not_free_sp);
extern int release_glb (void);
extern int rdnml (int done_file);
extern int free_bnode_list (BMeshNode *head, long num_node);
extern int free_belem_list (BMeshElem *head, long num_elem);
extern int free_node_list (MeshNode *head, long num_node);
extern int free_elem_list (MeshElem *head, long num_elem);
extern int free_line_list (LineData *head, int num_elem);
extern int set_fixed_bdy_node (BMeshNode *bdy_n_head, long bdy_num_node,
			MeshNode *msh_n_head, long msh_num_node);
extern int lap_soomth (MeshNode *msh_n_head, long msh_num_node,
		      int soomth_class);
extern int debug_output (char *fout_name);
extern int final_output (int out_type);
extern int fit_sp_node (MeshNode *msh_n_head, long n_msh_node,
		 MeshNode *sp_n_head,  int n_sp_node, double g_size);
extern int fit_sp_line (MeshNode *msh_n_head, long n_msh_node,
		 MeshElem *msh_l_head, long n_msh_elem,
		 MeshNode *sp_n_head,  int n_sp_node,
		 LineData *sp_l_head,  int n_sp_line, REAL g_size);
extern int fit_spoly_line (MeshNode *msh_n_head, long n_msh_node,
	     MeshElem *msh_l_head, long n_msh_elem,
	     MeshNode *spoly_n_head,  int n_spoly_node,
	     LineData *spoly_l_head,  int n_spoly_elem,
	     LineData **spoly_list_head, int *num_seg_poly, REAL g_size);
extern int mesh_assess (MeshElem *msh_l_head, long n_msh_elem, 
			int jcb_flag, int vol_flag, int asp_flag,
			int skw_flag, int warp_flag, int qua_flag);
extern int out_mesh_quali (MeshElem *msh_l_head, long n_msh_elem, char *fname);
extern int gen_brick (BMeshNode *bdy_n_head, long bdy_num_node,
                      BMeshElem *bdy_l_head, long bdy_num_elem,
                      MeshNode **msh_n_head, long *msh_num_node,
                      MeshElem **msh_l_head, long *msh_num_elem,
	              REAL *g_size);
extern int gen_elem (BMeshNode *bdy_n_head, long bdy_num_node,
              BMeshElem *bdy_l_head, long bdy_num_elem,
              MeshNode **msh_n_head, long *msh_num_node,
              MeshElem **msh_l_head, long *msh_num_elem,
              REAL *g_size);
extern int mesh_nod_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		   MeshNode *msh_n_head, long n_msh_node,
		   int class_type, MeshNode *msh_n_curt);
extern int kill_element (MeshElem **msh_l_head, long *n_msh_elem, int kill_mode);
extern int kill_iso_node (MeshNode **msh_n_head, long *n_msh_node);
extern void conform_out_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
                 BMeshElem *bdy_l_head, long bdy_num_elem,
		 MeshNode *msh_n_head, long msh_num_node,
                 MeshElem *msh_l_head, long msh_num_elem);
extern void conform_in_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
		 BMeshElem *bdy_l_head, long bdy_num_elem,
		 MeshNode *msh_n_head, long msh_num_node,
		 MeshElem *msh_l_head, long msh_num_elem);
extern int conform_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
                BMeshElem *bdy_l_head, long bdy_num_elem,
		        MeshNode *msh_n_head, long *msh_node,
                MeshElem *msh_l_head, long *msh_elem);

extern int ref_bdy_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
		   MeshNode **msh_n_head, long *num_mesh_nd,
		   MeshElem **msh_l_head, long *num_mesh_el);
extern int ref_hex_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
		   MeshNode **msh_n_head, long *num_mesh_nd,
		   MeshElem **msh_l_head, long *num_mesh_el);
extern void free_adj_lists (MeshNode *head, long num_nodes);
extern int mk_adjlist(MeshNode *n_head,long num_node, MeshElem *e_head, 
		      long num_elem);
extern int set_elem_mtrl  (BMeshNode *bdy_n_head, long bdy_num_node,
		    BMeshElem *bdy_l_head, long bdy_num_elem,
		    MeshNode *msh_n_head, long msh_num_node,
		    MeshElem *msh_l_head, long msh_num_elem);
extern int set_elem_mtrl_b  (BMeshNode *bdy_n_head, long bdy_num_node,
            BMeshElem *bdy_l_head, long bdy_num_elem,
            MeshNode *msh_n_head, long msh_num_node,
            MeshElem *msh_l_head, long msh_num_elem);
extern int set_elem_mtrl_test  (BMeshNode *bdy_n_head, long bdy_num_node,
		    BMeshElem *bdy_l_head, long bdy_num_elem,
		    MeshNode *msh_n_head, long msh_num_node,
		    MeshElem *msh_l_head, long msh_num_elem);
extern int clean_poor_elem  (MeshElem  **msh_l_head, long *msh_num_elem);
extern int rectify_mesh   (BMeshNode *bdy_n_head, long bdy_num_node,
		    BMeshElem *bdy_l_head, long bdy_num_elem,
		    MeshNode  **msh_n_head, long *msh_num_node,
		    MeshElem  **msh_l_head, long *msh_num_elem);
extern int  back_ori_node (MeshNode *msh_n_head, long msh_num_node);
extern int  adj_node_loc  (MeshNode *msh_n_head, long msh_num_node,
			   REAL mov_distance);
extern int free_patch (Spatch *adj_patch, long num_patch);
extern int ext_mat_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type);
extern int ext_num_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type);
extern int free_polyline_list (LineData **head,  int *seg_in_poly, int num_poly);
extern int check_cross_bdy_elem (MeshNode **nnptr, int num_node);
extern int normalize_bdy_nodes (double scale_factor);
extern int denormal_nodes (void);
extern int set_fixed_bdy_node (BMeshNode *bdy_n_head, long bdy_num_node,
							MeshNode *msh_n_head, long msh_num_node);

/* Ziji 10/21/98 #ifdef _XWINDOW_
extern int X_motif_GUI (void);
#endif */

/* Ziji 9/2/99 */
extern void search_bdy_node (MeshNode *msh_n_head, long msh_num_node);

/* local function */
int debug_check  (char *title);
int check_elem_mtrl (int show_outbound);
int check_unfitted (void);
int check_null_bdynode_ptr (void);


/* Global setting */ 
static int Elimination = ALL_MODE;


/* Ziji 102298 */
/* Pauses for a specified number of milliseconds. */
/*void sleep( clock_t wait )
{
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() )
      ;
}
*/

int
main (int argc, char *argv[])
{
    int  k, sp_flag, view_flag=0;
/*Ziji 102198    int  smooth_class, status, ref_flag, x_win_flag=1, mesh_done=BAD;
*/    int  smooth_class, status, ref_flag, mesh_done=BAD;
    REAL gsize, scale_factor;

/* Ziji 1/5/98 in order to output specialty stuff to a new diag file */
if((fpzw  = fopen( "sp.dia", "w" )) == NULL )
   printf( "The specialty diag file can not be created!\n" );
/* end of Ziji */

/* Ziji 9/7/99 in order to output conforming stuff to a new diag file */
if((fpzw2  = fopen( "conform.dia", "w" )) == NULL )
   printf( "The conforming diag file can not be created!\n" );
/* end of Ziji */

/* Ziji 102298 */
/*	printf("============================================================\n");
	printf("|           ....................................           |\n");
	printf("|           . 3D  ADAPTIVE  MESH   GENERATOION .           |\n");
	printf("|           ....................................           |\n");
	printf("|                                                          |\n");
	printf("|             --- Delveloped & Maintained by               |\n");
	printf("|                 Dr. John M. Sullivan, Jr.                |\n");
	printf("|                 Dr. James Qingyang Zhang                 |\n");
	printf("|                                                          |\n");
	printf("|              Worcester Polytechnic Institute             |\n");
	printf("|                     sullivan@wpi.edu                     |\n");
	printf("|----------------------------------------------------------|\n");
	printf("============================================================\n\n");
    sleep( (clock_t)3 * CLOCKS_PER_SEC ); *//* delay 3 seconds */

/* end of Ziji 102298 */

/* moved up by Ziji 4/16/99 */
    /* initialize global setting */
    init_glb (0); 

    scale_factor       = DEFAULT_SCALE_FACTOR;
    Max_auto_ref_level = DEFAULT_AUTO_REF_LEVEL;
    k = 3;
	if (argc < k)
	{
        printf ("\n====== Define Internal Model Size ======\n");
        printf ("\n  A model with extreme physical size (too large or too\n");
        printf ("small) may cause truncate problem. User may define an \n");
        printf ("absolute model size --- the maximum internal model size,\n");
        printf ("to re-scale the model before generating mesh. A unit \n");
        printf ("internal model size (1.0) is correspond to a nomalized\n");
        printf ("scaling on the input model -- which is the default setting\n");

        printf ("\nInput internal model size (1 - 10000): ");
        scanf  ("%lf", &scale_factor);
        if (scale_factor < LOWTOL || scale_factor > 100000) 
            scale_factor = DEFAULT_SCALE_FACTOR;

        printf ("\nInput the max. number of auto-refinement level : ");
        scanf ("%d", &Max_auto_ref_level);
        if (Max_auto_ref_level <= 0 || Max_auto_ref_level > 15)
            Max_auto_ref_level = DEFAULT_AUTO_REF_LEVEL;

/* added by Ziji, 4/16/99 */
		if (Max_auto_ref_level>0) {
		   printf("\n\n While checking if a building block crosses physical bdy element,\n");
		   printf(" Ignore adjacent physical bdy elem? (0=ignore; 1=not ignore): ");
           scanf("%d", &autoref_ignore_adj_bdy);
		   if ((autoref_ignore_adj_bdy!=0)&&(autoref_ignore_adj_bdy!=1))
			   autoref_ignore_adj_bdy=0;
		   printf("\n Ignore same material bdy elem? (0=ignore; 1=not ignore): ");
           scanf("%d", &autoref_ignore_same_mtrl_bdy);
		   if ((autoref_ignore_same_mtrl_bdy!=0)&&(autoref_ignore_same_mtrl_bdy!=1))
			   autoref_ignore_same_mtrl_bdy=0;
		}
/* end of Ziji */
	}
	else
	{
		while (argc >= k)
		{
			if (strcmp (argv[k-2], "-s") == 0 || strcmp (argv[k-2], "/s") == 0)
			{
				/* user defined scale factor */
				scale_factor = atof (argv[k-1]);
				if (scale_factor < 0 || fabs (scale_factor) < LOWTOL || scale_factor > 1.e5)
                    scale_factor = DEFAULT_SCALE_FACTOR;
			}
			else if (strcmp (argv[k-2], "-n") == 0 || strcmp (argv[k-2], "/n") == 0) 
			{
				Max_auto_ref_level = atoi (argv[k-1]);
				if (Max_auto_ref_level < 0)
					Max_auto_ref_level = 0;
			}
			k += 2;
		}
	}
    printf ("The absolute model size           = %lf \n", scale_factor);
    printf ("The max. level of auto refinement = %d  \n", Max_auto_ref_level);

    /* initialize global setting */
/* Ziji, 4/16/99 moved up    init_glb (0); */

    /* open diag. file */
    Diag_file = fopen (Diag_fname, "wt");
    if (Diag_file == NULL)
    {
        printf ("\nCan't open file '%s'!\n", Diag_fname);
        return (-1);
    }

/* Ziji 102198 #ifdef _XWINDOW_
    printf ("\nRun X-window Display ? (No: 0 / Yes: 1) : ");
    scanf ("%d", &x_win_flag);
#else
    x_win_flag = 0;
#endif
*/

    /* read in new NML format data file */
    if (rdnml (0) == BAD)   
    {
        printf ("\nPress any key to quit!\n");
        getchar (); getchar ();
        return (-1);
    }

    printf ("\nAfter read in NML file.\n");

    if (Msh_node_head_ptr != NULL)
    {
        printf ("\nDo you want just to evaluate volume mesh (without generate new mesh)? (Yes:1 / No:0): ");
        scanf ("%d", &view_flag);
        if (view_flag == 1)
            goto VIEW_MESH;
    }
#ifdef NORMALIZE_DATA
    /* normalize the bdy data */
    normalize_bdy_nodes (scale_factor); 
#endif

/*
#ifdef _XWINDOW_
    if (x_win_flag)
           X_motif_GUI ();
#endif
*/
    if ((Bdy_node_head_ptr != NULL && Bdy_nodes != BAD) &&
            Msh_node_head_ptr == NULL)
    {
	    gen_elem (Bdy_node_head_ptr, Bdy_nodes,
                  Bdy_elem_head_ptr, Bdy_elem,
		         &Msh_node_head_ptr, &Msh_nodes,
		         &Msh_elem_head_ptr, &Msh_elem,
		         &gsize);
        
	    /* if (Global_size == BAD)  this cause problem when given size not make sense */  
        Global_size = gsize;
    }
    else
    {
	    mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);
	    mesh_done = OK; /* for skipping some steps (needs figure out) */
    }
    
/*Ziji 102198 #ifdef _XWINDOW_
    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/    /*
    if (x_win_flag)
           X_motif_GUI ();
    */
/*Ziji 102198 #endif
*/

    if ((Bdy_elem_head_ptr != NULL && Bdy_elem != BAD) &&
	    (Msh_node_head_ptr != NULL && Msh_nodes != BAD))
    {
	    /* mesh node classification status = OK/BAD */
        printf ("\nDoing mesh node classify. \n");
	    status = mesh_nod_classify (Bdy_elem_head_ptr, Bdy_elem,
			            Msh_node_head_ptr, Msh_nodes, WHOLE, NULL);

        /*
        printf ("\nBefore output file classify.out\n");
	    debug_output ("classify.out");
	    */

/*Ziji 8/4/00	    if (mesh_done == BAD)
        {
            printf ("\nEliminating the elements in given region. \n");
            kill_element (&Msh_elem_head_ptr, &Msh_elem, Elimination);
            kill_iso_node (&Msh_node_head_ptr, &Msh_nodes);

			/* added by Ziji, 3/10/00 */
/*Ziji 8/4/00			if ((Msh_nodes==0)||(Msh_elem==0)) {
				printf("\nThere are %ld nodes and %ld elements left!\n", Msh_nodes, Msh_elem);
				exit(-10);
			}
			/* end of Ziji, 3/10/00 */

	        /* reset Adjacent Node and Element list */
	        /* free adjlist first */
/*Ziji 8/4/00	        free_adj_lists (Msh_node_head_ptr, Msh_nodes);
	        /* creat adjlist */
/*Ziji 8/4/00	        mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);

	        printf ("\nAfter elimination--Total Nodes: %ld; Tolal Elem: %ld\n",
                    Msh_nodes, Msh_elem); 
        
            /* debug_output ("kill_element.out"); */
/*Ziji 8/4/00	    }
	    else
	    {
	        printf ("\nUser given mesh ... eliminating operation skipped!\n");
            printf ("\n(Re-process mesh = 0   /  View mesh = 1) : ");
            scanf  ("%d", &view_flag);
            if (view_flag) 
            {
                view_flag = 1;
                goto VIEW_MESH;
            }
        }

        /* comment out for user */
        /*
        mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
        if (x_win_flag)
             X_motif_GUI ();
        */
    }


    if (Msh_elem_head_ptr->E_type == TET4)
    {
        /* for tetrahedra element */
        if (Ref_batch_flag == BAD)
            printf ("\nNeed Refinement? (No: 0 / Yes: 1) : ");
        else
        {
            /* batch refining mode */
            /* in Batch refining mode */
            if (Num_file_batch < Cur_num_file_read+1)
            {
                Ref_batch_flag = BAD;
	            Num_file_batch = Cur_num_file_read = 0;
                ref_flag = 0;
                goto G10;
            }
        }

        do
        {
            if (Ref_batch_flag == BAD)
            {
                printf ("\nInput 'ref_flag':");
                scanf ("%d", &ref_flag);
            }
            else
                ref_flag = 1;

            if (ref_flag == 1)
            {
	            /* refinement along BDY */
	            status = ref_bdy_elem (Bdy_elem_head_ptr, Bdy_elem,
		                            &Msh_node_head_ptr, &Msh_nodes,
		                            &Msh_elem_head_ptr, &Msh_elem);

	            if (status == BAD)   break;

	            printf ("\nRefinement Done!\n");
                /* debug_check ("Debug...refine done");   */

	            /* mesh node classification status = OK/BAD */
	            printf ("\nDoing mesh node classify again. \n");
	            status = mesh_nod_classify (Bdy_elem_head_ptr, Bdy_elem,
			                Msh_node_head_ptr, Msh_nodes, WHOLE, NULL);
	            /*
                printf ("\nBefore output file classify2.out\n");
	            debug_output ("classify2.out");
	            */
/* Ziji 102198 #ifdef _XWINDOW_
	            mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/		    /*
	            if (Ref_batch_flag == BAD)
	                if (x_win_flag)
		                X_motif_GUI ();
		    */
/* Ziji 102198 #endif */

	            printf ("\nEliminating the elements in given region (2). \n");
	            kill_element (&Msh_elem_head_ptr, &Msh_elem, Elimination);
	            kill_iso_node (&Msh_node_head_ptr, &Msh_nodes);

	            /* reset Adjacent Node and Element list */
	            /* free adjlist first */
	            free_adj_lists (Msh_node_head_ptr, Msh_nodes);
	            /* creat adjlist */
	            mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);

	            printf ("\nAfter elimination (2)--Total Nodes: %ld; Tolal Elem: %ld\n",
		                Msh_nodes, Msh_elem);


	            mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
	            /* out_mesh_quali (Msh_elem_head_ptr, Msh_elem, "quali0.out"); */

	            /* debug_output ("kill2_element.out"); */
                if (Ref_batch_flag == BAD)
	            {
/* Ziji 102198 #ifdef _XWINDOW_ */
		      /*
	                if (x_win_flag)
		            X_motif_GUI ();
		      */
/* Ziji 102198 #endif */
	                printf ("\nNeed Refinement Again? (No: 0 / Yes: 1) : ");
	            }
            }
        } while (ref_flag == 1);
    }
    else if (Msh_elem_head_ptr->E_type == HEX8)
    {
	    status = ref_hex_elem (Bdy_elem_head_ptr, Bdy_elem,
                                &Msh_node_head_ptr, &Msh_nodes,
		                        &Msh_elem_head_ptr, &Msh_elem);
    
		
//final_output (FINAL_OUT);


        /*  mesh node classification status = OK/BAD */
	    printf ("\nDoing mesh node classify again. \n");
	    status = mesh_nod_classify (Bdy_elem_head_ptr, Bdy_elem,
			                Msh_node_head_ptr, Msh_nodes, WHOLE, NULL);
/* Ziji 102198 #ifdef _XWINDOW_ 
	    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	    /*
	    if (x_win_flag)
		    X_motif_GUI ();
	    */
/* Ziji 102198 #endif */
	    /*
	    printf ("\nBefore output file refhex.out\n");
	    debug_output ("refhex.out");
	    */

//final_output (FINAL_OUT);

		printf ("\nEliminating the elements in given region (2). \n");
	    /* use ALL_MODE here for find numerical surface --- CENTRAL_MODE */
	    kill_element (&Msh_elem_head_ptr, &Msh_elem, Elimination);
	    kill_iso_node (&Msh_node_head_ptr, &Msh_nodes);

	    /* reset Adjacent Node and Element list */
	    /* free adjlist first */
	    free_adj_lists (Msh_node_head_ptr, Msh_nodes);
	    /* creat adjlist */
	    mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);

	    printf ("\nAfter elimination (2)--Total Nodes: %ld; Tolal Elem: %ld\n",
		                Msh_nodes, Msh_elem);

	    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
        out_mesh_quali (Msh_elem_head_ptr, Msh_elem, "quali1.out");

/* Ziji 102198 #ifdef _XWINDOW_ */
	/*
	    if (x_win_flag)
		    X_motif_GUI ();
	*/
/* Ziji 102198 #endif */
    }
    /* extract Numerical surface */
    printf ("\nExport Numerical Surfaces? (Yes=1/No=0): ");
    scanf  ("%d", &Numerical_surf);
    if (Numerical_surf != 1)    Numerical_surf = 0;

    if (Numerical_surf == 1)
    {
        Main_file = fopen (Main_fname, "wt");
        if (Main_file == NULL)
        {
            printf ("\nCan't open file '%s' --- quit\n", Main_fname);
            exit (-1);
        }
        
        set_elem_mtrl_b  (Bdy_node_head_ptr, Bdy_nodes,
		              Bdy_elem_head_ptr, Bdy_elem,
                      Msh_node_head_ptr, Msh_nodes,
		              Msh_elem_head_ptr, Msh_elem);

        /* write input bdy file name  */
        fprintf (Main_file, "%s\n", Input_name);
        final_output (NUMER_OUT);

        printf ("\nBefore extract Numerical surface!\n");
        ext_num_surfaces (Bdy_node_head_ptr, Bdy_nodes,
		                Bdy_elem_head_ptr, Bdy_elem,
                        Msh_node_head_ptr, Msh_nodes,
		                Msh_elem_head_ptr, Msh_elem, 
                        FINAL_EXBDY); /* INITIAL_EXBDY);*/

        printf ("\nAfter extract Numerical surface!\n");

    }

    /*
    if (x_win_flag)
	       X_motif_GUI ();
    */

G10:  ;

    /* do specialty stuff */
    sp_flag = 0;
    if ((Sp_node_head_ptr != NULL && Sp_nodes != BAD) &&
	    (Msh_node_head_ptr != NULL && Msh_nodes != BAD) && Global_size != BAD)
    {
        sp_flag = 1;

		set_fixed_bdy_node (Bdy_node_head_ptr, Bdy_nodes,
								Msh_node_head_ptr, Msh_nodes);

/* added by Ziji, 3/16/99 */
		search_bdy_node(Msh_node_head_ptr, Msh_nodes);


        /* fit specialty nodes */
/* Ziji 1/6/99 */
		fprintf(fpzw, "\nStart fiting specialty nodes...");

        fit_sp_node (Msh_node_head_ptr, Msh_nodes,
		            Sp_node_head_ptr, Sp_nodes, Global_size);

        printf ("\nAfter fit specialty nodes.\n");
/* Ziji 1/5/99        printf ("\nAfter fit specialty nodes.\n"); */
        printf ("\nAfter fit specialty nodes.\n");
        fprintf(fpzw, "\nAfter fit specialty nodes.\n");


        /* after fitting specialty nodes */ 
        /* comment out for user */

/* Ziji 102198 #ifdef _XWINDOW_ 
        mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	/*
        if (x_win_flag)
              X_motif_GUI ();  
	*/
/* Ziji 102198 #endif */
        /* fit specialty lines */
        fit_sp_line (Msh_node_head_ptr, Msh_nodes,
		                Msh_elem_head_ptr, Msh_elem,
		                Sp_node_head_ptr,  Sp_nodes,
		                Sp_line_head_ptr,  Sp_elem, Global_size);

        if (Numerical_surf == 1)
        {
            /* write sp. line fitting file name  */
            fprintf (Main_file, "%s\n", Splin_fname);
        }

	    smooth_class = 3;
        lap_soomth (Msh_node_head_ptr, Msh_nodes, smooth_class);
        
        /* debug_output ("fitline.out");  */

/* Ziji 102198 #ifdef _XWINDOW_ */
        /* mesh quality assessment */
        /* comment out for user */
/* Ziji 102198         mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	/*
        if (x_win_flag)
            X_motif_GUI ();
	*/ 
/* Ziji 102198 #endif */
    }
    else
    {
        if (Numerical_surf) 
        {
            /* no numerical specialty line file !! */
            fprintf (Main_file, "none.dat\n");
        }
    }

    if ((Spoly_node_head_ptr != NULL && Sp_poly_nodes != BAD) &&
	    (Msh_node_head_ptr != NULL && Msh_nodes != BAD) && Global_size != BAD)
    {
        sp_flag = 1;

		set_fixed_bdy_node (Bdy_node_head_ptr, Bdy_nodes,
								Msh_node_head_ptr, Msh_nodes);

        fit_spoly_line (Msh_node_head_ptr, Msh_nodes,
			            Msh_elem_head_ptr, Msh_elem,
			            Spoly_node_head_ptr, Sp_poly_nodes,
			            Spoly_elem_head_ptr,  Sp_poly_elem,
			            Spoly_list_head_ptr, Num_seg_in_poly, Global_size);

        if (Numerical_surf == 1)
        {
            /* write sp. line fitting file name  */
            fprintf (Main_file, "%s\n", Spoly_fname);
        }
	    /* debug_output ("fitspline.out");  */

    	/* mesh quality assessment */
	    /* comment out for user */
/* Ziji 102198 #ifdef _XWINDOW_ */
/* Ziji 102198 	    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	    /*
	    if (x_win_flag)
	        X_motif_GUI ();
	    */
/* Ziji 102198 #endif */
    }
    else
    {
        if (Numerical_surf) 
        {
            /* no numerical specialty polyline file !! */
            fprintf (Main_file, "none.dat\n");
        }
    }

    if (Numerical_surf) 
    {
        /* no  nodeal motion  file !! */
        fprintf (Main_file, "none.dat\n");
        goto EXIT;      /* just do numerical mesh */
    }

    if (sp_flag)
    {
        /* Laplacian mesh node soomthing	*/
        printf ("\nSmoothing...\n");
        smooth_class = 3;
        lap_soomth (Msh_node_head_ptr, Msh_nodes, smooth_class);

        /* debug_output ("lapsmooth.out");  */
    }

/* Ziji 1/5/98 
	conforming operation is waived here because of specialty test	*/

/* Ziji 1/5/98 in order to output specialty stuff to a new diag file */
fclose(fpzw);
/* end of Ziji */


//    final_output (FINAL_OUT);



    if ((Bdy_node_head_ptr != NULL && Bdy_nodes != BAD) &&
	    (Msh_node_head_ptr != NULL && Msh_nodes != BAD) )
    {
#ifdef OLD_CONFORM
		/* Ziji 9/7/99 */
		fprintf(fpzw2, "Old conforming...\n");
		/* end of Ziji */
	    conform_out_bdy (Bdy_node_head_ptr, Bdy_nodes,
                            Bdy_elem_head_ptr, Bdy_elem,
			                Msh_node_head_ptr, Msh_nodes,
                            Msh_elem_head_ptr, Msh_elem);
      
        /* debug_output ("conform.out");   */
	    printf ("\nAfter conform_out_bdy \n");

       /* comment out for user */
/* Ziji 102198 #ifdef _XWINDOW_
	    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	    /*
	    if (x_win_flag)
                  X_motif_GUI ();
	    */
/* Ziji 102198 #endif */
        if (Bdy_lst_type == BD3DMTRL)
	        conform_in_bdy  (Bdy_node_head_ptr, Bdy_nodes,
			                Bdy_elem_head_ptr, Bdy_elem,
			                Msh_node_head_ptr, Msh_nodes,
                            Msh_elem_head_ptr, Msh_elem);
  
        /* debug_output ("conform2.out");  */
	    printf ("\nAfter conform_in_bdy \n");
#else
		/* Ziji 9/7/99 */
		fprintf(fpzw2, "New conforming...\n");
		/* end of Ziji */

        /* try new conforming process */
        if (Bdy_lst_type == BD3DMTRL)
	        conform_bdy (Bdy_node_head_ptr, Bdy_nodes,
			             Bdy_elem_head_ptr, Bdy_elem,
			             Msh_node_head_ptr, &Msh_nodes,
                         Msh_elem_head_ptr, &Msh_elem);
      
        /* debug_output ("conform.out");  */
	    printf ("\nAfter conform_bdy \n");
#endif
        
        /* comment out for user */
/* Ziji 102198 #ifdef _XWINDOW_ 
	    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
*/	    /*
	    if (x_win_flag)
                  X_motif_GUI ();
	    */
/* Ziji 102198 #endif */
    }

/* Ziji 9/7/99 in order to output conforming stuff to a new diag file */
fclose(fpzw2);
/* end of Ziji */

    /* debug checking for unfitted elem. */ 
    check_unfitted ();

    /* set elem. Mtrl. based on central mode, or can use b version-check 9 nodes */
    printf ("\nMaterial classifying...\n");
#ifdef QUICK_MTRL_SORT
    set_elem_mtrl  (Bdy_node_head_ptr, Bdy_nodes,
		            Bdy_elem_head_ptr, Bdy_elem,
                    Msh_node_head_ptr, Msh_nodes,
		            Msh_elem_head_ptr, Msh_elem);
#else
    set_elem_mtrl_b  (Bdy_node_head_ptr, Bdy_nodes,
		              Bdy_elem_head_ptr, Bdy_elem,
                      Msh_node_head_ptr, Msh_nodes,
		              Msh_elem_head_ptr, Msh_elem);
#endif

    /* mesh quality assessment */
    printf ("\nPost-processing...\n");
    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);

    /* clean bad mesh element */
    clean_poor_elem  (&Msh_elem_head_ptr, &Msh_elem);
	kill_iso_node (&Msh_node_head_ptr, &Msh_nodes);

    /* reset Adjacent Node and Element list */
	free_adj_lists (Msh_node_head_ptr, Msh_nodes);
	/* creat adjlist */
	mk_adjlist (Msh_node_head_ptr, Msh_nodes, Msh_elem_head_ptr, Msh_elem);

    /* clean the cross outbound elem */
    rectify_mesh   (Bdy_node_head_ptr, Bdy_nodes,
                    Bdy_elem_head_ptr, Bdy_elem,   
                    &Msh_node_head_ptr, &Msh_nodes,
		            &Msh_elem_head_ptr, &Msh_elem);

#ifdef NORMALIZE_DATA
    /* restore data */
    denormal_nodes (); 
#endif

VIEW_MESH:
    /* mesh quality assessment */
    mesh_assess (Msh_elem_head_ptr, Msh_elem, 1, 1, 1, 1, 1, 1);
    out_mesh_quali (Msh_elem_head_ptr, Msh_elem, "quali5.out");


    printf ("\nOverview.\n");
/* Ziji 102198 #ifdef _XWINDOW_ */
    /* Check X-window available */
/* Ziji 102198     if (x_win_flag)
          X_motif_GUI ();
#endif
*/    
    /* final mesh output */ 
    /*
    printf ("\nNeed output ? (1=yes / 0=No): ");
    scanf ("%d", &status);
    if (status == 1)
    */

    final_output (FINAL_OUT);

    /* extract boundary interfaces and checking material bdy */
RE_ENTRY:
    status = ext_mat_surfaces (Bdy_node_head_ptr, Bdy_nodes,
                            Bdy_elem_head_ptr, Bdy_elem,
                            Msh_node_head_ptr, Msh_nodes,
                            Msh_elem_head_ptr, Msh_elem, FINAL_EXBDY);
    if (status != BAD)
    {
        printf ("\nAfter extracting material BDY.\n");
/* Ziji 102198 #ifdef _XWINDOW_ */
            /* Check X-window available */
/* Ziji 102198             if (x_win_flag)
                X_motif_GUI (); 
#endif       */
            goto RE_ENTRY;
    }

    /* check mesh element 
    if (!view_flag)
        check_elem_mtrl (1);
    */

EXIT:
/* Ziji 102198 #ifdef _XWINDOW_ */
            /* Check X-window available */
/* Ziji 102198             if (x_win_flag)
                X_motif_GUI (); 
#endif       
*/

    /* free memory space */
    release_glb ();  /* free memory for mesh quality issue */

    if (Bdy_node_head_ptr)
	    free_bnode_list (Bdy_node_head_ptr, Bdy_nodes);

    if (Bdy_elem_head_ptr)
	    free_belem_list (Bdy_elem_head_ptr, Bdy_elem);

    if (Msh_node_head_ptr)
	    free_node_list (Msh_node_head_ptr, Msh_nodes);

    if (Msh_elem_head_ptr)
	    free_elem_list (Msh_elem_head_ptr, Msh_elem);

    if (Sp_node_head_ptr)
	    free_node_list (Sp_node_head_ptr, Sp_nodes);

    if (Sp_line_head_ptr)
	    free_line_list (Sp_line_head_ptr, Sp_elem);

    if (Spoly_list_head_ptr)
        free_polyline_list (Spoly_list_head_ptr, Num_seg_in_poly, 
			    Sp_poly_elem);

    if (Num_seg_in_poly)
        free ((char *) Num_seg_in_poly); 

    if (Spoly_node_head_ptr)
	    free_node_list (Spoly_node_head_ptr, Sp_poly_nodes);

    if (Spoly_elem_head_ptr) 
	    free_line_list (Spoly_elem_head_ptr, Sp_poly_elem);
     
    for (k=0; k<Num_interface; k++)
    {
        if (Num_patch_in_NFace[k] > 0)
	        free_patch (NFace_head[k], Num_patch_in_NFace[k]);
    }



    if (Numerical_surf == 1 && Main_file)
        fclose (Main_file);


    fclose (Diag_file);
    printf ("\nFinished!\n");
    //printf ("\nPress any key to quit!\n");
    //getchar ();
    return (0);
}


/* debug tool:  check consistence of Total num. of node and elem 
                and the adj. list in node structure.
*/
int
debug_check  (char *title)
{
    int      k;
    long     ii;
    MeshNode *cur_nptr;
    MeshElem *cur_eptr;
    AdjList  *cur_anptr;
    AdjElem  *cur_aeptr;


    printf ("\n********** debug_check :  %s *************\n", title);

    ii = 0;
    cur_nptr = Msh_node_head_ptr;
    do
    {
        
        if ((ii++) > 100000) 
	    {
	        printf ("\nnode number > 100000! quit!\n");
            break;
	    }

        /* check adjacent list */
        k = 0;
        cur_anptr = cur_nptr->Fst_adj;
        while (cur_anptr)
        {
            k++;
            cur_anptr = cur_anptr->ptr;
        }
        if (k != cur_nptr->Num_adj)
            printf ("\nError...the Num. adj node [node %ld]  = %d (Num_adj = %d)!\n",
                       k, ii, cur_nptr->Num_adj);  
        
        k = 0;
        cur_aeptr = cur_nptr->Fst_adj_elem;
        while (cur_aeptr)
        {
            k++;
            cur_aeptr = cur_aeptr->ptr;
        }
        if (k != cur_nptr->Num_adj_elem)
            printf ("\nError...the Num. adj elem  [node %ld]  = %d (Num_adj_elem = %d)!\n",
                       k, ii, cur_nptr->Num_adj_elem);  
        
	    cur_nptr = cur_nptr->Next;
    } while (cur_nptr != Msh_node_head_ptr && cur_nptr);

    if (ii != Msh_nodes)
      printf ("\nError...Total Number node = %ld (Msh_nodes = %ld)!\n",
	      ii, Msh_nodes);

    ii = 0;
    cur_eptr = Msh_elem_head_ptr;
    do
    {
        if ((ii++) > 100000)             
	    {
	        printf ("\nelem. number > 100000! quit!\n");
            break;
	    }
	    cur_eptr = cur_eptr->Next;
    } while (cur_eptr != Msh_elem_head_ptr && cur_eptr);

    if (ii != Msh_elem)
      printf ("\nError...Total Number Elem. = %ld (Msh_elem = %ld)!\n",
	      ii, Msh_elem);

    return (OK);
}



int
check_elem_mtrl (int show_outbound)
{
    int      num_bdy, num_p, k, e_mtrl, unconsis_flag;
    long     ii, kk0, kk1, kk2, kk3, num_unconsist_node=0, num_outside_node=0;
    MeshElem *eptr;
    MeshNode **nnptr;

    fprintf (Diag_file, "\n*************** Summary of elem. mtal *****************\n");
    fprintf (Diag_file, "Total number of element :  %ld\n", Msh_elem);
    for (ii=0, eptr=Msh_elem_head_ptr; ii<Msh_elem; ii++, eptr=eptr->Next)
    {
        switch (eptr->E_type)
        {
	        case TET4:
		        num_p = 4;
		        nnptr = eptr->Elem.tet4.NodePtr;
		        break;
	        case HEX8:
		        num_p = 8;
		        nnptr = eptr->Elem.hex8.NodePtr;
		        break;
	        default:
		        fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		        continue;
        }
        e_mtrl = eptr->Mtrl_in;
        if (e_mtrl == 0 && show_outbound)
            fprintf (Diag_file, "\nZero mtrl elem. existed : Elem (%ld)!\n", ii);

        unconsis_flag = 0;
        num_bdy = 0;

        for (k=0; k<num_p; k++)
        {
            if (nnptr[k]->Mtrl > BDY_NODE_CODE) num_bdy++;
            if (nnptr[k]->Mtrl <= BDY_NODE_CODE && nnptr[k]->Mtrl != e_mtrl)
            {
                num_unconsist_node++;
                /*
                printf ("\nUnconsistent Node in elem %ld (mtrl=%d) / (node mtrl=%d)\n",
                        ii, e_mtrl, nnptr[k]->Mtrl);
                */
                unconsis_flag = 1;
            }

            if (nnptr[k]->Mtrl == 0)
            {
                num_outside_node++;
                if (show_outbound)
                    fprintf (Diag_file, "\nOutside node in elem %ld (node adj.=%d, elem adj.=%d)\n",
                            ii, nnptr[k]->Num_adj, nnptr[k]->Num_adj_elem);
                
            }

        }
        if (num_bdy > 2)
        {
            kk0 = nnptr[0]->Mtrl;   kk1 = nnptr[1]->Mtrl;
            kk2 = nnptr[2]->Mtrl;   kk3 = nnptr[3]->Mtrl;
            fprintf (Diag_file, "Elem. %ld 3 or 4 bdy nodes (mtrl(%d) %ld, %ld, %ld, %ld) !\n", 
               ii, e_mtrl, kk0, kk1, kk2, kk3);
        }
        if (unconsis_flag )
        {
            kk0 = nnptr[0]->Mtrl;   kk1 = nnptr[1]->Mtrl;
            kk2 = nnptr[2]->Mtrl;   kk3 = nnptr[3]->Mtrl;
            fprintf (Diag_file, "Elem. %ld unconsistent (mtrl(%d) %ld, %ld, %ld, %ld) !\n", 
               ii, e_mtrl, kk0, kk1, kk2, kk3);
        }
    }


    fprintf (Diag_file, "\nNum. of unconsistent node in elem search = %ld\n", num_unconsist_node);
    fprintf (Diag_file, "Num. of outside node in elem search = %ld\n", num_outside_node);

    fprintf (Diag_file, "\n*************** End of Summary *****************\n");

    return (0);
}


int 
check_unfitted (void)
{

    int      num_p;
    long     ii, kk0, kk1, kk2, kk3, num_unfitted=0;
    MeshElem *eptr;
    MeshNode **nnptr;

    fprintf (Diag_file, "\n*************** Summary of elem. conforming ************\n");
    fprintf (Diag_file, "Total number of element :  %ld\n", Msh_elem);
    for (ii=0, eptr=Msh_elem_head_ptr; ii<Msh_elem; ii++, eptr=eptr->Next)
    {
        switch (eptr->E_type)
        {
	        case TET4:
		        num_p = 4;
		        nnptr = eptr->Elem.tet4.NodePtr;
		        break;
	        case HEX8:
		        num_p = 8;
		        nnptr = eptr->Elem.hex8.NodePtr;
		        break;
	        default:
		        fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		        continue;
        }
        if (check_cross_bdy_elem (nnptr, num_p) == OK)
        {  
            num_unfitted++;
            kk0 = nnptr[0]->Mtrl;   kk1 = nnptr[1]->Mtrl;
            kk2 = nnptr[2]->Mtrl;   kk3 = nnptr[3]->Mtrl;
            fprintf (Diag_file, "Elem. %ld unfitted(mtrl %ld, %ld, %ld, %ld) !\n", 
                    ii, kk0, kk1, kk2, kk3);
        }
   }

    fprintf (Diag_file, "\nNum. of unfitted elem  = %ld\n", num_unfitted);
    fprintf (Diag_file, "\n*************** End of Summary *****************\n");
    return (0);
}




int 
check_null_bdynode_ptr (void)
{
    long        ii;
    MeshNode    *nptr;

    for (ii=0, nptr=Msh_node_head_ptr; ii < Msh_nodes; ii++, nptr=nptr->Next)
    {
        if (nptr->Mtrl > BDY_NODE_CODE && nptr->bdy_ptr == NULL)
            fprintf (Diag_file, "\nOdd bdy. node (%ld)\n", ii);
    }
    return (0);
}
