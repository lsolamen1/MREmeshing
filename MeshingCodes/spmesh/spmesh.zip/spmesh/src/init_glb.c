  
/*
  ************************************************************************
  *  init_glb.c :   Initialization of global setting         *
  *                                  *
  *  Qingyang Zhang                Dec. 29, 1994     *
  ************************************************************************
*/


#include <stdio.h>
#include <malloc.h>
#include <math.h>
#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define external global varibles */
#include "defglb.h"

#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))

/*
** Local Functions
*/

int init_glb (int do_not_free_sp);
int release_glb (void);
int normalize_bdy_nodes (double scale_factor);
int denormal_nodes (void);
int normalize_def_bdy_nodes (BMeshNode *head_bnptr, long num_bdy_node, 
                            BMeshElem *head_beptr, long num_bdy_elem);
int define_boundary_reflvl (void);

extern REAL v_magn(REAL *vec, int n);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);


int
init_glb (int do_not_free_sp)
{
    int  i, k;

    Model_name [0] = '\0';
    Numbering   = 1;         /* default w/ numbering on node & elem list */
    Input_type  = 1;
    Analy_type  = BAD;
    Dimen   = 3;
    Mesh_type   = HEX8;     /* default mesh type */
    if (do_not_free_sp == 0)
    {
      Global_size = BAD;
      G_factor    = 0.75;
      Build_blk_type = REGULAR_HEX;
    }
    BDxmin= BDymin= BDzmin= BDxmax= BDymax= BDzmax = BAD;
    Norm_scale = 1.;
    Norm_orig[X]  = Norm_orig[Y]  = Norm_orig[Z] = 0.;
    Ref_dist = 0.;
    Bdy_nodes= Bdy_elem= Msh_nodes= Msh_elem = BAD;
    Bdy_lst_type = Msh_lst_type = BAD;
    Num_bc1= Num_bc2= Num_bc3 = BAD;
    Batch_fname [0] = '\0';
    Batch_in       = NULL;
    Num_file_batch = 0;
    Cur_num_file_read = 0;
    Ref_batch_flag = BAD;
    Numerical_surf = 0;

    Main_file   = NULL;    /* main file to hold global name list */
    Spnod_file  = NULL;    /* numerical specialty node file */
    Splin_file  = NULL;    /* numerical specialty line sequence file */
    Spoly_file  = NULL;    /* numerical sp. polyline sequence file */
    Nodmo_file  = NULL;    /* Global volume node motion status file */

    Bdy_node_head_ptr = NULL;
    Bdy_node_curt_ptr = NULL;
    Bdy_elem_head_ptr = NULL;   /* Trianglar patch boundary surface */
    Bdy_elem_curt_ptr = NULL;

    Msh_node_head_ptr = NULL;
    Msh_node_curt_ptr = NULL;
    Msh_elem_head_ptr = NULL;   /* Mesh elemen: 3D tet hex ...  */
    Msh_elem_curt_ptr = NULL;
    if (do_not_free_sp == 0)
    {
        Sp_nodes= Sp_elem = BAD;
        Sp_poly_nodes = Sp_poly_elem = BAD;

        Sp_node_head_ptr = NULL;
        Sp_node_curt_ptr = NULL;
        Sp_line_head_ptr = NULL;    /* the nodes of Specialty line have to be */
        Sp_line_curt_ptr = NULL;    /* Specialty nodes */

        /* specialty polyline header information */
        Spoly_node_head_ptr = NULL;
        Spoly_node_curt_ptr = NULL;
        Spoly_elem_head_ptr = NULL;
        Spoly_elem_curt_ptr = NULL;
        /* detail list of each specialty polyline */
        Num_seg_in_poly = NULL;
        Spoly_list_head_ptr = NULL;
        Spoly_list_curt_ptr = NULL;  
    }

    /* for auto refiment */
    Min_ref_level = 0;            /* the minimal refinement level for boundary element */
    Max_ref_level = 0;            /* the maximum refinement level for match all bdy. element */
    User_ref_level = 0;

    /* for find numerical surface */
    Num_interface = Num_NFace = 0;
    for (k=0; k<MAX_FACE; k++)   
    {
        NFace_head[k] = NULL;
        Num_patch_in_NFace[k] = 0;
        BFace_mtrl[0][k] = BFace_mtrl[1][k]  = 0;
    }
    for (i=0; i<MAX_REF_LEVEL; i++)
    {
        Ref_level_head[i] = Ref_level_tail[i] = NULL;
    }

    Num_nfitnod = 0;
    Cur_fitnod = Fitnod_head = NULL;

    /* initial for mesh quality issue and allocate memory */
    Q_mean    = 0.;  V_mean    = 0.;   Asp_mean = 0.;
    Jaco_mean = 0.;  Skw_mean  = 0.;   Warp_mean = 0.;
    Q_min = V_min = Asp_min = Jaco_min = Skw_min = Warp_min = 0.;
    Q_max = V_max = Asp_max = Jaco_max = Skw_max = Warp_max = 0.;
    Q_tick_min = V_tick_min = Asp_tick_min = Jaco_tick_min = 0.0;
    Skw_tick_min = Warp_tick_min = 0.;
    Q_tick_max = V_tick_max = Asp_tick_max = Jaco_tick_max = 1.0;
    Skw_tick_max = Warp_tick_max = 1.0;
    num_Q_histo_slot = DF_Q_HISTO;   num_V_histo_slot = DF_V_HISTO;
    num_Asp_histo_slot = DF_A_HISTO; num_Jaco_histo_slot = DF_J_HISTO;
    num_Skw_histo_slot = DF_S_HISTO; num_Warp_histo_slot = DF_W_HISTO;
    num_Q_pie_slot = DF_Q_PIE;       num_V_pie_slot = DF_V_PIE;
    num_Asp_pie_slot = DF_A_PIE;    num_Jaco_pie_slot = DF_J_PIE;
    num_Skw_pie_slot = DF_S_PIE;     num_Warp_pie_slot = DF_W_PIE;
    Q_histo_slots    = (long *) malloc (sizeof (long)*num_Q_histo_slot);
    V_histo_slots    = (long *) malloc (sizeof (long)*num_V_histo_slot);
    Asp_histo_slots  = (long *) malloc (sizeof (long)*num_Asp_histo_slot);
    Jaco_histo_slots = (long *) malloc (sizeof (long)*num_Jaco_histo_slot); 
    Skw_histo_slots  = (long *) malloc (sizeof (long)*num_Skw_histo_slot);
    Warp_histo_slots = (long *) malloc (sizeof (long)*num_Warp_histo_slot);
    Q_pie_slots      = (long *) malloc (sizeof (long)*num_Q_pie_slot);
    V_pie_slots      = (long *) malloc (sizeof (long)*num_V_pie_slot);
    Asp_pie_slots    = (long *) malloc (sizeof (long)*num_Asp_pie_slot);
    Jaco_pie_slots   = (long *) malloc (sizeof (long)*num_Jaco_pie_slot);
    Skw_pie_slots    = (long *) malloc (sizeof (long)*num_Skw_pie_slot);
    Warp_pie_slots   = (long *) malloc (sizeof (long)*num_Warp_pie_slot);

/* added by Ziji, 4/16/99, init as ignore */
autoref_ignore_adj_bdy = 0;
autoref_ignore_same_mtrl_bdy = 0;
/* end of Ziji */

    return (OK);
}




int 
release_glb (void)
{
    /* free memory space */
    if (Q_histo_slots)
    free ((char *)Q_histo_slots);

    if (V_histo_slots)
    free ((char *)V_histo_slots);

    if (Asp_histo_slots)
    free ((char *)Asp_histo_slots);

    if (Jaco_histo_slots)
    free ((char *)Jaco_histo_slots);

    if (Skw_histo_slots)
    free ((char *)Skw_histo_slots);

    if (Warp_histo_slots)
    free ((char *)Warp_histo_slots);

    if (Q_pie_slots)
    free ((char *)Q_pie_slots);

    if (V_pie_slots)
    free ((char *)V_pie_slots);

    if (Asp_pie_slots)
    free ((char *)Asp_pie_slots);

    if (Jaco_pie_slots)
    free ((char *)Jaco_pie_slots);

    if (Skw_pie_slots)
    free ((char *)Skw_pie_slots);

    if (Warp_pie_slots)
    free ((char *)Warp_pie_slots);


  return (OK);
}


/* 
    To prevent the model size deviating too much 
    normalize the node coordinates and multiple a factor Glb_scale 
*/
int
normalize_bdy_nodes (double scale_factor)
{
    int         k;
    double      dx, dy, dz, del_max;
    long        ii;
    BMeshNode   *bnptr;
    BMeshElem   *beptr;
    MeshNode    *spnptr;
    //LineData    *splptr;


    if ((BDxmin==BAD && BDymin==BAD && BDzmin&&BAD && BDxmax==BAD && 
         BDymax==BAD && BDzmax==BAD) || Bdy_nodes <= 0)   return (-1);
    
    dx = BDxmax - BDxmin;
    dy = BDymax - BDymin;
    dz = BDzmax - BDzmin;

    del_max = dx;
    del_max = dy > del_max ? dy : del_max;
    del_max = dz > del_max ? dz : del_max;

    Norm_scale = scale_factor / del_max;
    Norm_orig[X] = BDxmin;
    Norm_orig[Y] = BDymin;
    Norm_orig[Z] = BDzmin;
    
    /* normalize bounding box */
    BDxmax = (BDxmax - Norm_orig[X]) *Norm_scale;
    BDxmin = (BDxmin - Norm_orig[X]) *Norm_scale;
    BDymax = (BDymax - Norm_orig[Y]) *Norm_scale;
    BDymin = (BDymin - Norm_orig[Y]) *Norm_scale;
    BDzmax = (BDzmax - Norm_orig[Z]) *Norm_scale;
    BDzmin = (BDzmin - Norm_orig[Z]) *Norm_scale;

    /* bdy nodes */
    for (ii=0, bnptr=Bdy_node_head_ptr; ii<Bdy_nodes; ii++, bnptr=bnptr->Next)
    {
        for (k=0; k<3; k++)
            bnptr->Coor[k] = (bnptr->Coor[k] - Norm_orig[k]) * Norm_scale;
    }

    /* bdy patch bounding boxes */
    for (ii=0, beptr=Bdy_elem_head_ptr; ii<Bdy_elem; ii++, beptr=beptr->Next)
    {
        beptr->xmin = (beptr->xmin - Norm_orig[X]) * Norm_scale;       
        beptr->ymin = (beptr->ymin - Norm_orig[Y]) * Norm_scale;       
        beptr->zmin = (beptr->zmin - Norm_orig[Z]) * Norm_scale;       
        beptr->xmax = (beptr->xmax - Norm_orig[X]) * Norm_scale;       
        beptr->ymax = (beptr->ymax - Norm_orig[Y]) * Norm_scale;       
        beptr->zmax = (beptr->zmax - Norm_orig[Z]) * Norm_scale;       
    }

    /* specialty lines */
    if (Sp_nodes > 0)
    {
        for (ii=0, spnptr=Sp_node_head_ptr; ii<Sp_nodes; ii++, spnptr=spnptr->Next)
        {
            for (k=0; k<3; k++)
                spnptr->Coor[k] = (spnptr->Coor[k] - Norm_orig[k]) * Norm_scale;
        }
    }
    /* specialty polylines */
    if (Sp_poly_nodes)
    {
        for (ii=0, spnptr=Spoly_node_head_ptr; ii<Sp_poly_nodes; ii++, spnptr=spnptr->Next)
        {
            for (k=0; k<3; k++)
                spnptr->Coor[k] = (spnptr->Coor[k] - Norm_orig[k]) * Norm_scale;
        }
    }

    return (0);
}


int
denormal_nodes (void)
{
    int         k;
    long        ii;
    MeshNode    *nptr;
    BMeshNode   *bnptr;
    BMeshElem   *beptr;
    MeshNode    *spnptr;
    //LineData    *splptr;

    if ((BDxmin==BAD && BDymin==BAD && BDzmin&&BAD && BDxmax==BAD && 
         BDymax==BAD && BDzmax==BAD))   return (-1);
    if (fabs (Norm_scale) < HIGTOL)     return (-2); 

    /* boundary box */
    BDxmax = BDxmax / Norm_scale + Norm_orig[X];
    BDxmin = BDxmin / Norm_scale + Norm_orig[X];
    BDymax = BDymax / Norm_scale + Norm_orig[Y];
    BDymin = BDymin / Norm_scale + Norm_orig[Y];
    BDzmax = BDzmax / Norm_scale + Norm_orig[Z];
    BDzmin = BDzmin / Norm_scale + Norm_orig[Z];


    for (ii=0, bnptr=Bdy_node_head_ptr; ii<Bdy_nodes; ii++, bnptr=bnptr->Next)
    {
        for (k=0; k<3; k++)
            bnptr->Coor[k] = bnptr->Coor[k] / Norm_scale + Norm_orig[k];
    }

    /* bdy patch bounding box */
    for (ii=0, beptr=Bdy_elem_head_ptr; ii<Bdy_elem; ii++, beptr=beptr->Next)
    {
        beptr->xmin = beptr->xmin / Norm_scale + Norm_orig[X];       
        beptr->ymin = beptr->ymin / Norm_scale + Norm_orig[Y];       
        beptr->zmin = beptr->zmin / Norm_scale + Norm_orig[Z];       
        beptr->xmax = beptr->xmax / Norm_scale + Norm_orig[X];       
        beptr->ymax = beptr->zmax / Norm_scale + Norm_orig[Y];       
        beptr->zmax = beptr->zmax / Norm_scale + Norm_orig[Z];       
    }
    
    /* volume mesh */
    for (ii=0, nptr=Msh_node_head_ptr; ii<Msh_nodes; ii++, nptr=nptr->Next)
    {
        for (k=0; k<3; k++)
            nptr->Coor[k] = nptr->Coor[k] / Norm_scale + Norm_orig[k];
    }

    /* specialty lines */
    if (Sp_nodes > 0)
    {
        for (ii=0, spnptr=Sp_node_head_ptr; ii<Sp_nodes; ii++, spnptr=spnptr->Next)
        {
            for (k=0; k<3; k++)
                spnptr->Coor[k] = spnptr->Coor[k] / Norm_scale + Norm_orig[k];
        }
    }
    /* specialty polylines */
    if (Sp_poly_nodes > 0)
    {
        for (ii=0, spnptr=Spoly_node_head_ptr; ii<Sp_poly_nodes; ii++, spnptr=spnptr->Next)
        {
            for (k=0; k<3; k++)
                spnptr->Coor[k] = spnptr->Coor[k] / Norm_scale + Norm_orig[k];
        }
    }

    return (0);
}





int
normalize_def_bdy_nodes (BMeshNode *head_bnptr, long num_bdy_node, 
                        BMeshElem *head_beptr, long num_bdy_elem)
{
    int         k;
    long        ii;
    BMeshNode   *bnptr;
    BMeshElem   *beptr;

    for (ii=0, bnptr=head_bnptr; ii<num_bdy_node; ii++, bnptr=bnptr->Next)
    {
        for (k=0; k<3; k++)
            bnptr->Coor[k] = (bnptr->Coor[k] - Norm_orig[k]) * Norm_scale;
    }

    /* bdy patch bounding boxes */
    for (ii=0, beptr=head_beptr; ii<num_bdy_elem; ii++, beptr=beptr->Next)
    {
        beptr->xmin = (beptr->xmin - Norm_orig[X]) * Norm_scale;       
        beptr->ymin = (beptr->ymin - Norm_orig[Y]) * Norm_scale;       
        beptr->zmin = (beptr->zmin - Norm_orig[Z]) * Norm_scale;       
        beptr->xmax = (beptr->xmax - Norm_orig[X]) * Norm_scale;       
        beptr->ymax = (beptr->ymax - Norm_orig[Y]) * Norm_scale;       
        beptr->zmax = (beptr->zmax - Norm_orig[Z]) * Norm_scale;       
    }

    return (0);
}


/* define refinement level numbers for boundary trianglar
   patch based on the global mesh size:
    the refinement level number means that, by given global
    mesh size, the number of refinements needed to model the
    details of the given boundary element.
*/

int 
define_boundary_reflvl (void)
{
    int  ia;
    long ii;
    REAL min_len, len, vec[3];
    BMeshNode   *bnptr1, *bnptr2;
    BMeshElem   *beptr;

    Min_ref_level = 10000000;
    Max_ref_level = -10000000;
    for (ii=0, beptr=Bdy_elem_head_ptr; ii<Bdy_elem; ii++, beptr=beptr->Next)
    {
        min_len = 1.e10;
        for (ia=0; ia<3; ia++)
        {    
            bnptr1 = beptr->Elem.tri3.NodePtr[ia];
            bnptr2 = beptr->Elem.tri3.NodePtr[imod(ia+1, 3)];
            v_make(bnptr1->Coor, bnptr2->Coor, 3, vec);
            len = v_magn(vec, 3);
            if (len < min_len)  min_len = len;
        }

        beptr->ref_levlel = (int)(Global_size / (2. * min_len));
        if (beptr->ref_levlel < Min_ref_level)  
            Min_ref_level = beptr->ref_levlel; 
        if (beptr->ref_levlel > Max_ref_level)  
            Max_ref_level = beptr->ref_levlel; 
    }
    return (0);
}
