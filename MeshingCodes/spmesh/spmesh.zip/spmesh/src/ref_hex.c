   
/*
  ************************************************************************
  *  ref_hex.c : Mesh refinement for Hex element                     	 *
  *									 *
  *  Qingyang Zhang				   Oct. 2, 1995	         *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>



#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"
#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))
#define MAX_ADJ_ELEM    96

#define LREFINE_MAX     2

/*
** External Functions
*/
/* added by Ziji 4/16/99 */
extern long conv_bnode_ptr (BMeshNode *head, BMeshNode *node_ptr, long total_nodes);

extern REAL v_dot(REAL *vec1, REAL *vec2, int n);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern int v_norm(REAL *vec, int n);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern int nod_inout (REAL *d, REAL *e, BMeshElem *bdy_l_head,
							 long n_bdy_elem, BMeshElem **on_bdy_eptr, int db_flag);
extern int  tri_patch_bound (BMeshNode **nnptr, double *xmin, double *ymin, 
               double *zmin, double *xmax, double *ymax, double *zmax);
extern void tri_patch_box (REAL *xmin, REAL *ymin, REAL *zmin,
		    REAL *xmax, REAL *ymax, REAL *zmax,
		    MeshElem *bdy_l_head, long n_bdy_elem);
extern REAL pnt2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *pnt);
extern int free_adj_elem (AdjElem *ad_ptr);
extern int mk_adjlist(MeshNode *n_head,long num_node, MeshElem *e_head, long num_elem);
extern int free_adj (AdjList *ad_ptr);
extern int free_adj_elem (AdjElem *ad_ptr);
extern int free_bnode_list (BMeshNode *head, long num_node);
extern int free_belem_list (BMeshElem *head, long num_elem);
extern int free_node_list (MeshNode *head, long num_node);
extern int free_elem_list (MeshElem *head, long num_elem);
extern MeshNode *conv_node_idx (MeshNode *head, long node_idx);
extern BMeshNode *conv_bnode_idx (BMeshNode *head, long node_idx);
extern int alloc_error (char *str);
extern int debug_check  (char *title);
extern void free_adj_lists (MeshNode *head, long num_nodes);
extern void free_a_elem (MeshElem *eptr, MeshElem **msh_l_head, long *num_mesh_el);
extern int read_ref_region (char *fname, BMeshNode **xbdy_n_head, long *xbdy_num_node,
		     BMeshElem **xbdy_l_head, long *xbdy_num_elem);
extern int create_tet4_in_delta (MeshElem **msh_l_head, 
                      MeshElem **msh_l_curt_ptr, 
                      long *g_el_num, MeshNode **nd_idx_ptr, 
                      long *glb_loc_map, int tet_type);
extern int refine_tets (MeshElem **msh_l_head, long *num_mesh_el,
			AdjElem *ref_list, long num_ref);
extern MeshNode ** tet4_2_tet10 (MeshElem *eptr);
extern int find_tet_pattern (MeshElem *eptr);
extern int process_tet4_6 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
extern int process_tet4_7 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
extern int process_tet4_8 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
extern int process_tet4_9 (MeshNode *msh_n_head, long *num_mesh_nd, MeshElem *eptr);
extern int normalize_def_bdy_nodes (BMeshNode *head_bnptr, long num_bdy_node, 
                            BMeshElem *head_beptr, long num_bdy_elem);
extern int define_boundary_reflvl (void);
extern int mesh_nod_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		   MeshNode *msh_n_head, long n_msh_node, int class_type, MeshNode *msh_n_curt);
extern NODE_MTRL nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
                   BMeshElem **on_bdy_eptr);
extern int line_tri_cross (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);
extern int random_shoot_full (double *st_pnt, double *ed_pnt);


/*
** Local Functions
*/
int ref_hex_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
		   MeshNode **msh_n_head, long *num_mesh_nd,
		   MeshElem **msh_l_head, long *num_mesh_el);
int tag_ref_hex_zone (MeshElem  *msh_l_head,  long num_mesh_el,
			BMeshElem *surf_l_head, long surf_num_elem, REAL distance,
			AdjElem **ref_elm_list, AdjElem **lst_ref_elm,
			long *num_ref_elm, int auto_mode);
int check_ref_hex (MeshElem *eptr, BMeshElem *surf_l_head, long surf_num_elem,
		   REAL ref_dist, int auto_mode);
int tag_hex_elem (MeshElem *eptr, AdjElem **ref_elm_list, AdjElem **lst_ref_elm,
			long *num_ref_elm);
int one_level_check (MeshNode *msh_n_head, long num_node, AdjElem **ref_elm_list,
		 AdjElem **lst_ref_elm, long *num_ref_elm);
int refine_hexs  (MeshNode **msh_n_head, long *num_mesh_nd,
		  MeshElem **msh_l_head, long *num_mesh_el,
		  AdjElem *ref_list, long num_ref);
int refine_a_hex (MeshElem *eptr, MeshNode **msh_n_head, long *num_mesh_nd,
		  MeshElem **msh_l_head, long *num_mesh_el);
MeshNode * match_node_ptr (REAL *pnt, MeshNode **msh_n_head,
			   long *num_mesh_nd, int level);
MeshElem * create_a_hex_elem (MeshElem **msh_l_head, long *num_mesh_el);
int delta_hex_to_tet4 (MeshElem **msh_l_head, long *num_mesh_el);
int break_a_hex_to_tets (MeshElem *hex_eptr, MeshElem **fst_tet_ptr,
			 MeshElem **lst_tet_ptr);
int connect_single_node (MeshNode *msh_n_head, long num_node);
int adj_level (AdjElem *aeptr, int num_adj_elem, MeshElem **check_list,
	       int *num_higher);
int check_tet_mid (MeshElem *eptr, MeshNode *nptr);
MeshNode * check_mid_pnt (MeshNode *base_nptr, MeshNode *end_nptr);
int check_delta_knit (MeshNode *msh_n_head, long *num_mesh_nd,
								MeshElem *msh_l_head, long num_elem);
int tag_large_elem (MeshElem  *msh_l_head,  long num_mesh_el,
		        BMeshElem *surf_l_head, long surf_num_elem, 
		        AdjElem **ref_elm_list, AdjElem **lst_ref_elm, long *num_ref_elm);
int hex_diagonal_check (MeshNode **nnptr, BMeshElem *bdy_l_head, long n_bdy_elem);

extern REAL Max_size;
extern AdjElem *Ref_elm_list, *Last_ref_elm;
extern long Num_ref_elm;

/*
** Global Variables
*/
				       

/*
** Local Variables
*/

/* the option setup:
    option: 1-5     five optional refinement schemes respectively
    option: 100     check for large element which cross boundaries
    option: 200     quit|finish mesh refinement
*/  
int
ref_hex_elem (BMeshElem *bdy_l_head, long bdy_num_elem,
	      MeshNode **msh_n_head, long *num_mesh_nd,
	      MeshElem **msh_l_head, long *num_mesh_el)
{
  REAL bxmin, bymin, bzmin, bxmax, bymax, bzmax;
  char ref_fname[80];
  int  count;
  int  k, ref_flag, option, flag=0, max_num_adjelem=0, num_adj_elm;
  long ii, num_node;
  long xbdy_num_node, xbdy_num_elem, surf_num_elem;
  REAL distance;
  BMeshNode *xbdy_n_head;
  BMeshElem *xbdy_l_head, *surf_l_head;
  MeshNode  *nptr;
  MeshElem  *eptr;

  static int  auto_mode = 0;
  static int  lrefine_count = 0;

  /* clean warning messages */

  /* initialization */
  Ref_elm_list = Last_ref_elm = NULL;
  Num_ref_elm  = 0;
  Ref_batch_flag = BAD;

  for (k=0; k<MAX_REF_LEVEL; k++)
  {
      Ref_level_head[k] = Ref_level_tail[k] = NULL;
      Level_tail_num[k] = 0;
  }

  /* setup pointer for original mesh node list */
  Ref_level_head[0] = Msh_node_head_ptr;
  Ref_level_tail[0] = Msh_node_head_ptr->Prev;
  Level_tail_num[0] = *num_mesh_nd;

  /* initial and element attributes checking  */
  eptr = *msh_l_head;
  for (ii=0; ii< *num_mesh_el; ii++)
  {
    eptr->attr = 0;    /* record the refinement level */
    eptr->status = BAD;
    if (eptr->E_type != HEX8)
      {
	    printf ("\nWarning elem. No.%ld type is not a HEX8!\n", ii);
      }
    eptr = eptr->Next;
  }
  /* set level node and level element pointer */
  option = 0;
  for (;;)
  {
       /* initialization */
       xbdy_num_node = xbdy_num_elem = 0;
       xbdy_n_head = NULL;
       xbdy_l_head = NULL;

       if (Ref_batch_flag == BAD)
       {
            if (option != 100)
            {
	            printf ("\nNeed Refinement? (No: 0 / Yes: 1) : ");
	            scanf ("%d", &ref_flag);
            }

	        if (ref_flag == 0)    
            {
                option = 100;
                goto G50;
                /* break; */
            }
            
            auto_mode = 0;
	        printf ("\nRefinement Based on(1=Along BDY | 2=along Given Region\n");
            printf ("| 3=Inside Given Region | 4=Batch | 5=Based on bdy patch sizes) : ");
	        scanf ("%d", &option);
            if (option == 5)
            {
                /* define boundary elem. refinement level */
                define_boundary_reflvl ();
                do 
                {
                    printf ("Input the refinement level (Min: %2d - Max: %3d) : ",
                            Min_ref_level, Max_ref_level);
                    scanf ("%d", &User_ref_level);
                } while (User_ref_level < 0 || User_ref_level > Max_ref_level);

                option = 1;     /* set as along the boundary */
                auto_mode = 1;
            }
       }
       else
       {
	        /* in Batch refining mode */
	        if (Num_file_batch > Cur_num_file_read)
	        {
	            fscanf (Batch_in, "%s %d %lf", ref_fname, &option, &distance);

#ifdef NORMALIZE_DATA
		        distance *= Norm_scale;
#endif
	            Ref_dist = distance;
	            Cur_num_file_read++;
	        }
	        else
	        {
	            Ref_batch_flag = BAD;
	            Num_file_batch = Cur_num_file_read = 0;
                ref_flag = 0;
	            option = 100;
                goto G50;
	            /* break; */
	        }
       }

       if (option < 0 || option > 4)    continue;

       /* initialization 
       xbdy_num_node = xbdy_num_elem = 0;
       xbdy_n_head = NULL;
       xbdy_l_head = NULL;
       */
        
       if (option == 1)
       {
	        if (Ref_batch_flag == BAD)
	        {
                bxmin = BDxmin;     bymin = BDymin;     bzmin = BDzmin;
                bxmax = BDxmax;     bymax = BDymax;     bzmax = BDzmax;

#ifdef NORMALIZE_DATA
                /* since the bdy data has been normalized, but user should
                see the original size 
                */
                bxmin = bxmin / Norm_scale + Norm_orig[X];
                bymin = bymin / Norm_scale + Norm_orig[Y];
                bzmin = bzmin / Norm_scale + Norm_orig[Z];
                bxmax = bxmax / Norm_scale + Norm_orig[X];
                bymax = bymax / Norm_scale + Norm_orig[Y];
                bzmax = bzmax / Norm_scale + Norm_orig[Z];
#endif

	            printf ("\nGlobal Bounding Box: ");
	            printf ("\nxmin = %8.4lf;    xmax = %8.4lf;",   bxmin, bxmax);
	            printf ("\nymin = %8.4lf;    ymax = %8.4lf;",   bymin, bymax);
	            printf ("\nzmin = %8.4lf;    zmax = %8.4lf;\n", bzmin, bzmax);

	            printf ("\nInput the distance to BDY (define refinement zone): ");
	            scanf  ("%lf", &distance);

#ifdef NORMALIZE_DATA
		        distance *= Norm_scale;
#endif
	            Ref_dist = distance;
	        }
	        surf_l_head   = bdy_l_head;
	        surf_num_elem = bdy_num_elem;
       }
       else if (option == 2 || option == 3)
       {
	        if (Ref_batch_flag == BAD)
	        {
	            /* read in tri-patch region file */
	            printf ("\nInput Refining region definition file :");
	            scanf  ("%s", ref_fname);
	        }
	        /* read_ref_region (ref_fname, ...)  */
	        if (read_ref_region (ref_fname, &xbdy_n_head, &xbdy_num_node, 
                              &xbdy_l_head, &xbdy_num_elem) == BAD)
	                continue;

#ifdef NORMALIZE_DATA
		normalize_def_bdy_nodes (xbdy_n_head, xbdy_num_node, xbdy_l_head,
			                    xbdy_num_elem);
#endif

	        if (option == 2)
	        {
	            if (Ref_batch_flag == BAD)
	            {
	                printf ("\nInput the distance to XBDY (define refinement zone): ");
		            scanf  ("%lf", &distance);

#ifdef NORMALIZE_DATA
			    distance *= Norm_scale;
#endif

		            Ref_dist = distance;
	            }
	        }
	        else
	        {
	            /*
		        option == 3 case
		        equal zero or negative  means refine the inside of the region
		        Note that : user should responsible for a closed surface input
	            */
	            Ref_dist = distance = 0.;
	        }
	        surf_l_head   = xbdy_l_head;
	        surf_num_elem = xbdy_num_elem;
       }
       else if (option == 4)
       {
	        /* read in batch file name */
	        printf ("\nInput Batch File Name: ");
	        scanf  ("%s", Batch_fname);

	        if ((Batch_in = fopen (Batch_fname, "rt")) == NULL)
	        {
		        printf ("\nError...File %s not found!\n", Batch_fname);
		        continue;
	        }
	        else
	        {
	            Ref_batch_flag = OK;
		        fscanf (Batch_in, "%d", &Num_file_batch);
		        continue;
	        }
        }

G50:
	    Ref_elm_list = Last_ref_elm = NULL;
        Num_ref_elm  = 0;
        flag = BAD;
	    /* define refinement zone and tag nodes and element for refining */
        if (option == 100)
        {
            if (lrefine_count < Max_auto_ref_level)
            {
                lrefine_count++;
                /* checking for element space fitting */
                flag = tag_large_elem (*msh_l_head, *num_mesh_el,
                                        bdy_l_head, bdy_num_elem, 
                                        &Ref_elm_list, &Last_ref_elm, &Num_ref_elm); 
            }
            else
                option = 200;

            if (flag != OK)
                option = 200;   /* quit refinement */
        }
        else
        {
            flag = tag_ref_hex_zone (*msh_l_head, *num_mesh_el,
				        surf_l_head, surf_num_elem, distance,
				        &Ref_elm_list, &Last_ref_elm, &Num_ref_elm, auto_mode);
        }

	    printf ("\nAfter Tag ref_hex_zone\n");
        if (flag == OK)
        {
	        printf ("\nBefore One level check\n");
	        /* one level difference checking */
	        one_level_check (*msh_n_head, *num_mesh_nd, &Ref_elm_list,
					     &Last_ref_elm, &Num_ref_elm);

	        printf ("\nAfter One level check\n");
            printf ("\nNumber of hex needs be refined : %ld\n", Num_ref_elm);
	        /* refine elements */
	        refine_hexs (msh_n_head, num_mesh_nd, msh_l_head, num_mesh_el,
						  Ref_elm_list, Num_ref_elm);

	        printf ("\nAfter refine_hexs\n");
	        printf ("\nNum. of nodes : %ld\nNum. of hex : %ld\n",
			        *num_mesh_nd, *num_mesh_el);
	    }
             
	    /* free refinment element list */
        if (Ref_elm_list)
        {
		    free_adj_elem (Ref_elm_list);
            Ref_elm_list = NULL;
        }

	    /* free memory space */
	    if (xbdy_n_head)
		    free_bnode_list (xbdy_n_head, xbdy_num_node);

	    if (xbdy_l_head)
		    free_belem_list (xbdy_l_head, xbdy_num_elem);

        /* free adjlist first */
	    free_adj_lists (*msh_n_head, *num_mesh_nd);

	    /* creat adjlist */
	    mk_adjlist (*msh_n_head, *num_mesh_nd, *msh_l_head, *num_mesh_el);
        if (option == 200)
            break;
  }

  /* for deltahedra type hex, break into tetrahedron elements */
  if (Build_blk_type == 1)
  {
		printf ("\nBefore break down into tets\n");
		delta_hex_to_tet4 (msh_l_head, num_mesh_el);

		printf ("\nAfter break down into tets\n");

		/* free adjlist first */
		free_adj_lists (*msh_n_head, *num_mesh_nd);

		/* creat adjlist */
		mk_adjlist (*msh_n_head, *num_mesh_nd, *msh_l_head, *num_mesh_el);

		count = 0;
		for (;;)
		{
			Ref_elm_list = Last_ref_elm = NULL;
			Num_ref_elm  = 0;

			printf ("\nCheck tets knitting -- iteration : %d\n", ++count);

			/* connect singularity nodes */
			connect_single_node (*msh_n_head, *num_mesh_nd);

			/* check element with knitting condition and create a
				element list to be refined
			*/
			ref_flag = check_delta_knit (*msh_n_head, num_mesh_nd,
						     *msh_l_head, *num_mesh_el);

			if (Num_ref_elm == 0)    break;
			/* refine elements */
			refine_tets (msh_l_head, num_mesh_el, Ref_elm_list, Num_ref_elm);

			/* free refinment element list */
			free_adj_elem (Ref_elm_list);
            Ref_elm_list = NULL;
                                          
			/* free adjlist first */
			free_adj_lists (*msh_n_head, *num_mesh_nd);

			/* creat adjlist */
			mk_adjlist (*msh_n_head, *num_mesh_nd, *msh_l_head, *num_mesh_el);
		}
	    printf ("\nNum. of nodes : %ld\nNum. of tetrhedra : %ld\n",
			        *num_mesh_nd, *num_mesh_el);
  }

  /* check maximum node-elem. connectivity */
  nptr = *msh_n_head;
  num_node =  *num_mesh_nd;
  for (ii=0; ii<num_node; ii++)
  {
      num_adj_elm = nptr->Num_adj_elem;
      if (num_adj_elm >max_num_adjelem) max_num_adjelem = num_adj_elm; 
      nptr = nptr->Next;
  }

  printf ("\nMax. number of adjacent elem. connected to node : %d\n",  
             max_num_adjelem);

  return (OK);
}




/* define refinement zone and tag nodes and element for refining */
int
tag_ref_hex_zone (MeshElem  *msh_l_head,  long num_mesh_el,
		BMeshElem *surf_l_head, long surf_num_elem, REAL distance,
		AdjElem **ref_elm_list, AdjElem **lst_ref_elm,
		long *num_ref_elm, int auto_mode)
{
  int  in_zone, flag=OK;
  long ii, num_elem;
  MeshElem  *eptr;

  num_elem = num_mesh_el;

  /* find max. size of the object */
  Max_size = BDxmax - BDxmin;
  if (Max_size < BDymax - BDymin)  Max_size = BDymax - BDymin;
  if (Max_size < BDzmax - BDzmin)  Max_size = BDzmax - BDzmin;

  /* check middle node of the hex element */
  eptr = msh_l_head;
  for (ii=0; ii<num_elem; ii++)
  {
	in_zone = check_ref_hex (eptr, surf_l_head, surf_num_elem, distance, auto_mode);
	if (in_zone == OK)
	{
	  eptr->status = OK;    /* borrow the field to record in_zone */
	  /* tag refining elements */
	  if (tag_hex_elem (eptr, ref_elm_list, lst_ref_elm, num_ref_elm) == BAD)
	  {
		  printf ("\nThere is an error in tagging refining element\n") ;
		  flag = BAD;
          eptr->status = BAD;
	  }
	}
	else
	{
	  eptr->status = BAD;
	}

	eptr = eptr->Next;
  }

  return (flag);
}





/* Check the distance from given surface patch to test node
   if the node to surface distance is less than given distance
   the node is in refining zone, then return OK otherwise is BAD
   current strategy check three nodes on the diagonal, if all three
   node are out of region, return outside (BAD) otherwise return 
   inside (OK) skip this and try all corner nodes
*/
int
check_ref_hex_backup (MeshElem *eptr, BMeshElem *surf_l_head, long surf_num_elem,
	       REAL ref_dist)
{
      int  m, k, db_flag=BAD;
      long ii;
      REAL pnt[3], dist, min_dist, d[3], e[3], xlen;
      MeshNode  node;
      BMeshElem *septr, *bdy_patch_ptr;

      static REAL factor[3] = {0.25, 0.5, 0.75};

      for (m=0; m<3; m++)
      {
                /* find node on diaganol line as given factor of the Hex */
		for (k=0; k<3; k++)
		{
		  /*
		     d[k] = factor[m]*(eptr->Elem.hex8.NodePtr[3]->Coor[k] +
		                 eptr->Elem.hex8.NodePtr[5]->Coor[k]);
		  */
		     d[k] = eptr->Elem.hex8.NodePtr[4]->Coor[k] + 
                            factor[m]*(eptr->Elem.hex8.NodePtr[2]->Coor[k] -
		                       eptr->Elem.hex8.NodePtr[4]->Coor[k]);
	             node.Coor[k] = d[k];
		}

		if (ref_dist < HIGTOL)
		{
			/* check in-out refine inside */
			/* maximum ray cast distant */
			xlen = 4. * (BDxmax - BDxmin);

			/* end node */
#ifdef RANDOM_VACTOR
            random_shoot_full (d, e);
#else
			e[X] = d[X] + xlen;
			e[Y] = d[Y];
			e[Z] = d[Z];
#endif

			/* determin node in-out */
			if (nod_inout (d, e, surf_l_head, surf_num_elem,
					&bdy_patch_ptr, db_flag) == 0)
				continue; /*  return (BAD); outside region */
			else
				return (OK);   /* in (or on) the region */
		}

		/* along the Given region */
		min_dist = 1.e10;

		septr = surf_l_head;
		for (ii=0; ii<surf_num_elem; ii++)
		{
			/* box checking with bdy. patch */
			if (d[X]+ref_dist < septr->xmin || d[X]-ref_dist > septr->xmax)  goto G0;
			if (d[Y]+ref_dist < septr->ymin || d[Y]-ref_dist > septr->ymax)  goto G0;
			if (d[Z]+ref_dist < septr->zmin || d[Z]-ref_dist > septr->zmax)  goto G0;

			/* find closest distance to surface patches */
			dist = pnt2bdy (&node, septr, pnt);  /* pnt --- dummy */
			if (dist < min_dist)
			{
				min_dist = dist;
			}
			if (min_dist < ref_dist)    return (OK);
G0: 		        septr = septr->Next;
		}

	 /* check inbound */
	 if (min_dist < ref_dist)    return (OK);
	 else                        continue;    /* return (BAD);  */


     }

     return (BAD);

}


/* try corner nodes if any those nodes in region, tag it */
int
check_ref_hex (MeshElem *eptr, BMeshElem *surf_l_head, long surf_num_elem,
	       REAL ref_dist, int auto_mode)
{
    int  m, k, db_flag=BAD, dummy;
    long ii;
    REAL pnt[3], dist, min_dist, d[3], e[3], xlen;
    MeshNode  node, **nnptr;
    BMeshElem *septr, *bdy_patch_ptr;

    nnptr = eptr->Elem.hex8.NodePtr;
    for (m=0; m<8; m++)
    {
	    for (k=0; k<3; k++) 
        { 
		    d[k] = nnptr[m]->Coor[k];
            node.Coor[k] = d[k];
		}

		if (ref_dist < HIGTOL)
		{
			/* check in-out refine inside */
			/* maximum ray cast distant */
			xlen = 4. * (BDxmax - BDxmin);

			/* end node */
#ifdef RANDOM_VACTOR
            random_shoot_full (d, e);
#else
			e[X] = d[X] + xlen;
			e[Y] = d[Y];
			e[Z] = d[Z];
#endif
			/* determin node in-out */			
			if (nod_inout (d, e, surf_l_head, surf_num_elem,
					&bdy_patch_ptr, db_flag) == 0)
				continue; /*  return (BAD); outside region */
			else
				return (OK);   /* in (or on) the region */
		}

		/* along the Given region */
		min_dist = 1.e10;

		septr = surf_l_head;
		for (ii=0; ii<surf_num_elem; ii++)
		{
			/* box checking with bdy. patch */
			if (d[X]+ref_dist < septr->xmin || d[X]-ref_dist > septr->xmax)  goto G0;
			if (d[Y]+ref_dist < septr->ymin || d[Y]-ref_dist > septr->ymax)  goto G0;
			if (d[Z]+ref_dist < septr->zmin || d[Z]-ref_dist > septr->zmax)  goto G0;

			/* find closest distance to surface patches */
			dist = pnt2bdy (&node, septr, pnt);  /* pnt --- dummy */
			if (dist < min_dist)
			{
				min_dist = dist;
			}
		    if (min_dist < ref_dist) 
            {
                if (auto_mode)
                {
                    if (septr)
                    {   /* attr : current element's refinement level */
                        if (eptr->attr < septr->ref_levlel &&
                            eptr->attr < User_ref_level)
                            return (OK);  /* not detailed enough */
                        else
                            dummy = 1;
                            
                    }
                }
                else
                    return (OK);
            }
G0:		    septr = septr->Next;
		}

	    /* check inbound */
	    if (min_dist < ref_dist && auto_mode == 0)    return (OK);
	    else                        continue;    /* return (BAD);  */
    }

     return (BAD);
}




/* tag the elements to be refined, and create a ref. elem. list */
int
tag_hex_elem (MeshElem *eptr, AdjElem **ref_elm_list, AdjElem **lst_ref_elm,
	      long *num_ref_elm)
{
  AdjElem   *aeptr;


	if (eptr->status == OK)
	{
	   (eptr->attr)++;    /* record the refinement level */

	   aeptr = (AdjElem *) malloc (sizeof (AdjElem));
	   if (!aeptr) alloc_error ("refhex-1");
	   aeptr->idx = eptr;
	   aeptr->ptr = NULL;
	   if (*ref_elm_list == NULL && *num_ref_elm == 0)
	   {
	      /* first element to be refined */
	      *ref_elm_list = *lst_ref_elm = aeptr;
	   }
	   else
	   {
	      (*lst_ref_elm)->ptr = aeptr;
	      *lst_ref_elm        = aeptr;
	   }
	   (*num_ref_elm)++;
	}
	return (OK);

}



/* One level differece checking :
   search node-elem adj. list. Note that for original deployed node
   and elements. all internal nodes have 8 adjacent elements and
   6 adjacent nodes.
   1) if there are two adj. elem. have 2 level diffence, the higher level
      element should be taged.
   2) if only one element has 2 level difference, extra check should be applied
	   if the element is the diagnal element of base element. don't tag.
	   otherwise tag it.
      diagnal checking: find vectors from base node to base element center
      and the element to be checked if the angle between these two vectors
		is around 180 degree the element should be the diagnal element
   3) check if there is any more than 2 level difference element existed,
      given a warning message.
   4) The checking is also a multi-loop searching if there is new element
      has been taged. the search will be end with no more new element has
      been checked again.
*/

int
one_level_check (MeshNode *msh_n_head, long num_node, AdjElem **ref_elm_list,
		 AdjElem **lst_ref_elm, long *num_ref_elm)
{
    int  k, m, match_flag=0, taged_flag=0, num_adj_elm, max_level;
	int  num_max_level, num_lower_elem;
    long ii;
    MeshNode *nptr;
    MeshElem *lower_elm_ptr[MAX_ADJ_ELEM], *base_elem_ptr;
	 AdjElem  *aeptr;
    /* diag node idx (start from 0..7) */
	 static int diag_vtx_num [8] = {6, 7, 4, 5, 2, 3, 0, 1};


	 for (;;)
	 {
		taged_flag = 0;
		nptr = msh_n_head;
		for (ii=0; ii<num_node; ii++)
		{
			max_level = -10000;
			num_adj_elm = nptr->Num_adj_elem;
			if (num_adj_elm > MAX_ADJ_ELEM)
			{
				printf ("\nWaning...Unreasonable high num. of adj. elem : %d\n",
							num_adj_elm);
				goto   CON1;
			}
			else if (num_adj_elm == 1)   goto CON1;

			/* find the max. level (smallest elem.) */
	    
			aeptr = nptr->Fst_adj_elem;
			for (k=0; k<num_adj_elm; k++)
			{
				if (aeptr->idx->attr > max_level)
				{
					max_level = aeptr->idx->attr;
					base_elem_ptr = aeptr->idx;
				}
				aeptr = aeptr->ptr;
			}

			/* printf ("\nMax. level (for Node %ld) : %d\n", ii+1, max_level);*/
			/* check level difference */
			num_lower_elem = 0;
			num_max_level  = 0;
			aeptr = nptr->Fst_adj_elem;
			for (k=0; k<num_adj_elm; k++)
			{
				if ((max_level - aeptr->idx->attr) == 2)
					lower_elm_ptr[num_lower_elem++] = aeptr->idx;
				else if ((max_level - aeptr->idx->attr) == 0)
					num_max_level++;
				else if (max_level - aeptr->idx->attr > 2)
                                     printf ("\nlevel diff : %d\n", max_level - aeptr->idx->attr); 

				aeptr = aeptr->ptr;
			}

			/* num_lower_elem > 1  || (num_lower_elem==1 && num_max_level > 1)*/
			if (num_lower_elem > 0 )
			{
				for  (m=0; m<num_lower_elem; m++)
				{
					if (lower_elm_ptr[m]->status == OK)
					{
					    printf ("\nWarning... Refinement undone Can't tag it againg!\n");
					}
					else
					{
					   lower_elm_ptr[m]->status = OK;
					   if (tag_hex_elem (lower_elm_ptr[m], ref_elm_list,
							     lst_ref_elm, num_ref_elm) == BAD)
					   {
						printf ("\nThere is an error in tagging refining element:2\n") ;
					   }
					   else
						taged_flag = OK;
					}
				}
			}
            /*
			else if (num_lower_elem == 1)
			{
				// check diagnal mode 
				eptr = lower_elm_ptr[0];
				match_flag = 0;
				for (m=0; m<8; m++)
					if (eptr->Elem.hex8.NodePtr[m] == nptr)
					{
						match_flag = 1;
						nod_idx = diag_vtx_num [m];
						break;
					}

				if (match_flag==0)
				{
					printf ("Warning...Can't match node in Hex8 elem.\n");
					goto CON1;
				}

				match_flag = 0;
				for (m=0; m<8; m++)
					if (base_elem_ptr->Elem.hex8.NodePtr[m] == nptr)
				{
					match_flag = 1;
					base_idx = diag_vtx_num [m];
					break;
				}

				if (match_flag==0)
				{
					printf ("Warning...Can't match node in Hex8 elem(2).\n");
					goto CON1;
				}

				// find diagnal vector 
				v_make (nptr->Coor, eptr->Elem.hex8.NodePtr[nod_idx]->Coor,
							3, vec1);
				v_norm (vec1, 3);

				v_make (nptr->Coor, base_elem_ptr->Elem.hex8.NodePtr[base_idx]->Coor,
							3, vec2);
				v_norm (vec2, 3);


				// check angle between these two vector 
				if (fabs (v_dot (vec1, vec2, 3)) > LOWTOL)
				{
					// It's not a diagnal elem, tag it 
					taged_flag = OK;
					eptr->status = OK;
					if (tag_hex_elem (eptr, ref_elm_list,
							lst_ref_elm, num_ref_elm) == BAD)
					{
						printf ("\nThere is an error in tagging refining element:2\n") ;
					}
				}

			}
		        */

CON1:	    nptr = nptr->Next;
		}
		if (taged_flag == 0)   break;
    }

    return (OK);
}


/* refine a hex into 8 sub_hex */
int
refine_hexs  (MeshNode **msh_n_head, long *num_mesh_nd,
			MeshElem **msh_l_head, long *num_mesh_el,
			AdjElem *ref_list, long num_ref)
{
    long      num_elem, cp=0, count=0;
    int       num_interval = 500;
    MeshElem  *eptr;
    AdjElem   *aeptr;

    /* clean warning messages */
    num_elem = num_ref;

    num_elem = *num_mesh_el;
    aeptr = ref_list;
    while (aeptr)
    {
	    eptr = aeptr->idx;
	    /* complete break down to 8 hex8 */
	    refine_a_hex (eptr, msh_n_head, num_mesh_nd, msh_l_head, num_mesh_el);
	    num_elem += 7;
	    cp++;
	    if (!imod (cp, num_interval))
	    {
	        count += num_interval;
	        printf ("%ld Hexs done(cp=%ld)!\n", count, cp);
	    }
	    aeptr = aeptr->ptr;
    }

    /* doubly check */
    if (num_elem != *num_mesh_el)
       printf ("\nWarning... Number of element didn't match after refinement\n");

	 return (OK);
}


/* break into 8 hexs */
int
refine_a_hex (MeshElem *eptr, MeshNode **msh_n_head, long *num_mesh_nd,
	      MeshElem **msh_l_head, long *num_mesh_el)
{
    int      i, j, level;
    REAL     node_coor[27][3], pnt[3];
    MeshElem *sub_eptr;
    MeshNode **nnptr, *new_nnptr[27];

    /* idx start from 0..26 */
    static int hex1_8_idx [8][8] = { {18, 22, 26, 25,  4, 13, 17, 16},
				 { 0,  8, 12, 11, 18, 22, 26, 25},
				 { 8,  1,  9, 12, 22, 19, 23, 26},
				 {22, 19, 23, 26, 13,  5, 14, 17},
				 {25, 26, 24, 21, 16, 17, 15,  7},
				 {11, 12, 10,  3, 25, 26, 24, 21},
				 {12,  9,  2, 10, 26, 23, 20, 24},
				 {26, 23, 20, 24, 17, 14,  6, 15} };

    level = eptr->attr;	/* just search given level nodes */
    nnptr = eptr->Elem.hex8.NodePtr;
    /* find node coordinates for broken down */
    /* pass parent node coord. */
    for (i=0; i<8; i++)
		for (j=0; j<3; j++)
		{
			node_coor[i][j] = nnptr[i]->Coor[j];
			new_nnptr[i] = nnptr[i];
		}

	 /* determine derived node coord. and map in mesh node list */
	 for (j=0; j<3; j++)
		pnt[j] = node_coor[8][j] = 0.5 * (node_coor[0][j] + node_coor[1][j]);

	 new_nnptr[8] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[9][j] = 0.5 * (node_coor[1][j] + node_coor[2][j]);

	 new_nnptr[9] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[10][j] = 0.5 * (node_coor[2][j] + node_coor[3][j]);

	 new_nnptr[10] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[11][j] = 0.5 * (node_coor[3][j] + node_coor[0][j]);

	 new_nnptr[11] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[12][j] = 0.5 * (node_coor[8][j] + node_coor[10][j]);

	 new_nnptr[12] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[13][j] = 0.5 * (node_coor[4][j] + node_coor[5][j]);

	 new_nnptr[13] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[14][j] = 0.5 * (node_coor[5][j] + node_coor[6][j]);

	 new_nnptr[14] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[15][j] = 0.5 * (node_coor[6][j] + node_coor[7][j]);

	 new_nnptr[15] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[16][j] = 0.5 * (node_coor[7][j] + node_coor[4][j]);

	 new_nnptr[16] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[17][j] = 0.5 * (node_coor[13][j] + node_coor[15][j]);

	 new_nnptr[17] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[18][j] = 0.5 * (node_coor[0][j] + node_coor[4][j]);

	 new_nnptr[18] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[19][j] = 0.5 * (node_coor[1][j] + node_coor[5][j]);

	 new_nnptr[19] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[20][j] = 0.5 * (node_coor[2][j] + node_coor[6][j]);

	 new_nnptr[20] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[21][j] = 0.5 * (node_coor[3][j] + node_coor[7][j]);

	 new_nnptr[21] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[22][j] = 0.5 * (node_coor[8][j] + node_coor[13][j]);

	 new_nnptr[22] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[23][j] = 0.5 * (node_coor[9][j] + node_coor[14][j]);

	 new_nnptr[23] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[24][j] = 0.5 * (node_coor[10][j] + node_coor[15][j]);

	 new_nnptr[24] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[25][j] = 0.5 * (node_coor[11][j] + node_coor[16][j]);

	 new_nnptr[25] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, level);

	 for (j=0; j<3; j++)
		pnt[j] = node_coor[26][j] = 0.5 * (node_coor[2][j] + node_coor[4][j]);

	 new_nnptr[26] = match_node_ptr (pnt, msh_n_head, num_mesh_nd, -1);


	 for (i=0; i<8; i++)
	 {
		sub_eptr = create_a_hex_elem (msh_l_head, num_mesh_el);
		sub_eptr->E_type = HEX8;
		sub_eptr->attr	 = eptr->attr;  /* refinement level */
		sub_eptr->status = BAD;           /* untag */
		/* set element node ptr */
		for (j=0; j<8; j++)
		 	sub_eptr->Elem.hex8.NodePtr[j] = new_nnptr[hex1_8_idx[i][j]];
	 }
	 /* free base (parent) element */
	 free_a_elem (eptr, msh_l_head, num_mesh_el);

	 return (OK);
}

/* to match a node in mesh node list, if not match,  allocate a new node and
	insert it into node list,  and return the pointer of the node.
   right now search all new nodes in the list and late on it could be
   defined to search certain level of nodes in the list
*/
MeshNode *
match_node_ptr (REAL *pnt, MeshNode **msh_n_head, long *num_mesh_nd, int level)
{
    int       i, match_flag=0;
    long      ii, cp=0, max_search_num;
    MeshNode *nptr;

    if (level < 0)    goto CON;  /* don't try to match! just allocat it at tail of 0 level node */
    

    /* quick search */
    max_search_num = Level_tail_num[level]; /* notice it's the num. of nodes in the level */
    if (max_search_num <= 0)		    /* should not be less then 0 */
	goto CON;

    nptr = Ref_level_head[level];
    for (ii=0; ii<max_search_num; ii++) 
    {
	 if (fabs (nptr->Coor[X] - pnt[X]) < HIGTOL)
	     if (fabs (nptr->Coor[Y] - pnt[Y]) < HIGTOL)
	         if (fabs (nptr->Coor[Z] - pnt[Z]) < HIGTOL)
		 {
	                 match_flag = OK;
		         break;
		 }

	 /* debug checking */
         /* 
	 if (++cp > max_search_num)
	 {
	      printf ("\nProblem in match node list!\n");
	      break;
	 }
         */
         nptr = nptr->Next;
    }

CON:
    if (level < 0)     level = 0;   
    if (match_flag == 0)
    {
	/* allocate memory for new node */
	nptr = (MeshNode *) malloc (sizeof (MeshNode));
	if (!nptr)	alloc_error ("refhex-2");
	else
	{
	   nptr->Fst_adj = NULL;
	   nptr->Num_adj = 0;
	   nptr->Fst_adj_elem = NULL;
	   nptr->Num_adj_elem = 0;
	   nptr->status	= 0;
	   nptr->in_zone = 0;
	   nptr->Mtrl = BAD;
	   nptr->Prev = NULL;
	   nptr->Next = NULL;
	}
	if (Level_tail_num[level] == 0)
	{
	   /* first node in the level and insert at overall tail of node list */
           nptr->Prev = Ref_level_tail[level-1];
           nptr->Next = Ref_level_tail[level-1]->Next;
           Ref_level_tail[level-1]->Next->Prev = nptr;
	   Ref_level_tail[level-1]->Next       = nptr;
	   Ref_level_head[level] = Ref_level_tail[level] = nptr; 
        }
        else
	{
	  /* set up links to node list in tail of the level */
	  nptr->Next = Ref_level_tail[level]->Next;
	  nptr->Prev = Ref_level_tail[level];
	  Ref_level_tail[level]->Next->Prev = nptr;
	  Ref_level_tail[level]->Next = nptr;
	  Ref_level_tail[level] = nptr;
        }

        (Level_tail_num[level])++;	   
	(*num_mesh_nd)++;

	/* set coord. */
	for (i=0; i<3; i++)    nptr->Coor[i] = pnt[i];
     }

     return (nptr);
}




/* create an element and add to tail of the elem. list */
MeshElem *
create_a_hex_elem (MeshElem **msh_l_head, long *num_mesh_el)
{
     int      i;
     MeshElem *eptr;
     MeshNode **nnptr;

	    /* allocate for elem */
		 eptr = (MeshElem *) malloc (sizeof (MeshElem));
	    if (!eptr)	alloc_error ("refhex-3");
	    else
	    {
		eptr->attr = 0;
		eptr->status = 0;
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
		nnptr = eptr->Elem.hex8.NodePtr;
		for (i=0; i<8; i++) nnptr[i] = NULL;
		 }

	    /* link to tail of the elem list */
	    eptr->Prev = (*msh_l_head)->Prev;
	    eptr->Next = *msh_l_head;
	    (*msh_l_head)->Prev->Next = eptr;
	    (*msh_l_head)->Prev = eptr;
	    (*num_mesh_el)++;
    return (eptr);
}




/* break deltahedra hex model into tet4 model */
int 
delta_hex_to_tet4 (MeshElem **msh_l_head, long *num_mesh_el)
{

     long      ii, num_elem;
     MeshElem  *cur_hex_eptr, *next_hex_eptr, *fst_tet_ptr, *lst_tet_ptr;
     MeshElem  *cur_prev_eptr;

     num_elem = *num_mesh_el;
     cur_hex_eptr = *msh_l_head;
     cur_prev_eptr = (*msh_l_head)->Prev;
     for (ii=0; ii<num_elem; ii++)
     {
         next_hex_eptr = cur_hex_eptr->Next;
	 
	 /* 
	    break a deltahedra into six tet4.
	    input : a hex elem. pointer,
				output : a short tet4 link list with 6 tets
	 */
	 break_a_hex_to_tets (cur_hex_eptr, &fst_tet_ptr, &lst_tet_ptr);
	 
	 /* free parent hex */
	 free ((char *) cur_hex_eptr);
	 
         /* set links */
	 cur_prev_eptr->Next = fst_tet_ptr;
	 fst_tet_ptr->Prev   = cur_prev_eptr;
	 cur_prev_eptr       = lst_tet_ptr;

	 /* count element number increment : 6-1 = 5 */
	 (*num_mesh_el) += 5;
	 
         if (ii == 0)   *msh_l_head = fst_tet_ptr;  /* set global head */

	 cur_hex_eptr = next_hex_eptr;
     }

     /* close global element list link */
     (*msh_l_head)->Prev = lst_tet_ptr;
     lst_tet_ptr->Next = *msh_l_head;
     
     return (OK);
}



/* break a deltahedra type hex element into 6 tet4s */
int
break_a_hex_to_tets (MeshElem *hex_eptr, MeshElem **fst_tet_ptr,
                     MeshElem **lst_tet_ptr)
{

  int     i;
  MeshElem *eptr, *prev_eptr;
  MeshNode **nnptr, **hex_nnptr;

  int     dummy, memsize, alloc_size, *iptr;

  /* given 8 nodes (local index 1-8) to break down into six tets  */
  static int type_I[6][4] = { {1, 6, 5, 8},
			      {2, 7, 4, 3},
                              {1, 7, 8, 4}, 
                              {1, 2, 7, 4}, 
			      {1, 8, 7, 6},
			      {1, 7, 2, 6},
                            };

  hex_nnptr = hex_eptr->Elem.hex8.NodePtr;
  prev_eptr = NULL;
  for (i=0; i<6; i++)
  {
              /* allocate memory for tetrahedra element */
	     eptr = (MeshElem *) malloc (sizeof (MeshElem));
	     if (!eptr)	
	     {
	         memsize = sizeof (MeshElem);
		 printf ("Here run out of memory ---eptr = %ld, size=%d\n", 
			 eptr, memsize);
		 for (;;)
		 {
		   printf ("Testing... Try again=0 | quit=1\n");
		   scanf ("%d", &dummy);
		   if (dummy == 1)
		   {
		      break;
		   }
		   else
		   {
		     printf ("\nKey in # of bytes to allocate [0 -- %d] : ", memsize);
		     scanf ("%d", &alloc_size);
		     if (alloc_size < 0) continue;
		     iptr = (int *) malloc (alloc_size);	   
		     if (!iptr)
		     {
			 printf ("Failed again to allocate %d bytes of mem\n", 
				 alloc_size);
		     }
		     else
		     {
			 printf ("Sucessful to allocate %d bytes of mem\n", 
				 alloc_size);
			 free ((char *)iptr);
		 	 if (alloc_size >= memsize)
			 {
			   printf ("OOPs! There is a system problem."); 
                           printf ("It fools the 'malloc' function.  quit!\n");
			   break;
			 }
		     }
		   }
		 }
		 alloc_error ("refhex-4");
	     }
	     else
	     {
				eptr->E_type   = TET4;
				eptr->attr     = hex_eptr->attr;
				eptr->status   = hex_eptr->status;
				eptr->Mtrl_in  = BAD;
				eptr->Mtrl_out = BAD;
				eptr->Prev = NULL;
				eptr->Next = NULL;
	     }

	     /* set elem. link */
	     if (i == 0)    (*fst_tet_ptr)  = eptr;
	     else           prev_eptr->Next = eptr;

	     eptr->Prev = prev_eptr;
		  prev_eptr  = eptr;

	     nnptr = eptr->Elem.tet4.NodePtr;

	     nnptr[0] = hex_nnptr[type_I[i][0]-1];
	     nnptr[1] = hex_nnptr[type_I[i][1]-1];
	     nnptr[2] = hex_nnptr[type_I[i][2]-1];
	     nnptr[3] = hex_nnptr[type_I[i][3]-1];

	     

    }	     
    
    (*lst_tet_ptr) = eptr;


     return (OK);
}



/* connect singularity nodes due to hex refinement */
int
connect_single_node (MeshNode *msh_n_head, long num_node)
{
	 int      k, diff, num_chk_elem;
	 long     ii;
	 MeshNode *nptr;
	 MeshElem *ck_list[MAX_ADJ_ELEM];
	 AdjElem  *aeptr;

	 nptr = msh_n_head;
	 for (ii=0; ii<num_node; ii++)
	 { 

		if (nptr->Num_adj_elem < 2)   goto CON;
		aeptr = nptr->Fst_adj_elem;

		diff = adj_level (aeptr, nptr->Num_adj_elem, ck_list, &num_chk_elem);
		if (diff == 0)   goto CON;      /* done */
		else if(diff > 2 || diff < 0)
		{
			printf ("\nWarning... Invalid level difference in node adj. list : %d\n", diff);
			goto CON;
		}
		/* check middle point of higher level tet element */
		for (k=0; k<num_chk_elem; k++)
			check_tet_mid (ck_list[k], nptr);
CON:
		nptr = nptr->Next;
	 }

	 return (OK);
}



/* find max. level difference in given node adj. list, and return a list
	of element at least with one level higher then lowest level
	should be one level lower then highest level!!
*/
int
adj_level (AdjElem *aeptr, int num_adj_elem, MeshElem **check_list,
		int *num_higher)
{
	 int i=0, max_level=-10000, min_level=10000;
	 AdjElem  *cur_aeptr;

	 *num_higher = 0;
	 cur_aeptr = aeptr;
	 while (cur_aeptr)
	 {
		if (cur_aeptr->idx->attr < min_level)
			min_level = cur_aeptr->idx->attr;
		if (cur_aeptr->idx->attr > max_level)
			max_level = cur_aeptr->idx->attr;
		i++;
		cur_aeptr = cur_aeptr->ptr;
	 }
	 /* debug checking */
	 if (i != num_adj_elem)
	 {
		printf ("\nWarning...incompatible adj_elem list : %d (%d)\n", i, num_adj_elem);
		return (10000);
	 }
	 cur_aeptr = aeptr;
	 while (cur_aeptr)
	 {
		if (cur_aeptr->idx->attr <  max_level /* > min_level */)
		{
			if (*num_higher > MAX_ADJ_ELEM - 1)
			{
				printf ("\nWarning...num_adj_elem too large : %d\n", *num_higher);
				return (10000);
			}

			check_list[(*num_higher)++] = cur_aeptr->idx;
		}
		cur_aeptr = cur_aeptr->ptr;
	 }

	 return (max_level - min_level);
}



/* check higher level tet's middle point and see if there are middle point
	matchs nodes in adj. node list. and set proper node pointer
*/
int
check_tet_mid (MeshElem *eptr, MeshNode *nptr)
{
	  int      base_idx= -1, k, num_match_pnt=0;
	  MeshNode **nnptr, *mid_nptr;

	  static int mid_num [4][4] = { {0, 4, 6, 7},
					{4, 0, 5, 8},
					{6, 5, 0, 9},
					{7, 8, 9, 0} };
					
	  static int vtx_num [6][2] = { {0, 1},
					{1, 2},
					{2, 0},
					{0, 3},
					{1, 3},
					{2, 3} };

	  if (eptr->E_type == TET10)
			nnptr = eptr->Elem.tet10.NodePtr;
	  else /* TET4 type */
			nnptr = eptr->Elem.tet4.NodePtr;

	  /* find base node index */
	  for (k=0; k<4; k++)
	  {
			if (nptr == nnptr[k])
			{
				base_idx = k;
				break;
			}
	  }
	  if (base_idx == -1)
	  {
			printf ("\nWarning... Can't match base node!\n");
			return (BAD);
	  }

	  /* check middle point with three edges connected to base node */
	  for (k=0; k<4; k++)
	  {
			if (k == base_idx)   continue;   /* base node */

			mid_nptr = check_mid_pnt (nptr, nnptr[k]);
			if (mid_nptr)
			{
				/* match a middle node */
				if (eptr->E_type == TET4)
				{
					nnptr = tet4_2_tet10 (eptr);
					nnptr[mid_num[base_idx][k]] = mid_nptr;
					num_match_pnt++;
				}
				else
				{
					/* a promoted TET10 */
					if (nnptr[mid_num[base_idx][k]] == NULL)
					{
						nnptr[mid_num[base_idx][k]] = mid_nptr;
						num_match_pnt++;
					}
					else if (nnptr[mid_num[base_idx][k]] != mid_nptr)
					{
						/* assgin it anyway */
						nnptr[mid_num[base_idx][k]] = mid_nptr;
						printf ("\nConflict middle node in delta_hex/tet!\n");
					}
				}
			}
	  }


	  return (num_match_pnt);
}



/* check the middle point of an edge */
MeshNode *
check_mid_pnt (MeshNode *base_nptr, MeshNode *end_nptr)
{
	  int      k;
	  REAL     mid_coor[3];
	  MeshNode *mid_nptr=NULL;
	  AdjList  *anptr;

	 /* find middle point coordinate on the edge */
	 for (k=0; k<3; k++)
			mid_coor[k] = 0.5 * (base_nptr->Coor[k] + end_nptr->Coor[k]);

	 anptr = base_nptr->Fst_adj;
	 while (anptr)
	 {
		if (v_rang (anptr->idx->Coor, mid_coor, 3) < HIGTOL)
		{
			mid_nptr = anptr->idx;
			break;
		}
		anptr = anptr->ptr;
	 }

	 return (mid_nptr);
}




/*
	check element with knitting condition and create a
	 element list to be refined
*/
int
check_delta_knit (MeshNode *msh_n_head, long *num_mesh_nd,
						MeshElem *msh_l_head, long num_elem)
{
	 int      new_promote, new_node, elem_pattern;
	 long      tet4_num, tet5_num, tet6_num, tet7_num, tet8_num, tet9_num;
	 long      tet10_num;
	 long     ii, dbg_num;
	 MeshElem  *eptr;
	 AdjElem   *aeptr;

	 /* create initial refinement list */
	 eptr = msh_l_head;
	 for (ii=0; ii<num_elem; ii++)
	 {
		if (eptr->E_type == TET10)
		{
			aeptr = (AdjElem *) malloc (sizeof (AdjElem));
			if (!aeptr) alloc_error ("refhex-5");
			aeptr->idx = eptr;
			aeptr->ptr = NULL;
			if (Ref_elm_list == NULL && Num_ref_elm == 0)
			{
				/* first element to be refined */
				Ref_elm_list = Last_ref_elm = aeptr;
			}
			else
			{
				Last_ref_elm->ptr = aeptr;
				Last_ref_elm      = aeptr;
			}
			Num_ref_elm++;
		}
		eptr = eptr->Next;
	 }

	 /* checking break down conditions for promoted element.
		 if it doesn't match break down pattern then add mid
		 nodes to match the pattern. This is an iteration
		 process since the new promotion may chance the refine-
		 ment list. So the process will be finished until there
		 is no new promotion happened. That means, for final
		 pattern, only have 10, 7, 6, 5 (may be 4?) nodes TET10
		 left.
		 Attention: The refinement list will be kept expand
		 during process. Don't be suprise.
    */
	 if (Ref_elm_list == NULL)
	 {
	   printf ("\nNULL refinement list !!\n");
	   return (0);
	 }
	 for (;;)
	 {
	        new_promote = BAD;
	        new_node    = 0;
		dbg_num     = 0;

		 /* for debug */
		tet4_num    = 0;
		tet5_num    = 0;
		tet6_num    = 0;
		tet7_num    = 0;
		tet8_num    = 0;
		tet9_num    = 0;
		tet10_num    = 0;

		 aeptr = Ref_elm_list;
       while (aeptr)
       {
			dbg_num++;
			eptr = aeptr->idx;
			if (eptr->E_type == TET10)
			{
				/* if the tet is ref_level, it means it's already 10 node tet */
				/* find element pattern */
				elem_pattern = find_tet_pattern (eptr);

				switch (elem_pattern)
				{
					case TET4_4:
							tet4_num++;
							printf ("\nUn-promoted element!!\n");
							break;
					case TET4_5:
							/* generally,  all set. but may check if needs
								insert a mid-node on oppesite edge.
							*/
							tet5_num++;
							break;
					case TET4_6:
							/* if two mid-node do not on same face leave as
								6 node pattern, otherwise raise to 7 node.
							*/
							tet6_num++;
							if (process_tet4_6 (msh_n_head, num_mesh_nd, eptr)
									 == OK)
							{
								new_promote = OK;
								new_node++;
							}
							break;
					case TET4_7:
							/* if three mid-node do not on same face raise
								to 10 node tet, otherwise leave it as 7 node.
								pattern.
							*/
							tet7_num++;
							if (process_tet4_7 (msh_n_head, num_mesh_nd, eptr)
									== OK)
							{
								new_promote = OK;
								new_node += 3;
							}
							break;
					case TET4_8:
							tet8_num++;
							/* promote to 10 nodes tet10 */
							/* add two mid-node. first. */
							process_tet4_8 (msh_n_head, num_mesh_nd, eptr);
							new_node += 2;
							new_promote = OK;
							break;
					case TET4_9:
							tet9_num++;
							/* add one more mid-node up to 10 node tet10 */
							process_tet4_9 (msh_n_head, num_mesh_nd, eptr);
							new_node++;
							new_promote = OK;
							break;
					case TET4_10:
							/* all set for complete break down */
							tet10_num++;
							break;
					default:
							printf ("\nWarning...Unknown promoted type!!\n");

				}
			}

			aeptr = aeptr->ptr;
		 }

		 /* double checking for debug */
		 if (dbg_num != Num_ref_elm)
			printf ("\nThe num. of refined elements did not match: dbg=%8ld (%8ld)\n",
						dbg_num, Num_ref_elm);

		 if (new_promote == BAD && new_node == 0)   break;

	 }

	 /* for debug */
	printf ("\nTotal Num_ref_elm                = %ld", Num_ref_elm);
	printf ("\nNum. of Tet4 (should be 0)       = %ld", tet4_num);
	printf ("\nNum. of Tet5                     = %ld", tet5_num);
	printf ("\nNum. of Tet6                     = %ld", tet6_num);
	printf ("\nNum. of Tet7                     = %ld", tet7_num);
	printf ("\nNum. of Tet8 (should be 0)       = %ld", tet8_num);
	printf ("\nNum. of Tet9 (should be 0)       = %ld", tet9_num);
	printf ("\nNum. of Tet10                    = %ld\n", tet10_num);
	return (0);
}


/* define refinement zone and tag nodes and element for refining
   based on boundary surface span
    1. tag an element to be refined if it sit on more than 2 diff. mtrls region
    2. the central mtrl is different as all the other coner nodes.
    3. if hex's diagonal intersection checking crossed two bdy patches.
*/
int
tag_large_elem (MeshElem  *msh_l_head,  long num_mesh_el,
		BMeshElem *surf_l_head, long surf_num_elem, 
		AdjElem **ref_elm_list, AdjElem **lst_ref_elm, long *num_ref_elm)
{
    int         k, m, flag, mtrl_in, mtrl_out, num_p, ret_flag=BAD;
    int         count;
    long        ii, kk;
    NODE_MTRL   cen_mtrl;
    REAL        cen_pt[3], e[3];
    BMeshElem   *bdy_patch_ptr;
    MeshElem    *eptr;
    MeshNode    **nnptr;

    /* set node material code */
    mesh_nod_classify (surf_l_head, surf_num_elem,
		                Msh_node_head_ptr, Msh_nodes, WHOLE, NULL);
    for (ii=0, eptr=msh_l_head; ii<num_mesh_el; ii++, eptr=eptr->Next)
    {
        if (eptr->E_type != HEX8) 
        {
            printf ("\nUnhandled Elem. Type (%d)");
            continue;
        }
        num_p = 8;
        nnptr = eptr->Elem.hex8.NodePtr;
        for (k=0; k<3; k++)
		{
            cen_pt[k] = 0;
            for (m=0; m<num_p; m++)
                    cen_pt[k] += nnptr[m]->Coor[k];

            cen_pt[k] /= (REAL)num_p;
        }
        /* end node */
#ifdef RANDOM_VACTOR
        random_shoot_full (cen_pt, e);
#else
        e[X] = cen_pt[X] + 4.*(BDxmax - BDxmin);
        e[Y] = cen_pt[Y];
        e[Z] = cen_pt[Z];
#endif
        /* determin central point mtrl */
        cen_mtrl = nod_in_region (cen_pt, e, surf_l_head,
                                  surf_num_elem, &bdy_patch_ptr);

        if (cen_mtrl > BDY_NODE_CODE)
        {
           /* on boundary */
           continue;
           /*
           mtrl_in  = nnptr[k]->Mtrl / MTRL_IN_CODE;
           mtrl_out = (nnptr[k]->Mtrl - MTRL_IN_CODE * mtrl_in) / MTRL_OUT_CODE; 
           */
        } 

        /* to determine if the element needs be tagged */
        flag = BAD;
        for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
        for (k=0; k<num_p; k++)
        {
            if (nnptr[k]->Mtrl > BDY_NODE_CODE) 
            {   /* boundary node */
                mtrl_in  = nnptr[k]->Mtrl / MTRL_IN_CODE;
                mtrl_out = (nnptr[k]->Mtrl - MTRL_IN_CODE * mtrl_in) / MTRL_OUT_CODE; 
                if (mtrl_in < MAX_MTRL_NUM) Mtrl_code[mtrl_in]++;
                if (mtrl_out < MAX_MTRL_NUM) Mtrl_code[mtrl_out]++;
            }
            else
            {
                if (nnptr[k]->Mtrl < MAX_MTRL_NUM) 
                        Mtrl_code[nnptr[k]->Mtrl]++;
                else
                {
                    kk = nnptr[k]->Mtrl;
                    printf ("\nWrong Mtrl code: %ld!\n", kk);
                }
            }
        }

        /* check how many mtrl regions the elem. sit on */
        count = 0;
        for (k=0; k<MAX_MTRL_NUM; k++)
        {
            if (Mtrl_code[k])   count++;
        }
        
        if (count > 2)  flag = OK;
        else if (Mtrl_code [cen_mtrl] == 0)
        {
            /* all the other nodes are in diff. mtrl code */
            flag = OK;
        }
        /*
        else if ((nnptr[0]->Mtrl != cen_mtrl && nnptr[6]->Mtrl != cen_mtrl) ||
                 (nnptr[1]->Mtrl != cen_mtrl && nnptr[7]->Mtrl != cen_mtrl) ||
                 (nnptr[2]->Mtrl != cen_mtrl && nnptr[4]->Mtrl != cen_mtrl) ||
                 (nnptr[3]->Mtrl != cen_mtrl && nnptr[5]->Mtrl != cen_mtrl))
        {
            // elem. cross 2 mtrl bdys
            flag = OK;
        }
        */
        else if (hex_diagonal_check (nnptr, surf_l_head, surf_num_elem) == OK)
        {
            flag = OK;
        }
 
	    if (flag == OK)
	    {
            ret_flag     = OK;
	        eptr->status = OK;    /* borrow the field to record in_zone */
	        /* tag refining elements */
	        if (tag_hex_elem (eptr, ref_elm_list, lst_ref_elm, num_ref_elm) == BAD)
	        {
		        printf ("\nThere is an error in tagging refining element\n") ;
		        flag = BAD;
                eptr->status = BAD;
	        }
	    }
        else
            eptr->status = BAD;

    }
    return (ret_flag);
}


/* use diagonal lines for intersection checking against bdy patches */
/* revised by Ziji Wu, 4/16/99 
   unless user selects so, the hex will not be taged if it,
   1. only crosses two adjacent physical boundary elements; and/or
   2. only crosses physical boundary elements that have same material

   revised by Ziji Wu, 8/3/00
   instead of using 4 diagonals, it will use 12 vectors shooting from
   one face to the opposite face respectively. Hopefully, they will 
   cover more space than the diagonals. The previous version was 
   saved as hex_diagonal_check_bak after this subroutine.
*/
int 
hex_diagonal_check (MeshNode **nnptr, BMeshElem *bdy_l_head, 
                    long n_bdy_elem)
{
    int      i, k, cross_type, cross_count, flag=0;
    long     jj;
    REAL     a[3], b[3], c[3], d[3], e[3], r[3];
    REAL     ray_xmin, ray_xmax, ray_ymin, ray_ymax, ray_zmin, ray_zmax;
    REAL     st[3][12], ed[3][12];
    BMeshNode *n_1, *n_2, *n_3;
    BMeshElem *bdy_eptr;
/* added by Ziji 4/16/99 */
	long crossed[3][100], cmat, bnode; 
	/* up to 100 bdy pieces can be recorded */
	/* counter of how many materials crossed */
	int  izw, jzw, cnt, kzw, mzw;
/* end of Ziji */
	double   factor = 1./3;

	for (i=0; i<3; i++) {
		st[i][0] = factor*nnptr[0]->Coor[i]+(1.-factor)*nnptr[2]->Coor[i];
		st[i][2] = (1.-factor)*nnptr[0]->Coor[i]+factor*nnptr[2]->Coor[i];
		st[i][1] = factor*nnptr[1]->Coor[i]+(1.-factor)*nnptr[3]->Coor[i];
		st[i][3] = (1.-factor)*nnptr[1]->Coor[i]+factor*nnptr[3]->Coor[i];
		ed[i][0] = factor*nnptr[4]->Coor[i]+(1.-factor)*nnptr[6]->Coor[i];
		ed[i][2] = (1.-factor)*nnptr[4]->Coor[i]+factor*nnptr[6]->Coor[i];
		ed[i][1] = factor*nnptr[5]->Coor[i]+(1.-factor)*nnptr[7]->Coor[i];
		ed[i][3] = (1.-factor)*nnptr[5]->Coor[i]+factor*nnptr[7]->Coor[i];

		st[i][4] = factor*nnptr[0]->Coor[i]+(1.-factor)*nnptr[5]->Coor[i];
		st[i][6] = (1.-factor)*nnptr[0]->Coor[i]+factor*nnptr[5]->Coor[i];
		st[i][5] = factor*nnptr[1]->Coor[i]+(1.-factor)*nnptr[4]->Coor[i];
		st[i][7] = (1.-factor)*nnptr[1]->Coor[i]+factor*nnptr[4]->Coor[i];
		ed[i][4] = factor*nnptr[3]->Coor[i]+(1.-factor)*nnptr[6]->Coor[i];
		ed[i][6] = (1.-factor)*nnptr[3]->Coor[i]+factor*nnptr[6]->Coor[i];
		ed[i][5] = factor*nnptr[2]->Coor[i]+(1.-factor)*nnptr[7]->Coor[i];
		ed[i][7] = (1.-factor)*nnptr[2]->Coor[i]+factor*nnptr[7]->Coor[i];

		st[i][8] = factor*nnptr[1]->Coor[i]+(1.-factor)*nnptr[6]->Coor[i];
		st[i][10] = (1.-factor)*nnptr[1]->Coor[i]+factor*nnptr[6]->Coor[i];
		st[i][9] = factor*nnptr[2]->Coor[i]+(1.-factor)*nnptr[5]->Coor[i];
		st[i][11] = (1.-factor)*nnptr[2]->Coor[i]+factor*nnptr[5]->Coor[i];
		ed[i][8] = factor*nnptr[0]->Coor[i]+(1.-factor)*nnptr[7]->Coor[i];
		ed[i][10] = (1.-factor)*nnptr[0]->Coor[i]+factor*nnptr[7]->Coor[i];
		ed[i][9] = factor*nnptr[3]->Coor[i]+(1.-factor)*nnptr[4]->Coor[i];
		ed[i][11] = (1.-factor)*nnptr[3]->Coor[i]+factor*nnptr[4]->Coor[i];
	}

/* added by Ziji 4/16/99 */
	if (autoref_ignore_same_mtrl_bdy==0) 
	    for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
/* end of Ziji */

    for (i=0; i<12; i++)
    {
        for (k=0; k<3; k++)
        {
            d[k] = st[k][i];
            e[k] = ed[k][i];
        }
	    /* find the bounding box (limit) of the vector d --> e */
	    ray_xmin = (d[X] < e[X]) ? d[X] : e[X];
	    ray_xmax = (d[X] > e[X]) ? d[X] : e[X];
	    ray_ymin = (d[Y] < e[Y]) ? d[Y] : e[Y];
	    ray_ymax = (d[Y] > e[Y]) ? d[Y] : e[Y];
	    ray_zmin = (d[Z] < e[Z]) ? d[Z] : e[Z];
	    ray_zmax = (d[Z] > e[Z]) ? d[Z] : e[Z];
        cross_count = 0;

/* added by Ziji 4/16/99 */
		if (autoref_ignore_same_mtrl_bdy==0) cmat=0;
/* end of Ziji */

	    for (jj=0, bdy_eptr=bdy_l_head; jj<n_bdy_elem; jj++, bdy_eptr=bdy_eptr->Next)
	    {
		    /* check bounding */
		    if (ray_xmin > bdy_eptr->xmax || ray_xmax < bdy_eptr->xmin)   continue;
		    if (ray_ymin > bdy_eptr->ymax || ray_ymax < bdy_eptr->ymin)   continue;
		    if (ray_zmin > bdy_eptr->zmax || ray_zmax < bdy_eptr->zmin)   continue;
		    /* search for each boundary element */
		    n_1 = bdy_eptr->Elem.tri3.NodePtr[0];
		    n_2 = bdy_eptr->Elem.tri3.NodePtr[1];
		    n_3 = bdy_eptr->Elem.tri3.NodePtr[2];
		    /* define vector a, b, c */
		    a[X] = n_1->Coor[X];
		    a[Y] = n_1->Coor[Y];
		    a[Z] = n_1->Coor[Z];

		    b[X] = n_2->Coor[X] - a[X];
		    b[Y] = n_2->Coor[Y] - a[Y];
		    b[Z] = n_2->Coor[Z] - a[Z];

		    c[X] = n_3->Coor[X] - a[X];
		    c[Y] = n_3->Coor[Y] - a[Y];
		    c[Z] = n_3->Coor[Z] - a[Z];
		    /* cross checking */
		    cross_type = line_tri_cross (d, e, a, b, c, r);

		    if (cross_type == INBOUND)
		    {
/*Ziji 4/16/99                cross_count++;
                if (cross_count > 1)
                {
                    flag = 1;
                    break;
                }
*/
				if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==1)) {
					cross_count++;
	                if (cross_count > 1)
		            {
			            flag = 1;
				        break;
					}
				}
				else {
					if (autoref_ignore_same_mtrl_bdy==0) {
						if (Mtrl_code[bdy_eptr->Mtrl_in]==0) {
							Mtrl_code[bdy_eptr->Mtrl_in]++;
							cmat++;
						}
						if (Mtrl_code[bdy_eptr->Mtrl_out]==0) {
							Mtrl_code[bdy_eptr->Mtrl_out]++;
							cmat++;
						}
					}
					if (autoref_ignore_adj_bdy==0) {
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_1, Bdy_nodes);
						crossed[0][cross_count]=bnode;
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_2, Bdy_nodes);
						crossed[1][cross_count]=bnode;
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_3, Bdy_nodes);
						crossed[2][cross_count]=bnode;
						cross_count++;
					}
				}
/* end of Ziji */
		    }
        }

/* Ziji, 4/16/99         if (flag == 1)
            return (OK);
*/
		if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==1)) {
			/* neither of them has been set up (do not ignore) */
			if (flag == 1)	return (OK);
		}
		else if ((autoref_ignore_adj_bdy==0)&&(autoref_ignore_same_mtrl_bdy==1)) {
			/* only ignore adjacent bdy */
			if (cross_count>1) {
				for (izw=0; izw<cross_count-1; izw++){
					for (jzw=izw+1; jzw<cross_count; jzw++) {
						cnt=0;
						for (kzw=0; kzw<3; kzw++){
							for (mzw=0; mzw<3; mzw++) {
								if (crossed[kzw][izw]==crossed[mzw][jzw]) cnt++;
							}
						}
						if (cnt<2) return (OK);
					}
				}
			} /* otherwise, do not need check */
		}
		else if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==0)) {
			/* only ignore same matl */
			if (cmat>2) return (OK);
		}
		else /*if ((autoref_ignore_adj_bdy==0)&&(autoref_ignore_same_mtrl_bdy==0))*/ {
			/* both are set (ignore) */
			if ((cross_count>1)&&(cmat>2)) {
				for (izw=0; izw<cross_count-1; izw++){
					for (jzw=izw+1; jzw<cross_count; jzw++) {
						cnt=0;
						for (kzw=0; kzw<3; kzw++){
							for (mzw=0; mzw<3; mzw++) {
								if (crossed[kzw][izw]==crossed[mzw][jzw]) cnt++;
							}
						}
						if (cnt<2) return (OK);
					}
				}
			} /* otherwise, do not need check */
		}
/* end of Ziji */
    }
 
    return (BAD);   
}


/* use diagonal lines for intersection checking against bdy patches */
/* revised by Ziji Wu, 4/16/99 
   unless user selects so, the hex will not be taged if it,
   1. only crosses two adjacent physical boundary elements; and/or
   2. only crosses physical boundary elements that have same material
*/
int 
hex_diagonal_check_bak (MeshNode **nnptr, BMeshElem *bdy_l_head, 
                    long n_bdy_elem)
{
    int      i, k, cross_type, cross_count, flag=0;
    long     jj;
    REAL     a[3], b[3], c[3], d[3], e[3], r[3];
    REAL     ray_xmin, ray_xmax, ray_ymin, ray_ymax, ray_zmin, ray_zmax;
    MeshNode *st[4], *ed[4];
    BMeshNode *n_1, *n_2, *n_3;
    BMeshElem *bdy_eptr;
/* added by Ziji 4/16/99 */
	long crossed[3][100], cmat, bnode; 
	/* up to 100 bdy pieces can be recorded */
	/* counter of how many materials crossed */
	int  izw, jzw, cnt, kzw, mzw;
/* end of Ziji */

    st[0] = nnptr[0];    ed[0] = nnptr[6];
    st[1] = nnptr[1];    ed[1] = nnptr[7];
    st[2] = nnptr[2];    ed[2] = nnptr[4];
    st[3] = nnptr[3];    ed[3] = nnptr[5];

/* added by Ziji 4/16/99 */
	if (autoref_ignore_same_mtrl_bdy==0) 
	    for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
/* end of Ziji */

    for (i=0; i<4; i++)
    {
        for (k=0; k<3; k++)
        {
            d[k] = st[i]->Coor[k];
            e[k] = ed[i]->Coor[k];
        }
	    /* find the bounding box (limit) of the vector d --> e */
	    ray_xmin = (d[X] < e[X]) ? d[X] : e[X];
	    ray_xmax = (d[X] > e[X]) ? d[X] : e[X];
	    ray_ymin = (d[Y] < e[Y]) ? d[Y] : e[Y];
	    ray_ymax = (d[Y] > e[Y]) ? d[Y] : e[Y];
	    ray_zmin = (d[Z] < e[Z]) ? d[Z] : e[Z];
	    ray_zmax = (d[Z] > e[Z]) ? d[Z] : e[Z];
        cross_count = 0;

/* added by Ziji 4/16/99 */
		if (autoref_ignore_same_mtrl_bdy==0) cmat=0;
/* end of Ziji */

	    for (jj=0, bdy_eptr=bdy_l_head; jj<n_bdy_elem; jj++, bdy_eptr=bdy_eptr->Next)
	    {
		    /* check bounding */
		    if (ray_xmin > bdy_eptr->xmax || ray_xmax < bdy_eptr->xmin)   continue;
		    if (ray_ymin > bdy_eptr->ymax || ray_ymax < bdy_eptr->ymin)   continue;
		    if (ray_zmin > bdy_eptr->zmax || ray_zmax < bdy_eptr->zmin)   continue;
		    /* search for each boundary element */
		    n_1 = bdy_eptr->Elem.tri3.NodePtr[0];
		    n_2 = bdy_eptr->Elem.tri3.NodePtr[1];
		    n_3 = bdy_eptr->Elem.tri3.NodePtr[2];
		    /* define vector a, b, c */
		    a[X] = n_1->Coor[X];
		    a[Y] = n_1->Coor[Y];
		    a[Z] = n_1->Coor[Z];

		    b[X] = n_2->Coor[X] - a[X];
		    b[Y] = n_2->Coor[Y] - a[Y];
		    b[Z] = n_2->Coor[Z] - a[Z];

		    c[X] = n_3->Coor[X] - a[X];
		    c[Y] = n_3->Coor[Y] - a[Y];
		    c[Z] = n_3->Coor[Z] - a[Z];
		    /* cross checking */
		    cross_type = line_tri_cross (d, e, a, b, c, r);

		    if (cross_type == INBOUND)
		    {
/*Ziji 4/16/99                cross_count++;
                if (cross_count > 1)
                {
                    flag = 1;
                    break;
                }
*/
				if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==1)) {
					cross_count++;
	                if (cross_count > 1)
		            {
			            flag = 1;
				        break;
					}
				}
				else {
					if (autoref_ignore_same_mtrl_bdy==0) {
						if (Mtrl_code[bdy_eptr->Mtrl_in]==0) {
							Mtrl_code[bdy_eptr->Mtrl_in]++;
							cmat++;
						}
						if (Mtrl_code[bdy_eptr->Mtrl_out]==0) {
							Mtrl_code[bdy_eptr->Mtrl_out]++;
							cmat++;
						}
					}
					if (autoref_ignore_adj_bdy==0) {
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_1, Bdy_nodes);
						crossed[0][cross_count]=bnode;
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_2, Bdy_nodes);
						crossed[1][cross_count]=bnode;
						bnode=conv_bnode_ptr(Bdy_node_head_ptr, n_3, Bdy_nodes);
						crossed[2][cross_count]=bnode;
						cross_count++;
					}
				}
/* end of Ziji */
		    }
        }

/* Ziji, 4/16/99         if (flag == 1)
            return (OK);
*/
		if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==1)) {
			/* neither of them has been set up (do not ignore) */
			if (flag == 1)	return (OK);
		}
		else if ((autoref_ignore_adj_bdy==0)&&(autoref_ignore_same_mtrl_bdy==1)) {
			/* only ignore adjacent bdy */
			if (cross_count>1) {
				for (izw=0; izw<cross_count-1; izw++){
					for (jzw=izw+1; jzw<cross_count; jzw++) {
						cnt=0;
						for (kzw=0; kzw<3; kzw++){
							for (mzw=0; mzw<3; mzw++) {
								if (crossed[kzw][izw]==crossed[mzw][jzw]) cnt++;
							}
						}
						if (cnt<2) return (OK);
					}
				}
			} /* otherwise, do not need check */
		}
		else if ((autoref_ignore_adj_bdy==1)&&(autoref_ignore_same_mtrl_bdy==0)) {
			/* only ignore same matl */
			if (cmat>2) return (OK);
		}
		else /*if ((autoref_ignore_adj_bdy==0)&&(autoref_ignore_same_mtrl_bdy==0))*/ {
			/* both are set (ignore) */
			if ((cross_count>1)&&(cmat>2)) {
				for (izw=0; izw<cross_count-1; izw++){
					for (jzw=izw+1; jzw<cross_count; jzw++) {
						cnt=0;
						for (kzw=0; kzw<3; kzw++){
							for (mzw=0; mzw<3; mzw++) {
								if (crossed[kzw][izw]==crossed[mzw][jzw]) cnt++;
							}
						}
						if (cnt<2) return (OK);
					}
				}
			} /* otherwise, do not need check */
		}
/* end of Ziji */
    }
 
    return (BAD);   
}

