/*fil**********************************************************************
	NAME:           dyalloc.c
	PROJECT:        ALL
	MODULE:         Dynamic memory allocation
	AUTHOR:         James Q. Zhang
	DATE:           Feb. 25, 1997.
	DESCRIPTION:    Port from Numerical Recipe in C
***************************************************************************/
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include "dyalloc.h"

void 
nrerror(char error_text[])
{
	void exit();

	fprintf(stderr,"Dynamic Memory Allocate error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"Quit to system!!!\n");
	exit(1);
}


/* float 1D array (float *a) : a[nl] - a[nh] */ 
float *
vector (TYPE_SIZE nl, TYPE_SIZE nh)
{
	float *v;

	v=(float *)ALLOC_TYPE((unsigned) (nh-nl+1)*sizeof(float));
	if (!v) nrerror("allocation failure in vector()");
	return v-nl;
}

/* integer 1D array (int *a) : a[nl] - a[nh] */ 
int *
ivector (TYPE_SIZE nl, TYPE_SIZE nh)
{
	int *v;

	v=(int *)ALLOC_TYPE((unsigned) (nh-nl+1)*sizeof(int));
	if (!v) nrerror("allocation failure in ivector()");
	return v-nl;
}


/* double 1D array (double *a) : a[nl] - a[nh] */ 
double *
dvector (TYPE_SIZE nl, TYPE_SIZE nh)
{
	double *v;

	v=(double *)ALLOC_TYPE((unsigned) (nh-nl+1)*sizeof(double));
	if (!v) nrerror("allocation failure in dvector()");
	return v-nl;
}


/* float 2D array (float **a) : a[nrl][ncl] - a[nrh][nch] */ 
float **
matrix (TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i;
	float **m;

	m=(float **) ALLOC_TYPE((unsigned) (nrh-nrl+1)*sizeof(float*));
	if (!m) nrerror("allocation failure 1 in matrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(float *) ALLOC_TYPE((unsigned) (nch-ncl+1)*sizeof(float));
		if (!m[i]) nrerror("allocation failure 2 in matrix()");
		m[i] -= ncl;
	}
	return m;
}



/* double 2D array (double **a) : a[nrl][ncl] - a[nrh][nch] */ 
double **
dmatrix (TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i;
	double **m;

	m=(double **) ALLOC_TYPE((unsigned) (nrh-nrl+1)*sizeof(double*));
	if (!m) nrerror("allocation failure 1 in dmatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(double *) ALLOC_TYPE((unsigned) (nch-ncl+1)*sizeof(double));
		if (!m[i]) nrerror("allocation failure 2 in dmatrix()");
		m[i] -= ncl;
	}
	return m;
}



/* integer 2D array (int **a) : a[nrl][ncl] - a[nrh][nch] */ 
int **
imatrix (TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE   i;
    int         **m;

	m=(int **)ALLOC_TYPE((unsigned) (nrh-nrl+1)*sizeof(int*));
	if (!m) nrerror("allocation failure 1 in imatrix()");
	m -= nrl;

	for(i=nrl;i<=nrh;i++) {
		m[i]=(int *)ALLOC_TYPE((unsigned) (nch-ncl+1)*sizeof(int));
		if (!m[i]) nrerror("allocation failure 2 in imatrix()");
		m[i] -= ncl;
	}
	return m;
}




/* float 2D sub_array (float **b **a )
b[newrl][newcl] - b[newrl+(oldrh-oldrl)][newcl+(oldch-oldcl)] 
within the range of array a : equal to a[oldrl][oldcl] - a[oldrh][oldch]
*/  
float **submatrix (float **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch,
                   TYPE_SIZE newrl, TYPE_SIZE newcl)
{
	TYPE_SIZE i,j;
	float **m;

	m=(float **) ALLOC_TYPE((unsigned) (oldrh-oldrl+1)*sizeof(float*));
	if (!m) nrerror("allocation failure in submatrix()");
	m -= newrl;

	for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+oldcl-newcl;

	return m;
}








/* double 2D sub_array (double **b **a )
b[newrl][newcl] - b[newrl+(oldrh-oldrl)][newcl+(oldch-oldcl)] 
within the range of array a : equal to a[oldrl][oldcl] - a[oldrh][oldch]
*/  
double **
subdmatrix (double **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch,
            TYPE_SIZE newrl, TYPE_SIZE newcl)
{
	TYPE_SIZE i,j;
	double **m;

	m=(double **) ALLOC_TYPE((unsigned) (oldrh-oldrl+1)*sizeof(double*));
	if (!m) nrerror("allocation failure in subdmatrix()");
	m -= newrl;

	for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+oldcl-newcl;

	return m;
}





/* Integer 2D sub_array (int **b **a )
b[newrl][newcl] - b[newrl+(oldrh-oldrl)][newcl+(oldch-oldcl)] 
within the range of array a : equal to a[oldrl][oldcl] - a[oldrh][oldch]
*/  
int **
subimatrix (int **a, TYPE_SIZE oldrl, TYPE_SIZE oldrh, TYPE_SIZE oldcl, TYPE_SIZE oldch,
            TYPE_SIZE newrl, TYPE_SIZE newcl)
{
	TYPE_SIZE i,j;
	int **m;

	m=(int **) ALLOC_TYPE((unsigned) (oldrh-oldrl+1)*sizeof(int*));
	if (!m) nrerror("allocation failure in subimatrix()");
	m -= newrl;

	for(i=oldrl,j=newrl;i<=oldrh;i++,j++) m[j]=a[i]+oldcl-newcl;

	return m;
}






/* free a allocated memory for float 1D array v[nl]-v[nh] */
void 
free_vector (float *v, TYPE_SIZE nl, TYPE_SIZE nh)
{
	FREE_TYPE((char*) (v+nl));
}

/* free a allocated memory for int 1D array v[nl]-v[nh] */
void 
free_ivector (int *v, TYPE_SIZE nl, TYPE_SIZE nh)
{
	FREE_TYPE((char*) (v+nl));
}

/* free a allocated memory for double 1D array v[nl]-v[nh] */
void 
free_dvector (double *v, TYPE_SIZE nl, TYPE_SIZE nh)
{
	FREE_TYPE((char*) (v+nl));
}


/* free a allocated memory for float 2D array m[nl][cl]-v[nh][ch] */
void 
free_matrix (float **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i;

	for(i=nrh;i>=nrl;i--) FREE_TYPE((char*) (m[i]+ncl));
	FREE_TYPE((char*) (m+nrl));
}


/* free a allocated memory for double 2D array m[nl][cl]-v[nh][ch] */
void 
free_dmatrix(double **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i;

	for(i=nrh;i>=nrl;i--) FREE_TYPE((char*) (m[i]+ncl));
	FREE_TYPE((char*) (m+nrl));
}



/* free a allocated memory for int 2D array m[nl][cl]-v[nh][ch] */
void 
free_imatrix (int **m, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i;

	for(i=nrh;i>=nrl;i--) FREE_TYPE((char*) (m[i]+ncl));
	FREE_TYPE((char*) (m+nrl));
}


/* free a allocated memory for float 2D sub_array b[nl][cl]-v[nh][ch] */
void 
free_submatrix (float **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}


/* free a allocated memory for double 2D sub_array b[nl][cl]-v[nh][ch] */
void 
free_subdmatrix (double **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}



/* free a allocated memory for int 2D sub_array b[nl][cl]-v[nh][ch] */
void 
free_subimatrix (int **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}




/*
// convert a float matrix 
float **
convert_matrix (float **a, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i,j,nrow,ncol;
	float **m;

	nrow=nrh-nrl+1;
	ncol=nch-ncl+1;
	m = (float **) ALLOC_TYPE((unsigned) (nrow)*sizeof(float*));
	if (!m) nrerror("allocation failure in convert_matrix()");
	m -= nrl;
	for(i=0,j=nrl;i<=nrow-1;i++,j++) m[j]=a+ncol*i-ncl;
	return m;
}




// convert a double matrix 
double **
convert_dmatrix (double **a, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i,j,nrow,ncol;
	double **m;

	nrow=nrh-nrl+1;
	ncol=nch-ncl+1;
	m = (double **) ALLOC_TYPE((unsigned) (nrow)*sizeof(double*));
	if (!m) nrerror("allocation failure in convert_matrix()");
	m -= nrl;
	for(i=0,j=nrl;i<=nrow-1;i++,j++) m[j]=a+ncol*i-ncl;
	return m;
}




// convert a int matrix 
int **
convert_imatrix (int **a, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	TYPE_SIZE i,j,nrow,ncol;
	int **m;

	nrow=nrh-nrl+1;
	ncol=nch-ncl+1;
	m = (int **) ALLOC_TYPE((unsigned) (nrow)*sizeof(int*));
	if (!m) nrerror("allocation failure in convert_matrix()");
	m -= nrl;
	for(i=0,j=nrl;i<=nrow-1;i++,j++) m[j]=a+ncol*i-ncl;
	return m;
}







void 
free_convert_matrix (float **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}


void 
free_convert_dmatrix (double **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}


void 
free_convert_imatrix (int **b, TYPE_SIZE nrl, TYPE_SIZE nrh, TYPE_SIZE ncl, TYPE_SIZE nch)
{
	FREE_TYPE((char*) (b+nrl));
}

*/





