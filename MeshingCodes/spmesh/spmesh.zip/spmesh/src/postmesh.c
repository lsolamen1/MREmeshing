   
/*
  ************************************************************************
  *  postmesh.c : Postprocess befor output final mesh :                  *
  *               Different format output, rectifying mesh, rebuild      *
  *               bad qulity mesh ...                                    *
  *                                                                      *
  *  Qingyang Zhang                                Aug 19, 1995          *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include <malloc.h>



#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"
#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))


/*
** External Functions
*/
extern REAL sg_isp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
extern NODE_MTRL nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
                   BMeshElem **on_bdy_eptr);
extern int final_output_wpi (void);
extern long remove_hi_conn (MeshNode **msh_n_head, long *msh_num_node,
                   MeshElem **msh_l_head, long *msh_num_elem,
                   int max_adj);
extern long conv_node_ptr (MeshNode *head, MeshNode *node_ptr, long total_nodes);
extern int ray_tri_cross_conf (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type);
extern int random_shoot_full (double *st_pnt, double *ed_pnt);



/*
** Local Functions
*/
int set_elem_mtrl  (BMeshNode *bdy_n_head, long bdy_num_node,
                    BMeshElem *bdy_l_head, long bdy_num_elem,
                    MeshNode *msh_n_head, long msh_num_node,
                    MeshElem *msh_l_head, long msh_num_elem);
int clean_poor_elem  (MeshElem  **msh_l_head, long *msh_num_elem);
int rectify_mesh   (BMeshNode *bdy_n_head, long bdy_num_node,
                    BMeshElem *bdy_l_head, long bdy_num_elem,
                    MeshNode  **msh_n_head, long *msh_num_node,
                    MeshElem  **msh_l_head, long *msh_num_elem);
int final_output (int out_type);
int final_output_thayer (int type);
int intersect_bdy (REAL *d, REAL *e, REAL *inter_pt, int mtrl_code,
                   BMeshElem *bdy_l_head, long bdy_num_elem, BMeshElem **act_beptr);
int line_bdy (BMeshElem *beptr, REAL *d, REAL *e,  REAL *pnt);


int 
set_elem_mtrl_b  (BMeshNode *bdy_n_head, long bdy_num_node,
                BMeshElem *bdy_l_head, long bdy_num_elem,
                MeshNode  *msh_n_head, long msh_num_node,
                MeshElem  *msh_l_head, long msh_num_elem);


/* added by Ziji 8/19/99 */
int clean_collapsed_elem (MeshElem  *msh_elm, long *msh_num_elem);

/*
** Global Variables
*/
                                               
/* set material code for mesh element */
int 
set_elem_mtrl  (BMeshNode *bdy_n_head, long bdy_num_node,
                BMeshElem *bdy_l_head, long bdy_num_elem,
                MeshNode  *msh_n_head, long msh_num_node,
                MeshElem  *msh_l_head, long msh_num_elem)
{
  int  k, m, num_p, count, mtrl_in, mtrl_out, done_flag, bdy_flag;
  int  mtrl_1, mtrl_2, num_mtr_1, num_mtr_2, mtrl_weight;
  int  mtrl_priority[MAX_MTRL_NUM];
  long ii, kk;
  NODE_MTRL cen_mtrl;
  REAL     cen_pt[3], e[3];
  BMeshElem *bdy_patch_ptr;
  MeshElem *eptr;
  MeshNode **nnptr;

    /*  default priority is set as the largest mtrl code has the highest
        priority. it should be changed, and allow user to determine
    */
    for (k=0; k<MAX_MTRL_NUM; k++)    mtrl_priority[k] = k;

    for (ii=0, eptr=msh_l_head; ii<msh_num_elem; ii++, eptr=eptr->Next)
    {
        bdy_flag = done_flag = 0;
        switch (eptr->E_type)
        {
            case TET4:
                num_p = 4;
                nnptr = eptr->Elem.tet4.NodePtr;

#ifdef ISP_CENTRAL
                sg_isp(nnptr[0]->Coor, nnptr[1]->Coor, nnptr[2]->Coor,
                            nnptr[3]->Coor, cen_pt);
#else
                for (k=0; k<3; k++)
		        {
                    cen_pt[k] = 0;
                    for (m=0; m<num_p; m++)
                          cen_pt[k] += nnptr[m]->Coor[k];

                    cen_pt[k] /= (REAL)num_p;
		        }
#endif
                break;
            case HEX8:
                num_p = 8;
                nnptr = eptr->Elem.hex8.NodePtr;
                for (k=0; k<3; m++)
		        {
                    cen_pt[k] = 0;
                    for (m=0; m<num_p; m++)
                          cen_pt[k] += nnptr[k]->Coor[m];

                    cen_pt[k] /= (REAL)num_p;
		        }

                break;
            default:                           
                printf ("\nError...Unknown element type (%d)!\n",
                eptr->E_type);
                continue;
        }

        /* end node */

#ifdef RANDOM_VACTOR
        random_shoot_full (cen_pt, e);
#else
        e[X] = cen_pt[X] + 4.*(BDxmax - BDxmin);
        e[Y] = cen_pt[Y];
        e[Z] = cen_pt[Z];
#endif

        /* determin central point mtrl */
        cen_mtrl = nod_in_region (cen_pt, e, Bdy_elem_head_ptr,
                                  Bdy_elem, &bdy_patch_ptr);

        count = 0;
        for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
        for (k=0; k<num_p; k++)
        {
            if (nnptr[k]->Mtrl > BDY_NODE_CODE) 
            {   /* boundary node */
                bdy_flag++;
                mtrl_in  = nnptr[k]->Mtrl / MTRL_IN_CODE;
                mtrl_out = (nnptr[k]->Mtrl - MTRL_IN_CODE * mtrl_in) / MTRL_OUT_CODE; 
                if (mtrl_in < MAX_MTRL_NUM) Mtrl_code[mtrl_in]++;
                if (mtrl_out < MAX_MTRL_NUM) Mtrl_code[mtrl_out]++;
            }
            else
            {
                if (nnptr[k]->Mtrl < MAX_MTRL_NUM) 
                        Mtrl_code[nnptr[k]->Mtrl]++;
                else
                {
                    kk = nnptr[k]->Mtrl;
                    printf ("\nWrong Mtrl code: %ld!\n", kk);
                }
            }
        }
        
        /* check if the element belong to multi-region */
        for (k=0; k<MAX_MTRL_NUM; k++)
        {
            if (Mtrl_code[k])   count++;
        }

        if (count == 1)
        {  /* within single material region */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
               
                if (bdy_flag > 0)
                {
                    eptr->Mtrl_in = cen_mtrl;
                    done_flag = 1;
                }
                else if (Mtrl_code[k] == num_p)  
                {
                    eptr->Mtrl_in = k;
                    done_flag = 1;
                }
            }
            if (done_flag == 1)  continue;
            else
              printf ("\nUnable to determine Material code(*)!\n");
        }
        
        if (count < 3)
        {
            if (cen_mtrl <= BDY_NODE_CODE)
            {
                eptr->Mtrl_in = cen_mtrl;
                continue;
            }
        }
        
        if (count == 2) 
        {  /* within two material regions */
           mtrl_1 = mtrl_2 = num_mtr_1 = num_mtr_2 = 0;

           /* find material 1 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k])  
                {
                    mtrl_1 = k;
                    num_mtr_1 = Mtrl_code[k];
                }
            }

            /* find material 2 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k] && k != mtrl_1)  
                {
                    mtrl_2 = k;
                    num_mtr_2 = Mtrl_code[k];
                }
            }
           
            if (num_mtr_1 == 0 || num_mtr_2 == 0)
              printf ("\nWarning... in determine Mtrl code (2 materials)!\n");

            if (num_mtr_1 == num_mtr_2)
            {   
                if (num_p == TET4)
                {
                    /*  2/2 type for tets, need more check */
                    /* current set as take highest priority material 
                     it could be changed to do more checking as conforming
                     internal boundary to compare the moving distance of 
                     two sets of nodes which sit in different material regions
                    */
                    /* check central of the element */
                    if (mtrl_1 == cen_mtrl)      eptr->Mtrl_in = mtrl_1;
                    else if (mtrl_2 == cen_mtrl) eptr->Mtrl_in = mtrl_2;
                    else
                    {
                        mtrl_1 = mtrl_weight = 0; 
                        for (k=0; k<MAX_MTRL_NUM; k++)
                        {
                            if (Mtrl_code[k])  
                            {
                                if (mtrl_priority[k] > mtrl_weight)
                                { 
                                    mtrl_1 = k;
                                    mtrl_weight = mtrl_priority[k];
                                }
                            }
                        }
                        eptr->Mtrl_in = mtrl_1;
                    }
                }
                else
                {
                    /* take highest priority material */
                    mtrl_1 = mtrl_weight = 0; 
                    for (k=0; k<MAX_MTRL_NUM; k++)
                    {
                        if (Mtrl_code[k])  
                        {
                            if (mtrl_priority[k] > mtrl_weight)
                            { 
                                mtrl_1 = k;
                                mtrl_weight = mtrl_priority[k];
                            }
                        }
                    }
                    eptr->Mtrl_in = mtrl_1;
                }
            }
            else if (num_mtr_1 > num_mtr_2)
            {
                /*  if (mtrl_1 != 0) */
                    eptr->Mtrl_in = mtrl_1;
            }
            else
            {  
                eptr->Mtrl_in = mtrl_2;
            }
               
        } 
        else if (count == 3 || count == 4)
        {
            /* take highest priority */
            mtrl_1 = mtrl_weight = 0; 
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k])  
                {
                    if (mtrl_priority[k] > mtrl_weight)
                    { 
                        mtrl_1 = k;
                        mtrl_weight = mtrl_priority[k];
                    }
                }
            }
            eptr->Mtrl_in = mtrl_1;
        }
        else
         printf ("\nUnable to determine Material code: %d!\n", count);    
    }

    return (OK);
}




/* clean poor mesh element */
int 
clean_poor_elem  (MeshElem  **msh_l_head, long *msh_num_elem)
{
  long ii, n_tmp_elem, num_zero_elem=0, num_bad_elem=0;
  int  k, num_p;
  MeshNode **nnptr;
  MeshElem *eptr, *tmp_l_head, *tmp_next;
  AdjElem  *aeptr, *prev_aeptr;

  n_tmp_elem = *msh_num_elem;
  tmp_l_head = *msh_l_head;

  eptr = tmp_l_head;
  for (ii=0; ii<(*msh_num_elem); ii++)
  {
      
      /* save the pointer to next element */
      tmp_next = eptr->Next;
      /* check zero elements */

      if (eptr->Quli.Qfactor < HIGTOL || eptr->Quli.Jmin < HIGTOL || eptr->Quli.Asp < HIGTOL || eptr->Mtrl_in == 0)
      {  /* bad element which will crash the system */
         if (eptr->Mtrl_in == 0)   num_zero_elem++;
         else                      num_bad_elem++;

         switch (eptr->E_type)
         {  
            case TET4:
                num_p = 4;
                nnptr = eptr->Elem.tet4.NodePtr;
                break;
            case PYRAM5:
                num_p = 5;
                nnptr = eptr->Elem.pyr5.NodePtr;
                break;
            case PRISM6:
                num_p = 6;
                nnptr = eptr->Elem.prm6.NodePtr;
                break;
            case HEX8:
                num_p = 8;
                nnptr = eptr->Elem.hex8.NodePtr;
                break;
            case TRI6:
                num_p = 6;
                nnptr = eptr->Elem.tri6.NodePtr;
                break;
            default:
                num_p = -1;
                printf ("\nError...Unknown element type!\n");
                return (BAD);
        }

        /* relink before kill the elem. */
        if (eptr == tmp_l_head)
        {   /* current elem. is head elem. */
            if (eptr->Next == NULL && eptr->Prev == NULL)
            {  /* the only element in the elem. list */
                 if (n_tmp_elem == 1)
                     tmp_l_head = NULL;
                 else 
                   printf ("\nError... Elem. number not compatible [1] : %8d;"
                              , n_tmp_elem);
            }
            else if (eptr->Next == eptr->Prev)
            {  /* only two (include head itself) elem. left in the list */
                if (n_tmp_elem == 2)
                {
                     tmp_l_head = eptr->Next;
                     tmp_l_head->Next = tmp_l_head->Prev = NULL;
                }
                else 
                   printf ("\nError... Elem. number not compatible [2] : %8d;"
                              , n_tmp_elem);
            }
            else
            {
                tmp_l_head = eptr->Next;
                tmp_l_head->Prev = eptr->Prev;
                eptr->Prev->Next = tmp_l_head;
            }
        }
        else if (eptr == tmp_l_head->Prev)
        {  /* last elem. in the list */
            eptr->Prev->Next = tmp_l_head;
            tmp_l_head->Prev = eptr->Prev;
        }
        else
        {
            eptr->Prev->Next = eptr->Next;
            eptr->Next->Prev = eptr->Prev;
        }

        /* eliminate the associated component in node-element list */
        for (k=0; k<num_p; k++)
        {
            prev_aeptr = aeptr = nnptr[k]->Fst_adj_elem;
            if (nnptr[k]->Num_adj_elem == 0)
            {
                printf ("\nWarning...Wrong adj_elem list!\n");
            }
            else
            {
                do
                {
                    if (eptr == aeptr->idx) 
                    {
                        /*
                        if (aeptr->ptr == NULL)
                        {   the last element in the list 
                            prev_aeptr->ptr == NULL;
                        }
                        */
                        if (prev_aeptr == aeptr)
                        {  /* the first element in the list */
                            nnptr[k]->Fst_adj_elem = aeptr->ptr;
                        } 
                        else
                        {
                            prev_aeptr->ptr = aeptr->ptr;
                        }  
                        free ((char *) aeptr);
                        (nnptr[k]->Num_adj_elem)--;
                        aeptr = prev_aeptr;
                        break;
                    }
                    prev_aeptr = aeptr;
                    aeptr = aeptr->ptr;
                } while (aeptr);
            }
        
        }

        free ((char *)eptr);
        n_tmp_elem--;

      }
      eptr = tmp_next;
  }

  /* change global */
  *msh_num_elem = n_tmp_elem;
  *msh_l_head   = tmp_l_head;

  /* do it again for sharp element */


  printf ("\nNum. of elem. outbound being removed: %ld\n", num_zero_elem);
  printf ("Num. of bad elem. being removed     : %ld\n", num_bad_elem);
  return (OK);
}



/* clean collapsed mesh element 
   added by Ziji Wu, 8/19/99
  */
int 
clean_collapsed_elem (MeshElem  *msh_elm, long *msh_num_elem)
{
  long n_tmp_elem;
  int  k, num_p;
  MeshNode **nnptr;
  MeshElem *eptr, *tmp_next;
  AdjElem  *aeptr, *prev_aeptr;

  n_tmp_elem = *msh_num_elem;
  eptr = msh_elm;
  /* save the pointer to next element */
  tmp_next = eptr->Next;
  num_p = 4;
  nnptr = eptr->Elem.tet4.NodePtr;

  /* relink before kill the elem. */
  if (eptr->Next == NULL && eptr->Prev == NULL)
  {  /* the only element in the elem. list */
  }
  else if (eptr->Prev == NULL)
  {  /* first elem. in the list */
     eptr->Next->Prev = NULL;
  }
  else if (eptr->Next == NULL)
  {  /* last elem. in the list */
     eptr->Prev->Next = NULL;
  }
  else
  {
	  eptr->Prev->Next = eptr->Next;
	  eptr->Next->Prev = eptr->Prev;
  }

  /* eliminate the associated component in node-element list */
  for (k=0; k<num_p; k++)
  {
	  prev_aeptr = aeptr = nnptr[k]->Fst_adj_elem;
      if (nnptr[k]->Num_adj_elem != 0)
      {
          do
          {
			  if (eptr == aeptr->idx) 
              {
				  if (prev_aeptr == aeptr)
                  {  /* the first element in the list */
					  nnptr[k]->Fst_adj_elem = aeptr->ptr;
                  } 
                  else
                  {
                      prev_aeptr->ptr = aeptr->ptr;
                  }  
                  free ((char *) aeptr);
                  (nnptr[k]->Num_adj_elem)--;
                  aeptr = prev_aeptr;
                  break;
               }
               prev_aeptr = aeptr;
               aeptr = aeptr->ptr;
           } while (aeptr);
	  }
  }

  free ((char *)eptr);
  n_tmp_elem--;

  /* change global */
  *msh_num_elem = n_tmp_elem;

  return (OK);
}





/* rectify poor mesh: to take care the tet. elem. with two nodes
    on the boundary and one node inbound and one node outbound
*/
int 
rectify_mesh   (BMeshNode *bdy_n_head, long bdy_num_node,
                BMeshElem *bdy_l_head, long bdy_num_elem,
                MeshNode  **msh_n_head, long *msh_num_node,
                MeshElem  **msh_l_head, long *msh_num_elem)
{
    int         k, m_code, count, inbound_idx, outbound_idx;
    long        ii, num_elem, num_rectify=0;  
    REAL        d[3], e[3], inter_pt[3], quli;
    BMeshElem   *act_beptr;
    MeshNode    **nnptr;
    MeshElem    *eptr;

    num_elem = *msh_num_elem;
    for (ii=0, eptr=*msh_l_head; ii < num_elem; ii++, eptr=eptr->Next)
    {
        if (eptr->E_type != TET4)           continue;
        nnptr = eptr->Elem.tet4.NodePtr;

        inbound_idx = outbound_idx = -1;
        count = 0;

        for (k=0; k<4; k++)
        {
            if (nnptr[k]->Mtrl == 0)    
                outbound_idx = k;
            else if (nnptr[k]->Mtrl < MAX_MTRL_NUM && nnptr[k]->Mtrl != 0)
                inbound_idx = k;
            else if (nnptr[k]->Mtrl > BDY_NODE_CODE)
                count++;
        }

        if (count != 2 || outbound_idx == -1)    continue;
        else if (inbound_idx == -1)
        {
            /*
            printf ("\nOdd elem. in rectify_mesh.(%d, %d, %d, %d)\n",
                nnptr[0]->Mtrl,nnptr[1]->Mtrl,nnptr[2]->Mtrl,nnptr[3]->Mtrl);
            */
            continue;
        }

        /* find intersection point */
        for (k=0; k<3; k++)
        {
            d[k] = nnptr[inbound_idx]->Coor[k];
            e[k] = nnptr[outbound_idx]->Coor[k];
        }
        
        m_code = nnptr[inbound_idx]->Mtrl; 
        if (intersect_bdy (d, e, inter_pt, m_code, bdy_l_head, 
                           bdy_num_elem, &act_beptr) == BAD)  
            continue;
        
        /* move outbound node to intersection point */
        for (k=0; k<3; k++)
            nnptr[outbound_idx]->Coor[k] = inter_pt[k];

        /* check mesh quality (count it !!) */
        if (avg_quli (nnptr[outbound_idx], &quli, VOLRAT) > LOWTOL) /* min_jacob */
        {
            if (quli > 0.1 * MIN_QUALITY)
            {   
                /* good move */
                nnptr[outbound_idx]->Mtrl = 
                    act_beptr->Mtrl_in * MTRL_IN_CODE + act_beptr->Mtrl_out * MTRL_OUT_CODE;
                num_rectify++;
                continue;
            }
        }
        /* restore original coord. */
        for (k=0; k<3; k++)
            nnptr[outbound_idx]->Coor[k] = e[k];
    }

    printf ("\n%ld mesh nodes adjusted\n", num_rectify);
    /*
    int  max_adj = 36;
    long num_hi_conn;

    // Carve out high connective mesh nodes and re-generate local mesh 
    
    printf ("\nDefine High Connectivity (Num. of Elem. conn. to a node [24-48]) : ");
    scanf ("%d", &max_adj);
    if (max_adj < 12)    max_adj = 24;

    num_hi_conn = remove_hi_conn (msh_n_head, msh_num_node, msh_l_head, msh_num_elem, max_adj);
    
    printf ("\nNumber of hi-conn node being carved out: %ld\n", num_hi_conn);
    */
  return (OK);
}












/* create output files in user selected format */
int 
final_output (int out_type)
{
    int         f_fmt, status;
    long        ii;
    MeshNode    *nptr, **nnptr;
    MeshElem    *eptr;


    /* since a non-isolated node at least has one adj. node
       to accelerated the output, borrow the wt field of 
       first adj node structure to save a node index and note
       the idx needs long type but wt is a double type. use
       forced type convertion and this should not lose anything
    */
    for (ii=0, nptr=Msh_node_head_ptr; ii<Msh_nodes; ii++, nptr=nptr->Next)
    {
        if (nptr->Fst_adj == NULL)
            printf ("\nNull Adj. node list at node %ld\n", ii+1);
        else
            nptr->Fst_adj->wt = (double)(ii+1);
    }
    
    /* here borrow quality field to save mesh node indices to make sure 
       all the elem. related info. are saved in associated space
       this is the last effort to accelate the write file only good for 
       tet4 elem.
    */
    for (ii=0, eptr=Msh_elem_head_ptr; ii<Msh_elem; ii++, eptr=eptr->Next)
    {
        nnptr = eptr->Elem.tet4.NodePtr;
        eptr->Quli.Volumn = nnptr[0]->Fst_adj->wt;  /* node 0 */
        eptr->Quli.Jmin   = nnptr[1]->Fst_adj->wt;  /* node 1 */
        eptr->Quli.Skew   = nnptr[2]->Fst_adj->wt;  /* node 2 */
        eptr->Quli.Warp   = nnptr[3]->Fst_adj->wt;  /* node 3 */
    }
    
    if (out_type == NUMER_OUT)
    {
        f_fmt = 1;
    }
    else
    {
        printf ("\nNeed output ? (1=yes / 0=No): ");
        scanf ("%d", &status);
        if (status != 1)
            return (status);

        printf ("\nOutput file format (WPI: 0/ Thayer: 1): " );
        scanf  ("%d", &f_fmt);
    }

    if (f_fmt == 1)     return (final_output_thayer (out_type));
    else                return (final_output_wpi ());
}
                   



/* create output files in Thayer format  */
int 
final_output_thayer (int type)
{
    char fout_name[80], nod_name[80], elm_name[80], open_type[4]="w+t";
    int  k, num_p, f_type,left_sign;
    long ii, e1, e2, e3, e4, kk, num_interval=10000;
    REAL xx, yy, zz;
    REAL fxx, fyy, fzz;
    FILE *fout; 
    MeshNode **nnptr;

    if (type == NUMER_OUT)
    {
        left_sign   = 1;
        f_type      = 0;
        strcpy (nod_name, "volmesh.nod");
        strcpy (elm_name, "volmesh.elm");
    }
    else
    {
        printf ("\nElem. numbering convension (Right Hand Rule(normal in)=0/Left Hand Rule(normal out)=1 : ");
        scanf ("%d", &left_sign);

        printf ("\nFile Type (Ascii: 0 | Binary: 1) : ");
        scanf  ("%d", &f_type);
        if (f_type != 1)      f_type = 0;
        if (f_type)           open_type[2] = 'b';
    
        printf ("\nOutput file name (without file extension! default as .nod and .elm) : ");
        scanf  ("%s", fout_name);

        strcpy (nod_name, fout_name);
        strcat (nod_name, ".nod");
    
        strcpy (elm_name, fout_name);
        strcat (elm_name, ".elm");
    }

    /* output mesh node list */
    if ((fout = fopen (nod_name, open_type)) == NULL)
    {
        printf ("\nCan't open output file : %s\n", nod_name);
        return (BAD);
    }


    if (f_type == 0)
    { /* ASCII format */
        fprintf (fout, "1     %ld\n", Msh_nodes);

        Msh_node_curt_ptr = Msh_node_head_ptr;
        for (ii=0; ii<Msh_nodes; ii++)
        {
            xx = Msh_node_curt_ptr->Coor[X];
            yy = Msh_node_curt_ptr->Coor[Y];
            zz = Msh_node_curt_ptr->Coor[Z];
            fprintf (fout, "%8ld%12.6lf %12.6lf %12.6lf\n", ii+1,
                        xx, yy, zz);
            Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
        }
    }
    else
    {   /* binary format */
        k = 1;    
        /* dummy for Thayer format: there are two dummies in node file header*/
        fwrite (&k, sizeof (k), 1, fout);
/* Ziji 12/17/98        fwrite (&k, sizeof (k), 1, fout); */
        fwrite (&Msh_nodes, sizeof (Msh_nodes), 1, fout); /* long integer ?? */

        Msh_node_curt_ptr = Msh_node_head_ptr;
        for (ii=0; ii<Msh_nodes; ii++)
        {
            /* two dummies to match Thayer format */
            fwrite (&k, sizeof (k), 1, fout); 
/* Ziji 12/17/98            fwrite (&k, sizeof (k), 1, fout); */

            fxx = Msh_node_curt_ptr->Coor[X];
            fyy = Msh_node_curt_ptr->Coor[Y];
            fzz = Msh_node_curt_ptr->Coor[Z];
            fwrite (&fxx, sizeof (fxx), 1, fout);
            fwrite (&fyy, sizeof (fyy), 1, fout);
            fwrite (&fzz, sizeof (fzz), 1, fout);
            Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
        }
    }
    fclose (fout);

    /* output mesh element list */
    if ((fout = fopen (elm_name, open_type)) == NULL)
    {
        printf ("\nCan't open output file : %s\n", elm_name);
        return (BAD);
    }
    if (f_type == 0)
    { /* ASCII format */
        fprintf (fout, "1    4     1    %ld\n", Msh_elem);

        /* default as include output material code! (give user an option?)*/
        Msh_elem_curt_ptr = Msh_elem_head_ptr;
        for (ii=0; ii<Msh_elem; ii++)
        {
	        if (!imod (ii, num_interval))
	        {
	            printf ("%ld elem. saved!\n", ii);
	        }
            switch (Msh_elem_curt_ptr->E_type)
            {
                case TET4:
                    num_p = 4;
                    nnptr = Msh_elem_curt_ptr->Elem.tet4.NodePtr;
                    break;
                default:
                    num_p = -1;
                    printf ("\nError...Unknown element type!\n");
                    return (BAD);
            }

            /* read in elem. node list and convert to MeshNode ptr. */
            e1 = (long)(Msh_elem_curt_ptr->Quli.Volumn);  /* (nnptr[0]->Fst_adj->wt); */
            e2 = (long)(Msh_elem_curt_ptr->Quli.Jmin);    /* (nnptr[1]->Fst_adj->wt); */
            e3 = (long)(Msh_elem_curt_ptr->Quli.Skew);    /* (nnptr[2]->Fst_adj->wt); */
            e4 = (long)(Msh_elem_curt_ptr->Quli.Warp);    /* (nnptr[3]->Fst_adj->wt); */
            if (num_p == 4 && left_sign==1)
            {
                fprintf (fout, "%8ld %10ld %10ld %10ld %10ld %8d\n", 
                    ii+1, e1, e3, e2, e4, Msh_elem_curt_ptr->Mtrl_in);
            }
            else
            {
                fprintf (fout, "%8ld %10ld %10ld %10ld %10ld %8d\n", 
                    ii+1, e1, e2, e3, e4, Msh_elem_curt_ptr->Mtrl_in);
            }
            Msh_elem_curt_ptr = Msh_elem_curt_ptr->Next;
        }
  }
  else
  {   /* binary format */
    
      /* dummy for Thayer format? Thayer did not deinfe binary format for bounary
       connectivity file. Does it need two dummies in  header ?
      */
      k = 1;
      fwrite (&k, sizeof (k), 1, fout);
      k = 4;
      fwrite (&k, sizeof (k), 1, fout);
      k = 1;
      fwrite (&k, sizeof (k), 1, fout);
      fwrite (&Msh_elem, sizeof (Msh_elem), 1, fout); /* it's a long interge */

      /* default as include output material code! (give user an option?)*/
      Msh_elem_curt_ptr = Msh_elem_head_ptr;
      for (ii=0; ii<Msh_elem; ii++)
      {
	    if (!imod (ii, num_interval))
	    {
	            printf ("%ld elem. saved!\n", ii);
	    }
        switch (Msh_elem_curt_ptr->E_type)
        {
            case TET4:
                num_p = 4;
                nnptr = Msh_elem_curt_ptr->Elem.tet4.NodePtr;
                break;
            default:
                num_p = -1;
                printf ("\nError...Unknown element type!\n");
                return (BAD);
        }

        kk = ii+1;
        fwrite (&kk, sizeof (kk), 1, fout);

        /* read in elem. node list and convert to MeshNode ptr. */
        e1 = (long)(Msh_elem_curt_ptr->Quli.Volumn);  /* (nnptr[0]->Fst_adj->wt); */
        e2 = (long)(Msh_elem_curt_ptr->Quli.Jmin);    /* (nnptr[1]->Fst_adj->wt); */
        e3 = (long)(Msh_elem_curt_ptr->Quli.Skew);    /* (nnptr[2]->Fst_adj->wt); */
        e4 = (long)(Msh_elem_curt_ptr->Quli.Warp);    /* (nnptr[3]->Fst_adj->wt); */
        if (num_p == 4 && left_sign==1)
        {
            fwrite (&e1, sizeof (e1), 1, fout);
            fwrite (&e3, sizeof (e3), 1, fout);
            fwrite (&e2, sizeof (e2), 1, fout);
            fwrite (&e4, sizeof (e4), 1, fout);
        }
        else
        {
            fwrite (&e1, sizeof (e1), 1, fout);
            fwrite (&e2, sizeof (e3), 1, fout);
            fwrite (&e3, sizeof (e2), 1, fout);
            fwrite (&e4, sizeof (e4), 1, fout);
        }

        fwrite (&(Msh_elem_curt_ptr->Mtrl_in), 
                 sizeof (Msh_elem_curt_ptr->Mtrl_in), 1, fout);

        Msh_elem_curt_ptr = Msh_elem_curt_ptr->Next;
      }
  }

  fclose (fout);

/* Ziji Wu, 8/23/99 */
  printf ("%ld elem. saved!\n", Msh_elem);

  /* write to control file for numerical mesh */
  if (Numerical_surf == 1 && type == NUMER_OUT)
  {
        fprintf (Main_file, "%s\n", nod_name);
        fprintf (Main_file, "%s\n", elm_name);
  }
  return (OK);

}



                                               
/* set material code for mesh element */
/* for both tet and brick element use nine point testing to determine
    the material for the element. It should reliable to handle the elem.
    cross two material and probably can handle the element cross three 
    material. Note that the last point is central point.
*/
int 
set_elem_mtrl_b  (BMeshNode *bdy_n_head, long bdy_num_node,
                BMeshElem *bdy_l_head, long bdy_num_elem,
                MeshNode  *msh_n_head, long msh_num_node,
                MeshElem  *msh_l_head, long msh_num_elem)
{
  int  j, k, m, num_p, count, done_flag;
  int  num_mtr_1, num_mtr_2, num_mtr_3, mtrl_weight, cur_num; 
  int  mtrl_1, mtrl_2, mtrl_3, cur_mtrl, mtrl_in, mtrl_out;
  int  mtrl_priority[MAX_MTRL_NUM];
  // int  idx1, idx2;
  long ii;      //   l0, l1, l2, l3, l4, l5
  NODE_MTRL p_mtrl[9];      // intf_code[4], intf_tmp;    
  REAL     cen_pt[3], e[3], pt[9][3], sum;
  BMeshElem *bdy_patch_ptr;
  MeshElem *eptr;
  MeshNode **nnptr, *nptr;
  AdjElem  *aeptr;

  // int izw;


    /*  default priority is set as the largest mtrl code has the highest
        priority. it should be changed, and allow user to determine
    */
    for (k=0; k<MAX_MTRL_NUM; k++)    mtrl_priority[k] = k;

    eptr = msh_l_head;
    for (ii=0; ii<msh_num_elem; ii++)
    {
        done_flag = 0;
        switch (eptr->E_type)
        {
            case TET4:
                num_p = 4;
                nnptr = eptr->Elem.tet4.NodePtr; 
                /* corner nodes */
                for (k=0; k<4; k++) 
                    for (m=0; m<3; m++)
                        pt[k][m] = nnptr[k]->Coor[m];
                /* central point */
#ifdef ISP_CENTRAL                 
                sg_csp (nnptr[0]->Coor, nnptr[1]->Coor, nnptr[2]->Coor,
                        nnptr[3]->Coor, cen_pt, sum);
                for (m=0; m<3; m++)     pt[8][m] = cen_pt[m];
#else
                for (m=0; m<3; m++)
		        {
                     pt[8][m] = 0.;
                     for (k=0; k<4; k++)
                           pt[8][m] += nnptr[k]->Coor[m];

                     pt[8][m] /= 4;
		        }
#endif
                /* Pass corner nodes' mtrl */
                for (k=0; k<4; k++)    p_mtrl[k] = nnptr[k]->Mtrl;

                /* find central point mtrl */
#ifdef RANDOM_VACTOR
                random_shoot_full (pt[8], e);
#else
                e[X] = pt[8][X] + 4.*(BDxmax - BDxmin);
                e[Y] = pt[8][Y];
                e[Z] = pt[8][Z];
#endif

                for (m=0; m<3; m++)     cen_pt[m] = pt[8][m];
                if ((p_mtrl[8] = nod_in_region (cen_pt, e, 
                        Bdy_elem_head_ptr, Bdy_elem, &bdy_patch_ptr)) == -1)
                {
                    fprintf (Diag_file, "negative mtrl code\n");
		        }

                break;
            case HEX8:
                num_p = 8;
                nnptr = eptr->Elem.hex8.NodePtr;
                /* corner nodes */
                for (k=0; k<8; k++) 
                    for (m=0; m<3; m++)
                        pt[k][m] = nnptr[k]->Coor[m];
                
                /* central point */
                for (m=0; m<3; m++) 
                {   
                    sum = 0;
                    for (k=0; k<8; k++)   sum += pt[k][m];
                    pt[8][m] = sum / 8.;
                }
                /* classify point mtrl */  
                for (k=0; k<8; k++)    p_mtrl[k] = nnptr[k]->Mtrl;

#ifdef RANDOM_VACTOR
                random_shoot_full (pt[8], e);
#else           
                e[X] = pt[8][X] + 4.*(BDxmax - BDxmin);
                e[Y] = pt[8][Y];
                e[Z] = pt[8][Z];
#endif

                /* determin where node in */
                for (m=0; m<3; m++)     cen_pt[m] = pt[8][m];
                p_mtrl[8] = nod_in_region (cen_pt, e, Bdy_elem_head_ptr,
                                            Bdy_elem, &bdy_patch_ptr);
                break;
            default:                           
                fprintf (Diag_file, "\nError...Unknown element type (%d)!\n",
                            eptr->E_type);
                goto CON;
        }
        
        /* checking for special cases first: 
        a) four corner nodes on bdy determine by center node 
           (for the elem. ride on bdy but the volumn in 0 or...)
        b) three corner nodes on bdy one node in 0 or ... check center
           and the other corner.
        c) all four nodes in one mtrl. region.
        */
        if (p_mtrl[8] == 0)
        {   /* clean the elem. cross external bound */
            eptr->Mtrl_in = 0;
            goto CON;
        }

        count   = 0;
        cur_num = 0;
        for (k=0; k<4; k++)
        {
            /* here need to know if all the bdy nodes on same bdy interface */
            if (p_mtrl[k] > BDY_NODE_CODE)  count++;
            else
            {
                cur_num++;
                if (k == 0)                     mtrl_in  = mtrl_out = p_mtrl[k];
                else if (mtrl_in != p_mtrl[k])  mtrl_out = p_mtrl[k];
            }

            /* check sharp elem. on external bound */
            if (p_mtrl[k] == 0)
            {
                if (nnptr[k]->Num_adj_elem < 4 /*?? == 1*/)
                {
                    /* sharp elem. set in outside mtrl */
                    eptr->Mtrl_in = 0;
                    goto CON;
                }
            }
        }

        if (cur_num == num_p && mtrl_in == mtrl_out)
        {
            /* all nodes are inside the same mtrl region */
            if (mtrl_in == p_mtrl[8])
            {
                eptr->Mtrl_in = p_mtrl[8];
                goto CON;
            }
        }

        /*
        if (count == 4)   
        {
            eptr->Mtrl_in = p_mtrl[8];
            goto CON;
        }
        else if (count == 3)
        {
            // check how many interfaces are site on 
            cur_num = 0;
            for (k=0; k<4; k++)
            {
                if (p_mtrl[k] > BDY_NODE_CODE)
                {
                    // because left/right side mtrl can swap 
                    //   so make a deal and put small num. as left
                    //   for easy to compare!
                    
                    mtrl_in  = p_mtrl[k] / MTRL_IN_CODE;
                    mtrl_out = (p_mtrl[k] - MTRL_IN_CODE * mtrl_in) / MTRL_OUT_CODE; 
                    intf_tmp = (mtrl_in<mtrl_out) ? 
                        mtrl_in *MTRL_IN_CODE+mtrl_out*MTRL_OUT_CODE :
                        mtrl_out*MTRL_IN_CODE+mtrl_in *MTRL_OUT_CODE;

                    done_flag = 0;
                    for (m=0; m<cur_num; m++)
                    {
                        if (intf_code[m] == intf_tmp) 
                            done_flag = 1;
                    }
                    if (!done_flag)
                        intf_code[cur_num++] = intf_tmp;
                }
            }

            if (cur_num > 1)
            {
                // it could be more elegent ! 
                eptr->Mtrl_in = p_mtrl[8];
                // &&& 
                //l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1]; l3 = p_mtrl[2]; l4 = p_mtrl[3];
                //fprintf (Diag_file, "\nThree Nodes on more than one BDY Take center (%ld) %ld %ld %ld %ld\n",
                //                l0, l1, l2, l3, l4);
                goto CON;
            }
            for (k=0; k<4; k++)
            {
                if (p_mtrl[k] <= BDY_NODE_CODE)
                {
                    if (p_mtrl[k] == p_mtrl[8])
                    {
                        eptr->Mtrl_in = p_mtrl[k]; 
                        // &&& 
                        //l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1]; l3 = p_mtrl[2]; l4 = p_mtrl[3];
                        //fprintf (Diag_file, "\nThree Nodes on same BDY Take center (%ld) %ld %ld %ld %ld\n",
                        //        l0, l1, l2, l3, l4);
                        
                    }
                    else
                    {
                        // take common mtrl !! 
                        // eptr->Mtrl_in = p_mtrl[k]; 
                        // eptr->Mtrl_in = p_mtrl[8];
                        // &&& 
                        //l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1]; l3 = p_mtrl[2]; l4 = p_mtrl[3];
                        //fprintf (Diag_file, "\nThree Nodes on same BDY II-force (%ld) %ld %ld %ld %ld\n",
                        //        l0, l1, l2, l3, l4);
                                               
                    }
                    goto CON;
                }
            }
        }
        else if (count == 2)
        {
            for (k=0; k<4; k++)
            {
                if (p_mtrl[k] <= BDY_NODE_CODE)
                {
                    idx1 = k;
                    break;
                }
            }
            for (k=0; k<4; k++)
            {
                if (p_mtrl[k] <= BDY_NODE_CODE && k != idx1)
                {
                    idx2 = k;
                    if (p_mtrl[idx1] == p_mtrl[idx2])
                    {
                        // take over it as the elem. mtrl 
                        eptr->Mtrl_in = p_mtrl[idx1];
                        // &&& 
                        //l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1]; l3 = p_mtrl[2]; l4 = p_mtrl[3];
                        //fprintf (Diag_file, "\nTwo Nodes on BDY  (%ld) %ld %ld %ld %ld\n",
                                l0, l1, l2, l3, l4);
                    
                        goto CON;
                    }
                }
            }

            l0 = -1;
            for (k=0; k<4; k++)
            {
               
                if (p_mtrl[k] > BDY_NODE_CODE)
                {
                    if (l0 == -1)               l0 = p_mtrl[k];
                    else if (l0 == p_mtrl[k])   continue;
                    else
                    {
                       eptr->Mtrl_in = p_mtrl[8];
                       // &&& 
                       //l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1]; l3 = p_mtrl[2]; l4 = p_mtrl[3];
                       //fprintf (Diag_file, "\nTwo Nodes on different BDY  (%ld) %ld %ld %ld %ld\n",
                       //         l0, l1, l2, l3, l4);
                       
                       goto CON;
                    }
                }
            }

        }
        */
        /* find mtrl for middle points of tet. elem. */
        if (eptr->E_type == TET4) 
        {
            /* extra middle points */
            for (k=0; k<4; k++)
            {
                for (m=0; m<3; m++)     
                {
                    /* pt[4+k][m] = 0.5 * (pt[k][m] + pt[8][m]);*/
                    pt[4+k][m] = pt[k][m] + 0.25 * (pt[8][m] - pt[k][m]);
                } 
            }
            /* classify point mtrl */  
            for (k=4; k<8; k++)
            {
#ifdef RANDOM_VACTOR
                random_shoot_full (pt[k], e);
#else
                e[X] = pt[k][X] + 4.*(BDxmax - BDxmin);
                e[Y] = pt[k][Y];
                e[Z] = pt[k][Z];
#endif

                /* determin where node in */ 
                for (m=0; m<3; m++)     cen_pt[m] = pt[k][m];
                if ((p_mtrl[k] = nod_in_region (cen_pt, e, 
                        Bdy_elem_head_ptr, Bdy_elem, &bdy_patch_ptr)) == -1)
                {
                    fprintf (Diag_file, "negative mtrl code (sub_mid)\n");
		        }
            }
        }
        
        done_flag =0;
        count = 0;
        for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;  
         
/*        for (k=0; k<9; k++)  /* nine point scheme */
        for (k=4; k<9; k++)     /* five points */
        {

            if (p_mtrl[k] > BDY_NODE_CODE) 
            {   /* boundary node */
                /* printf ("\nNode on BDY Mtrl = %ld\n", kk=p_mtrl[k]);*/
                mtrl_in  = p_mtrl[k] / MTRL_IN_CODE;
                mtrl_out = (p_mtrl[k] - MTRL_IN_CODE * mtrl_in) / MTRL_OUT_CODE; 
                if (mtrl_in < MAX_MTRL_NUM) Mtrl_code[mtrl_in]++;
                if (mtrl_out < MAX_MTRL_NUM) Mtrl_code[mtrl_out]++;
            }
            else
                if (p_mtrl[k] < MAX_MTRL_NUM) Mtrl_code[p_mtrl[k]]++;
        }

        /* check if the element belong to multi-region */
        for (k=0; k<MAX_MTRL_NUM; k++)
        {
            if (Mtrl_code[k])   count++;
        }

        if (count == 1)
        {  /* within single material region */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                /* if (Mtrl_code[k] == 9)  */
                if (Mtrl_code[k] == 5)  
		        {
		            eptr->Mtrl_in = k;
		            done_flag = 1;
		        }
	        }
            if (done_flag == 0)  
              fprintf (Diag_file, "\nUnable to determine Material code(*)!\n");
            else
            {
                ;
                /*
                l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1], l3 = p_mtrl[2]; l4 = p_mtrl[3];
                fprintf (Diag_file, "\nIn One-region (special-- should not happen):  (%ld) %ld %ld %ld %ld\n",
                                l0, l1, l2, l3, l4);
                */
            }
        }
        else if (count == 2) 
        {  /* within two material regions */
           mtrl_1 = mtrl_2 = num_mtr_1 = num_mtr_2 = 0;

           /* find material 1 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k])  
                {
                    mtrl_1 = k;
                    num_mtr_1 = Mtrl_code[k];
                }                                      
            }

            /* find material 2 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k] && k != mtrl_1)  
                {
                    mtrl_2 = k;
                    num_mtr_2 = Mtrl_code[k];
                }
            }
           
            if (num_mtr_1 == 0 || num_mtr_2 == 0)
              fprintf (Diag_file, "\nWarning... in determine Mtrl code (2 materials)!\n");

            if (num_mtr_1 == num_mtr_2)
            {   
                /* printf ("\nEqual nodes in region!\n"); */
                if (mtrl_1 == p_mtrl[8])      eptr->Mtrl_in = mtrl_1;
                else if (mtrl_2 == p_mtrl[8]) eptr->Mtrl_in = mtrl_2;
                else
                {
                    mtrl_1 = mtrl_weight = 0; 
                    for (k=0; k<MAX_MTRL_NUM; k++)
                    {
                        if (Mtrl_code[k])  
                        {
                             if (mtrl_priority[k] > mtrl_weight)
                             { 
                                    mtrl_1 = k;
                                    mtrl_weight = mtrl_priority[k];
                             }
                        }
                    }
                    eptr->Mtrl_in = mtrl_1;
                }
            }
            else if (num_mtr_1 > num_mtr_2)
            {
                eptr->Mtrl_in = mtrl_1;
            }
            else
            {  
                eptr->Mtrl_in = mtrl_2;
            }
            /* &&& 
            l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1], l3 = p_mtrl[2]; l4 = p_mtrl[3];
            fprintf (Diag_file, "\nIn Two-regions (mtr_1=%d <==> mtrl_2=%d):  (%ld) %ld %ld %ld %ld\n",
                                num_mtr_1, num_mtr_2, l0, l1, l2, l3, l4);
            */
               
        }
        else if (count == 3)
        {  
           eptr->Mtrl_in = p_mtrl[8];
           /* &&& 
           l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1], l3 = p_mtrl[2]; l4 = p_mtrl[3];
           fprintf (Diag_file, "\nIn three-regions: Take center III (%ld) %ld %ld %ld %ld\n",
                                l0, l1, l2, l3, l4);
           */
           goto CON; /* debug short cut!! */
           
           
           /* within three material regions */
           mtrl_1 = mtrl_2 = mtrl_3 = num_mtr_1 = num_mtr_2 = num_mtr_3 = 0;

           /* find material 1 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k])  
                {
                    mtrl_1 = k;
                    num_mtr_1 = Mtrl_code[k];
                }
            }
            /* find material 2 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k] && k != mtrl_1)  
                {
                    mtrl_2 = k;
                    num_mtr_2 = Mtrl_code[k];
                }
            }
            /* find material 3 */
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k] && k != mtrl_1 && k != mtrl_2)  
                {
                    mtrl_3 = k;
                    num_mtr_3 = Mtrl_code[k];
                }
            }
           
            if (num_mtr_1 == 0 || num_mtr_2 == 0 || num_mtr_3 == 0)
              printf ("\nWarning... in determine Mtrl code (2 materials)!\n");
              
            if (num_mtr_1 == num_mtr_2 && num_mtr_1 == num_mtr_3)
            {   

                if (mtrl_1 == p_mtrl[8])      eptr->Mtrl_in = mtrl_1;
                else if (mtrl_2 == p_mtrl[8]) eptr->Mtrl_in = mtrl_2;
                else if (mtrl_3 == p_mtrl[8]) eptr->Mtrl_in = mtrl_3;
                else
                {
                    mtrl_1 = mtrl_weight = 0; 
                    for (k=0; k<MAX_MTRL_NUM; k++)
                    {
                        if (Mtrl_code[k])  
                        {
                             if (mtrl_priority[k] > mtrl_weight)
                             { 
                                    mtrl_1 = k;
                                    mtrl_weight = mtrl_priority[k];
                             }
                        }
                    }
                    eptr->Mtrl_in = mtrl_1;
                } 
            }
            else
            {   
                cur_mtrl = mtrl_1;  
                cur_num  = num_mtr_1;
                if (num_mtr_2 > cur_num)
                {
                    cur_mtrl  = mtrl_2;
                    cur_num   = num_mtr_2;
                }
                if (num_mtr_3 > cur_num)
                {
                    cur_mtrl  = mtrl_3;
                    cur_num   = num_mtr_3;
                }
                eptr->Mtrl_in = cur_mtrl;
            }
        }
        else if (count == 4)
        {
            /* take highest priority */
            mtrl_1 = mtrl_weight = 0; 
            for (k=0; k<MAX_MTRL_NUM; k++)
            {
                if (Mtrl_code[k])  
                {
                    if (mtrl_priority[k] > mtrl_weight)
                    { 
                        mtrl_1 = k;
                        mtrl_weight = mtrl_priority[k];
                    }
                }
            }
            eptr->Mtrl_in = mtrl_1;
            /* &&& 
            l0 = eptr->Mtrl_in; l1 = p_mtrl[0]; l2 = p_mtrl[1], l3 = p_mtrl[2]; l4 = p_mtrl[3];
            fprintf (Diag_file, "\nIn Four-regions:  (%ld) %ld %ld %ld %ld\n",
                                l0, l1, l2, l3, l4);
            */
        }
        else
         printf ("\nUnable to determine Material code: %d!\n", count);

CON:    if (eptr->Mtrl_in == -1 || eptr->Mtrl_in > MAX_MTRL_NUM-1)
           fprintf (Diag_file, "\n No. %ld element Mtrl_in = %d (flat elem on bdy?)\n", ii, eptr->Mtrl_in);

	    eptr = eptr->Next;
    }

    /* adjust elem. mtrl. to prevent sharp elem piercing into to other region */
    
    for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
    {   
        if (nptr->Mtrl > BDY_NODE_CODE)     continue;      /* boundary node skip it */
        /* only handle the elem ride on two mtrls */
        num_mtr_1 = num_mtr_2 = 0;
        mtrl_1 = mtrl_2 = -1;
        for (j=0, aeptr=nptr->Fst_adj_elem; aeptr; j++, aeptr=aeptr->ptr)
        {
            eptr = aeptr->idx;
            if (mtrl_1 == -1)   
            {
                mtrl_1 = eptr->Mtrl_in;
                num_mtr_1 = 1;
            }
            else if (eptr->Mtrl_in != mtrl_1 && mtrl_2 == -1)
            {
                mtrl_2 = eptr->Mtrl_in;
                num_mtr_2 = 1;
            }
            else if (eptr->Mtrl_in == mtrl_1)    num_mtr_1++;
            else if (eptr->Mtrl_in == mtrl_2)    num_mtr_2++;
            else if (eptr->Mtrl_in != mtrl_1 || eptr->Mtrl_in != mtrl_2)
            {
                fprintf (Diag_file, "\nThe node %ld has adj.elem on 3 mtrls!\n", ii);
                continue;
            }
            else
                fprintf (Diag_file, "\nOOPs!?? Should not be.(node=%ld)\n", ii);
        }

        if (j != nptr->Num_adj_elem)
            printf ("\nUnconsistent adj. elem. list (j=%d | %d)\n", j, nptr->Num_adj_elem);


        if (num_mtr_1==0  || num_mtr_2==0)   continue;  /* has one mtrl adj elem all set! */
        if (num_mtr_1 < 3 && num_mtr_2 > 3)         cur_mtrl = mtrl_2; /* sharp elem(or try < 2, 3?). adjust to cur_mtrl */
        else if (num_mtr_2 < 3 && num_mtr_1 > 3)    cur_mtrl = mtrl_1;
        else                        continue;          /* no adjustment  */

        /* remove sharp piercing elem. */
        for (j=0, aeptr=nptr->Fst_adj_elem; aeptr; j++, aeptr=aeptr->ptr)
        {
            eptr = aeptr->idx;
            if (eptr->Mtrl_in != cur_mtrl)   
            {
                /* &&& 
                l0 = eptr->Mtrl_in; l5 = cur_mtrl;
                l1 = nnptr[0]->Mtrl; l2 = nnptr[1]->Mtrl; l3 = nnptr[2]->Mtrl; l4 = nnptr[3]->Mtrl;
                fprintf (Diag_file, "\nAdjusted element Mtrl (%ld) %ld %ld %ld %ld to (%ld)[num_m1=%d/num_m2=%d]\n",
                                l0, l1, l2, l3, l4, l5, num_mtr_1, num_mtr_2);
                */
                eptr->Mtrl_in = cur_mtrl;
            }
        }
    }
    
    return (OK);
}



/* find the distance and intersection point (if it has one) between a ray
   and bdy patch. if return 1.e10 and pnt[*]=999. --- no intersection pnt
*/
int
line_bdy (BMeshElem *beptr, REAL *d, REAL *e,  REAL *pnt)
{
   int  k, cross_type;
   REAL a[3], b[3], c[3], r[3], dist;
   BMeshNode *n[3];

   /* pass the node ptr. of the bdy. patch */
   for (k=0; k<3; k++)  n[k] = beptr->Elem.tri3.NodePtr[k];

   /* define vector a, b, c for tri-patch */
   for (k=0; k<3; k++)  a[k] = n[0]->Coor[k];
   for (k=0; k<3; k++)  b[k] = n[1]->Coor[k] - a[k];
   for (k=0; k<3; k++)  c[k] = n[2]->Coor[k] - a[k];

   /* checking intersection */
   cross_type = ray_tri_cross_conf (d, e, a, b, c, r);

   for (k=0; k<3; k++)    pnt[k] = 999.;   /* set as default */
   if (cross_type == INBOUND || cross_type == ONEDGE || cross_type == COPLANE)
   {  /*determin the distance to bdy and pass the Coor.of intersected point */ 
      for (k=0; k<3; k++)   pnt[k] = r[k];
      dist = v_rang(d, r, 3);
      if (dist/v_rang (d, e, 3) <= 1.0)
          return (OK);
      else
          return (BAD);
   }

   return (BAD);
}

/* find the intersection point with bdy */
int
intersect_bdy (REAL *d, REAL *e, REAL *inter_pt, int mtrl_code,
               BMeshElem *bdy_l_head, long bdy_num_elem, BMeshElem **act_beptr)
{
    long        ii;
    REAL        xmin, xmax, ymin, ymax, zmin, zmax;
    BMeshElem   *beptr;

    xmin = xmax = d[X];
    ymin = ymax = d[Y];
    zmin = zmax = d[Z];
    if (e[X] > xmax)        xmax = e[X];
    else if (e[X] < xmin)   xmin = e[X];
    if (e[Y] > ymax)        ymax = e[Y];
    else if (e[Y] < ymin)   ymin = e[Y];
    if (e[Z] > zmax)        zmax = e[Z];
    else if (e[Z] < zmin)   zmin = e[Z];

    for (ii=0, beptr=bdy_l_head; ii<bdy_num_elem; ii++, beptr = beptr->Next)
    {
	    if (beptr->Mtrl_in == mtrl_code || beptr->Mtrl_out == mtrl_code)
	    {   /* right BDY patch */
	        /* box checking with bdy. patch */
	        if (xmax < beptr->xmin || xmin > beptr->xmax)  continue;
	        if (ymax < beptr->ymin || ymin > beptr->ymax)  continue;
	        if (zmax < beptr->zmin || zmin > beptr->zmax)  continue;

	         /* find closest bdy. patch. to move to */
             if (line_bdy (beptr, d, e, inter_pt) == BAD)
                    continue;
             else 
             {
                *act_beptr = beptr;
                return (OK);
             }
        }
    }

    return (BAD);
}

