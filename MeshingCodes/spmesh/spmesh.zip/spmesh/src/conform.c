/* 
  ************************************************************************
  *  conform.c : Boundary Conformage for Tetrahedron Mesh	             *
  *									                                     *
  *  Qingyang Zhang				   Augest 16, 1996	                     *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>

#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

#define  imod(x,y)  (int)(fmod((REAL)(x), (REAL)(y)))
#define GetRandom( min, max ) ((rand() % (int)(((max) + 1) - (min))) + (min))

#define MTRL1   0
#define MTRL2   1
#define BDY12   3
#define NOMOV   4

#define ITERATION_TIMES 5
#define MAX_SM_ITER     5
#define CONFORM_TIMES   3

/* for power fit */
#define MAX_SUB_MOVE        3
#define INFLUENT_ZONE_LEVEL 1

#define LOC_FACTOR  0.5
#define DIS_FACTOR  0.8
#define NUM_DIR     18

#define PLAIN_FIT   0
#define POWER_FIT   1


long    Num_elastic_done;
long    Num_power_fit;
long    Num_power_undone;
MeshNode *Zone_list[MAX_ADJACENT_NODES];
int Zone_node_status[MAX_ADJACENT_NODES];

/*
** External Functions
*/
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern int  v_norm(REAL *vec, int n);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL v_dot(REAL *vec1, REAL *vec2, int n);
extern int  mk_ecs2wcs_mat (REAL *extrusion, REAL *ecs2wcs_mat);
extern void mat3_mat4 (REAL *mat3x3, REAL *mat4x4);
extern int  xfer_4x4 (REAL *mat, REAL *inp);
extern void xfv2w(REAL *vm,REAL vx,REAL vy,REAL vz,
				    REAL *wx,REAL *wy,REAL *wz );
extern void xfwm2v(REAL *wm,REAL x,REAL y,REAL z,
                    REAL *u,REAL *v,REAL *w);
extern REAL edge_process (REAL *node_1, REAL *node_2, REAL *node_4, REAL *r);
extern void search_bdy_node (MeshNode *msh_n_head, long msh_num_node);
extern REAL elem_assess (MeshElem *eptr, int qulity_type);
extern REAL avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type);
extern REAL pnt2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *pnt);
extern REAL loc_size (MeshNode *in_node);
extern void set_new_position (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		       int node_status);
extern void set_new_position_b  (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		            int node_status, REAL factor);
extern REAL fit_tet4_test (MeshElem *eptr, MeshNode **nnptr, REAL *node_quli, 
	                int quali_type);
extern void set_ori_position (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl);
extern NODE_MTRL nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
                   BMeshElem **on_bdy_eptr);
extern int alloc_error (char *str);
extern int check_unfitted (void);
extern int check_null_bdynode_ptr (void);

extern int elastic_conform_tet4 (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, int mtrl_code,
                NodeInfo *node_buf, REAL ave_dist1, REAL ave_dist2, REAL loc_size_1, REAL loc_size_2, 
                int num_set_1, int num_set_2, int quali_type, REAL min_quali);
extern int random_shoot_full (double *st_pnt, double *ed_pnt);


/* added by Ziji Wu, 8/18/99 */
extern REAL v_magn(REAL *vec, int n);
extern clean_collapsed_elem (MeshElem  *msh_elm, long *msh_num_elem);
extern REAL v_dot(REAL *vec1, REAL *vec2, int n);
#define EXTRALOWTOL    1.E-2
extern MeshElem * create_an_elem (MeshElem **msh_l_head, long *num_mesh_el);

extern FILE *fpzw2;

/*
** Local Functions
*/
int conform_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
                 BMeshElem *bdy_l_head, long bdy_num_elem,
		         MeshNode *msh_n_head,  long *msh_node,
                 MeshElem *msh_l_head,  long *msh_elem);
MeshElem *cur_elem_conform (MeshElem *msh_l_head, long msh_num_elem, MeshElem *cur_eptr, int mtrl_code);
BMeshElem *find_conf_bdy (REAL *node, REAL *inter_pt, REAL *opt_dist, int mtrl_code,
		        BMeshElem *bdy_l_head, long bdy_num_elem);
int conf_tet4_bdy (MeshElem *cur_eptr, int mtrl_code, BMeshElem *bdy_l_head, long bdy_num_elem, REAL min_quali, int fit_mode);
void sort_nod_mtrl (int *nd_idx, NodeInfo *node_buf, int num_mov, int mov_mtrl);
int ray_dir (REAL *src, REAL *dest, REAL delta, int num_dir, 
             REAL *nx, REAL *ny, REAL *nz);
REAL ray2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *ray, REAL *pnt);
int ray_tri_cross_conf (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);
int find_opt_ray (BMeshElem *bdy_l_head, long bdy_num_elem, int num_dir, 
              REAL *nx, REAL *ny, REAL *nz, int mtrl_code, 
              MeshElem *cur_eptr, MeshNode *nptr, int quali_type, REAL min_quali,
              REAL *inter_pt, REAL *opt_dist, REAL *out_quali, BMeshElem **out_bdy_ptr);
int power_fit_tet4 (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, int mtrl_code,
              NodeInfo *node_buf, REAL ave_dist1, REAL ave_dist2, REAL loc_size_1, REAL loc_size_2,
                int num_set_1, int num_set_2, int quali_type, REAL min_quali);
int check_adj_node_elem_list (MeshNode *msh_n_head, long msh_num_node,
                          MeshElem *msh_l_head, long msh_num_elem);
int elem_smooth (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *eptr, 
          REAL smooth_criteria, int quali_type, REAL min_quali, int bdy_sm_type);
int smooth_node_list (MeshNode **smooth_list, int *node_mask, int num_smooth, BMeshElem *bdy_l_head, 
                long bdy_num_elem, REAL smooth_criteria, int quali_type, REAL min_quali);
int single_node_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		                  MeshNode *nptr);
int check_cross_bdy_elem (MeshNode **nnptr, int num_node);
int create_node_set_buffer (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, 
           int mtrl_code, int quali_type, NodeInfo *node_buf, int *num_set_1, int *num_set_2, 
           REAL *ave_dist1, REAL *ave_dist2, REAL *loc_size_1, REAL *loc_size_2);
int influence_zone (MeshElem *eptr, int zone_level, MeshNode **z_list, int *zlist_node_status);
int set_node_mask (MeshElem *eptr, MeshNode **z_list, int num_inzone, int bdy_sm_type, int *buf_mask);

/* added by Ziji Wu, 8/18/99 */
void
find_conf_bdy_edge (NodeInfo *node_buf, int mtrl_code, BMeshElem *bdy_l_head, long bdy_num_elem, REAL *move, long *mat);
/* added by Ziji Wu, 8/16/99 */
int conf_elem_split (MeshElem *cur_eptr, int mtrl_code, BMeshElem *bdy_l_head, long bdy_num_elem, 
						 REAL min_quali, MeshElem **msh_l_head, long *msh_num_elem, MeshNode *msh_n_head,
						 long *msh_node);
/* added by Ziji Wu, 9/1/99 */
MeshElem *
search_cannotfit_elem (MeshElem *msh_l_head, long msh_num_elem, MeshElem *cur_eptr, int mtrl_code);

AdjElem *create_adj_elem();
void add_elm_2_nd_adj(MeshElem *elm, MeshNode *pt);
void add_pt_2_nd_adj(MeshNode *pt1, MeshNode *pt2);
void remove_pt_from_nd_adj(MeshNode *pt1, MeshNode *pt2);
void remove_elm_from_nd(MeshElem *elm, MeshNode *pt);


/*
** Global Variables
*/
/* this value should pass to conf_bdy.c 
 for computing intersection point! keep it extern global !!
*/

extern REAL  Max_size;


/*
** Local Variables
*/ 
/* single link list */
typedef struct t_elem_list_stru {
  MeshElem *elem_ptr;
  struct t_elem_list_stru *Next;
} ElemList;



/* conforming external and internal boundary
the mesh send in: with node classification.
*/
int
conform_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
             BMeshElem *bdy_l_head, long bdy_num_elem,
		     MeshNode *msh_n_head, long *msh_node,
             MeshElem *msh_l_head, long *msh_elem)
{
  int       k, imtrl, done_flag, conf_times=0;
  int       mtrl_region_code[MAX_MTRL_NUM], mtrl_code; 
  long      ii, kk, num_unfit=0, lcount=0;
  long      msh_num_node, msh_num_elem, num_elist;
  REAL      min_quali;
  MeshNode  *nptr, **nnptr;
  MeshElem  *cur_eptr, *new_eptr;
  ElemList  el_list, *cur_elist, *tmp_elist;

/* Ziji Wu, 9/1/99 */
  MeshElem  *etmp;
  int       fit_cnt, split_rtn;
    
  msh_num_node = *msh_node;
  msh_num_elem = *msh_elem;
  
  /* Initialization */
  num_elist           = 0;
  cur_elist           = &el_list;
  cur_elist->Next     = NULL;
  cur_elist->elem_ptr = NULL;

  /* check_adj_node_elem_list (msh_n_head, msh_num_node, msh_l_head, msh_num_elem);*/

  for (ii=0, cur_eptr=msh_l_head; ii<msh_num_elem; ii++, cur_eptr=cur_eptr->Next)
  {
      cur_eptr->attr   = UNFIT;
      cur_eptr->status = 0;
  }
    
  Num_elastic_done = 0;
  Num_power_fit    = 0;
  Num_power_undone = 0;
  Num_interface    = 0;
  min_quali        = MIN_QUALITY;
  for (k=0; k<MAX_MTRL_NUM; k++)      
  {
      Mtrl_code[k] = mtrl_region_code [k] = 0;
  }

  /* find total number of materials */ 
  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
  {   
/* Ziji 1/7/99      nptr->status  = FREE;  */   /* do initialize no node status */
	  if ((nptr->status!=FIXED)&&(nptr->status<0)) 
		nptr->status  = FREE;     /* do initialize no node status */
/* end of Ziji */

      /* nptr->bdy_ptr = NULL; */
      kk = nptr->Mtrl;
      
      if (kk < 0 || kk > MAX_MTRL_NUM-1) 
      {
          /* printf ("\nPre-existed bdy mtrl. : %ld!\n", kk); */
          continue;
      }
     
      if (Mtrl_code[kk] == 0)   Mtrl_code[kk] = 1;
  } 
  
  for (k=1; k<MAX_MTRL_NUM; k++)
  {
      if (Mtrl_code[k])  
      {   /* Use the array to skip gap of mtrl code */
          mtrl_region_code[Num_interface++] = k;
      }
  }
  printf ("\nFound %d Boundary Interfaces. \n", Num_interface);
  printf ("Conforming... please wait.\n");

  if (Num_interface == 0)
  {
      fprintf (Diag_file, "\nNo Mtrl. interface found!\n");
      return (BAD); /* No Mtrl find */
  }

  /* find max. size of the object */
  Max_size = BDxmax - BDxmin;
  if (Max_size < BDymax - BDymin)  Max_size = BDymax - BDymin;
  if (Max_size < BDzmax - BDzmin)  Max_size = BDzmax - BDzmin;

  /* search mesh model to find outter BDY node, these nodes need be took care when smoothing*/
  /* the status of bdy. node is set as OUTNODE */
  search_bdy_node (msh_n_head, msh_num_node);

ITER:
  conf_times++;
  /* conforming bdy */
  for (imtrl=0; imtrl<Num_interface; imtrl++)
  {
      /* current mtrl region to conforming */
      mtrl_code = mtrl_region_code[imtrl];
      /* find an elem. across the given conforming mtrl bdy (ride on two mtrl. only) */
      if ((cur_eptr=cur_elem_conform (msh_l_head, msh_num_elem, NULL, mtrl_code)) == NULL)
      {
          printf ("\nNo start for Mtrl. %d -- all set!\n", mtrl_code);
          continue;
      }

      do 
      {
	    switch (cur_eptr->E_type)
	    {
	        case TET4:
                if (conf_tet4_bdy (cur_eptr, mtrl_code, bdy_l_head, 
                          bdy_num_elem, min_quali, PLAIN_FIT) == BAD)
                {
                    /* After the process the elem. can't be fitted */
                    done_flag = 0;
                    cur_eptr->attr = CANNOTFIT;
                    /* borrow this field to record the mtrl bdy to fit, for late use */
                    cur_eptr->Mtrl_out = mtrl_code; 
                    num_unfit++;
                    /* printf ("\nUnfitted elem. : %ld. \n", num_unfit); */
                }
                else
                {
                    done_flag = 1;
                }
		        break;
	        case HEX8:
		        break;
	        default:
		        fprintf (Diag_file, "\nError...Unknown element type (%d) in conform.c!\n", cur_eptr->E_type);
	    }

        /* search next elem. to conforming */
        new_eptr=cur_elem_conform (msh_l_head, msh_num_elem, cur_eptr, mtrl_code);
        if (new_eptr == NULL) break;

        if (new_eptr==cur_eptr && done_flag==0)
        {
          fprintf (Diag_file, "\nUnfitted elem. for Mtrl. %d, need special op.\n", mtrl_code);
          fprintf (Diag_file, "\nShould not be here!!\n");
          cur_eptr = new_eptr;
        }
        else
            cur_eptr = new_eptr;

        if (cur_eptr->status > 2)
        {
            /* the elem. has been processed three times but still undone 
               just tag it as can't be fitted to provent a dead loop.
            */
            done_flag = 0;
            cur_eptr->attr = CANNOTFIT;
            /* borrow this field to record the mtrl bdy to fit, for late use */
            cur_eptr->Mtrl_out = mtrl_code; 
            num_unfit++;
            /* printf ("\nUnfitted elem.(tried 3 times) : %ld. \n", num_unfit); */
            continue;
            
        }
      } while (cur_eptr);

  }

  /* clear el_list */
  if (el_list.Next || num_elist)
  {
      lcount=0;
      cur_elist=el_list.Next;
      while (cur_elist) 
      {
          lcount++;
          tmp_elist = cur_elist->Next;
          free ((char *)cur_elist);
          cur_elist = tmp_elist;
      }
      if (lcount != num_elist)
          fprintf (Diag_file, "\nUnconsistent elem list! %ld (%ld)\n", lcount, num_elist);

      cur_elist       = &el_list;
      cur_elist->Next = NULL;
      num_elist       = 0;
  }
  
  /* double check the unfitted elem. may be already done because of its
     adj. elem.'s process
  */

  for (ii=0, cur_eptr=msh_l_head; ii<msh_num_elem; ii++, cur_eptr=cur_eptr->Next)
  {     
      if (cur_eptr->attr == CANNOTFIT)
      {
         if (cur_eptr->E_type == TET4)
         {  
            nnptr = cur_eptr->Elem.tet4.NodePtr;
            if (check_cross_bdy_elem (nnptr, 4) != OK)
            {
                num_unfit--;
                /* printf ("\nAutomatic fitted elem.\n"); */
            }
            else
            {  
                /* recode the unfitted elem. in elem list */
                cur_elist->Next = (ElemList *) malloc (sizeof (ElemList));  
                if (cur_elist->Next == NULL)    alloc_error ("conform-1"); 
                num_elist++;
                cur_elist = cur_elist->Next;
                cur_elist->elem_ptr = cur_eptr;
                cur_elist->Next = NULL;
            }
         }
/* added by Ziji Wu, 9/2/99 
   the last time of conforming will not re-set the element status */
if (conf_times < CONFORM_TIMES) {
/* end of Ziji */	  
         /* set back for next iteration */
         cur_eptr->attr   = UNFIT;
         cur_eptr->status = 0;
/* added by Ziji Wu, 9/2/99 */
}
/* end of Ziji */
      }
  }

  /* call power fit */
  if (num_unfit > 0 && conf_times < CONFORM_TIMES)
  {
    for (ii=0, cur_elist=el_list.Next; cur_elist; ii++, cur_elist=cur_elist->Next)
    {
        cur_eptr = cur_elist->elem_ptr;
        /* retreive this field to get the mtrl bdy to fit */
        if ((mtrl_code=cur_eptr->Mtrl_out) == BAD)
        {
            fprintf (Diag_file, "Unknown mtrl Bdy to fit!\n"); 
            continue;
        }
        
/* Ziji 9/1/99, to skip power fit
        if (conf_tet4_bdy (cur_eptr, mtrl_code, bdy_l_head, 
                          bdy_num_elem, min_quali, POWER_FIT) == OK)
        {
            /* power fit solved an elem */
/* Ziji            cur_eptr->Mtrl_out = BAD; /* set back to origin */
/* Ziji            num_unfit--;
            Num_elastic_done++;
        }
*/        
    }
    if (ii != num_elist)
        fprintf (Diag_file, "\nUnmatched CANNOTFIT list : %ld (%ld)!\n", ii, num_elist);
  }

  printf ("\n********** the %dth conforming iteration ***********", conf_times);
  fprintf (Diag_file, "\n********** the %dth conforming iteration ***********", conf_times);
  fprintf (Diag_file, "\n           num_unfitted = %ld \n", num_unfit);
  if (num_unfit > 0 && conf_times < CONFORM_TIMES)
  {
      min_quali *= 0.3;
      num_unfit = 0;
      goto ITER;
  }

/* added by Ziji Wu, 9/01/99 
   if there are still some unfitted elem left, see if it can be solved by
   splitting into two elements */
if (num_unfit>0) {
	printf("\n\n There are still %d unfitted elements. Try to split them.\n", num_unfit);
	fprintf(fpzw2, "\nThere are still %d unfitted elements. Try to split them.\n", num_unfit);
//	num_unfit = 0;
	fit_cnt = 0;
	for (imtrl=0; imtrl<Num_interface; imtrl++)
	{
		/* current mtrl region to conforming */
		mtrl_code = mtrl_region_code[imtrl];
		/* find an elem. across the given conforming mtrl bdy (ride on two mtrl. only) */
		if ((cur_eptr=search_cannotfit_elem (msh_l_head, msh_num_elem, NULL, mtrl_code)) == NULL) {
			fprintf(fpzw2, "\n Material %d has done.", mtrl_code);
			continue;
		}
		fprintf(fpzw2, "\n\n Doing material %d.", mtrl_code);

		/* clear elem status flag */
		etmp = cur_eptr;
		do {
			if (etmp->status>0) etmp->status = 0;
			etmp = etmp->Next;
		}while (etmp!=msh_l_head);

		/* loop over to fit */
		etmp = NULL;
		do
		{
			/* try to split the elem */
			split_rtn = conf_elem_split(cur_eptr, mtrl_code, bdy_l_head, bdy_num_elem, 
				        min_quali, &msh_l_head, msh_elem, msh_n_head, msh_node);
			if (split_rtn==NONE) {
				etmp = cur_eptr;
			}
			else if (split_rtn==BAD) {
//				num_unfit ++;
				etmp = cur_eptr;
//				cur_eptr->attr = CANNOTFIT2;
				cur_eptr->status ++; /* so that no elem can be processed more than a certain times */
				fprintf(fpzw2, "\nElem cannnot fit: \n");
				for (k=0; k<4; k++)
					fprintf(fpzw2, "  ND%d: Coor(%lf, %lf, %lf) Mtrl(%ld)\n", 
					   k+1, cur_eptr->Elem.tet4.NodePtr[k]->Coor[0], cur_eptr->Elem.tet4.NodePtr[k]->Coor[1], 
					   cur_eptr->Elem.tet4.NodePtr[k]->Coor[2], cur_eptr->Elem.tet4.NodePtr[k]->Mtrl);
				fprintf(fpzw2, "  Elem Status (%d)\n", cur_eptr->status);
			}
			else {
				fit_cnt ++;
				etmp = NULL;
			}

			/* search next elem. to conforming */
			new_eptr=search_cannotfit_elem (msh_l_head, msh_num_elem, etmp, mtrl_code);
			
			if (new_eptr == NULL) break;
			else cur_eptr = new_eptr;
		} while (cur_eptr);
	}
}

printf("\n There are %d elements being splitted.\n", fit_cnt);
fprintf(fpzw2, "\n There are %d elements being splitted.\n", fit_cnt);
/* end of Ziji */
  
  /*
  fprintf (Diag_file, "\nNumber of power fit done: %ld!\n", Num_power_fit);
  fprintf (Diag_file, "\nNum. elem. can't handle by power fit: %ld!\n", Num_power_undone);
  */
  
  fprintf (Diag_file, "\nNumber of unfitted elem.: %ld!\n", num_unfit);
  /* fprintf (Diag_file, "\nNumber of elastic fitting done %ld\n", Num_elastic_done); */


  /* clear el_list */
  if (el_list.Next || num_elist)
  {
      lcount=0;
      cur_elist=el_list.Next; 
      while (cur_elist) 
      {
          lcount++;
          tmp_elist = cur_elist->Next;
          free ((char *)cur_elist);
          cur_elist = tmp_elist;
      }
      if (lcount != num_elist)
          fprintf (Diag_file, "\nUnconsistent elem list! %ld (%ld)\n", lcount, num_elist);

      cur_elist       = &el_list;
      cur_elist->Next = NULL;
      num_elist       = 0;
  }


  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
  {   
      if (nptr->status == OUTNODE)
        nptr->status  = FIXED;     /* Set it back for late op. */
  } 

  return (OK);
}


int
conf_tet4_bdy (MeshElem *cur_eptr, int mtrl_code, BMeshElem *bdy_l_head, 
               long bdy_num_elem, REAL min_quali, int fit_mode)
{
    /* int     i, j, k; */
    int     quali_type, num_set_1, num_set_2; 
    int     num_mov, mov_mtrl, set_1_done, set_2_done;
    int     iteration, flag;
    REAL    set_1_quli, set_2_quli;
    REAL    loc_size_1, loc_size_2, mov_factor, ave_dist1, ave_dist2;
    REAL     node_avg_quli[4], smooth_criteria;
    MeshNode **nnptr;
    NodeInfo node_buf[4];

    quali_type = VOLRAT;
    mov_factor = 1.;      /* initial moving factor */
    (cur_eptr->status)++; /* count process times */

    iteration=0;
RE:
    if (fit_mode == PLAIN_FIT)
    {
        /* PALIN_FIT mode */
        flag = create_node_set_buffer (bdy_l_head, bdy_num_elem, cur_eptr, 
            mtrl_code, quali_type, node_buf, &num_set_1, &num_set_2, 
            &ave_dist1, &ave_dist2, &loc_size_1, &loc_size_2);
    
        if (flag == BAD)        return (BAD); /* can't create buffer */
        else if (flag == OK)    return (OK);  /* all set */
        nnptr = cur_eptr->Elem.tet4.NodePtr;
        if (ave_dist1 > XHUGE && ave_dist2 > XHUGE) 
        {
            fprintf (Diag_file, "Warning... can't move (ave_dist1=%lf <==> ave_dist2=%lf)\n", 
                    ave_dist1, ave_dist2);
            return (BAD); /* can't move */
        }
    
        /* try old method first */
        set_1_done = set_2_done = BAD;
    
        /* test move -- set 1 */
        if (ave_dist1 < G_factor*loc_size_1)
        {
            num_mov = num_set_1;
	        mov_mtrl = MTRL1;
	        /* dump a test and move a set of node to BDY */
	        set_new_position_b (nnptr, node_buf, mov_mtrl, FREE, mov_factor);
	
	        /* check out if it' acceptable */
	        set_1_quli = fit_tet4_test (cur_eptr, nnptr, node_avg_quli, quali_type);
	        if (set_1_quli > min_quali)  set_1_done = OK;

	        /* dump back for test move of set 2 nodes */
	        set_ori_position (nnptr, node_buf, mov_mtrl);
        }

        /* test move -- set 2 */
        if (ave_dist2 < G_factor*loc_size_2)
        {
            num_mov = num_set_2;
	        mov_mtrl = MTRL2;
	        /* dump a test and move a set of node to BDY */
	        set_new_position_b (nnptr, node_buf, mov_mtrl, FREE, mov_factor);
	
	        /* &&&check out if it's acceptable */
	        set_2_quli = fit_tet4_test (cur_eptr, nnptr, node_avg_quli, quali_type);
	        if (set_2_quli > min_quali)  set_2_done = OK;

	        /* dump back for less confusion if the set one is the best one */
	        set_ori_position (nnptr, node_buf, mov_mtrl);
        }

        if (set_1_done!=BAD || set_2_done!=BAD)
        {   /* old method works determine which set of node will be 
            move onto the BDY */
            if (set_1_done == BAD)
            {
                num_mov = num_set_2;
	            mov_mtrl = MTRL2;
            }
            else if (set_2_done == BAD)
            {
                num_mov = num_set_1;
	            mov_mtrl = MTRL1;
            }
            else
            {
                if (set_1_quli > set_2_quli)
	            {
	                num_mov = num_set_1;
	                mov_mtrl = MTRL1;
	            }
	            else
	            {
	                num_mov = num_set_2;
	                mov_mtrl = MTRL2;
	            }
            }
            /* finally fit the BDY */
            set_new_position_b (nnptr, node_buf, mov_mtrl, FIXED, mov_factor);
            return (OK);
        }
        if (++iteration < ITERATION_TIMES)
        {
            /* do local smoothing */
            smooth_criteria = loc_size_1 < loc_size_2 ? 0.1*loc_size_1 : 0.1*loc_size_2;
            if (smooth_criteria < LOWTOL) 
                fprintf (Diag_file, "\nSoomth criteria too small (%lf)!\n", smooth_criteria);

            elem_smooth (bdy_l_head, bdy_num_elem, cur_eptr, smooth_criteria, 
                     quali_type, min_quali, MOVE_ELEM_BDY);
            goto RE;
        }
        else
            return (BAD);

    }
    else
    {
        /* power fit,  need special process */
/*Ziji 8/19/99, skip powerfit        if (power_fit_tet4 (bdy_l_head, bdy_num_elem, cur_eptr, mtrl_code, node_buf, 
                            ave_dist1, ave_dist2, loc_size_1, loc_size_2,
                            num_set_1, num_set_2, quali_type, min_quali) == OK)
Ziji*/        /*
        if (elastic_conform_tet4 (bdy_l_head, bdy_num_elem, cur_eptr, mtrl_code,
                                  node_buf, ave_dist1, ave_dist2, loc_size_1, 
                                  loc_size_2, num_set_1, num_set_2, quali_type, 
                                  min_quali) == OK)
        */
/* Ziji 8/19/99        {
            return (OK);
        }
        return (BAD);
Ziji */    

        printf ("\nDon't know how to report!\n");
        return (OK);
    }

}


/* added by Ziji Wu, 8/31/99 
   this subroutine is going to remove elm from pt's adj list */
void remove_elm_from_nd(MeshElem *elm, MeshNode *pt)
{
	AdjElem  *adj, *tmp;
	int      i;

	adj = pt->Fst_adj_elem;
	tmp = adj;
	if (adj->idx==elm) {
		/* elm is the first in pt's adj list */
		pt->Fst_adj_elem = adj->ptr;
		pt->Num_adj_elem --;
		free(adj);
	}
	else {
		/* find elm's position */
		adj = adj->ptr;
		for (i=1; i<pt->Num_adj_elem; i++, adj=adj->ptr) {
			if (adj->idx==elm) break;
			tmp = adj;
		}

		if (adj==NULL) { /* elm is not in pt's adj list */ }
		else if (adj->idx==elm){
			/* elm is in pt's adj list */
			if (i==pt->Num_adj_elem) {
				/* elm is the last in pt's adj list */
				tmp->ptr = NULL;
				pt->Num_adj_elem --;
				free(adj);
			}
			else {
				tmp->ptr = adj->ptr;
				pt->Num_adj_elem --;
				free(adj);
			}
		}
	}
}

/* added by Ziji Wu, 8/30/99 
   this subroutine is going to remove pt2 from pt1's adj list */
void remove_pt_from_nd_adj(MeshNode *pt2, MeshNode *pt1)
{
	AdjList  *adj, *tmp;
	int      i;

	adj = pt1->Fst_adj;
	tmp = adj;
	if (adj->idx==pt2) {
		/* pt2 is the first in pt1's adj list */
		pt1->Fst_adj = adj->ptr;
		pt1->Num_adj --;
		free(adj);
	}
	else {
		/* find pt2's position */
		adj = adj->ptr;
		for (i=1; i<pt1->Num_adj; i++, adj=adj->ptr) {
			if (adj->idx==pt2) break;
			tmp = adj;
		}

		if (adj==NULL) { /* pt2 is not in pt1's adj list */ }
		else if (adj->idx==pt2){
			/* pt2 is in pt1's adj list */
			if (i==pt1->Num_adj) {
				/* pt2 is the last in pt1's adj list */
				tmp->ptr = NULL;
				pt1->Num_adj --;
				free(adj);
			}
			else {
				tmp->ptr = adj->ptr;
				pt1->Num_adj --;
				free(adj);
			}
		}
	}
}


/* added by Ziji Wu, 8/30/99 
   this subroutine is going to add pt2 to pt1's adj list */
void add_pt_2_nd_adj(MeshNode *pt2, MeshNode *pt1)
{
	AdjList  *adj;
	int      i;

	/* check if pt2 is already on pt1's list */
	adj = pt1->Fst_adj;
	for (i=0; i<pt1->Num_adj; i++, adj=adj->ptr) {
		if (adj->idx==pt2) return;
	}

    adj = (AdjList *) malloc (sizeof (AdjList));
	adj->ptr = NULL;

	if (pt1->Num_adj>0) adj->ptr = pt1->Fst_adj;
	adj->idx = pt2;
	adj->wt = 0.;
	pt1->Fst_adj = adj;
	pt1->Num_adj ++;
}

/* added by Ziji Wu, 8/30/99 
   this subroutine is going to add elm to pt's elem adj list */
void add_elm_2_nd_adj(MeshElem *elm, MeshNode *pt)
{
	AdjElem  *adj;
	int      i;

	/* check if elm is already on pt's list */
	adj = pt->Fst_adj_elem;
	for (i=0; i<pt->Num_adj_elem; i++, adj=adj->ptr) {
		if (adj->idx==elm) return;
	}

    adj = create_adj_elem();
	if (pt->Num_adj_elem>0) adj->ptr = pt->Fst_adj_elem;
	adj->idx = elm;
	pt->Fst_adj_elem = adj;
	pt->Num_adj_elem ++;
}

/* added by Ziji Wu, 8/30/99 
   this subroutine is going to create an adj elem with initialization */
AdjElem *create_adj_elem()
{
	AdjElem *adj;

	adj = (AdjElem *) malloc (sizeof (AdjElem));
	adj->idx = NULL;
	adj->wt  = 0.;
	adj->ptr = NULL;

	return (adj);
}


/* added by Ziji Wu, 8/30/99 
   this subroutine is going to add a node to the current element. It will first find
   an edge that crosses bdy patch closest to its center. Then, split all the elements
   share that edge.
*/
int
conf_elem_split (MeshElem *cur_eptr, int mtrl_code, BMeshElem *bdy_l_head, 
               long bdy_num_elem, REAL min_quali, MeshElem **msh_l_head, long *msh_num_elem, 
			   MeshNode *msh_n_head, long *msh_node)
{
    MeshNode **nnptr, **node;
	NodeInfo node_buf[4];
	int      i, j, k, ii;
	int      num1;
	AdjElem  *aeptr1, *aeptr2;
	MeshElem *eptr, *eptr1, *newelm;
	REAL     x, split[6];
	long     mat[6];
	int      edge[2][6], face[3][4], edge_face[2][6], n1, n2;
	MeshNode *newpt, *pt1, *pt2;
	AdjElem  *eadd1, *eadd2, *ept1, *ept2, *edel, *tmp;
	int      nelm1, nelm2, ndel;
	REAL     best_qual, avg_qual, worst_in_best_qual, avg_tol, qual, worst_qual;

	avg_tol = min_quali/0.09;

	/* edge list of an element */
	edge[0][0] = 0; edge[1][0] = 1;
	edge[0][1] = 0; edge[1][1] = 2;
	edge[0][2] = 0; edge[1][2] = 3;
	edge[0][3] = 1; edge[1][3] = 2;
	edge[0][4] = 1; edge[1][4] = 3;
	edge[0][5] = 2; edge[1][5] = 3;

	/* face list of an element */
	face[0][0] = 1; face[1][0] = 3; face[2][0] = 2;
	face[0][1] = 0; face[1][1] = 2; face[2][1] = 3;
	face[0][2] = 0; face[1][2] = 3; face[2][2] = 1;
	face[0][3] = 0; face[1][3] = 1; face[2][3] = 2;

	/* face attached to edge list of an element 
	   this array also shows which two nodes are
	   not on an edge
	*/
	edge_face[0][0] = 2; edge_face[1][0] = 3;
	edge_face[0][1] = 1; edge_face[1][1] = 3;
	edge_face[0][2] = 1; edge_face[1][2] = 2;
	edge_face[0][3] = 0; edge_face[1][3] = 3;
	edge_face[0][4] = 0; edge_face[1][4] = 2;
	edge_face[0][5] = 0; edge_face[1][5] = 1;

	/* pass elem. node to buffer */
    nnptr=cur_eptr->Elem.tet4.NodePtr;
    for (i=0; i<4; i++)
    {
        for (j=0; j<3; j++)    
			node_buf[i].ori_coor[j] = node_buf[i].mov_coor[j] = nnptr[i]->Coor[j];
        if (nnptr[i]->Mtrl > BDY_NODE_CODE)
            node_buf[i].bdy_ptr = nnptr[i]->bdy_ptr;
        else
            node_buf[i].bdy_ptr = NULL; 

        node_buf[i].Mtrl    = nnptr[i]->Mtrl;
        node_buf[i].status  = nnptr[i]->status;
		/* this var will store the percentage of moving wrt the length of the edge.
		   -1 means haven't check yet. */
		node_buf[i].mov_dist = -1.;
    }

    /* find an intersecting edge */
    find_conf_bdy_edge (node_buf, mtrl_code, bdy_l_head, bdy_num_elem, split, mat);

	/* find the edge that has the intersection point closest to its center */
	num1 = -1;
	x = 2.;
	best_qual = 0.;
	worst_in_best_qual = 1.;
	for (ii=0; ii<6; ii++) {
		if (split[ii]<0.) continue;
		/* test split, check the quality of the new elements. */
		avg_qual = 0.;
		worst_qual = 1.;
		nelm1 = 0; /* number of new elem */
		pt1 = nnptr[edge[0][ii]];
		pt2 = nnptr[edge[1][ii]];
		/* create a new point */
		/* allocate memory for new node */
	    newpt = (MeshNode *) malloc (sizeof (MeshNode));
		if (!newpt)	alloc_error ("conform-2");
	    else
		{
			newpt->Fst_adj = NULL;
			newpt->Num_adj = 0;
			newpt->Fst_adj_elem = NULL;
			newpt->Num_adj_elem = 0;
			newpt->status  = FIXED;
			newpt->in_zone = 0;
			newpt->Mtrl = mat[ii];
			newpt->Prev = NULL;
			newpt->Next = NULL;
			for(i=0; i<3; i++) 
				newpt->Coor[i] = pt1->Coor[i] + split[ii]*(pt2->Coor[i]-pt1->Coor[i]);
	    }

		/* find all the elements share this edge, split, and check the quality */
		newelm = (MeshElem *) malloc (sizeof (MeshElem));
		newelm->E_type = TET4;
		aeptr1=pt1->Fst_adj_elem;
		for (i=0; i<pt1->Num_adj_elem; i++, aeptr1=aeptr1->ptr) {
			eptr = aeptr1->idx;
			aeptr2=pt2->Fst_adj_elem;
			for (j=0; j<pt2->Num_adj_elem; j++, aeptr2=aeptr2->ptr) {
				eptr1 = aeptr2->idx;
				if (eptr==eptr1) {
					/* this elem should be splitted */
					/* figure out the edge number in this elem */
				    node=eptr->Elem.tet4.NodePtr;
					for (k=0; k<6; k++) {
						if (((node[edge[0][k]]==pt1)&&(node[edge[1][k]]==pt2)) ||
							((node[edge[0][k]]==pt2)&&(node[edge[1][k]]==pt1))) 
							break;
					}
					
					/* create two new elements */
					for (n1=0; n1<4; n1++) {
						if ((n1==edge_face[0][k])||(n1==edge_face[1][k])) continue;
						/* update node list of this elem, and
						   adj elem list of the nodes */
						for (n2=0; n2<3; n2++) {
							newelm->Elem.tet4.NodePtr[n2] = node[face[n2][n1]];
						}
						newelm->Elem.tet4.NodePtr[3] = newpt;
						/* check quality */
						qual = elem_assess (newelm, VOLRAT);
						avg_qual += qual;
						if (worst_qual>qual) worst_qual = qual;
						nelm1++;
					}
				}
			}
		}
		free(newpt);
		free(newelm);
		avg_qual = avg_qual / nelm1;

		/* find the best split */
		if (best_qual<avg_qual) {
			x = split[ii];
			num1 = ii;
			best_qual = avg_qual;
			worst_in_best_qual = worst_qual;
		}
	}

	if ((num1!=(-1))&&((best_qual<avg_tol)||(worst_in_best_qual<min_quali))) {
		return (BAD);
	}
	else if (num1 != (-1)) {
		/* really do the splitting */
		pt1 = nnptr[edge[0][num1]];
		pt2 = nnptr[edge[1][num1]];
		/* this element and its adjacent elems should be splitted */
		/* remove these two nodes from each other's adj list */
		remove_pt_from_nd_adj(pt1, pt2);
		remove_pt_from_nd_adj(pt2, pt1);

		/* create a new point */
		/* allocate memory for new node */
	    newpt = (MeshNode *) malloc (sizeof (MeshNode));
		if (!newpt)	alloc_error ("conform-3");
	    else
		{
			newpt->Fst_adj = NULL;
			newpt->Num_adj = 0;
			newpt->Fst_adj_elem = NULL;
			newpt->Num_adj_elem = 0;
			newpt->status  = FIXED;
			newpt->in_zone = 0;
			newpt->Mtrl = mat[num1];
			newpt->Prev = NULL;
			newpt->Next = NULL;
			for(i=0; i<3; i++) 
				newpt->Coor[i] = pt1->Coor[i] + x*(pt2->Coor[i]-pt1->Coor[i]);
	    }
		(*msh_node) ++;
		/* set up links to node list in tail */
	    newpt->Next = msh_n_head;
		newpt->Prev = msh_n_head->Prev;
	    msh_n_head->Prev->Next = newpt;
		msh_n_head->Prev = newpt;

		/* add the new pt to pt1 and pt2's adj lists */
		add_pt_2_nd_adj(pt1, newpt);
		add_pt_2_nd_adj(pt2, newpt);
		add_pt_2_nd_adj(newpt, pt1);
		add_pt_2_nd_adj(newpt, pt2);

		/* create two adjacent element lists for the two pts,
		   so that they can append the newly generated elem 
		   to their elem adj list later */
		eadd1 = create_adj_elem();
		eadd2 = create_adj_elem();
		edel  = create_adj_elem();
		nelm1 = 0;
		nelm2 = 0;
		ndel  = 0;

		/* find all the elements share this edge, split, and re-link */
		aeptr1=pt1->Fst_adj_elem;
		for (i=0; i<pt1->Num_adj_elem; i++, aeptr1=aeptr1->ptr) {
			eptr = aeptr1->idx;
			aeptr2=pt2->Fst_adj_elem;
			for (j=0; j<pt2->Num_adj_elem; j++, aeptr2=aeptr2->ptr) {
				eptr1 = aeptr2->idx;
				if (eptr==eptr1) {
					/* this elem should be splitted */
					/* figure out the edge number in this elem */
				    node=eptr->Elem.tet4.NodePtr;
					for (k=0; k<6; k++) {
						if (((node[edge[0][k]]==pt1)&&(node[edge[1][k]]==pt2)) ||
							((node[edge[0][k]]==pt2)&&(node[edge[1][k]]==pt1))) 
							break;
					}
					
					/* update node adj lists */
					add_pt_2_nd_adj(newpt, node[edge_face[0][k]]);
					add_pt_2_nd_adj(newpt, node[edge_face[1][k]]);
					add_pt_2_nd_adj(node[edge_face[0][k]], newpt);
					add_pt_2_nd_adj(node[edge_face[1][k]], newpt);

					/* create two new elements */
					for (n1=0; n1<4; n1++) {
						if ((n1==edge_face[0][k])||(n1==edge_face[1][k])) continue;
						newelm = create_an_elem(msh_l_head, msh_num_elem);
						newelm->E_type = TET4;
						newelm->attr = FITTED2;
						newelm->status = eptr1->status + 1;
						/* update node list of this elem, and
						   adj elem list of the nodes */
						for (n2=0; n2<3; n2++) {
							newelm->Elem.tet4.NodePtr[n2] = node[face[n2][n1]];
							/* append this new elem to the node's elem adj list 
							   Note, if the node is pt1 or pt2, the elem should
							   be stored in the temp adj lists first */
							if (node[face[n2][n1]]==pt1) {
								if (eadd1->idx==NULL) {
									eadd1->idx = newelm;
									ept1 = eadd1;
								}
								else {
									ept1->ptr = create_adj_elem();
									ept1->ptr->idx = newelm;
									ept1 = ept1->ptr;
								}
								nelm1 ++;
							}
							else if (node[face[n2][n1]]==pt2) {
								if (eadd2->idx==NULL) {
									eadd2->idx = newelm;
									ept2= eadd2;
								}
								else {
									ept2->ptr = create_adj_elem();
									ept2->ptr->idx = newelm;
									ept2 = ept2->ptr;
								}
								nelm2 ++;
							}
							else {
								add_elm_2_nd_adj(newelm, node[face[n2][n1]]);
							}
						}
						newelm->Elem.tet4.NodePtr[3] = newpt;
						add_elm_2_nd_adj(newelm, newpt);
					}

					ndel ++;
					/* append this elem to the deletion list */
					if (edel->idx==NULL) {
						/* the list is empty right now */
						edel->idx = eptr1;
						tmp = edel;
					}
					else {
						/* there are elem in the list */
						tmp->ptr = create_adj_elem();
						tmp = tmp->ptr;
						tmp->idx = eptr1;
					}
				}
			}
		}

		/* append temp elem adj lists to the two pts */
		ept1->ptr = pt1->Fst_adj_elem;
		pt1->Fst_adj_elem = eadd1;
		pt1->Num_adj_elem += nelm1;

		ept2->ptr = pt2->Fst_adj_elem;
		pt2->Fst_adj_elem = eadd2;
		pt2->Num_adj_elem += nelm2;

		/* update the adj elem list of the nodes before delete the elems */
		for (i=0; i<ndel; i++) {
			node = edel->idx->Elem.tet4.NodePtr;
			for (k=0; k<4; k++) remove_elm_from_nd(edel->idx, node[k]);
			/* delete the old elem */
			if ((*msh_l_head)==edel->idx) (*msh_l_head) = edel->idx->Next;
			edel->idx->Prev->Next = edel->idx->Next;
			edel->idx->Next->Prev = edel->idx->Prev;
			free(edel->idx);
			tmp = edel;
			edel = edel->ptr;
			free(tmp);
			(*msh_num_elem) --;
		}
		
		return (OK);
	}
	
	return (NONE);
}


/* local smoothing: do soomthing on elem. nodes(include bdy nodes)  and all the nodes adjacent to elem. nodes
    except the nodes on the boundary 
 */
int 
elem_smooth (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *eptr, 
             REAL smooth_criteria, int quali_type, REAL min_quali, int bdy_sm_type)
{
    int      i, k, num_p, num_smooth, dup_flag;
    int      node_mask[MAX_ADJACENT_NODES];
    long     kk;
    MeshNode **nnptr, *nptr, *smooth_list[MAX_ADJACENT_NODES];
    AdjList  *anptr;    

    num_smooth      = 0;
    switch (eptr->E_type)
    {
	    case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    default:
		    fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		    return (BAD);

    }

    /* find nodes need be smoothing */
    for (i=0; i<num_p; i++)
    {
        /* for base elem. nodes, allow bdy node to move (but not outbound nodes) */
        if (nnptr[i]->status == OUTNODE) 
                continue;  /* skip outbound nodes */

/* Ziji 1/11/99 */  /* no FIXED OR ONSPBDY nodes can be moved */
        if ((nnptr[i]->status == FIXED)||(nnptr[i]->status == ONSPBDY)||(nnptr[i]->status >0 ))
                continue;  /* skip it */

        if (nnptr[i]->Mtrl > BDY_NODE_CODE)
        {
            if (bdy_sm_type==MOVE_ELEM_BDY || bdy_sm_type==MOVE_ALL_BDY)
            {
                nnptr[i]->Mtrl = nnptr[i]->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */ 
                if (nnptr[i]->status == DONE)     nnptr[i]->status = FREE;
                if (nnptr[i]->Mtrl < 0 || nnptr[i]->Mtrl > MAX_MTRL_NUM-1)
                {
                    kk = nnptr[i]->Mtrl;
                    fprintf (Diag_file, "\nWarning...problem mtrl %ld!\n", kk);
                }
            }
            else 
                continue;
        }
        node_mask[num_smooth] = 1;
        smooth_list[num_smooth++] = nnptr[i];
    }

    for (i=0; i<num_p; i++)
    {
        /* for adjacent nodes, bdy nodes will be skiped */
        for (anptr=nnptr[i]->Fst_adj; anptr; anptr=anptr->ptr)
        {
            dup_flag = 0;
            nptr = anptr->idx;
            if (nptr == NULL)
            {
                fprintf (Diag_file, "\nError adj. node ... elem_smooth.\n");
                continue;
            }

            if (nptr->status == OUTNODE) 
                    continue; 
/* Ziji 1/11/99 */  /* no FIXED OR ONSPBDY nodes can be moved */
            if ((nptr->status == FIXED)||(nptr->status == ONSPBDY)||(nptr->status > 0))
                continue;  /* skip it */

            if (nptr->Mtrl > BDY_NODE_CODE)
            {
                if (bdy_sm_type==MOVE_ADJ_BDY || bdy_sm_type==MOVE_ALL_BDY)
                {
                    nptr->Mtrl = nptr->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */
/* Ziji 1/11/99 why??? */                    if (nptr->status == DONE)     nptr->status = FREE; 
                    if (nptr->Mtrl < 0 || nptr->Mtrl > MAX_MTRL_NUM-1)
                    {
                        kk = nnptr[i]->Mtrl;
                        fprintf (Diag_file, "\nWarning...problem mtrl %ld!\n", kk);
                    }
                }
                else
                    continue;    /* skip adj. bdy node */
            }

            /* add into the list if it's not a duplicated node */
            for (k=0; k<num_smooth; k++)
            {
                if (smooth_list[k] == nptr)
                     dup_flag = 1;
            }
            if (dup_flag)  continue;
            if (num_smooth > MAX_ADJACENT_NODES - 1)
            {
                fprintf (Diag_file, "\nSoomth list full (%d)!\n", num_smooth);
            }
            else
            {
                node_mask[num_smooth] = 1;
                smooth_list[num_smooth++] = nptr;
            }
        }
    }

    /* consistency checking */
    for (k=0; k<num_smooth; k++)
    {
        if (smooth_list[k]->status == DONE || smooth_list[k]->Mtrl > BDY_NODE_CODE)
                fprintf (Diag_file, "\nProblem node!!\n");
    }

    smooth_node_list (smooth_list, node_mask, num_smooth, bdy_l_head, 
        bdy_num_elem, smooth_criteria, quali_type, min_quali);

    return (OK);
}



int
smooth_node_list (MeshNode **smooth_list, int *node_mask, int num_smooth, 
        BMeshElem *bdy_l_head, long bdy_num_elem, REAL smooth_criteria, 
        int quali_type, REAL min_quali)
{
    int      i, k, count, num_adj;
    REAL     node_quli, dist;
    REAL     max_smooth_dist, ori_node_coor[3], new_node_coor[3];
    MeshNode *nptr;
    AdjList  *anptr;    

    count=0;
    do
    {
        if (++count > MAX_SM_ITER)
            fprintf (Diag_file, "\nSoomth count > %d (smooth criteria = %lf | max_dist = %lf)\n", 
                    MAX_SM_ITER, smooth_criteria, max_smooth_dist);

        max_smooth_dist = 0;
        for (i=0; i<num_smooth; i++)
        {
            if (node_mask[i] == -1 || smooth_list[i]->status == DONE)   continue;

            /* save original node coord. */
            for (k=0; k<3; k++)
                ori_node_coor[k] = smooth_list[i]->Coor[k];

            /* smoothing */
            num_adj = 0;
            for (k=0; k<3; k++)   new_node_coor[k] = 0.;
            for (anptr=smooth_list[i]->Fst_adj; anptr; anptr=anptr->ptr)
            {
                num_adj++;
                nptr = anptr->idx;
                for (k=0; k<3; k++)
                    new_node_coor[k] += nptr->Coor[k];
            }

            for (k=0; k<3; k++)
                new_node_coor[k] /= num_adj;

            for (k=0; k<3; k++)
                smooth_list[i]->Coor[k] = new_node_coor[k];

            /* check adj. mesh quality */
	        if (avg_quli (smooth_list[i], &node_quli, quali_type) < min_quali)
            {
                /* printf ("\nCan't disturb node %d in smooth list!\n", i); */
                /* restore original node coord. */
                for (k=0; k<3; k++)
                    smooth_list[i]->Coor[k] = ori_node_coor[k];

                continue;
            }
            else
            {
                /* record max. soomth dist */
                dist = v_rang(ori_node_coor, new_node_coor, 3);
                if (dist > max_smooth_dist)
                    max_smooth_dist = dist;
            }
        }
    } while (max_smooth_dist > smooth_criteria);

    /* do node classificatoin */
    for (i=0; i<num_smooth; i++)
    {
        if (node_mask[i] == -1 || smooth_list[i]->status == DONE)    
            continue;
        /*
        if (smooth_list[i]->status == DONE)
        {
            printf ("\nMay cause problem!!\n");
        }
        */
        single_node_classify (bdy_l_head, bdy_num_elem, smooth_list[i]);
    }
    return (OK);
}



MeshElem *
cur_elem_conform (MeshElem *msh_l_head, long msh_num_elem, MeshElem *cur_eptr, int mtrl_code)
{
    static int      idummy=0;
    int      k, ip, cur_num_p, num_p, count; 
    long     ii;
    MeshNode **cur_nnptr, **nnptr, *nptr;
    MeshElem *eptr, *st_eptr=NULL;
    AdjElem  *aeptr;

    if (cur_eptr)
    {
	    switch (cur_eptr->E_type)
	    {
	        case TET4:
		        cur_num_p = 4;
		        cur_nnptr = cur_eptr->Elem.tet4.NodePtr;
		        break;
	        case HEX8:
		        cur_num_p = 8;
		        cur_nnptr = cur_eptr->Elem.hex8.NodePtr;
		        break;
	        default:
		        fprintf (Diag_file, "\nError...Unknown element type (%d)!\n", cur_eptr->E_type);
		        goto GLOBAL;
	    }

        for (ip=0; ip<cur_num_p; ip++)
        {
           /* search adj. elem. connect to current elem. node */
           nptr = cur_nnptr[ip];

           for (aeptr = nptr->Fst_adj_elem; aeptr; aeptr = aeptr->ptr)
           {
                eptr = aeptr->idx;
                if (eptr->attr == CANNOTFIT)   continue; /* skip the elem. has been tried */
	            switch (eptr->E_type)
	            {
	                case TET4:
		                num_p = 4;
		                nnptr = eptr->Elem.tet4.NodePtr;
		                break;
	                case HEX8:
		                num_p = 8;
		                nnptr = eptr->Elem.hex8.NodePtr;
		                break;
	                default:
		                fprintf (Diag_file, "\nError...Unknown element type (%d)!\n", eptr->E_type);
		                continue;
	            }

	            count = 0;
	            for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
	            for (k=0; k<num_p; k++)
	            {
	                if (nnptr[k]->Mtrl > BDY_NODE_CODE)     continue; /* boundary node */
	                Mtrl_code[nnptr[k]->Mtrl]++;
	            }
	            for (k=0; k<MAX_MTRL_NUM; k++)
	            {
	                if (Mtrl_code[k])   count++;
	            }

                /* eptr->status = count; the status now use for count the
                   the elem. has been processed how many times! 
                */
	            if (count > 1)
                {   /* ride on mtrl. boundary */
                    if (Mtrl_code[mtrl_code]) 
		                return (eptr);   /* element cross the given conforming bdy */
                }
           }
        }
    }

    /* global searching */
GLOBAL:
    
    for (ii=0,eptr = msh_l_head; ii<msh_num_elem; ii++, eptr=eptr->Next)
    {
            if (eptr->attr == CANNOTFIT)   continue; /* skip the elem. has been tried */

	        switch (eptr->E_type)
	        {
	            case TET4:
		            num_p = 4;
		            nnptr = eptr->Elem.tet4.NodePtr;
		            break;
	            case HEX8:
		            num_p = 8;
		            nnptr = eptr->Elem.hex8.NodePtr;
		            break;
	            default:
		            fprintf (Diag_file, "\nError...Unknown element type (%d)!\n", eptr->E_type);
		            continue;
	        }

	        count = 0;
	        for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
	        for (k=0; k<num_p; k++)
	        {
	            if (nnptr[k]->Mtrl > BDY_NODE_CODE)     continue; /* boundary node */
	            Mtrl_code[nnptr[k]->Mtrl]++;
	        }
	        for (k=0; k<MAX_MTRL_NUM; k++)
	        {
	            if (Mtrl_code[k])   count++;
	        }

            /* eptr->status = count; the status now use for count the
                   the elem. has been processed how many times! 
            */
	        if (count > 1)
            {   /* ride on mtrl. boundary */
                if (Mtrl_code[mtrl_code]) 
		            return (eptr);   /* element cross the given conforming bdy */
            }
    }

    return ((MeshElem *)NULL);
}


/* added by Ziji Wu, 9/1/99 */
MeshElem *
search_cannotfit_elem (MeshElem *msh_l_head, long msh_num_elem, MeshElem *cur_eptr, int mtrl_code)
{
    int      ip, cur_num_p = 4, nmat, i, nbdy;
    MeshNode **nnptr;
    MeshElem *tmp_eptr;
	long     mat[4], bdy_mat[2][4];

    if (cur_eptr==NULL) cur_eptr = msh_l_head;

	if ((cur_eptr->Next==NULL)||(cur_eptr->Next==msh_l_head)) return ((MeshElem *)NULL);
	tmp_eptr = cur_eptr->Next;

	do {
//		if (tmp_eptr->attr==CANNOTFIT){
//		if ((tmp_eptr->attr!=FITTED)&&(tmp_eptr->attr!=CANNOTFIT2)&&(tmp_eptr->status<=CONFORM_TIMES)){
//		if ((tmp_eptr->attr==CANNOTFIT)&&(tmp_eptr->status<=CONFORM_TIMES)){
		if (((tmp_eptr->attr==CANNOTFIT)||(tmp_eptr->attr==FITTED2))&&(tmp_eptr->status<CONFORM_TIMES)){
//		if (tmp_eptr->status<=CONFORM_TIMES){
			nnptr = tmp_eptr->Elem.tet4.NodePtr;

			/* check how many different mat this elem has */
			nmat = 0;
			nbdy = 0;
	        for (ip=0; ip<cur_num_p; ip++) {
				if (nnptr[ip]->Mtrl<=BDY_NODE_CODE) {
					for (i=0; i<nmat; i++) {
						if (nnptr[ip]->Mtrl==mat[i]) goto NEXTPT;
					}
					mat[nmat] = nnptr[ip]->Mtrl;
					nmat ++;
				}
				else {
					bdy_mat[0][ip] = nnptr[ip]->Mtrl / MTRL_IN_CODE;
					bdy_mat[1][ip] = (nnptr[ip]->Mtrl-MTRL_IN_CODE*bdy_mat[0][ip])/MTRL_OUT_CODE;
					nbdy ++;
				}
NEXTPT: ;
			}

			/* if this elem crosses bdy, check if one of the node is 
			in the mat that is looking for */
			if (nmat>1) {
/*				for (i=0; i<nmat; i++) {
					if (mat[i]==mtrl_code) 
*/						return (tmp_eptr);
//				}
			}
			else if ((nmat==1)&&(nbdy==3)) {
				/* check if any other nodes (on bdy) has different mtrl */
		        for (ip=0; ip<cur_num_p; ip++) {
					if (nnptr[ip]->Mtrl<=BDY_NODE_CODE) continue;
					if ((bdy_mat[0][ip]!=mat[0])&&(bdy_mat[1][ip]!=mat[0])) return (tmp_eptr);
				}
			}
			else if (nbdy==4){
				/* check if these bdy nodes are on different bdy */
				for (i=0; i<3; i++) {
					for (ip=i+1; ip<4; ip++) {
						if ((bdy_mat[0][i]!=bdy_mat[0][ip])&&(bdy_mat[1][i]!=bdy_mat[1][ip])&&
							(bdy_mat[1][i]!=bdy_mat[0][ip])&&(bdy_mat[0][i]!=bdy_mat[1][ip]))
							return (tmp_eptr);
					}
				}

				/* check if the elem mat has been classified correctly */

			}
		}
		tmp_eptr = tmp_eptr->Next;
	} while ((tmp_eptr)&&(tmp_eptr!=msh_l_head));

    return ((MeshElem *)NULL);
}


/* find shortest distance to certain BDY */
BMeshElem *
find_conf_bdy (REAL *node, REAL *inter_pt, REAL *opt_dist, int mtrl_code,
		        BMeshElem *bdy_l_head, long bdy_num_elem)
{
    int      k;
    long     ii;
    REAL  vec0[3], dist_min, dist, limit;
    REAL  pnt[3], opt_pnt[3];
    BMeshElem *beptr, *opt_beptr; 
    MeshNode *nptr, pt;

    limit = 2. * Global_size;
    /* dump a node structure for call  pnt2bdy and initialization */
    for (k=0; k<3; k++)
    {
      vec0[k] = pt.Coor[k] = node[k];
      opt_pnt[k] = 0.;
    }
    nptr = &pt;

    opt_beptr = NULL;
    /* traverse all the bounday patches */
    dist_min = 1.e10;
    
    for (ii=0, beptr=bdy_l_head; ii<bdy_num_elem; ii++, beptr = beptr->Next)
    {
	    if (beptr->Mtrl_in == mtrl_code || beptr->Mtrl_out == mtrl_code)
	    {   /* right BDY patch */
	        /* box checking with bdy. patch */
	        if (vec0[X]+limit < beptr->xmin ||
			    vec0[X]-limit > beptr->xmax)  continue;
	        if (vec0[Y]+limit < beptr->ymin ||
			    vec0[Y]-limit > beptr->ymax)  continue;
	        if (vec0[Z]+limit < beptr->zmin ||
			    vec0[Z]-limit > beptr->zmax)  continue;

	        /* find closest bdy. patch. to move to */
            dist = pnt2bdy (nptr, beptr, pnt);
	        if (dist < dist_min)
	        {
		        dist_min = dist;
		        for (k=0; k<3; k++)    opt_pnt[k] = pnt[k];
		        opt_beptr = beptr;
	        }
	    }    
    }

    *opt_dist = dist_min;
    for (k=0; k<3; k++)   inter_pt[k] = opt_pnt[k]; 
    if (fabs (inter_pt[0] - 999) < HIGTOL)    
        return (NULL); /* no opt pnt found */

    return (opt_beptr);
}


/* find intersection points of the edges of an elem and the certain bdy 
   added by Ziji Wu, 8/30/99
*/
void
find_conf_bdy_edge (NodeInfo *node_buf, int mtrl_code,
		        BMeshElem *bdy_l_head, long bdy_num_elem, REAL *move, long *mat)
{
    int       i, j;
    long      ii;
    REAL      vec[3], vec1[3], dist, len, dir;
	REAL      pt1[3], pt2[3], a[3], b[3], c[3], r[3];
    BMeshElem *beptr; 
	REAL      xmin, ymin, zmin, xmax, ymax, zmax;
	int       edge[2][6];

	/* initialize the move indicator */
	for (i=0; i<6; i++) { move[i] = -1.; mat[i] = -1; }
	edge[0][0] = 0; 	edge[1][0] = 1;
	edge[0][1] = 0; 	edge[1][1] = 2;
	edge[0][2] = 0; 	edge[1][2] = 3;
	edge[0][3] = 1; 	edge[1][3] = 2;
	edge[0][4] = 1; 	edge[1][4] = 3;
	edge[0][5] = 2; 	edge[1][5] = 3;

	/* find the intersection */
	for (i=0; i<6; i++) {
		/* find the intersection point, wrt the first node and the edge length */
		for (j=0; j<3; j++) pt1[j] = node_buf[edge[0][i]].ori_coor[j];
		xmin = xmax = pt1[0];
		ymin = ymax = pt1[1];
		zmin = zmax = pt1[2];
		for (j=0; j<3; j++) pt2[j] = node_buf[edge[1][i]].ori_coor[j];
		if (pt2[0]>xmin) xmax = pt2[0];
		else xmin = pt2[0];
		if (pt2[1]>ymin) ymax = pt2[1];
		else ymin = pt2[1];
		if (pt2[2]>zmin) zmax = pt2[2];
		else zmin = pt2[2];
		for (j=0; j<3; j++) vec1[j] = pt2[j] - pt1[j];
	    len = v_magn(vec1, 3);

		/* traverse all the bounday patches */
		for (ii=0, beptr=bdy_l_head; ii<bdy_num_elem; ii++, beptr = beptr->Next) {
			if (beptr->Mtrl_in == mtrl_code || beptr->Mtrl_out == mtrl_code) {
				/* box checking with bdy. patch */
				if (xmax < beptr->xmin || xmin > beptr->xmax)  continue;
				if (ymax < beptr->ymin || ymin > beptr->ymax)  continue;
		        if (zmax < beptr->zmin || zmin > beptr->zmax)  continue;

			    /* find closest bdy. patch. to move to */
				for (j=0; j<3; j++) {
					a[j] = beptr->Elem.tri3.NodePtr[0]->Coor[j];
					b[j] = beptr->Elem.tri3.NodePtr[1]->Coor[j] - a[j];
					c[j] = beptr->Elem.tri3.NodePtr[2]->Coor[j] - a[j];
				}

				if (ray_tri_cross_conf (pt1, pt2, a, b, c, r)==INBOUND) {
					for (j=0; j<3; j++) vec[j] = r[j] - pt1[j];
				    dist = v_magn(vec, 3)/len;
					if (dist>1.) continue;
					if ((1.-dist)<LOWTOL) {
						/* pt2 is the intersection pt */
						if (move[i] == -1.) {
							move[i] = 1.;
							mat[i] = beptr->Mtrl_in * MTRL_IN_CODE + beptr->Mtrl_out *MTRL_OUT_CODE;
						}
					}
					if (dist<LOWTOL) {
						/* pt1 is the intersection pt */
						if (move[i] == -1.) {
							move[i] = 0.;
							mat[i] = beptr->Mtrl_in * MTRL_IN_CODE + beptr->Mtrl_out *MTRL_OUT_CODE;
						}
					}

					/* not on the two edge nodes */
					dir = v_dot(vec, vec1, 3);
					if (dir<0.) continue;
					/* update the current edge info */
					if (move[i]==-1.) {
						move[i] = dist;
						mat[i] = beptr->Mtrl_in * MTRL_IN_CODE + beptr->Mtrl_out *MTRL_OUT_CODE;
					}
				    else if (fabs(dist-0.5) < fabs(move[i]-0.5)) {
						move[i] = dist;
						mat[i] = beptr->Mtrl_in * MTRL_IN_CODE + beptr->Mtrl_out *MTRL_OUT_CODE;
			        }
				}
			}
		}
	}

	return;
}


/* sort the nodes (in same mtrl set) in distance */
void
sort_nod_mtrl (int *nd_idx, NodeInfo *node_buf, int num_mov, int mov_mtrl)
{
    int j, k, idx=0, itmp;

    for (k=0; k<4; k++)
    {
        if (node_buf[k].set == mov_mtrl)    
                nd_idx[idx++] = k; 
    }
    
    if (num_mov != idx)   
        fprintf (Diag_file, "\nWarning...mtrl node not match! (idx=%d / num_mov=%d)\n",
                idx, num_mov);
    /*  bubble sort */
    for (j=0; j<num_mov-1; j++)
    {
        for (k=0; k<num_mov-1-j; k++)
            if (node_buf[nd_idx[k]].mov_dist > node_buf[nd_idx[k+1]].mov_dist)
            {
                itmp = nd_idx[k];    nd_idx[k] = nd_idx[k+1];   nd_idx[k+1] = itmp;
            }
    }
}



/* find a set of ray direction to shoot to */
int
ray_dir (REAL *src, REAL *dest, REAL delta, int num_dir, 
         REAL *nx, REAL *ny, REAL *nz)
{
    int    i, k;
    REAL dt, ecs_x, ecs_y, dotp;
    REAL extrusion[3], ecs2wcs_mat[9], vec[3], tmp[3];

    for (k=0; k<3; k++) vec[k] = extrusion[k] = src[k] - dest[k];
    
    if (mk_ecs2wcs_mat (extrusion, ecs2wcs_mat)==BAD)
    {
        fprintf (Diag_file, "\nCan't create ecs2wcs matrix!\n");
        return (BAD);
    }

    dt = 2*PI / num_dir;
    for (i=0; i<num_dir; i++)
    {
        ecs_x = delta * cos (dt*(REAL)i);
        ecs_y = delta * sin (dt*(REAL)i);
        /* pnt multiply from right 
        xfwm2v(ecs2wcs_mat, ecs_x, ecs_y, 0.0, &tmp[0], &tmp[1], &tmp[2]);
        */
        /* (try it) pnt multiply from left */
        xfv2w(ecs2wcs_mat, ecs_x, ecs_y, 0.0, &tmp[0], &tmp[1], &tmp[2]);
        
        /* check dot product, should be zero */
        dotp = v_dot(vec, tmp, 3);
        if (dotp > LOWTOL)
            fprintf (Diag_file, "\nDot product should be zero (%lf)??\n", dotp);

        /* convert to the direction shooting from src pnt */
        for (k=0; k<3; k++) tmp[k] = tmp[k] + dest[k] - src[k];
        v_norm(tmp, 3);
        nx[i] = tmp[0];   ny[i] = tmp[1];    nz[i] = tmp[2];
    }

    return (OK);
}




/* find the distance and intersection point (if it has one) between a ray
   and bdy patch. if return 1.e10 and pnt[*]=999. --- no intersection pnt
*/
REAL
ray2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *ray, REAL *pnt)
{
   int  k, cross_type;
   REAL dist;
   REAL a[3], b[3], c[3], d[3], e[3], r[3];
   BMeshNode *n[3];

   dist = XHUGE;

   /* pass the node ptr. of the bdy. patch */
   for (k=0; k<3; k++)  n[k] = beptr->Elem.tri3.NodePtr[k];

   /* define vector a, b, c for tri-patch */
   for (k=0; k<3; k++)  a[k] = n[0]->Coor[k];
   for (k=0; k<3; k++)  b[k] = n[1]->Coor[k] - a[k];
   for (k=0; k<3; k++)  c[k] = n[2]->Coor[k] - a[k];

   /* define a ray from given to patch in the normal direction of the patch */
   for (k=0; k<3; k++)  d[k] = nptr->Coor[k];

   /* determin end point of the ray */
   for (k=0; k<3; k++)    e[k] = d[k] + ray[k]*Max_size * 8;

   /* checking intersection */
   cross_type = ray_tri_cross_conf (d, e, a, b, c, r);

   for (k=0; k<3; k++)    pnt[k] = 999.;   /* set as default */
   if (cross_type == INBOUND || cross_type == ONEDGE)
   {  /*determin the distance to bdy and pass the Coor.of intersected point */ 
      dist = v_rang(d, r, 3);
      for (k=0; k<3; k++)   pnt[k] = r[k];
   }

   return (dist);
}



/*
     The function to find intersection point between a ray
     and a trianglar plane.

     input:   line (two endpoints) --- d[3] , e[3]
	      trianglar plane --- d[3], a[3], b[3]
				  a: a vector from origin to first node
				  b: a vector from first node to second node
				  c: a vector from first node to third node
			   2
			        *
		       b  *   *
		   1     *      *
		       *  *   *  *  3
		 a   *        c
		   *
	   o *
      output:   r --intersection point with the unbound plane defined by the
		    trianglation.

      return:   0 --- OUTBOUND;     INBOUND --- inbound;    
          NOTCROSS--- no inter.pnt. PARALLEL ---  parallel
		  COPLANE --- co-plane;     ONEDGE --- the start node d on the bdy
*/
int
ray_tri_cross_conf (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r)
{
      REAL t, u, w, x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4;
      REAL bxc[3], cxe[3], bxe[3], ee[3], dp1, dp2, dp3;
      int  inbound = OUTBOUND;


      r[0] = r[1] = r[2] = 0.0;
      ee[0] = e[0] - d[0];
      ee[1] = e[1] - d[1];
      ee[2] = e[2] - d[2];

      /*
	 CALCULATE t : the parameter from node d to intersection point along
		       the straight lin d --> e
      */
      bxc[0]=b[1]*c[2]-b[2]*c[1];
      bxc[1]=b[2]*c[0]-b[0]*c[2];
      bxc[2]=b[0]*c[1]-b[1]*c[0];
      dp1=bxc[0]*a[0]+bxc[1]*a[1]+bxc[2]*a[2];
      dp2=bxc[0]*d[0]+bxc[1]*d[1]+bxc[2]*d[2];
      dp3=bxc[0]*ee[0]+bxc[1]*ee[1]+bxc[2]*ee[2];

      /* If (BxC).E = 0 then the line segment and the plane are parallel */

      if ( fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      t=(dp1-dp2)/dp3;

      /* check ray direction  */
      if (t < 0.)
      {
          return (NOTCROSS);
      }
      /* find instersection point with unbound plane */
      if (t >= 0.0 && t <= 1.0)
      {
	    r[0] = d[0] + t*ee[0];
	    r[1] = d[1] + t*ee[1];
	    r[2] = d[2] + t*ee[2];
      }
      else
      {   /* out of the range */
	    return (inbound = OUTBOUND);
      }

      /*
	    CALCULATE u --- parmeter for vector b  u=[0,1]
      */
      cxe[0]=c[1]*ee[2]-c[2]*ee[1];
      cxe[1]=c[2]*ee[0]-c[0]*ee[2];
      cxe[2]=c[0]*ee[1]-c[1]*ee[0];
      dp1=cxe[0]*d[0]+cxe[1]*d[1]+cxe[2]*d[2];
      dp2=cxe[0]*a[0]+cxe[1]*a[1]+cxe[2]*a[2];
      dp3=cxe[0]*b[0]+cxe[1]*b[1]+cxe[2]*b[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }
      u = (dp1-dp2)/dp3;
      if (u < 0.0 || u > 1.0)   return (inbound = OUTBOUND);   /* outbound */

      /*
	    CALCULATE w ---- parameter for vector c w=[0,1]
      */

      bxe[0]=b[1]*ee[2]-b[2]*ee[1];
      bxe[1]=b[2]*ee[0]-b[0]*ee[2];
      bxe[2]=b[0]*ee[1]-b[1]*ee[0];
      dp1=bxe[0]*d[0]+bxe[1]*d[1]+bxe[2]*d[2];
      dp2=bxe[0]*a[0]+bxe[1]*a[1]+bxe[2]*a[2];
      dp3=bxe[0]*c[0]+bxe[1]*c[1]+bxe[2]*c[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      w=(dp1-dp2)/dp3;

      /* the if--else if -- else check has to follow the sequence! */
      if(w < 0. ||  u+w > 1.0)
      {
	    /* outbound */
	    return (inbound = OUTBOUND);
      }
      else if (fabs (t) < HIGTOL)
      { /* the start node d (tested node) is on the plane */
	    return (inbound = ONPLANE);
      }
      else if (fabs (u) < HIGTOL || fabs (w) < HIGTOL || fabs (u+w) < HIGTOL)
      {
	    /* ON the edge of tri-patch */
	    return (inbound = ONEDGE);
      }
      else
      {
	    /* inbound */
	    inbound = INBOUND;
      }

EXIT:
      if (inbound == PARALLEL)
      {
	    /* check co-plane */
	    /* following three nodes define a plane */
	    x1 = a[0];      y1 = a[1];       z1 = a[2];
	    x2 = a[0]+b[0]; y2 = a[1]+b[1];  z2 = a[2]+b[2];
	    x3 = a[0]+c[0]; y3 = a[1]+c[1];  z3 = a[2]+c[2];
	    /* check fourth node for co-plane */
	    x4 = d[0];      y4 = d[1];       z4 = d[2];
	    u = (x4-x1)*(y2-y1)*(z3-z1)
	        +(y4-y1)*(z2-z1)*(x3-x1)
	        +(z4-z1)*(x2-x1)*(y3-y1);

	    w = (z4-z1)*(y2-y1)*(x3-x1)
	        +(y4-y1)*(x2-x1)*(z3-z1)
	        +(x4-x1)*(z2-z1)*(y3-y1);

	    t = u - w;

	    if (fabs (t) < HIGTOL)   
	    {
	        inbound = COPLANE;      /* co-plane */
	    }
      }

      return (inbound);
}



/* find best move to certain BDY */
int
find_opt_ray (BMeshElem *bdy_l_head, long bdy_num_elem, int num_dir, 
              REAL *nx, REAL *ny, REAL *nz, int mtrl_code, 
              MeshElem *cur_eptr, MeshNode *nptr, int quali_type, REAL min_quali,
              REAL *inter_pt, REAL *opt_dist, REAL *out_quali, BMeshElem **out_bdy_ptr)
{
    int      i, k, iopt=BAD, count;
    long     ii;
    REAL  ray[3], limit;
    REAL  vec0[3], dist_min, sub_dist_min, dist, quali, opt_quali;
    REAL  pnt[3], opt_pnt[3], sub_opt_pnt[3];
    REAL  node_avg_quli[4];
    BMeshElem *beptr, *opt_beptr, *sub_opt_beptr; 

    for (k=0; k<3; k++)   vec0[k] = nptr->Coor[k];
    opt_beptr = sub_opt_beptr = NULL;
    dist_min = sub_dist_min = XHUGE;
    opt_quali = -XHUGE;
    *out_bdy_ptr = NULL;
    *opt_dist    = -XHUGE;
    *out_quali   = 0.0;
    limit = 2.* Global_size;

    /* traversal all the bounday patches */
    for (i=0; i<num_dir; i++)
    {
        ray[0] = nx[i];   ray[1] = ny[i];   ray[2] = nz[i];
        sub_dist_min  = XHUGE;
        sub_opt_beptr = NULL;
        count = 0;
        for (ii=0, beptr=bdy_l_head; ii<bdy_num_elem; ii++, beptr = beptr->Next)
        {
	        if (beptr->Mtrl_in == mtrl_code || beptr->Mtrl_out == mtrl_code)
	        {   /* right BDY patch */
	            /* box checking with bdy. patch */
	            if (vec0[X]+limit < beptr->xmin ||
			        vec0[X]-limit > beptr->xmax)  continue;
	            if (vec0[Y]+limit < beptr->ymin ||
			        vec0[Y]-limit > beptr->ymax)  continue;
	            if (vec0[Z]+limit < beptr->zmin||
			        vec0[Z]-limit > beptr->zmax)  continue;

	            /* find closest bdy. patch. to move to */
                if ((dist=ray2bdy (nptr, beptr, ray, pnt)) < XLARGE)
                {   /* can only has one intersectio piont?? */
	                if (dist < sub_dist_min)
	                {
                        count++;
		                sub_dist_min = dist;
                        sub_opt_beptr = beptr;
		                for (k=0; k<3; k++)   sub_opt_pnt[k] = pnt[k];
	                }
                }
	        }        
        }

        if (sub_dist_min < XLARGE)
        {   /* check mesh quality */
            /* printf ("\nThe %dth direction with %d times of inter. op.",i, count); */
            /* set node coord. for quality checking */
            for (k=0; k<3; k++)   nptr->Coor[k] = sub_opt_pnt[k];

            quali = fit_tet4_test (cur_eptr, cur_eptr->Elem.tet4.NodePtr, 
                                   node_avg_quli, quali_type);

            if (quali > min_quali && quali > opt_quali)
            {
                opt_quali = quali;
                dist_min = sub_dist_min;
                iopt = i;
                for (k=0; k<3; k++)
                {
                    opt_pnt[k]  = sub_opt_pnt[k];
                    opt_beptr   = sub_opt_beptr;
                }
            }

            /* restore node coord. */
            for (k=0; k<3; k++)   nptr->Coor[k] = vec0[k];
        }
    }


    for (k=0; k<3; k++)   inter_pt[k] = opt_pnt[k]; /* it need a value anyway */
    if (opt_quali > min_quali && iopt != BAD)
    {
        *out_quali = opt_quali;
        *opt_dist  = dist_min;
        *out_bdy_ptr = opt_beptr;
    }
    return (iopt);
}


int
single_node_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		              MeshNode *nptr)
{
    int  db_flag=BAD;
    long kk;
    REAL d[3], e[3], xlen;
    BMeshElem *bdy_patch_ptr;

    if (Bdy_lst_type != BD3DMTRL)
    {
        fprintf (Diag_file, "\nWarning... NO material information(single_node_classify)!\n");
        return (BAD);
    }

    xlen = 4 * Max_size;

	d[X] = nptr->Coor[X];
	d[Y] = nptr->Coor[Y];
	d[Z] = nptr->Coor[Z];
	/* end point */

#ifdef RANDOM_VACTOR
    random_shoot_full (d, e);
#else
    e[X] = d[X] + xlen;
	e[Y] = d[Y];
	e[Z] = d[Z];
#endif
            
    /* determin where node in */
	nptr->Mtrl = nod_in_region (d, e, bdy_l_head, n_bdy_elem, 
                                            &bdy_patch_ptr);
    nptr->bdy_ptr = bdy_patch_ptr;

    /* &&& a bdy node has a ptr of bdy patch */
    if (nptr->Mtrl > BDY_NODE_CODE && nptr->bdy_ptr == NULL)
    {
        kk = nptr->Mtrl;
        fprintf (Diag_file, "\nProblem node Mtrl classification: Mtrl=%ld, bdy_ptr=%ld\n",
                kk, nptr->bdy_ptr);
    }
    
    return (OK);
}


/* check if the elem. cross the mtrl bdy */
int 
check_cross_bdy_elem (MeshNode **nnptr, int num_node)
{
    int k, num_bdy=0, mtrl_1=BAD;

    /* find a first mtrl */
    for (k=0; k<num_node; k++)
    {
        if (nnptr[k]->Mtrl > BDY_NODE_CODE)
        {
            num_bdy++;
            continue;
        }
        else
        {
            mtrl_1 = nnptr[k]->Mtrl;
            break;
        }
    }
    if (num_bdy == num_node)  return (BAD);
    for (k=0; k<num_node; k++)
        if (nnptr[k]->Mtrl <= BDY_NODE_CODE && nnptr[k]->Mtrl != mtrl_1)
            return (OK);    /* the elem. cross bdy */

    return (BAD);
}


/*  set node buffer. if the node mtrl equals given mtrl_code set as MTRL1 (set 1)
                     otherwise could be bdy node (>99)  BDY12
                     or MTRL2 (set 2)
return :   = BAD can't do conforming 
           = OK  all set don't need a conforming
           = 0   buffer created, need conformnig
*/
int 
create_node_set_buffer (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, 
           int mtrl_code, int quali_type, NodeInfo *node_buf, int *num_set_1, int *num_set_2, 
           REAL *ave_dist1, REAL *ave_dist2, REAL *loc_size_1, REAL *loc_size_2)
{
    int      i, j, k;
    REAL     quli;
    MeshNode **nnptr;
    

    *ave_dist1 = *ave_dist2 = *loc_size_1 = *loc_size_2 = 0.;
    
    /* pass elem. node to buffer */
    *num_set_1 = *num_set_2 = 0;
    nnptr = cur_eptr->Elem.tet4.NodePtr;
    for (i=0; i<4; i++)
    {
        for (j=0; j<3; j++)    node_buf[i].ori_coor[j] = nnptr[i]->Coor[j];
        if (nnptr[i]->Mtrl > BDY_NODE_CODE)
            node_buf[i].bdy_ptr = nnptr[i]->bdy_ptr;
        else
            node_buf[i].bdy_ptr = NULL; 

        node_buf[i].Mtrl    = nnptr[i]->Mtrl;
        node_buf[i].status  = nnptr[i]->status;

    }

    for (i=0; i<4; i++)
    {
        quli = avg_quli (nnptr[i], &node_buf[i].ori_quali, quali_type);
        if (quli < LOWTOL)
        {
            fprintf (Diag_file, "\nWarning... min Jacob in adj. Elem = %lf!\n", quli); 
            return (BAD);
        }
    }

    /* Material classify --- in mtrl nodes and out of mtrl node */
    /* MTRL1(set 1) -- given mtrl: mtrl_code    MTRL2(set 2) -- other than mtrl_code */
    /* classify as two set of material and bdy node */
    for (i=0; i<4; i++)
    {
	    if (nnptr[i]->Mtrl > BDY_NODE_CODE)     node_buf[i].set = BDY12;
	    else if (nnptr[i]->Mtrl == mtrl_code)
	        { node_buf[i].set = MTRL1;   (*num_set_1)++; }
	    else 
	        { node_buf[i].set = MTRL2;   (*num_set_2)++; }
    }

    if (*num_set_1== 0 || *num_set_2==0)
        return (OK);                        /* all set */

    /* find intersection point move to bdy for each elem. node */
    for (i=0; i<4; i++)
    {   /* should only do MTRL1 and MTRL2 */
        if (node_buf[i].set==MTRL1 || node_buf[i].set==MTRL2)
        {
            if (node_buf[i].bdy_ptr)
               fprintf (Diag_file, "\nWarning...confusing BDY node (1).\n");

 	        node_buf[i].bdy_ptr =
	            find_conf_bdy (node_buf[i].ori_coor, node_buf[i].mov_coor,
			                  &node_buf[i].mov_dist, mtrl_code, bdy_l_head, bdy_num_elem);
	        if (node_buf[i].bdy_ptr == NULL)
	        {
	            /* can't find intersection with BDY --- set penalty dist. */
                fprintf (Diag_file, "\nUndefined BDY patch...(conf_tet4_bdy)\n");
	            node_buf[i].mov_dist = EXTRA;
	        }
            /* figure out the direction */
            v_make(node_buf[i].ori_coor, node_buf[i].mov_coor, 3, node_buf[i].mov_dir);
            v_norm(node_buf[i].mov_dir, 3);
        }
        else
        {
            /* it's BDY node (already being fitted) */
            
            if (node_buf[i].bdy_ptr == NULL)
               fprintf (Diag_file, "\nWarning...confusing BDY node (2).\n");
            

            for (k=0; k<3; k++) 
            {
                node_buf[i].ori_coor[k] = node_buf[i].mov_coor[k];
                node_buf[i].mov_dir[k] = 0.;
            }
            node_buf[i].mov_dist = 0.; 
        }
    }

    /* find average moving distance for each set of nodes */
    for (i=0; i<4; i++)
    {
	    if (node_buf[i].set == MTRL1)
	    {
	        if (nnptr[i]->status == FIXED || nnptr[i]->status == DONE)
	            *ave_dist1 += EXTRA;
	        else
            {
	            *ave_dist1 += node_buf[i].mov_dist;
                *loc_size_1 += loc_size (nnptr[i]);
	        }
	    }
	    else if (node_buf[i].set == MTRL2)
	    {
	        if (nnptr[i]->status == FIXED || nnptr[i]->status == DONE)
	            *ave_dist2 += EXTRA;
            else
            {
	            *ave_dist2 += node_buf[i].mov_dist;
                *loc_size_2 += loc_size (nnptr[i]);
            }
	    }
    }
    *ave_dist1  /= *num_set_1;
    *ave_dist2  /= *num_set_2;
    *loc_size_1 /= *num_set_1;
    *loc_size_2 /= *num_set_2;

    return (0);
}








/* power fit */
int
power_fit_tet4 (BMeshElem *bdy_l_head, long bdy_num_elem, MeshElem *cur_eptr, int mtrl_code,
                NodeInfo *node_buf, REAL ave_dist1, REAL ave_dist2, REAL loc_size_1, REAL loc_size_2, 
                int num_set_1, int num_set_2, int quali_type, REAL min_quali)
{
    int     k, inod, nd_idx[3], undone=0, done_flag, flag;
    int     num_mov, mov_mtrl, imove, num_sub_move, round; 
    int     num_inzone, *buf_mask, zone_level, nd_zone_idx;
    REAL    *buf_x, *buf_y, *buf_z, node_avg_quli[4], smooth_criteria;
    MeshNode  **nnptr;
    /*
    REAL    quali, lsize, delta;
    REAL    nx[NUM_DIR], ny[NUM_DIR], nz[NUM_DIR];
    REAL    inter_pt[3], opt_dist;
    BMeshElem *out_bdy_ptr;
    */

    /* define influence zone */
    num_sub_move = MAX_SUB_MOVE;/* take 3 sub_move to full range moving */
    zone_level   = INFLUENT_ZONE_LEVEL;
    num_inzone = influence_zone (cur_eptr, zone_level, Zone_list, Zone_node_status);

    /* allocate buffer and pass node coord. */
    buf_x = (REAL *) malloc ((unsigned) num_inzone * sizeof (REAL));
    buf_y = (REAL *) malloc ((unsigned) num_inzone * sizeof (REAL));
    buf_z = (REAL *) malloc ((unsigned) num_inzone * sizeof (REAL));
    buf_mask = (int *) malloc ((unsigned) num_inzone * sizeof (int));
    
    if (!buf_x || !buf_y || !buf_z || !buf_mask)
        alloc_error ("conform-4");

    for (k=0; k<num_inzone; k++)
    {
        buf_x[k] = Zone_list[k]->Coor[0];
        buf_y[k] = Zone_list[k]->Coor[1];
        buf_z[k] = Zone_list[k]->Coor[2];
    }

    /* set node mask: 1=can be move   -1=don't move */
    set_node_mask (cur_eptr, Zone_list, num_inzone, MOVE_ELEM_BDY, buf_mask); 

    num_mov = 0;  /* to prevent restore coord. if create buffer skiped (or failed)*/
    round   = 100;

    flag = create_node_set_buffer (bdy_l_head, bdy_num_elem, cur_eptr, 
                 mtrl_code, quali_type, node_buf, &num_set_1, &num_set_2, 
                 &ave_dist1, &ave_dist2, &loc_size_1, &loc_size_2);

    if (flag == BAD)        
    {
        undone = 1;
        done_flag = BAD;
        goto EX2; /* can't create buffer */
    }
    else if (flag == OK)    
    {
        undone = 0;
        done_flag = OK;
        goto EX2;  /* all set */
    }

    round = 1;
    if (ave_dist1 < ave_dist2)
    {
        num_mov = num_set_1;
	    mov_mtrl = MTRL1;
    }
    else
    {
        num_mov = num_set_2;
	    mov_mtrl = MTRL2;
    }
    
RE_ENTRY:
    /* sort moving nodes in distance  num. of node (1-3) */
    if (num_mov > 3) 
    {
      done_flag = BAD;
      goto EX2;
    }
    nnptr = cur_eptr->Elem.tet4.NodePtr;

    sort_nod_mtrl (nd_idx, node_buf, num_mov, mov_mtrl);

    /* loop moving nodes */
    for (inod=0; inod<num_mov; inod++)
    {
        undone = 0;
        if (node_buf[nd_idx[inod]].mov_dist < G_factor * Global_size)
        {
            /* move in full range */
            for (k=0; k<3; k++) 
                nnptr[nd_idx[inod]]->Coor[k] = node_buf[nd_idx[inod]].mov_coor[k];

            node_buf[nd_idx[inod]].mov_quali=fit_tet4_test (cur_eptr, nnptr, 
                                                    node_avg_quli, quali_type);
            if (node_buf[nd_idx[inod]].mov_quali > min_quali)
            {
                /* good move! set bdy pointer */
                if (node_buf[nd_idx[inod]].bdy_ptr)
                {
                    nnptr[nd_idx[inod]]->bdy_ptr = node_buf[nd_idx[inod]].bdy_ptr;
                    nnptr[nd_idx[inod]]->status = DONE;
	                nnptr[nd_idx[inod]]->Mtrl = node_buf[nd_idx[inod]].bdy_ptr->Mtrl_in * MTRL_IN_CODE
		                                  + node_buf[nd_idx[inod]].bdy_ptr->Mtrl_out * MTRL_OUT_CODE;
                }
                continue;     
            }

            /* restore original coord. */
            for (k=0; k<3; k++) 
                nnptr[nd_idx[inod]]->Coor[k] = node_buf[nd_idx[inod]].ori_coor[k];

            /* mask out current node, don't MOVE when soomthing */
            nd_zone_idx = -1;
            for (k=0; k<num_inzone; k++)
            {
                if (nnptr[nd_idx[inod]] == Zone_list[k])
                {
                    nd_zone_idx = k;
                    buf_mask[k] = -1;
                    break;
                }
            }
            if (nd_zone_idx == -1)
            {
                fprintf (Diag_file, "\nError...Can't find the node in the Zone_list.\n");
                continue;
            }

            /* moving in 1/3 of full range until fits */
            for (imove=1; imove<=num_sub_move; imove++)
            {
                for (k=0; k<3; k++)  
                {
                    nnptr[nd_idx[inod]]->Coor[k] = 
                        ((double)imove/(double)num_sub_move) * node_buf[nd_idx[inod]].mov_dir[k] 
                        * node_buf[nd_idx[inod]].mov_dist
                        + node_buf[nd_idx[inod]].ori_coor[k];
                }
    
                /* do soomthing */
                smooth_criteria = loc_size_1 < loc_size_2 ? 0.1*loc_size_1 : 0.1*loc_size_2;
                smooth_node_list (Zone_list, buf_mask, num_inzone, bdy_l_head, 
                        bdy_num_elem, smooth_criteria, quali_type, min_quali);

                /* check mesh quality */
                node_buf[nd_idx[inod]].mov_quali=fit_tet4_test (cur_eptr, nnptr, 
                                                    node_avg_quli, quali_type);
                if (node_buf[nd_idx[inod]].mov_quali > min_quali)
                {
                    continue;     
                }
                else
                {
                    undone = 1;
                    /* reset MASK */
                    buf_mask[nd_zone_idx] = 1;
                    break;
                }
            }
            
            if (undone)
            {
                /* restore original coord. */
                for (k=0; k<num_inzone; k++)
                {
                    Zone_list[k]->Coor[0] = buf_x[k];
                    Zone_list[k]->Coor[1] = buf_y[k];
                    Zone_list[k]->Coor[2] = buf_z[k];
                }
                break;
            }
            else
            {
                /* good move! set bdy pointer */
                if (node_buf[nd_idx[inod]].bdy_ptr)
                {
                    nnptr[nd_idx[inod]]->bdy_ptr = node_buf[nd_idx[inod]].bdy_ptr;
                    nnptr[nd_idx[inod]]->status = DONE;
	                nnptr[nd_idx[inod]]->Mtrl = node_buf[nd_idx[inod]].bdy_ptr->Mtrl_in * MTRL_IN_CODE
		                                  + node_buf[nd_idx[inod]].bdy_ptr->Mtrl_out * MTRL_OUT_CODE;
                } 
                /* re-compute the node buffer */
                if (inod < num_mov-1)
                {
                    flag = create_node_set_buffer (bdy_l_head, bdy_num_elem, cur_eptr, 
                            mtrl_code, quali_type, node_buf, &num_set_1, &num_set_2, 
                            &ave_dist1, &ave_dist2, &loc_size_1, &loc_size_2);

                    if (flag == BAD)        
                    {
                        undone = 1;
                        goto EX;/* can't create buffer */
                    }
                    else if (flag == OK)    
                    {
                        undone = 0;
                        goto EX;  /* all set */
                    }

                }
                
                continue;
            }

            undone = 1;   /* comment out if turn on following code; */
            /* find optimum moving direction */
            /*
            lsize = loc_size (nnptr[nd_idx[inod]]);
            delta = LOC_FACTOR*lsize < DIS_FACTOR*node_buf[nd_idx[inod]].mov_dist ? LOC_FACTOR*lsize : 
                                DIS_FACTOR*node_buf[nd_idx[inod]].mov_dist;
            
            // find NUM_DIR normals of ray to shoot to BDY for trying 
            if (ray_dir (nnptr[nd_idx[inod]]->Coor, node_buf[nd_idx[inod]].mov_coor,
                            delta, NUM_DIR, nx, ny, nz)==BAD)
            {   
                // restore original coord. 
                undone = 1;
                goto EX;
            }
            // find an optimum direction to move, return the ith dir or BAD 
            // given mtrl code 
 
            if (find_opt_ray (bdy_l_head, bdy_num_elem, NUM_DIR, nx, ny, nz, mov_mtrl, 
                     cur_eptr, nnptr[nd_idx[inod]], quali_type, min_quali, inter_pt, 
                     &opt_dist, &quali, &out_bdy_ptr) == BAD)
            {
                // printf ("\npower fit can't find an opt. dir.!\n"); 
                undone = 1;
            }
            else
            {
                // set moving coord. 
                for (k=0; k<3; k++) 
                    nnptr[nd_idx[inod]]->Coor[k] = inter_pt[k];

                // set bdy pointer 
                nnptr[nd_idx[inod]]->bdy_ptr = out_bdy_ptr;
                nnptr[nd_idx[inod]]->status = DONE;
	            nnptr[nd_idx[inod]]->Mtrl = out_bdy_ptr->Mtrl_in * MTRL_IN_CODE
		                                  + out_bdy_ptr->Mtrl_out * MTRL_OUT_CODE;
            }
            */
        }
        else
        {
            fprintf (Diag_file, "\nlarge dist. to move %lf <--> (%lf)\n", 
                    node_buf[nd_idx[inod]].mov_dist, G_factor * Global_size);
            undone = 1;
            goto EX;
        }
    }


EX:
    if (undone)
    {
        if (round < 2)
        {
            round++;
            num_mov = 0;  /* to prevent restore coord. if create buffer skiped (or failed)*/
            flag = create_node_set_buffer (bdy_l_head, bdy_num_elem, cur_eptr, 
                      mtrl_code, quali_type, node_buf, &num_set_1, &num_set_2, 
                            &ave_dist1, &ave_dist2, &loc_size_1, &loc_size_2);

            if (flag == BAD)        
            {
                 undone = 1;
                 goto EX; /* can't create buffer */
            }
            else if (flag == OK)    
            {
                 undone = 0;
                 goto EX;  /* all set */
            }
            /* switch to another set of node */
            if (mov_mtrl == MTRL1)
            {
                num_mov = num_set_2;
	            mov_mtrl = MTRL2;
            }
            else
            {
                num_mov = num_set_1;
	            mov_mtrl = MTRL1;
            }
            goto RE_ENTRY;
        }
        /* restore original coord. (if num_move=0 it will skip)*/
        for (inod=0; inod<num_mov; inod++)
            for (k=0; k<3; k++) 
                nnptr[nd_idx[inod]]->Coor[k] = node_buf[nd_idx[inod]].ori_coor[k];

        /* restore node Mtrl and status */
        for (inod=0; inod<4; inod++)
        {
            nnptr[inod]->Mtrl   = node_buf[inod].Mtrl;
            nnptr[inod]->status = node_buf[inod].status;
        }
                
        Num_power_undone++;
        done_flag = BAD;
    }
    else
    {
        Num_power_fit++;
        done_flag = OK;
    }

EX2:    
    /* free buffer */
    free ((char *)buf_x);
    free ((char *)buf_y);
    free ((char *)buf_z);
    free ((char *)buf_mask);

    return (done_flag);


}




/* define an influence zone around the base element
   the nodes in the zone list in the order of level 0, 1, 2 ...
   return the number of nodes in zone.
 */
int 
influence_zone (MeshElem *eptr, int zone_level, 
                MeshNode **z_list, int *zlist_node_status)
{
    int      i, k, num_p, num_inzone, dup_flag, middle_node_flag;
    int      level_head, level_tail, level_count;
    MeshNode **nnptr, *nptr;
    AdjList  *anptr;    

    num_inzone      = 0;
    switch (eptr->E_type)
    {
	    case TET4:
		    num_p = 4;
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case HEX8:
		    num_p = 8;
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    default:
		    fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		    return (BAD);

    }

    /* find nodes inzone */
    for (i=0; i<num_p; i++)
    {
        /* for base elem. nodes */
        z_list[num_inzone++] = nnptr[i];
    }
    level_head = 0; 
    level_tail = num_p - 1;
    level_count = 0;

    while (level_count < zone_level)
    {
        for (i=level_head; i<=level_tail; i++)
        {   
            /* need to handle the case: 
            the node is not on the outer level (zone_level-1), but since
            there is no next level of nodes connected to it, it is not
            a middle level node and it has to be treated as boundary node,
            that is, it must be fixed when doing elastic conforming
            */
            middle_node_flag = 0;
            /* for adjacent nodes, bdy nodes will be skiped */
            for (anptr=z_list[i]->Fst_adj; anptr; anptr=anptr->ptr)
            {
                dup_flag = 0;
                nptr = anptr->idx;
                if (nptr == NULL)
                {
                    fprintf (Diag_file, "\nError adj. node ... elem_smooth.\n");
                    continue;
                }

                /* add into the list if it's not a duplicated node */
                for (k=0; k<num_inzone; k++)
                {
                    if (z_list[k] == nptr)
                        dup_flag = 1;
                }
                if (dup_flag)  continue;
                if (num_inzone > MAX_ADJACENT_NODES - 1)
                {
                    fprintf (Diag_file, "\nZone list full (%d)!\n", num_inzone);
                }
                else
                {
                    zlist_node_status[num_inzone] = level_count;
                    z_list[num_inzone++] = nptr;
                    /* it's a node on middle level */
                    middle_node_flag = 1;
                }
            }

            if (middle_node_flag == 0)
            {
                /* this is a bdy node */
                zlist_node_status[i] = BDY_LEVEL;
            }
        }
        level_head = level_tail + 1;
        level_tail = num_inzone - 1;
        level_count++;
    }

    return (num_inzone);
}


/* Set node mask as the boundary node moving mode 
 */
int 
set_node_mask (MeshElem *eptr, MeshNode **z_list, int num_inzone, 
               int bdy_sm_type, int *buf_mask)
{
    int      i, num_p;
    long     kk;

    switch (eptr->E_type)
    {
	    case TET4:
		    num_p = 4;
		    break;
	    case HEX8:
		    num_p = 8;
		    break;
	    default:
		    fprintf (Diag_file, "\nError...Unknown element type (%d)[elem smooth]!\n", eptr->E_type);
		    return (BAD);
    }

    /* find nodes need be smoothing */
    for (i=0; i<num_p; i++)
    {
        /* for base elem. nodes, allow bdy node to move (but not outbound nodes) */
        if (z_list[i]->status == OUTNODE) 
        {
            buf_mask[i] = -1;
            continue;  /* skip outbound nodes */
        }
/* Ziji 1/11/99 */ /* no FIXED or ONSPBDY nodes can be moved */
        if ((z_list[i]->status == FIXED)||(z_list[i]->status == ONSPBDY)||(z_list[i]->status > 0))
        {
            buf_mask[i] = -1;
            continue;  /* skip outbound nodes */
        }

        buf_mask[i] = 1;
        if (z_list[i]->Mtrl > BDY_NODE_CODE)
        {
            if (bdy_sm_type==MOVE_ELEM_BDY || bdy_sm_type==MOVE_ALL_BDY)
            {
                z_list[i]->Mtrl = z_list[i]->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */ 
                if (z_list[i]->status == DONE)     z_list[i]->status = FREE;
                if (z_list[i]->Mtrl < 0 || z_list[i]->Mtrl > MAX_MTRL_NUM-1)
                {
                    fprintf (Diag_file, "\nWarning...problem mtrl %d!\n", z_list[i]->Mtrl);
                }
            }
            else 
            {
                buf_mask[i] = -1;
                continue;
            }
        }
    }

    for (i=num_p-1; i<num_inzone; i++)
    {
        /* start from level 1 -- adjacent nodes */

        if (z_list[i]->status == OUTNODE)
        {
            buf_mask[i] = -1;
            continue; 
        }

/* Ziji 1/11/99 */ /* no FIXED or ONSPBDY nodes can be moved */
        if ((z_list[i]->status == FIXED)||(z_list[i]->status == ONSPBDY)||(z_list[i]->status > 0))
        {
            buf_mask[i] = -1;
            continue;  /* skip outbound nodes */
        }

        buf_mask[i] = 1;
        if (z_list[i]->Mtrl > BDY_NODE_CODE)
        {
            if (bdy_sm_type==MOVE_ADJ_BDY || bdy_sm_type==MOVE_ALL_BDY)
            {
                z_list[i]->Mtrl = z_list[i]->Mtrl / MTRL_IN_CODE;  /* set as inside mtrl */
                if (z_list[i]->status == DONE)     z_list[i]->status = FREE;
                if (z_list[i]->Mtrl < 0 || z_list[i]->Mtrl > MAX_MTRL_NUM-1)
                {
                    kk = z_list[i]->Mtrl;
                    fprintf (Diag_file, "\nWarning...problem mtrl %ld!\n", kk);
                }
            }
            else
            {
                buf_mask[i] = -1;
                continue;    /* skip adj. bdy node */
            }
        }
    }

    /* consistency checking */
    for (i=0; i<num_inzone; i++)
    {
        if ((z_list[i]->status == DONE || z_list[i]->Mtrl > BDY_NODE_CODE)
            && buf_mask[i] == 1)
                fprintf (Diag_file, "\nProblem node!!\n");
    }
    return (OK);
}



/* debug checking for adjlist */
int 
check_adj_node_elem_list (MeshNode *msh_n_head, long msh_num_node,
                          MeshElem *msh_l_head, long msh_num_elem)
{
    int    count;
    long   ii;
    MeshNode *nptr;
    AdjList  *anptr;
    AdjElem  *aeptr;

    nptr = msh_n_head;
    for (ii=0; ii<msh_num_node; ii++, nptr = nptr->Next)
    {
        count = 0;
        for (anptr=nptr->Fst_adj; anptr; anptr=anptr->ptr)
            count++;

        if (count != nptr->Num_adj)
            fprintf (Diag_file, "\nUnconsistant Node/Node adj. list: %d(%d) at node %ld!\n",
                    count, nptr->Num_adj, ii);

        count = 0;
        for (aeptr=nptr->Fst_adj_elem; aeptr; aeptr=aeptr->ptr)
            count++;

        if (count != nptr->Num_adj_elem)
            fprintf (Diag_file, "\nUnconsistant Node/Elem adj. list: %d(%d) at node %ld!\n",
                    count, nptr->Num_adj_elem, ii);
    }

    return (OK);
}
 

