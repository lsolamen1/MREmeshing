/* 
  ************************************************************************
  *  Mat_surf.c : Extract Material Boundary Surfaces           *   
  *                                                                      *
  *  Qingyang Zhang                           Jan. 27, 1996              *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>



#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

/*
** External Functions
*/
extern int set_elem_mtrl  (BMeshNode *bdy_n_head, long bdy_num_node,
            BMeshElem *bdy_l_head, long bdy_num_elem,
            MeshNode *msh_n_head, long msh_num_node,
            MeshElem *msh_l_head, long msh_num_elem);
extern int nd_order(MeshNode *nptr, MeshNode **nnptr, int num_p);
extern int common_plane(MeshNode **plane_1, int num_p, MeshNode **plane_2, int sub_num_p);
extern int  free_belem_list (BMeshElem *head, long num_elem);
extern int alloc_error (char *str);
extern REAL v_angl3(REAL *vec1, REAL *vec2, int ideg, int n);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);


 
/*
** Local Functions
*/
void ini_mat_surf (void);
int ext_mat_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type);
int output_numerical_surf (int surf_num);
int search_mbdy_node (MeshNode *msh_n_head, long msh_num_node, int m_code);
int set_mnode_status (MeshNode *nptr, int m_code);
int num_patch_in_list (int intface_num, MeshNode **nod_ptr, int num_patch_node);
int collect_numerical_bdy (int interface_num, MeshNode *msh_n_head, 
         long msh_num_node, MeshElem *msh_l_head, long msh_num_elem,
         int m_code);
int free_patch (Spatch *adj_patch, long num_patch);
int add_patch_list (int interface_num, MeshNode **patch_node, int num_p,
                int mtrl_left, int mtrl_right, long elem_idx);
int surf_check (int ibface); 
unsigned int shave_tepee_elem (MeshElem *msh_l_head, long msh_num_elem, int mt_code);
REAL curv_index (MeshNode *nptr, int mtrl);


#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))


BMeshElem   *CBFace, *Cur_cbptr;      /* current working BDY interface */
long        Num_patch_in_CBFace;      /* num. of tri-patch in working BDY face*/
 
  /* faces connected to given node  note that idx start form 1 */
  static int hex8_plnd[8][3][4] = {{{1, 2, 3, 4}, {1, 4, 8, 5}, {1, 5, 6, 2},},
                   {{2, 3, 4, 1}, {2, 6, 7, 3}, {2, 1, 5, 6},},
                   {{3, 4, 2, 1}, {3, 2, 6, 7}, {3, 7, 8, 4},},
                   {{4, 1, 2, 3}, {4, 8, 5, 1}, {4, 3, 7, 8},},
                   {{5, 1, 4, 8}, {5, 8, 7, 6}, {5, 6, 1, 2},},
                   {{6, 5, 7, 8}, {6, 7, 3, 2}, {6, 2, 1, 5},},
                   {{7, 6, 5, 8}, {7, 3, 2, 6}, {7, 8, 4, 3},},
                   {{8, 5, 1, 4}, {8, 7, 6, 5}, {8, 4, 3, 7}}};

  static int tet4_plnd[4][3][3] = {{{1, 3, 2}, {1, 2, 4}, {1, 4, 3},},
                   {{2, 1, 3}, {2, 4, 1}, {2, 3, 4},},
                   {{3, 2, 1}, {3, 4, 2}, {3, 1, 4},},
                   {{4, 1, 2}, {4, 2, 3}, {4, 3, 1}}};
                   
  /* faces in elem. face-node index note that idx start from 0 (!!)*/                
  static int tet4_face_idx[4][3] = {{0, 1, 3},
                                    {1, 2, 3},
                                    {2, 0, 3},
                                    {0, 2, 1}};

  static int hex8_face_idx[6][4] = {{0, 1, 2, 3},
                                    {2, 1, 5, 6},
                                    {5, 4, 7, 6},
                                    {0, 3, 7, 4},
                                    {2, 6, 7, 3},
                                    {0, 4, 5, 1}};

                   


/* initialization */
void
ini_mat_surf (void)
{
  int  k; 
  
  for (k=0; k<Num_interface; k++)
  {
      if (Num_patch_in_NFace[k] > 0)
        free_patch (NFace_head[k], Num_patch_in_NFace[k]);
  }


  Num_interface = Num_NFace = 0;
  for (k=0; k<MAX_FACE; k++)   
  {
    NFace_head[k] = NULL;
    Num_patch_in_NFace[k] = 0;
    BFace_mtrl[0][k] = BFace_mtrl[1][k] = 0;

    Num_patch_in_CBFace = 0;
  }
  CBFace = NULL;
}





/* extract numerical surfaces for given boundary interfaces */
int
ext_mat_surfaces (BMeshNode *bdy_n_head, long bdy_num_node,
          BMeshElem *bdy_l_head, long bdy_num_elem,
          MeshNode *msh_n_head, long msh_num_node,
          MeshElem *msh_l_head, long msh_num_elem, int exbdy_type)
{
  int       ibface, k, m, mt_code, m_count, cur_midx, num_exbdy;  
  int       mtrl_region_code[MAX_MTRL_NUM]; 
  unsigned int num_tepee;
  long      ii, kk, total_patch, patch_idx;
  double    xx, yy, zz;
  MeshNode  *nptr;
  FILE      *fout;
  Spatch    *pptr;
  
  /* set mtrl code for elements */
  /* it has been done on material classification
  set_elem_mtrl (bdy_n_head, bdy_num_node,
                 bdy_l_head, bdy_num_elem,
                 msh_n_head, msh_num_node,
                 msh_l_head, msh_num_elem); 
  */
                 
  /* initialize --- it may already be done in iniglb */
  ini_mat_surf ();

  /* find total number of materials */ 
  Num_NFace = 0;
  Num_interface = 0;
  m_count = cur_midx = 0; 
  cur_midx = 0;
  for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
  
  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
  {   
      if (exbdy_type == FINAL_EXBDY)    nptr->status = FREE; /* initial */
      kk = nptr->Mtrl;
      if (kk < 0 || kk > MAX_MTRL_NUM-1)  continue;
      if (Mtrl_code[kk] == 0)   Mtrl_code[kk] = 1;
  } 
  
  for (k=1; k<MAX_MTRL_NUM; k++)
  {
      if (Mtrl_code[k])  Num_interface++;
  }
        
  printf ("\nFound %d Boundary Interfaces. \n", Num_interface);
  
  /* print out material region codes */
  printf ("\nMaterial Region Code: ");
  for (k=1; k<MAX_MTRL_NUM; k++)
  {
        if (Mtrl_code[k])   printf ("%3d ", k);
  }
  printf ("\n");
  do 
  {
      printf ("\nHow many boundary surfaces need be extracted [1-%d (-1 = skip)] :", 
                Num_interface);  
      scanf ("%d", &num_exbdy);
      if (num_exbdy < 0)   return (BAD);
   } while (num_exbdy <1 || num_exbdy > Num_interface);
   
   if (num_exbdy == Num_interface)
   {
       ibface = 0;
       for (k=1; k<MAX_MTRL_NUM; k++)
            if (Mtrl_code[k])  mtrl_region_code[ibface++] = k;  
   } 
   else
   {
     ibface = 0; 
     for (m=0; m<num_exbdy; m++)
     {   
       do
       {  
           printf ("\nPlease input No. %3d material region code : ", ibface+1);
           scanf ("%d", &k);
       } while (k<1 || k>MAX_MTRL_NUM-1);
       mtrl_region_code[ibface++] = k;
     }
   }
 
   /*  set node index for export numerical surface
       since a non-isolated node at least has one adj. node
       to accelerated the output, borrow the wt field of 
       first adj node structure to save a node index and note
       the idx needs long type but wt is a double type. use
       forced type convertion and this should not lose anything
    */
    for (ii=0, nptr=Msh_node_head_ptr; ii<Msh_nodes; ii++, nptr=nptr->Next)
    {
        if (nptr->Fst_adj == NULL)
            printf ("\nNull Adj. node list at node %ld\n", ii+1);
        else
            nptr->Fst_adj->wt = (double)(ii+1);
    }
    

   
   /* Extract approximate Numerical Surface for BDY interfaces */
  for (ibface=0; ibface<num_exbdy; ibface++)
  {  
        /* material code for current BDY */
        mt_code = mtrl_region_code[ibface];     
        num_tepee = 0;

        /* search nodes on mtrl. bdy interfaces and tag them as NSURFNODE */
        if (search_mbdy_node (msh_n_head, msh_num_node, mt_code) == BAD)
        {   
            fprintf (Diag_file, "\nCan't extract material region %d!\n", mt_code);
            goto CON2;
        }  
     
        /* shave lone tepee element --- all four nodes are one boundary  
            set these element material code as its adjacent material 
        */
       
        /* num_tepee = shave_tepee_elem (msh_l_head, msh_num_elem, mt_code); */
    
        /* find curvture index for numerical boundary node */
        /*
        for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr = nptr->Next)
        {   
            if (nptr->status == NSURFNODE) 
                 nptr->curv_idx = curv_index (nptr, mt_code);
        } 
        */


        /* extract numerical boundary from tag nodes */
        if (collect_numerical_bdy (ibface, msh_n_head, msh_num_node, msh_l_head,
                                    msh_num_elem, mt_code) == BAD) 
        {  
            fprintf (Diag_file, "\nExtract No. %d material region failed!\n");
            goto CON2; 
        } 
                                     
        Num_NFace++;
        printf ("\nMtrl %d of BDY %d --> %ld of Patch in list!\n",
                mt_code, ibface, Num_patch_in_NFace[ibface]);

        /* debug checking on numerical surface */
        surf_check (ibface); 
        /* save numerical surface file */
        output_numerical_surf (ibface);
CON2:
        /* reset node status */
        
        for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr = nptr->Next)
        {
            if (nptr->status == NSURFNODE)    nptr->status = FREE;
        }
  }

  printf ("\n%d Numerical Surfaces being extracted.\n", Num_NFace);
  /* save as nml format disk file */
  /* total patches */
  total_patch = 0;
  for (ibface=0; ibface<Num_NFace; ibface++)
            total_patch += Num_patch_in_NFace[ibface];

  if (total_patch == 0)
      return (OK);
  

  /* export material boundary for examine */
  fout = fopen ("matsurf.nml", "w+t"); 
  if (fout == NULL)    return (0);

    fprintf (fout, "\n#REM  *** Numerical surface (BDY) patch file ****\n");
    fprintf (fout, "#REM (matsurf.nml) -- use mesh node list and extracted mesh elem patch\n");
    fprintf (fout, "#MODEL_NAME %s\n", Model_name);
    /* fprintf (fout, "#NUMBERING %d\n", Numbering); */
    /* currently set output always with numbering */
    fprintf (fout, "#NUMBERING  1\n");
    fprintf (fout, "#INPUT_TYPE %d\n", Input_type);
    fprintf (fout, "#ANALY_TYPE %d\n", Analy_type);
    fprintf (fout, "#DIMENSION %d\n", Dimen);
    fprintf (fout, "#MESH_TYPE %d\n", Mesh_type);
    fprintf (fout, "#GLOBAL_SIZE %g\n", Global_size);
    fprintf (fout, "#BOUND_BOX %g %g %g %g %g %g\n", 
		            BDxmin, BDymin, BDzmin, BDxmax, BDymax, BDzmax);
    fprintf (fout, "#BDY_NODES %ld\n", Msh_nodes);
    fprintf (fout, "#BDY_ELEM %ld\n", total_patch);

    fprintf (fout, "\n#REM here use mesh node, so it may have extra nodes !!\n");
    fprintf (fout, "#BDY_NODE_COOR	 %ld    3\n", Msh_nodes); 

  /* note that here borrowed the mesh node list as bdy list */
    Msh_node_curt_ptr = Msh_node_head_ptr;
    for (ii=0; ii<Msh_nodes; ii++)
    {
	    xx = Msh_node_curt_ptr->Coor[X];
	    yy = Msh_node_curt_ptr->Coor[Y];
	    zz = Msh_node_curt_ptr->Coor[Z];
	    fprintf (fout, "%10ld%10.4lf %10.4lf %10.4lf\n", ii+1,
		            xx, yy, zz);
	    Msh_node_curt_ptr = Msh_node_curt_ptr->Next;
    }

  
  fprintf (fout, "#REM Tri-patch BDY elements\n");
  fprintf (fout, "#REM TITLE PARAMETERS: NUM_ELEM, TYPE(2D: 2 /3D: 3 /MTRL INCLUDE:12 or 13)\n");
  fprintf (fout, "#BDY_ELEM_LIST	%10ld  13\n", total_patch);

  patch_idx = 0;
  for (k=0; k<Num_NFace; k++)
  {
     if (Num_patch_in_NFace[k] > 0) 
     {
         for (ii=0, pptr=NFace_head[k]; ii<Num_patch_in_NFace[k]; ii++, pptr=pptr->Next)
         {  
             /* only for trianglar patch */
	         fprintf (fout, "%10ld %10ld %10ld %10ld %4d %4d\n", ++patch_idx,
                    (long)(pptr->NodePtr[0]->Fst_adj->wt),
                    (long)(pptr->NodePtr[1]->Fst_adj->wt),
                    (long)(pptr->NodePtr[2]->Fst_adj->wt), 
                    pptr->mtrl_left, pptr->mtrl_right);
         }
     }
  }

  fprintf (fout, "\n#END_OF_FILE\n");

  /* double check */
  if (total_patch != patch_idx)
      printf ("\nUnconsistent patch : %ld (%ld)\n", total_patch, patch_idx);
  
  fclose (fout);

  return (OK);
}


                            
/* search mesh model to find mtrl. BDY node, and set node status as NSURFNODE.
 */
int 
search_mbdy_node (MeshNode *msh_n_head, long msh_num_node, int m_code)
{
  long ii, lcount;
  MeshNode *nptr;

  
  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
  {
    /* see if node status has been set */
    if (nptr->status != FREE)  continue; /* the node has been done */

    /* check node status */
    if (set_mnode_status (nptr, m_code) == BAD)
        printf ("\nError...in node status ! (search_mbdy_node)\n");
  }   

  /* debugging checking */
  lcount = 0;  
  for (ii=0, nptr=msh_n_head; ii<msh_num_node; ii++, nptr=nptr->Next)
    if (nptr->status == NSURFNODE) lcount++;

  printf ("\nNum. nodes on Numerical bdy = %ld\n", lcount);      
  return (OK);
}

 
 

/* check the node, if it could be numerical bdy. node : set as NSURFNODE

   Process: Check all the element adjacent to test node.
   an element is counted as a set of plane which is the surface
   of the element.
   if a plane which includes the test node does not share
   by a plane of another element with same mtrl., the test node is BDY node
   and all the other on this plane are BDY nodes.
   The process acturally is to find BDY plane of the mesh model.
   So, instead of treat one node at a time, it is possible to
   treat all the nodes on the plane at once, that will accelate
   the process. 
   
   To check a bdy node:
   1. node's adj. elem.list has more than two mtrl. and at least one of
      them is mtrl -- m_code 
   2. all adj. elem. with m_code but the node on a patch which did not
      share with any other patch  --- external boundary.
   3. all adj. elem. with m_code and share patch with same
      mtrl. elem. --- internal node tag as INTNODE to avoid extra checking
*/
int 
set_mnode_status (MeshNode *nptr, int m_code)
{
  int      other_than_flag, with_code_flag, count, sub_count;
  int      i, j, k, id, jd, num_p, sub_num_p;
  int      num_elm_nod, sub_num_elm_nod, share_flag;
  
  MeshNode **nnptr, **sub_nnptr, *plane_1[4], *plane_2[4];
  MeshElem *eptr, *sub_eptr;
  AdjElem  *adeptr, *sub_adeptr;

  /* set pointer to first node of adj. element list. */
  adeptr = nptr->Fst_adj_elem;
  if (adeptr == NULL)           
  {
    printf ("\nDangling node!!\n");
    return (BAD);  /* the node did not connect to elem. */
  } 
  
  /* quick check */
  other_than_flag = with_code_flag = 0;
  count = 0;
  while (adeptr)
  {
      if (++count > nptr->Num_adj_elem)
      {
       printf ("\nWrong adj_elem counter(1) %d. \n", nptr->Num_adj_elem);
       break;
      }
      eptr = adeptr->idx;
      if (eptr->Mtrl_in == m_code)    with_code_flag  = 1;
      else                            other_than_flag = 1;
      adeptr = adeptr->ptr;    
  } 
  
  if (with_code_flag == 0)
  {
     /* not the case, skip */
     return (0);
  }
  else if (with_code_flag && other_than_flag)   
  {
     /* BDY node */
     nptr->status = NSURFNODE;
     return (OK);
  } 
  
  /* other_than_flag == 0 --- all adj. elem are m_code. check external bdy or internal nodes */
  adeptr = nptr->Fst_adj_elem;
  count = 0;
  while (adeptr)
  {
      /* set base element */
      eptr = adeptr->idx;
      if (eptr->Mtrl_in != m_code)
      {  
         /* not the case --- skip it */ 
         printf ("\nThis case should not be occured (base elem)!\n");
         adeptr = adeptr->ptr;
         continue;
      }
      /* check elem. type */
      switch (eptr->E_type)
      {
         case TET4:
            num_elm_nod = 4;
            num_p = 3;  /* triangle plane has three nodes */
            nnptr = eptr->Elem.tet4.NodePtr;
            break;
         case HEX8:
            num_elm_nod = 8;
            num_p = 4;  /* rectaglar plane has three nodes */
            nnptr = eptr->Elem.hex8.NodePtr;
            break;
         default:
            num_elm_nod = BAD;
            num_p = BAD;
            printf ("\nError...Unknown element type!\n");
            return (BAD);
      }

      /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
      if ((id=nd_order(nptr, nnptr, num_elm_nod)) == BAD)
      {
        printf ("\nError in nd_order (id)\n");  
        return (BAD);
      }  
     
      /* 3 face in the elem. connected to the node */
      for (i=0; i<3; i++)
      {
        /* set base plane 1 for searching */
        switch (eptr->E_type)
        {
            case TET4:
                for (k=0; k<num_p; k++)
                    plane_1[k] = nnptr[tet4_plnd[id][i][k] - 1];
                break;
            case HEX8:
                for (k=0; k<num_p; k++)
                     plane_1[k] = nnptr[hex8_plnd[id][i][k] - 1];
                break;
        }

        /* initial flag */
        share_flag = 0; 
        
        /* set sub-adj. to start */
        sub_adeptr = nptr->Fst_adj_elem;
        sub_count = 0;
        while (sub_adeptr)
        {
            if (sub_adeptr == adeptr)
            {   
                /* this is base elem. in adj. elem. list  --- skip */
                sub_adeptr = sub_adeptr->ptr;
                continue;
            }
            /* set sub-elem */
            sub_eptr = sub_adeptr->idx; 
            
            if (sub_eptr->Mtrl_in != m_code)
            {  
                /* not the case --- skip it */ 
                printf ("\nThis case should not be occured (sub elem)!\n");
                sub_adeptr = sub_adeptr->ptr;
                continue;
            }
            
            /* check sub-elem. type */
            switch (sub_eptr->E_type)
            {
                case TET4:
                    sub_num_elm_nod = 4;
                    sub_num_p = 3; /* triangle plane has three nodes */
                    sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
                    break;
                case HEX8:
                    sub_num_elm_nod = 8;
                    sub_num_p = 4; /* rectaglar plane has three nodes */
                    sub_nnptr = sub_eptr->Elem.hex8.NodePtr;
                    break;
                default:
                    sub_num_elm_nod = BAD;
                    sub_num_p = BAD;
                    printf ("\nError...Unknown element type!\n");
                    return (BAD);
            }

            /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
            if ((jd=nd_order(nptr, sub_nnptr, sub_num_elm_nod)) == BAD)
            {
                printf ("\nBAD nd_order (sub jd)\n");
                return (BAD);
            }
            
            /* 3 faces in sub. elem, which connected to base node */
            for (j=0; j<3; j++)
            {
                /* set sub plane 2 for comparing with */
                switch (sub_eptr->E_type)
                {
                    case TET4:
                        for (k=0; k<sub_num_p; k++) 
                            plane_2[k] = sub_nnptr[tet4_plnd[jd][j][k] - 1];
                        break;
                    case HEX8:
                        for (k=0; k<sub_num_p; k++)
                            plane_2[k] = sub_nnptr[hex8_plnd[jd][j][k] - 1];
                        break;
                }
                /*
                // check plane property: if both elem. share the plane,
                // it is an internal plane. but the nodes on the plane
                // may not be internal nodes. it needs more checking.
                */
                share_flag = common_plane (plane_1, num_p, plane_2, sub_num_p);
                if (share_flag == OK)   break;  /* quit from for loop */
                                                /* use two 'break's to avoid use goto */
            }
            if (share_flag == OK)   break;      /* quit from while loop */
            sub_adeptr = sub_adeptr->ptr;
        }

        if (share_flag != OK) 
        {
            /* the base plane did not share with another element. So
            it is a BDY plane and all the nodes on the plane are
            BDY nodes which need to be fitted to BDY surface.
            set all the plane as NSURFNODE to reduce search time.
            */
            for (k=0; k<num_p; k++)
            {
                if (plane_1[k]->status == FREE)
                    plane_1[k]->status = NSURFNODE;
            }

            /* debug checking */
            if (nptr->status != NSURFNODE)  printf ("\nFailed in node_status!!\n");
           
            /* return at this point to avoid duplication search */
            return 0;
        }
      } /* end for (i=0; i<3; ....) */

     adeptr = adeptr->ptr;
  }

  return 0;
}


 
 
 
/* collect numerial surface for given material interfae.
    //Note that:  the previous check has determine which node are the BDY node
    //           and taged as NSURFNODE 
    //a numerical bdy face should be a face shared by m_code mtrl elem. with
    //a elem. of other mtrl or 0 mtrl.
    //if a elem. share all its four faces with other mtrl. that's a kind of 
    //odd elem. (dangling elem??) No elem can have its all faces as numerical faces
*/
int
collect_numerical_bdy (int interface_num, MeshNode *msh_n_head, 
                       long msh_num_node, MeshElem *msh_l_head, 
                       long msh_num_elem, int m_code)
{ 
  unsigned int num_skip = 0;
  int      j, k, not_all_flag, jd, num_f, num_p, sub_num_p; 
  int      local_num_face, mtrl_left, mtrl_right;
  int      share_flag, sub_num_elm_nod, iface, inode, num_elm_nod;   
  long     ii;
  MeshNode *nptr, **nnptr, **sub_nnptr, *plane_1[4], *plane_2[4];
  MeshElem *eptr, *sub_eptr;
  AdjElem  *sub_adeptr;

 
  if (NFace_head[interface_num] || Num_patch_in_NFace[interface_num]) 
  {
     printf ("\nWarning...It is not a NULL header !!\n"); 
     return (BAD);
  }  
  /* go through elem. had same bdy_code */ 
  for (ii=0, eptr=msh_l_head; ii<msh_num_elem; ii++, eptr = eptr->Next)
  {
     if (eptr->Mtrl_in != m_code)
     {  /* skip other mtrl */
        continue;
     }
     mtrl_left = eptr->Mtrl_in; 
     /* check elem. type */
     switch (eptr->E_type)
     {
        case TET4:
            num_elm_nod = 4; 
            num_f = 4;  /* tet elem. has 4 faces */
            num_p = 3;  /* triangle plane has three nodes */
            nnptr = eptr->Elem.tet4.NodePtr;
            break;
        case HEX8:
            num_elm_nod = 8;
            num_f = 6;  /* brick elem. has 6 faces */
            num_p = 4;  /* rectaglar plane has four nodes */
            nnptr = eptr->Elem.hex8.NodePtr;
            break;
        default:
            num_elm_nod = BAD;
            num_p = BAD;
            printf ("\nError...Unknown element type!\n");
            return (BAD);
     }
     /* 
        // check if all the element nodes are 'NSURFNODE' -- it will form a
        // closed surface and cause 'over' face edge (use more than twice)
        // this type of element is 'tepee' element.
     */

     j = 0;
     for (k=0; k<num_elm_nod; k++)
        if (nnptr[k]->status == NSURFNODE)   j++;

     /* should not skip! do extra checking */
     /* 
     //if (j == num_elm_nod)
     //{  // skip tepee element  
     //   num_skip++;
     //   continue; 
     //}
     */
     

     local_num_face = 0;     
     /* chek all the elem. faces */
     for (iface=0; iface<num_f; iface++)
     {  
        /* pass node pointers */
        switch (eptr->E_type)
        {
            case TET4:
                for (k=0; k<num_p; k++) 
                      plane_1[k] = nnptr[tet4_face_idx[iface][k]];
                break;
            case HEX8:
                for (k=0; k<num_p; k++)
                      plane_1[k] = nnptr[hex8_face_idx[iface][k]];
                break;
        }  
        
        /* check all the nodes on face */  
        not_all_flag = 0;
        for (inode=0; inode<num_p; inode++)
            if (plane_1[inode]->status != NSURFNODE)   not_all_flag = 1;
     
        if (not_all_flag == 1)
        {
            /* not a numerial face. skip to next face */
            continue;
        } 
        
        /*  all nodes on face are numerical bdy nodes */  
        /*  a real bdy face should not share the face with another
            element with same material
            or above statement equals that if the face is shared with another
            face of same mtrl elem. then the face is not a bdy face
            pick arbitry node on base plane for checking
        */
        
        nptr = plane_1[0];
        /* initial flag */
        share_flag = 0; 
        
        /* set sub-adj. to start */
        sub_adeptr = nptr->Fst_adj_elem;
        while (sub_adeptr)
        {
            if (sub_adeptr->idx == eptr)
            {   
                /* this is base elem. in adj. elem. list  --- skip */
                sub_adeptr = sub_adeptr->ptr;
                continue;
            }
            /* set sub-elem */
            sub_eptr = sub_adeptr->idx; 
            /*
            if (sub_eptr->Mtrl_in != m_code)
            {  
                // not the case --- skip it 
                // printf ("\nThis case should not be occured (collec. sub elem)!\n");
                //
                sub_adeptr = sub_adeptr->ptr;
                continue;
            }
            */
            

            mtrl_right = sub_eptr->Mtrl_in; 
            /* check sub-elem. type */
            switch (sub_eptr->E_type)
            {
                case TET4:
                    sub_num_elm_nod = 4;
                    sub_num_p = 3; /* triangle plane has three nodes */
                    sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
                    break;
                case HEX8:
                    sub_num_elm_nod = 8;
                    sub_num_p = 4; /* rectaglar plane has three nodes */
                    sub_nnptr = sub_eptr->Elem.hex8.NodePtr;
                    break;
                default:
                    sub_num_elm_nod = BAD;
                    sub_num_p = BAD;
                    printf ("\nError...Unknown element type(colle. !\n");
                    return (BAD);
            }

            /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
            if ((jd=nd_order(nptr, sub_nnptr, sub_num_elm_nod)) == BAD)
            {
                printf ("\nBAD nd_order (sub jd)\n");
                return (BAD);
            }
            
            /* 3 faces in sub. elem, which connected to base node */
            for (j=0; j<3; j++)
            {
                /* set sub plane 2 for comparing with */
                switch (sub_eptr->E_type)
                {
                    case TET4:
                        for (k=0; k<sub_num_p; k++) 
                            plane_2[k] = sub_nnptr[tet4_plnd[jd][j][k] - 1];
                        break;
                    case HEX8:
                        for (k=0; k<sub_num_p; k++)
                            plane_2[k] = sub_nnptr[hex8_plnd[jd][j][k] - 1];
                     break;
                }

                /* check plane property: if both elem. share the plane,
                it is an internal plane. but the nodes on the plane
                may not be internal nodes. it needs more checking.
                */
                share_flag = common_plane (plane_1, num_p, plane_2, sub_num_p);
                if (share_flag == OK)   break;  /* quit from for loop */
                                                /* use two 'break's to avoid use goto */
            }
            if (share_flag == OK)   break;      /* quit from while loop */
            sub_adeptr = sub_adeptr->ptr;
        }

        /*
        if (share_flag == OK) 
        {                                
            // not a real bdy face 
            // continue;
        }
        */
        
        
        if (share_flag == OK)
        {
            if (mtrl_left == mtrl_right)
                continue;
        }
        else
            mtrl_right = 0;
        
        
        local_num_face++;
        /* found a numerical bdy face, check if in patch list, add it into list */
        if (num_patch_in_list (interface_num, plane_1, num_p) == OK) continue;

        /* add new patch into patch list */
        if (add_patch_list (interface_num, plane_1, num_p, mtrl_left, mtrl_right, ii) == BAD)
        {
            printf ("\nError in adding a patch into list!\n");
        }
        
     }  /* end of iface for loop */  
     if (local_num_face >= num_f)
         printf ("\nOdd elem.: %d faces extracted!\n", local_num_face);
  }     
     
  printf ("\n%d element being skiped when collect numerical surface.\n", num_skip);
  
  return (OK);
}

 
 
 

/* check if the face was in the main patch list */
int 
num_patch_in_list (int intface_num, MeshNode **nod_ptr, int num_patch_node)
{
    int k;
    long   num_patch, ipatch;
    MeshNode *plane_2[4];
    Spatch *head_pptr, *cur_pptr;

  head_pptr = NFace_head[intface_num]; 
  num_patch = Num_patch_in_NFace[intface_num];
  
  for (ipatch=0, cur_pptr=head_pptr; ipatch<num_patch; ipatch++, cur_pptr = cur_pptr->Next)
  { 
    for (k=0; k<num_patch_node; k++)
            plane_2[k] = cur_pptr->NodePtr[k]; 
            
    if (common_plane (nod_ptr, num_patch_node, plane_2, num_patch_node) == OK)
            return (OK); 
  } /* ipatch loop */

  return (BAD);

}



/* free a patch list */
int
free_patch (Spatch *adj_patch, long num_patch)
{
  long   ii=0;  
  Spatch *cur_pptr, *next_pptr;
    
  cur_pptr = adj_patch;
  for (ii=0; ii<num_patch; ii++)
  {
      next_pptr = cur_pptr->Next;
      if (cur_pptr)   free ((char *) cur_pptr);
      cur_pptr = next_pptr;
  }

  return (0);
}

/* add a patch into numerical patch list */
int
add_patch_list (int interface_num, MeshNode **patch_node, int num_p,
                int mtrl_left, int mtrl_right, long elem_idx)
{
    int k, patch_type;
    Spatch *pptr; 
    
    static Spatch *last_pptr;

     
    /* set patch type */
    if (num_p == 3)         patch_type = TET4;
    else if (num_p == 4)    patch_type = HEX8; 
    else 
    {
        printf ("\nWarning... Current unhandled type num_p = %d!\n", num_p);
        return (BAD);
    }
    
    if (NFace_head[interface_num] == NULL)
    { 
       /* setup the first patch to fit BDY interface */
       NFace_head[interface_num] = (Spatch *) malloc (sizeof (Spatch)); 
       if (!NFace_head[interface_num])    alloc_error ("matsurf-1");  
       Num_patch_in_NFace[interface_num] = 1;  /* num. of numerical surface */
       for (k=0; k<num_p; k++) 
       {
           NFace_head[interface_num]->NodePtr[k] = patch_node[k];
           NFace_head[interface_num]->edge_access_num[k] = 1;
       }
       NFace_head[interface_num]->patch_type = patch_type; 
       NFace_head[interface_num]->mtrl_left  = mtrl_left;
       NFace_head[interface_num]->mtrl_right = mtrl_right;
       NFace_head[interface_num]->elem_idx   = elem_idx;
       last_pptr = NFace_head[interface_num];
       NFace_head[interface_num]->Next = NULL;  
       NFace_head[interface_num]->Prev = NULL;  
    } 
    else
    {
       pptr = (Spatch *) malloc (sizeof (Spatch)); 
       if (!pptr) alloc_error ("matsurf-2");  
       Num_patch_in_NFace[interface_num]++;
       for (k=0; k<num_p; k++) 
       {
            pptr->NodePtr[k] = patch_node[k];
            pptr->edge_access_num[k] = 1;
       }
       pptr->patch_type = patch_type;
       pptr->mtrl_left  = mtrl_left;
       pptr->mtrl_right = mtrl_right;
       pptr->elem_idx   = elem_idx;
       pptr->Next = NULL; 
       pptr->Prev = last_pptr;
       last_pptr->Next = pptr;
       last_pptr = pptr;
    }

    return (OK);
}



/* check numerical surface properties */
int
surf_check (int ibface) 
{ 
  int  ia, ib, k, done_flag, num_p, sub_num_p;
  long ii, jj, num_done, num_patch, num_open, num_over; 
  MeshNode *nptr1, *nptr2, *sub_nptr1, *sub_nptr2;
  /* MeshNode *plane_1[4], *plane_2[4]; */
  Spatch *pptr, *sub_pptr; 
  
  /* set edge access number */
  num_patch = Num_patch_in_NFace[ibface];
  
  for (ii=0, pptr=NFace_head[ibface]; ii<num_patch-1; ii++, pptr=pptr->Next)
  { 
    if (pptr->patch_type == TET4)        num_p = 3;
    else if (pptr->patch_type == HEX8)   num_p = 4; 
    else 
    {
        printf ("\nWarning(surf_check)... Current unhandled type num_p = %d!\n", num_p);
        return (BAD);
    }
    /*
    for (k=0; k<num_p; k++) plane_1[k] = pptr->NodePtr[k]; 
    */
    
    for (jj=ii+1, sub_pptr=pptr->Next; jj<num_patch; jj++, sub_pptr=sub_pptr->Next)
    {   
        if (sub_pptr->patch_type == TET4)        sub_num_p = 3;
        else if (sub_pptr->patch_type == HEX8)   sub_num_p = 4; 
        else 
        {
            printf ("\nWarning(surf_check_sub)... Current unhandled type num_p = %d!\n", num_p);
            return (BAD);
        } 
        /* match edges between base patch and current patch */
        if (num_p != sub_num_p)
        {
            printf ("\nUnmatched patch type: base=%d (sub=%d)\n", num_p, sub_num_p);
        }
        /*
        for (k=0; k<sub_num_p; k++) plane_2[k] = sub_pptr->NodePtr[k]; 
        
        if (common_plane (plane_1, num_p, plane_2, sub_num_p) == OK)
        {
            printf ("\nDuplicated patch %ld <==> %ld!\n", ii, jj);
        }
        */

        for (ia=0; ia<num_p; ia++)
        {    
            nptr1 = pptr->NodePtr[ia];
            nptr2 = pptr->NodePtr[imod(ia+1, num_p)];
            if (nptr1 == nptr2)
                printf ("\nProblem edge (1). \n");

            for (ib=0; ib<sub_num_p; ib++) 
            {
                sub_nptr1 = sub_pptr->NodePtr[ib];
                sub_nptr2 = sub_pptr->NodePtr[imod(ib+1, sub_num_p)];
                if (sub_nptr1 == sub_nptr2)
                    printf ("\nProblem edge (2). \n");
                
                if ((nptr1 == sub_nptr1 && nptr2 == sub_nptr2) ||
                    (nptr1 == sub_nptr2 && nptr2 == sub_nptr1)) 
                {   
                    /* edge matched */
                    /*
                    if (pptr->edge_access_num[ia] > 1 || sub_pptr->edge_access_num[ib] > 1)
                        printf ("\nOOPS! How can??\n");
                    */

                    pptr->edge_access_num[ia]++;
                    sub_pptr->edge_access_num[ib]++;
                }
            }
        }
    }    
  } 
    
  
  /* count edge access */
  num_done = num_open = num_over = 0; 
  num_patch = Num_patch_in_NFace[ibface];
  pptr = NFace_head[ibface];
  for (ii=0; ii<num_patch; ii++)
  { 
    if (pptr->patch_type == TET4)        num_p = 3;
    else if (pptr->patch_type == HEX8)   num_p = 4; 
    else 
    {
        printf ("\nWarning(surf_check_2)... Current unhandled type num_p = %d!\n", num_p);
        return (BAD);
    }
    done_flag = 1;
    for (k=0; k<num_p; k++)
    {   
        if (pptr->edge_access_num[k] < 2) 
        {
            num_open++;
            done_flag = 0; 
            break;
        } 
        else if (pptr->edge_access_num[k] > 2)
        {
            num_over++;
            done_flag = 0;
            break;
        }
    } 
    if (done_flag == 1)    num_done++;
    pptr = pptr->Next;
  } 
  printf ("\nNumber of open face = %ld\n", num_open);  
  printf ("Number of over face = %ld\n", num_over);  
  printf ("Number of done face = %ld\n", num_done);  
                             
 
    return (OK);
}



/* save numerical surface as disk file */
int
output_numerical_surf (int surf_num)
{
    char fnod[80], felm[80], str_num[20], *str_dummy;  
    int   done_flag, k, sign, dec, num_patch_node;
    FILE *fout_nod, *fout_elm;  
    long   ii, num_patch, long_idx, total_node=0;
    Spatch *head_pptr, *pptr;  
    
    typedef struct t_nodelist {
        MeshNode *nptr; 
        struct t_nodelist *Next;
    } NOD_LIST; 
    
    NOD_LIST *nod_list, *last_list_ptr, *lptr, *next_lptr;
                       
    head_pptr = NFace_head[surf_num];
    num_patch = Num_patch_in_NFace[surf_num];
    if (head_pptr == NULL)  
    {
        if (Numerical_surf == 1)
        {
            /* write numerical surfaces file name */
            fprintf (Main_file, "none.dat\n");
        }
        return (BAD);    
    }
    
    nod_list = (NOD_LIST *) malloc (sizeof (NOD_LIST)); 
    if (!nod_list)  alloc_error ("matsurf-3");   
    
    nod_list->nptr = head_pptr->NodePtr[0];
    nod_list->Next = NULL;
    last_list_ptr = nod_list;
    total_node++;   
    
    /* borrow the access num. field as node num. (should < 65535) */
    
    ii = 0;
    pptr = head_pptr;
    while (pptr)
    {   
        ii++; 
        if (pptr->patch_type == TET4)    num_patch_node = 3;
        else if (pptr->patch_type == HEX8)  num_patch_node = 4; 
        else 
        {
            printf ("\nUnknown patch type for output : type = %d!\n", pptr->patch_type);
            pptr = pptr->Next; 
            continue;
	    }

        for (k=0; k<num_patch_node; k++)
        {  
            lptr = nod_list; 
            long_idx  = 0;  
            done_flag = 0;
            while (lptr)
            {   
                long_idx++;
		        if (lptr->nptr == pptr->NodePtr[k])
                {
                    pptr->edge_access_num[k] = long_idx;
                    done_flag = 1;   
                    break;
                }
                lptr = lptr->Next;
            } 
            if (done_flag == 1)   continue; 
            lptr = (NOD_LIST *) malloc (sizeof (NOD_LIST)); 
            if (!lptr)  alloc_error ("matsurf-4");  
            lptr->nptr = pptr->NodePtr[k];
            lptr->Next = NULL;
            last_list_ptr->Next = lptr;
            last_list_ptr       = lptr; 
            total_node++;                               
            pptr->edge_access_num[k] = long_idx + 1;                               
        }

        pptr = pptr->Next;
    }   
    

    /* debug checking */
    if (ii != num_patch)
        printf ("\nWarning ... Patch number doesn't match: %ld (%ld).\n",
                ii, num_patch);
                         
      /* use default file name "SURFi.nod" and "SURFi.elm" */ 
      /* create node file */
      strcpy (fnod, "surf");
      str_dummy = (char *) fcvt ((double)(surf_num+1), (int)0, &dec, &sign);
      strcpy (str_num, str_dummy); 
      strcat (fnod, str_num);
      strcat (fnod, ".nod"); 
      strcpy (felm, "surf");
      strcat (felm, str_num);
      strcat (felm, ".elm"); 
      
      /* save node file */
      fout_nod = fopen (fnod, "w+t"); 
      fprintf (fout_nod, "1 %ld\n", total_node);  
      lptr = nod_list;
      for (ii=0; ii<total_node; ii++)  
      {
	    fprintf (fout_nod, "%8ld %12.6lf %12.6lf %12.6lf %2d\n", /*ii+1,*/
	         (long)(lptr->nptr->Fst_adj->wt),
             lptr->nptr->Coor[0], lptr->nptr->Coor[1], 
             lptr->nptr->Coor[2], lptr->nptr->Mtrl);
             lptr = lptr->Next;          
      }
      fclose (fout_nod);
          
      /* save elem. file */
      fout_elm = fopen (felm, "w+t"); 
      fprintf (fout_elm, "1    %5d    0   %ld\n", num_patch_node, num_patch);
      pptr = head_pptr;
      for (ii=0; ii<num_patch; ii++)
      {  
         fprintf (fout_elm, "%8ld", ii+1);
         for (k=0; k<num_patch_node; k++)
         {  
	        /* fprintf (fout_elm, "%8ld", pptr->edge_access_num[k]); */
	        fprintf (fout_elm, "%8ld", (long)(pptr->NodePtr[k]->Fst_adj->wt));
	     }
         fprintf (fout_elm, "\n");                 
         pptr = pptr->Next;
      }
      fclose (fout_elm);
      
      /* free node list */  
      lptr = nod_list;
      while (lptr)
      {
          next_lptr = lptr->Next;
          free ((char *)lptr);
          lptr = next_lptr;
      }  

      if (Numerical_surf == 1)
      {
        /* write numerical surfaces file name */
        fprintf (Main_file, "%s\n", felm);
      }
      return (0);
}     
     



/* shave lone tepee element --- all its nodes are on mtrl bdy. 
    set as its adjacent material.
*/
unsigned int
shave_tepee_elem (MeshElem *msh_l_head, long msh_num_elem, int mt_code)
{   
    unsigned int   num_tepee=0, odd_count = 0;
    int            num_elm_nod, count, k, adj_mtrl;
    long            ii;
    MeshNode **nnptr;
    MeshElem *eptr, *sub_eptr; 
    AdjElem  *adeptr;
    
    eptr = msh_l_head;
    for (ii=0; ii<msh_num_elem; ii++)
    {   
        /* check elem. type */
        switch (eptr->E_type)
        {
            case TET4:
                num_elm_nod = 4;
                nnptr = eptr->Elem.tet4.NodePtr;
                break;
            case HEX8:
                num_elm_nod = 8;
                nnptr = eptr->Elem.hex8.NodePtr;
                break;
            default:
                num_elm_nod = BAD;
                printf ("\nError...Unknown element type!\n");
                return (0);
        }
        
        /* count numerical boundary node in the element*/
        count = 0;
        for (k=0; k<num_elm_nod; k++)
            if (nnptr[k]->status == NSURFNODE)     count++;

        if (count == num_elm_nod)
        {   /* lone tepee element at bdy */ 
            adj_mtrl = BAD;
            /* all nodes are on numerical surface, tag as adj mtrl*/
            for (k=0; k<num_elm_nod; k++)
            {
                adeptr = nnptr[k]->Fst_adj_elem;
                if (adeptr == NULL)           
                {
                    printf ("\nDangling node!!\n");
                    return (0);  /* the node did not connect to elem. */
                } 
                while (adeptr)
                {   
                    sub_eptr = adeptr->idx;
                    if (sub_eptr->Mtrl_in != mt_code)
                    {
                        adj_mtrl = sub_eptr->Mtrl_in;
                        goto BP;
                    }
                    adeptr = adeptr->ptr;    
                } 
            }  
BP:
            if (adj_mtrl == BAD)
            {
                /* printf ("\nCan't find adjacent material... Problem case!\n"); */
                /* this case can an elem on outbound !! */
                /* odd_count++; */
                adj_mtrl = 0;  
            }  
            else
            {
                num_tepee++; 
                /* find the tip node and set it to FREE */ 
		        /*
                min_curv = 1.e10;
                min_index = BAD;
                for (k=0; k<num_elm_nod; k++) 
                {
                    node_curv[k] = curv_index (nnptr[k], mt_code);
                    if (node_curv[k] < 0)
                    {  
                        printf ("\nFailed to find node curve %d = %lf\n", k, node_curv[k]);
                        continue;
                    }
                    else
                    {
		      
                        if (node_curv[k] < min_curv) 
                        {
                            min_curv = node_curv[k];
                            min_index = k;
                        }
                    } 
                } 
                if (min_index != BAD)
                {
		            // set the tip node not to be a numerical node 
                    nnptr[min_index]->status = FREE;
                }
		        */
                /* set the element to its adjacent material, assume across two mtrl. case */
                eptr->Mtrl_in = adj_mtrl; 
            }
        }
        eptr = eptr->Next;
    }
    
    /*
    printf ("\n%d odd element!\n", odd_count);
    printf ("\n%d tepee elements being shave!\n", num_tepee);
    */
    return (num_tepee);
}

/* find curvature index of given node : accumulate the angle formed
    by the edges connected to all the other nodes with NSURFNODE 
    node status.
    
*/
REAL
curv_index (MeshNode *nptr, int mtrl)
{   
  static int idx4[4][4] = { {0, 1, 2, 3},
                            {1, 2, 3, 0},
                            {2, 3, 0, 1},
                            {3, 0, 1, 2}};
  static int idx8[8][4] = { {0, 1, 3, 4},
                            {1, 5, 2, 0},
                            {2, 1, 6, 3},
                            {3, 2, 7, 0},
                            {4, 0, 5, 7},
                            {5, 1, 6, 4}, 
                            {6, 7, 5, 2},
                            {7, 4, 3, 6}}; 
  
    
    int      i, j, k, num_p, jd, num_adelem, idx1, idx2;
    int      duplicate_flag, num_angle=0;
    REAL     p1[3], p2[3], vec1[3], vec2[3], sangle, angle;
    MeshNode *nptr1, *nptr2, **nnptr, *side_a[100], *side_b[100];
    MeshElem *eptr/* , *sub_eptr */;
    AdjElem  *adeptr, *sub_adeptr;  
    
    
    sangle = 0;
    num_adelem = nptr->Num_adj_elem;
    adeptr = nptr->Fst_adj_elem;
    if (adeptr == NULL)
    {
        if (num_adelem) 
	    {
	        printf ("\nWrong adj_elem list\n");
	    }
	    else
	        printf ("\n A isolated node!\n");

        return (BAD);
    }
    /* check duplicated element in adj. */
    while (adeptr)
    {
        sub_adeptr = adeptr->ptr;
	    while (sub_adeptr)
	    {
	       if (sub_adeptr->idx == adeptr->idx)
	       {
		        printf ("\nDuplicated elements in adj. list !\n");
	       } 
	       sub_adeptr = sub_adeptr->ptr;
	    }
	    adeptr = adeptr->ptr;
    }  
    
    for (i=0, adeptr=nptr->Fst_adj_elem; i<num_adelem; i++, adeptr=adeptr->ptr)
    {   
        if (adeptr == NULL)
        {
	        if (num_adelem != i) 
	        {
	            printf ("\nWrong adj_elem list, num_adjelem = %d, i= %d\n",
		                num_adelem, i);
	        }
	        break;
        }

        eptr = adeptr->idx;
	    if (eptr->Mtrl_in != mtrl)      continue;
        if (eptr->E_type == TET4)
        {
            num_p = 4;
            nnptr = eptr->Elem.tet4.NodePtr;
        } 
        /*
        else if (eptr->E_type == HEX8)  
        {
            num_p = 8;
            nnptr = eptr->Elem.hex8.NodePtr;
        } 
        */
        else
        {
            printf ("\nUnknown elem. type %d in 'curv_idx'\n", eptr->E_type);
            return (BAD); 
        }
        
        if ((jd=nd_order(nptr, nnptr, num_p)) == BAD)
        {
            printf ("\nBAD nd_order (curv jd\n");
            return (BAD);
        }
        
        /* base node: nptr->Coor */ 
        for (j=0; j<3; j++)   /*  check three faces connected to node */
        {   
            idx1 = idx4[jd][j+1]; 
            if (imod(j+2, 4))   idx2 = idx4[jd][j+2];
            else                idx2 = idx4[jd][1];

            nptr1 = nnptr[idx1];
            nptr2 = nnptr[idx2];
            if (nptr1->status == NSURFNODE && nptr2->status == NSURFNODE)
            {
                /* search the sides list, see if already has the angle sides */
                duplicate_flag = 0;
                for (k=0; k<num_angle; k++)
                {
                    if ((side_a[k]==nptr1 && side_b[k]==nptr2) ||
                        (side_a[k]==nptr2 && side_b[k]==nptr1))
                    {
                        duplicate_flag = 1;
                        break;
                    }
                }
                if (duplicate_flag) continue;

                /* add into the list */
                side_a[num_angle] = nptr1;
                side_b[num_angle] = nptr2;
                num_angle++;
            }
        }    
    }
    /* compute the curv idx -- accumulated face angles */
    for (i=0; i<num_angle; i++)
    {
        for (k=0; k<3; k++)
        {
            p1[k] = side_a[i]->Coor[k];
            p2[k] = side_b[i]->Coor[k]; 
        } 
        v_make(nptr->Coor, p1, 3, vec1);
        v_make(nptr->Coor, p2, 3, vec2); 
        angle = fabs(v_angl3(vec1, vec2, 1, 3)); /* unit: degree */
        sangle += angle;
    }
    return (sangle);
}
