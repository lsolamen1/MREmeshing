 
/*
  ************************************************************************
  *  adt.h :  Abstract Data Type definition file 		         *
  *									 *
  *  Qingyang Zhang				   Jan. 10, 1995	 *
  ************************************************************************
*/
/* needs spmesh.h */

struct stackinfo { MeshNode *nptr; };

typedef struct t_stackcell {
       struct stackinfo info;
       struct t_stackcell *stptr;
} STACKCELL;


