/* 
  ************************************************************************
  *  conf_bdy.c : Boundary Conformage for Tetrahedron and Brick Mesh	 *
  *									                                     *
  *  Qingyang Zhang				   April 24, 1995	                     *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>
 
#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"

/* define global varibles */
#include "defglb.h"

#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))
#define GetRandom( min, max ) ((rand() % (int)(((max) + 1) - (min))) + (min))

#define MTRL1   0
#define MTRL2   1
#define BDY12   3
#define NOMOV   4


/*
** External Functions
*/
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern int v_norm(REAL *vec, int n);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);
extern REAL v_angl(REAL *vec1, REAL *vec2, int ideg);
extern void tri_patch_box (REAL *xmin, REAL *ymin, REAL *zmin,
		    REAL *xmax, REAL *ymax, REAL *zmax,
		    BMeshElem *bdy_l_head, long n_bdy_elem);
extern void v_cros(REAL *vec1, REAL *vec2, REAL *prod);
extern int v_norm(REAL *vec, int n);
extern REAL cosine_ang (REAL *node_1, REAL *node_2, REAL *node_3, REAL *node_4);
extern REAL pt_to_line (REAL *node_1, REAL *node_2, REAL *node_3);
extern REAL elem_assess (MeshElem *eptr, int qulity_type);
extern REAL avg_quli (MeshNode *nptr, REAL *avg_q, int qulity_type);
extern int alloc_error (char *str);
extern REAL loc_size (MeshNode *in_node);
extern int sp_move (BMeshNode *bdy_n_head, long bdy_num_node,
	     BMeshElem *bdy_l_head, long bdy_num_elem,
	     MeshNode *msh_n_head, long msh_num_node,
	     MeshElem *msh_l_head, long msh_num_elem,
	     MeshNode *base_nptr, REAL *new_loc, int num_level);


/*
** Local Functions
*/

void conform_out_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
		 BMeshElem *bdy_l_head, long bdy_num_elem,
		 MeshNode *msh_n_head, long msh_num_node,
		 MeshElem *msh_l_head, long msh_num_elem);
void search_bdy_node (MeshNode *msh_n_head, long msh_num_node);
int set_node_status (MeshNode *nptr);
/* Ziji 1/20/99 */
int set_node_status_b (MeshNode *nptr);

int nd_order(MeshNode *nptr, MeshNode **nnptr, int num_p);
int common_plane(MeshNode **plane_1, int num_p, 
                 MeshNode **plane_2, int sub_num_p);
int fit_exbdy (MeshNode *nptr, BMeshElem *bdy_l_head, long bdy_num_elem);
REAL pnt2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *pnt);
REAL edge_process (REAL *node_1, REAL *node_2, REAL *node_4, REAL *r);
void conform_in_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
		 BMeshElem *bdy_l_head, long bdy_num_elem,
		 MeshNode *msh_n_head, long msh_num_node,
		 MeshElem *msh_l_head, long msh_num_elem);
void find_bdy_elem (MeshElem *msh_l_head, long msh_num_elem);
int fit_tet4_inbdy (MeshElem *eptr, int fit_mode,
		    BMeshElem *bdy_l_head, long bdy_num_elem);
void set_new_position (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		       int node_status);
void set_new_position_b  (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		   int node_status, double factor);
void set_ori_position (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl);
REAL fit_tet4_test (MeshElem *eptr, MeshNode **nnptr, double *node_quli, 
	       int quali_type);
BMeshElem * find_inter_bdy (REAL *node, REAL *inter_pt, REAL *opt_dist, 
			  NODE_MTRL *mtrl, BMeshElem *bdy_l_head, long bdy_num_elem);
int line_tri_cross_conf (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);
int node_moving (REAL *node1, REAL *node2, double mov_factor);


/*
** Global Variables
*/

REAL  Max_size;  


/*
** Local Variables
*/ 
#define MAX_OPT       5

static int Fit_mode = NATURE;
static REAL Mov_factor = 1; 
static REAL Opt_factor = 0.618;




void
conform_out_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
                 BMeshElem *bdy_l_head, long bdy_num_elem,
		         MeshNode *msh_n_head, long msh_num_node,
                 MeshElem *msh_l_head, long msh_num_elem)
{
  long     ii;
  int      fit_flag, ext_done=0;
  MeshNode *nptr;

  /* search mesh model to find outter BDY node which will be conformed */
  /* the status of bdy. node is set as OUTNODE */
  search_bdy_node (msh_n_head, msh_num_node);

  /* find max. size of the object */
  Max_size = BDxmax - BDxmin;
  if (Max_size < BDymax - BDymin)  Max_size = BDymax - BDymin;
  if (Max_size < BDzmax - BDzmin)  Max_size = BDzmax - BDzmin;

  /* fit boundary nodes */
  nptr = msh_n_head;
  if (nptr == NULL)   return;
RE:
  printf ("\n****Conform External BDY****\n Please input moving factor[0-1]: (0=no move(quit)/ 1=move anyway/ others: iterative)"); 

  printf ("\n Moving factor (0-1) : ");

  scanf  ("%lf", &Mov_factor);

  if (Mov_factor <= HIGTOL) 
  {  
    Fit_mode = NOFIT;
    Mov_factor = 0.;
    if (ext_done == 0)    
      return;    /* external bdy undone and will handle cy inter bdy fitting */
  }
  else if (Mov_factor >= 1.0-HIGTOL) 
  {
    Fit_mode = FORCED;
    ext_done = 1; /* set external boundary being process */
    Mov_factor = 1.;
  }
  else
  {
    ext_done = 1;
    Fit_mode = NATURE;
  }

  ii = 0;
  do
  {
    if (nptr->status == OUTNODE)
    {
      ii++;
      if (Fit_mode == NOFIT)
      {
	    nptr->status = DONE;
	    goto CON;
      }
      fit_flag = fit_exbdy (nptr, bdy_l_head, bdy_num_elem);
      /* fit_flag: BAD--dnagling node. large distance moving*/
      if (fit_flag == BAD)  
	    fprintf (Diag_file, "\nCan't Fit on node %ld;\n", ii);
    }
CON:  nptr = nptr->Next;
  } while (nptr != msh_n_head);

  if (Fit_mode == NATURE)   goto RE;

  return;
}



/* search mesh model to find external BDY node which will be conformed.
   if outter BDY node is found, the node status is set as OUTNODE
   when the BDY node is fitted to BDY surface, the node status is set
   as DONE
 */

void 
search_bdy_node (MeshNode *msh_n_head, long msh_num_node)
{
  long ii;
  MeshNode *nptr;
/* Ziji 1/7/99 */
  int spflag;

  nptr = msh_n_head;
  for (ii=0; ii<msh_num_node; ii++)
  {
    /* see if node status has been set */
/* Ziji 1/12/99    if (nptr->status != FREE)
    {
      nptr = nptr->Next;
      continue;
    }
*/
	spflag = 0;
    if (nptr->status > 0 ) 
	{
		spflag = nptr->status;
		nptr->status = FREE;
	}
    else if (nptr->status == FIXED	) 
	{
      nptr = nptr->Next;
      continue;
	}
	else if (nptr->status != FREE)
    {
      nptr = nptr->Next;
      continue;
    }
/* end of Ziji */

    /* check node status */
    if (set_node_status (nptr) == BAD)
	    fprintf (Diag_file, "\nError...in node status ! (search_bdy_node)\n");

/* Ziji 1/12/99 */
	if (spflag>0) {
	  if (nptr->status==OUTNODE) {
	    nptr->status = ONSPBDY;
	  }
	  else {
	    nptr->status = spflag;
	  }
	}
/* end of Ziji */

    nptr = nptr->Next;
  }    

  return;
}


/* check the node, it could be bdy.     node :  set OUTNODE

   Process: Check all the element adjacent to test node.
   an element is counted as a set of plane which is the surface
   of the element.
   if a plane which includes the test node does not share
   by a plane of another element, the test node is BDY node
   and all the other on this plane are BDY nodes.
   The process actually is to find BDY plane of the mesh model.
   So, instead of treat one node at a time, it is possible to
   treat all the nodes on the plane at once, that will accelate
   the process. .
*/
int 
set_node_status (MeshNode *nptr)
{
 
  int      i, j, k, id, jd, num_p, sub_num_p;
  int      num_elm_nod, sub_num_elm_nod, share_flag;
  MeshNode **nnptr, **sub_nnptr, *plane_1[4], *plane_2[4];
  MeshElem *eptr, *sub_eptr;
  AdjElem  *adeptr, *sub_adeptr;
  static int hex8_plnd[8][3][4] = {{{1, 2, 3, 4}, {1, 4, 8, 5}, {1, 5, 6, 2},},
				   {{2, 3, 4, 1}, {2, 6, 7, 3}, {2, 1, 5, 6},},
				   {{3, 4, 2, 1}, {3, 2, 6, 7}, {3, 7, 8, 4},},
				   {{4, 1, 2, 3}, {4, 8, 5, 1}, {4, 3, 7, 8},},
				   {{5, 1, 4, 8}, {5, 8, 7, 6}, {5, 6, 1, 2},},
				   {{6, 5, 7, 8}, {6, 7, 3, 2}, {6, 2, 1, 5},},
				   {{7, 6, 5, 8}, {7, 3, 2, 6}, {7, 8, 4, 3},},
				   {{8, 5, 1, 4}, {8, 7, 6, 5}, {8, 4, 3, 7}}};

  static int tet4_plnd[4][3][3] = {{{1, 3, 2}, {1, 2, 4}, {1, 4, 3},},
				   {{2, 1, 3}, {2, 4, 1}, {2, 3, 4},},
				   {{3, 2, 1}, {3, 4, 2}, {3, 1, 4},},
				   {{4, 1, 2}, {4, 2, 3}, {4, 3, 1}}};

  /* set pointer to first node of adj. element list. */
  adeptr = nptr->Fst_adj_elem;
  if (adeptr == NULL)   
  {
    fprintf (Diag_file, "\nDangling node!!\n");
    return (BAD);  /* the node did not connect to elem. */
  }
  while (adeptr)
  {
     /* set base element */
     eptr = adeptr->idx;

     /* check elem. type */
     switch (eptr->E_type)
     {
	    case TET4:
            num_elm_nod = 4;
		    num_p = 3;  /* triangle plane has three nodes */
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case HEX8:
            num_elm_nod = 8;
		    num_p = 4;  /* rectaglar plane has three nodes */
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    default:
		    num_elm_nod = BAD;
		    num_p = BAD;
		    fprintf (Diag_file, "\nError...Unknown element type!\n");
		    return (BAD);
     }

     /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
     if ((id=nd_order(nptr, nnptr, num_elm_nod)) == BAD)
     {
       fprintf (Diag_file, "\nError in nd_order (id)\n");
       return (BAD);
     }
     for (i=0; i<3; i++)
     {
	    /* set base plane 1 for searching */
        switch (eptr->E_type)
        {
	        case TET4:
		        for (k=0; k<num_p; k++)
			        plane_1[k] = nnptr[tet4_plnd[id][i][k] - 1];
		        break;
	        case HEX8:
		        for (k=0; k<num_p; k++)
	                 plane_1[k] = nnptr[hex8_plnd[id][i][k] - 1];
		        break;
	    }

	    /* initial flag */
	    share_flag = 0;
	    /* set sub-adj. to start */
        sub_adeptr = nptr->Fst_adj_elem;
        while (sub_adeptr)
        {
	        if (sub_adeptr == adeptr)
	        { 
	            sub_adeptr = sub_adeptr->ptr;
	            continue;
	        }
	        /* set sub-elem */
	        sub_eptr = sub_adeptr->idx;
	        /* check sub-elem. type */
	        switch (sub_eptr->E_type)
	        {
	            case TET4:
		            sub_num_elm_nod = 4;
		            sub_num_p = 3; /* triangle plane has three nodes */
		            sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
		            break;
	            case HEX8:
		            sub_num_elm_nod = 8;
		            sub_num_p = 4; /* rectaglar plane has three nodes */
		            sub_nnptr = sub_eptr->Elem.hex8.NodePtr;
		            break;
	            default:
		            sub_num_elm_nod = BAD;
		            sub_num_p = BAD;
		            fprintf (Diag_file, "\nError...Unknown element type!\n");
		            return (BAD);
	        }

	        /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
	        if ((jd=nd_order(nptr, sub_nnptr, sub_num_elm_nod)) == BAD)
	        {
	            fprintf (Diag_file, "\nBAD nd_order (sub jd)\n");
                return (BAD);
	        }

	        for (j=0; j<3; j++)
	        {
	            /* set sub plane 2 for comparing with */
	            switch (sub_eptr->E_type)
	            {
	                case TET4:
                        for (k=0; k<sub_num_p; k++) 
	                        plane_2[k] = sub_nnptr[tet4_plnd[jd][j][k] - 1];
		                break;
	                case HEX8:
		                for (k=0; k<sub_num_p; k++)
			                plane_2[k] = sub_nnptr[hex8_plnd[jd][j][k] - 1];
		            break;
	            }

	            /* check plane property: if both elem. share the plane,
		        it is an internal plane. but the nodes on the plane
		        may not be internal nodes. it needs more checking.
                */
	            share_flag = common_plane (plane_1, num_p, plane_2, sub_num_p);
	            if (share_flag == OK)   break;

            }
            if (share_flag == OK)   break;
	        sub_adeptr = sub_adeptr->ptr;
        }

	    if (share_flag != OK) 
	    {
	        /* the base plane did not share with another element. So
	        it is a BDY plane and all the nodes on the plane are
	        BDY nodes which need to be fitted to BDY surface.
	        set all the plane as OUTNODE to reduce search time.
           */
	        for (k=0; k<num_p; k++)
	        {
	            if (plane_1[k]->status == FREE)
			        plane_1[k]->status = OUTNODE;
	        }

	        /* debug checking */
	        if (nptr->status != OUTNODE)  fprintf (Diag_file, "\nFailed in node_status!!\n");
	       
	        /* return at this point to avoid duplication search */
	        return 0;
	    }
    }

    adeptr = adeptr->ptr;
  }
  return 0;
}

/* Ziji 1/20/99 */
/* check the node, it could be bdy.     node :  set OUTNODE

   Process: similar to the set_node_status, but only this node
            will be marked as OUTNODE
			add several lines to check if this node is on interior bdy
*/
int 
set_node_status_b (MeshNode *nptr)
{
 
  int      i, j, k, id, jd, num_p, sub_num_p;
  int      num_elm_nod, sub_num_elm_nod, share_flag;
  MeshNode **nnptr, **sub_nnptr, *plane_1[4], *plane_2[4];
  MeshElem *eptr, *sub_eptr;
  AdjElem  *adeptr, *sub_adeptr;
  static int hex8_plnd[8][3][4] = {{{1, 2, 3, 4}, {1, 4, 8, 5}, {1, 5, 6, 2},},
				   {{2, 3, 4, 1}, {2, 6, 7, 3}, {2, 1, 5, 6},},
				   {{3, 4, 2, 1}, {3, 2, 6, 7}, {3, 7, 8, 4},},
				   {{4, 1, 2, 3}, {4, 8, 5, 1}, {4, 3, 7, 8},},
				   {{5, 1, 4, 8}, {5, 8, 7, 6}, {5, 6, 1, 2},},
				   {{6, 5, 7, 8}, {6, 7, 3, 2}, {6, 2, 1, 5},},
				   {{7, 6, 5, 8}, {7, 3, 2, 6}, {7, 8, 4, 3},},
				   {{8, 5, 1, 4}, {8, 7, 6, 5}, {8, 4, 3, 7}}};

  static int tet4_plnd[4][3][3] = {{{1, 3, 2}, {1, 2, 4}, {1, 4, 3},},
				   {{2, 1, 3}, {2, 4, 1}, {2, 3, 4},},
				   {{3, 2, 1}, {3, 4, 2}, {3, 1, 4},},
				   {{4, 1, 2}, {4, 2, 3}, {4, 3, 1}}};
  /* Ziji 1/22/99 */
  int count, mtrl[200];
  AdjList *adjnd;
  MeshNode *nd;

  /* set pointer to first node of adj. element list. */
  adeptr = nptr->Fst_adj_elem;
  if (adeptr == NULL)   
  {
    fprintf (Diag_file, "\nDangling node!!\n");
    return (BAD);  /* the node did not connect to elem. */
  }
  while (adeptr)
  {
     /* set base element */
     eptr = adeptr->idx;

     /* check elem. type */
     switch (eptr->E_type)
     {
	    case TET4:
            num_elm_nod = 4;
		    num_p = 3;  /* triangle plane has three nodes */
		    nnptr = eptr->Elem.tet4.NodePtr;
		    break;
	    case HEX8:
            num_elm_nod = 8;
		    num_p = 4;  /* rectaglar plane has three nodes */
		    nnptr = eptr->Elem.hex8.NodePtr;
		    break;
	    default:
		    num_elm_nod = BAD;
		    num_p = BAD;
		    fprintf (Diag_file, "\nError...Unknown element type!\n");
		    return (BAD);
     }

     /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
     if ((id=nd_order(nptr, nnptr, num_elm_nod)) == BAD)
     {
       fprintf (Diag_file, "\nError in nd_order (id)\n");
       return (BAD);
     }
     for (i=0; i<3; i++)
     {
	    /* set base plane 1 for searching */
        switch (eptr->E_type)
        {
	        case TET4:
		        for (k=0; k<num_p; k++)
			        plane_1[k] = nnptr[tet4_plnd[id][i][k] - 1];
		        break;
	        case HEX8:
		        for (k=0; k<num_p; k++)
	                 plane_1[k] = nnptr[hex8_plnd[id][i][k] - 1];
		        break;
	    }

	    /* initial flag */
	    share_flag = 0;
	    /* set sub-adj. to start */
        sub_adeptr = nptr->Fst_adj_elem;
        while (sub_adeptr)
        {
	        if (sub_adeptr == adeptr)
	        { 
	            sub_adeptr = sub_adeptr->ptr;
	            continue;
	        }
	        /* set sub-elem */
	        sub_eptr = sub_adeptr->idx;
	        /* check sub-elem. type */
	        switch (sub_eptr->E_type)
	        {
	            case TET4:
		            sub_num_elm_nod = 4;
		            sub_num_p = 3; /* triangle plane has three nodes */
		            sub_nnptr = sub_eptr->Elem.tet4.NodePtr;
		            break;
	            case HEX8:
		            sub_num_elm_nod = 8;
		            sub_num_p = 4; /* rectaglar plane has three nodes */
		            sub_nnptr = sub_eptr->Elem.hex8.NodePtr;
		            break;
	            default:
		            sub_num_elm_nod = BAD;
		            sub_num_p = BAD;
		            fprintf (Diag_file, "\nError...Unknown element type!\n");
		            return (BAD);
	        }

	        /* find the node order in the element for tet4: 0-3, hex8: 0-7*/
	        if ((jd=nd_order(nptr, sub_nnptr, sub_num_elm_nod)) == BAD)
	        {
	            fprintf (Diag_file, "\nBAD nd_order (sub jd)\n");
                return (BAD);
	        }

	        for (j=0; j<3; j++)
	        {
	            /* set sub plane 2 for comparing with */
	            switch (sub_eptr->E_type)
	            {
	                case TET4:
                        for (k=0; k<sub_num_p; k++) 
	                        plane_2[k] = sub_nnptr[tet4_plnd[jd][j][k] - 1];
		                break;
	                case HEX8:
		                for (k=0; k<sub_num_p; k++)
			                plane_2[k] = sub_nnptr[hex8_plnd[jd][j][k] - 1];
		            break;
	            }

	            /* check plane property: if both elem. share the plane,
		        it is an internal plane. but the nodes on the plane
		        may not be internal nodes. it needs more checking.
                */
	            share_flag = common_plane (plane_1, num_p, plane_2, sub_num_p);
	            if (share_flag == OK)   break;

            }
            if (share_flag == OK)   break;
	        sub_adeptr = sub_adeptr->ptr;
        }

	    if (share_flag != OK) 
	    {
	        /* the base plane did not share with another element. So
	        it is a BDY plane and all the nodes on the plane are
	        BDY nodes which need to be fitted to BDY surface.
	        set only this test node to be OUTNODE
           */
	        if (nptr->status!=FIXED) nptr->status = OUTNODE;
	       
	        /* return at this point to avoid duplication search */
	        return 0;
	    }
    }

    adeptr = adeptr->ptr;
  }
  
/* Ziji 1/22/99, added here to check if the elements adjacent to this
                 node have more than 1 material. if so, this node is
				 on an interior bdy */  
  /* set pointer to first node of adj. element list. */
  adjnd = nptr->Fst_adj;
  while (adjnd)
  {
     /* set base element */
     nd = adjnd->idx;
	 count = -1;
	 for (k=0; k<nptr->Num_adj; k++)      mtrl[k] = 0;
	 for (k=0; k<nptr->Num_adj; k++)
	 {
	   if (nd->Mtrl > BDY_NODE_CODE)     continue; /* boundary node */
       /* check if the material has been recorded */
       for (i=0; i<=count; i++)   if (nd->Mtrl==mtrl[i]) goto nextP;
	   count++;
	   mtrl[count] = nd->Mtrl;
nextP: ;
	 }
	 if ((count > 0) && (nptr->status!=FIXED)) {
	    nptr->status = OUTNODE;
        /* return at this point to avoid duplication search */
        return 0;
	 }
    adjnd = adjnd->ptr;
  }
/* end of Ziji */
  return 0;
}
/* end of Ziji */


/* find node order in elem. node list */
int
nd_order(MeshNode *nptr, MeshNode **nnptr, int num_p)
{
  int i;

  for (i=0; i<num_p; i++)
  {
    if (nptr == nnptr[i]) return (i); /* the idx start from 0 */
  }

  return (BAD);  /* not match */

}



/* check common plane which may has different node order but same node set */
int
common_plane(MeshNode **plane_1, int num_p, MeshNode **plane_2, int sub_num_p)
{

  int i, j, count=0;

  if (num_p != sub_num_p)
  {
    /* currently treat as a non-share plane. but late on a check of co-plane
       may be more reasonable than just check the number of node
    */
    fprintf (Diag_file, "\nThis is a pair of face with different nodes!\n");
    return (NONE);
  }

  for (i=0; i<num_p; i++)
  {
      for (j=0; j<sub_num_p; j++)
      {
	    if (plane_1[i] == plane_2[j])
	    {
	      count++;
          break;
        } 
      }
  }

  if (count == num_p)    return (OK);   /* common plane */
  else                   return (NONE); /* not share    */

}




/* fit the given node to external boundary */
int
fit_exbdy (MeshNode *nptr, BMeshElem *bdy_l_head, long bdy_num_elem)
{
  int   k, count, ok_type=NONE;
  long  ii;
  REAL  loc_sz = 0., vec0[3], vec1[3], coef=1, dist_min, dist;
  REAL  pnt[3], opt_pnt[3];
  AdjList  *adnptr;
  BMeshElem *beptr, *opt_beptr;

  /* find the size of local bounding box */
  /* set base node */
  for (k=0; k<3; k++) vec0[k] = nptr->Coor[k];

  /* search each adj. nodes */
  adnptr = nptr->Fst_adj;
  if (adnptr || adnptr->ptr)
  {
    count = 0;
    while (adnptr)
    {
	    for (k=0; k<3; k++) vec1[k] = adnptr->idx->Coor[k];
	    loc_sz += v_rang(vec0, vec1, 3);
	    count++;
	    adnptr = adnptr->ptr;
    }
    if (count != nptr->Num_adj)
	    fprintf (Diag_file, "\nWarning...Adj. node inconsistent!\n");
    /* take average distance to all adj. node, define loc_size */
    loc_sz = coef * loc_sz/ count;
  }
  else
  {
    fprintf (Diag_file, "\nError...Dangling node !\n");
    return (BAD);
  }

  /* traverse all the bounday patches */
  dist_min = 1.e10;
  beptr = bdy_l_head;
  for (ii=0; ii<bdy_num_elem; ii++)
  {
    /* box checking with bdy. patch */
    if (vec0[X]+loc_sz<beptr->xmin || vec0[X]-loc_sz > beptr->xmax)  goto G0;
    if (vec0[Y]+loc_sz<beptr->ymin || vec0[Y]-loc_sz > beptr->ymax)  goto G0;
    if (vec0[Z]+loc_sz<beptr->zmin || vec0[Z]-loc_sz > beptr->zmax)  goto G0;

    /* find closest bdy. patch. to move to */
    dist = pnt2bdy (nptr, beptr, pnt);
    if (dist < dist_min)
    {
      dist_min = dist;
      for (k=0; k<3; k++)    opt_pnt[k] = pnt[k];
      opt_beptr = beptr;
    }

G0: beptr = beptr->Next;
  }

  /* move onto the bdy. patch */
  if (dist_min < G_factor*loc_sz)
  {

    /*
     for (k=0; k<3; k++)   
         nptr->Coor[k] = opt_pnt[k]; 
    */

     /* move the node in inflence zone 
     sp_move (Bdy_node_head_ptr, Bdy_nodes,
	      Bdy_elem_head_ptr, Bdy_elem,
	      Msh_node_head_ptr, Msh_nodes,
	      Msh_elem_head_ptr, Msh_elem,
	      nptr, opt_pnt, 3);
    */
    node_moving (nptr->Coor, opt_pnt, Mov_factor);
    

     nptr->bdy_ptr = opt_beptr;
     /* set up bdy Mtrl code */
     if (Bdy_lst_type == BD3D)
     {   /* single material region */
	    nptr->Mtrl = MTRL_IN_CODE;
     }
     else if (Bdy_lst_type == BD3DMTRL)
     {
	    nptr->Mtrl =  nptr->bdy_ptr->Mtrl_in * MTRL_IN_CODE
		            + nptr->bdy_ptr->Mtrl_out * MTRL_OUT_CODE;
     }

     if (Fit_mode == FORCED) nptr->status  = DONE; /* otherwise go iteration */
     ok_type = OK;
  }
  else
  {
    /*
    printf ("\nWarning...can't fit bdy. a large distant: dist_min = %lf(loc_size:%lf--factor: %lf);\n", dist_min, loc_sz, G_factor);
    */
    ok_type = BAD;
  }

  return (ok_type);
}




/* find the distance and intersection point (if it has one) between a point
   and bdy patch
*/
REAL
pnt2bdy (MeshNode *nptr, BMeshElem *beptr, REAL *pnt)
{
   int  i, k, cross_type, coplane_cp=0;
   REAL dist, tmp_dist;
   REAL a[3], b[3], c[3], d[3], e[3], r[3], temp[3];
   BMeshNode *n[3];


   dist = 1.e10;

   /* pass the node ptr. of the bdy. patch */
   for (k=0; k<3; k++)  n[k] = beptr->Elem.tri3.NodePtr[k];

   /* define vector a, b, c for tri-patch */
   for (k=0; k<3; k++)  a[k] = n[0]->Coor[k];
   for (k=0; k<3; k++)  b[k] = n[1]->Coor[k] - a[k];
   for (k=0; k<3; k++)  c[k] = n[2]->Coor[k] - a[k];

   /* define a ray from given to patch in the normal direction of the patch */
   for (k=0; k<3; k++)  d[k] = nptr->Coor[k];

   /* find patch normal which pointed out of the bdy of the object 
      it is strongly depended on the node ordering CCW
   */
   v_cros(b, c, temp);
   v_norm(temp, 3);

   /* determin end point of the ray */
RE:
   for (k=0; k<3; k++)    e[k] = d[k] + temp[k]*Max_size * 8;

   /* checking intersection */
   cross_type = line_tri_cross_conf (d, e, a, b, c, r);

   for (k=0; k<3; k++)    pnt[k] = 999.;   /* set as default */
   if (cross_type == OUTBOUND)
   {  /*determin the distance to bdy and  the Coor. */
      /* through each node */
      for (i=0; i<3; i++)
      {
	    if ((tmp_dist=v_rang (d, n[i]->Coor, 3)) < dist)
	    {
	        dist = tmp_dist;
            for (k=0; k<3; k++)  pnt[k] = n[i]->Coor[k];
        }
      }
      /* through  each edge of tri_patch */
      for (i=0; i<3; i++)
      {
        for (k=0; k<3; k++)  a[k] = n[imod(i,3)]->Coor[k];
	    for (k=0; k<3; k++)  b[k] = n[imod(i+1,3)]->Coor[k];
	    tmp_dist = edge_process (a, b, d, r);
	    if (tmp_dist < dist)
	    {
	        dist = tmp_dist;
            for (k=0; k<3; k++)   pnt[k] = r[k];
	    }
      }
   }
   else if (cross_type == PARALLEL)
   {
        fprintf (Diag_file, "\nError... Imporssible to be PARALLEL!\n");
   }
   else if (cross_type == COPLANE)
   { 
     /* 
        coplane is a sort of parallel, if parallel should be
        the case, then coplane should not happen too.
     */
     if (coplane_cp < 2)
     {
        coplane_cp++;
        fprintf (Diag_file, "\nCOPLANE! Disturbing base node!\n"); 
	    for (k=0; k<3; k++)
	        d[k] += LOWTOL * (GetRandom( 1, 100 )/100.);

	    goto RE;
     }
     else 
        fprintf (Diag_file, "\nCO-plane!\n");
   }
   else   /* ONPLANE AND ONEDGE all treat as INBOUND */
   {  /*determin the distance to bdy and pass the Coor.of intersected point */ 
      dist = v_rang(d, r, 3);
      for (k=0; k<3; k++)   pnt[k] = r[k];
   }

   return (dist);
}






/* compute the distance and coordinates between given point and line seg. */
REAL
edge_process (REAL *node_1, REAL *node_2, REAL *node_4, REAL *r)
{
  int  k;
  REAL dist=1.e10, cos_garma, len, len12, len14, vec[3], t;

  /* find cosine garma */
  cos_garma = cosine_ang (node_1, node_2, node_1, node_4);

  /* find projected length on the constraint */
  len12 = v_rang (node_1, node_2, 3);
  len14 = v_rang (node_1, node_4, 3);
  len   = cos_garma * len14;
  t     = len / len12;

  if (cos_garma <= 0.0)
  {
      /* take the distance between node_1 and node_4 */
      dist = len14;
      for (k=0; k<3; k++)   r[k] = node_1[k];
  }
  else if (t > 1)
  {
      /* take the distance between node_2 and node_4 */
      dist = v_rang (node_2, node_4, 3);
      for (k=0; k<3; k++)   r[k] = node_2[k];
  }
  else
  {
      /* take the distance from node_4 to line (node_1 to node_2) */
      dist = pt_to_line (node_1, node_2, node_4);
      /* debug: */
      /*
      dref = sqrt (len14*len14 - len*len);
      if (fabs (dref - dist) > LOWTOL)
      printf ("\nWarning...On the result of triangulation! dist=%8.4lf(%8.4lf)\n",
	            dist, dref);
      */
      /* find the coord. of intersection point */
      v_make(node_1, node_2, 3, vec);
      for (k=0; k<3; k++)    r[k] = node_1[k] + t * vec[k];
  }
  return (dist);
}







/* conform internal boundary */
void
conform_in_bdy (BMeshNode *bdy_n_head, long bdy_num_node,
		 BMeshElem *bdy_l_head, long bdy_num_elem,
		 MeshNode *msh_n_head, long msh_num_node,
		 MeshElem *msh_l_head, long msh_num_elem)
{
  long     ii, num_unresolve=0;
  int      fit_flag, fit_mode=NATURE; /* FORCED */
  MeshElem *eptr;


  if (Bdy_lst_type == BD3D)
  {   /* single material region and without Mtrl info. with BDY patch */
     printf("\nsingle material region and without Mtrl info. with BDY patch.");
     printf ("\n---Bypass this step !!\n");
     return ;
  }


  /*check the status of element. (how many mtrl region the elem. belongs to)*/
  find_bdy_elem (msh_l_head, msh_num_elem);

  /* find max. size of the object */
  Max_size = BDxmax - BDxmin;
  if (Max_size < BDymax - BDymin)  Max_size = BDymax - BDymin;
  if (Max_size < BDzmax - BDzmin)  Max_size = BDzmax - BDzmin;

  /* fit elem cross boundary */
  eptr = msh_l_head;
  if (eptr == NULL)   return;

  for (ii=0; ii<msh_num_elem; ii++)
  {
	if (eptr->status > 0)
	{   /* fit element cross bdy */
	    if (eptr->status >1 && eptr->status < 3)
	    {
		    switch (eptr->E_type)
		    {
		        case TET4:
			        fit_flag = fit_tet4_inbdy (eptr, fit_mode, bdy_l_head,
			                                    bdy_num_elem);
			        
			        if (fit_flag == BAD)
                    {
				        num_unresolve++;
                        fprintf (Diag_file, "\nWarning...Can't Fit elem %ld;\n", ii+1);
                    }
			        break;
		        case HEX8:
	                break;
		        default:
			        fprintf (Diag_file, "\nUnkown Elem. type...%d!\n", eptr->E_type);
		    }
	    }
	    else
		   fprintf (Diag_file, "\n...in %d Material regions.\n", eptr->status);
	}
	eptr = eptr->Next;
  }

  fprintf (Diag_file, "\nNum. of unresolved elem. = %ld!\n", num_unresolve);
  
  return;
}




/* check all the elements if any element cross BDY set the status > 0 */
void
find_bdy_elem (MeshElem *msh_l_head, long msh_num_elem)
{
    int      k, num_p, count;
    long     ii;
    MeshElem *eptr;
    MeshNode **nnptr;

    eptr = msh_l_head;
    for (ii=0; ii<msh_num_elem; ii++)
    {
	    switch (eptr->E_type)
	    {
	       case TET4:
		        num_p = 4;
		        nnptr = eptr->Elem.tet4.NodePtr;
		        break;
	       case HEX8:
		        num_p = 8;
		        nnptr = eptr->Elem.hex8.NodePtr;
		        break;
	       default:
		        fprintf (Diag_file, "\nError...Unknown element type (%d)!\n", eptr->E_type);
		        goto CON;
	    }

	    count = 0;
	    for (k=0; k<MAX_MTRL_NUM; k++)      Mtrl_code[k] = 0;
	    for (k=0; k<num_p; k++)
	    {
	        if (nnptr[k]->Mtrl > BDY_NODE_CODE)     continue; /* boundary node */
	        Mtrl_code[nnptr[k]->Mtrl]++;
	    }
	    for (k=0; k<MAX_MTRL_NUM; k++)
	    {
	        if (Mtrl_code[k])   count++;
	    }
	    if (count > 1)
		    eptr->status = count;   /* element cross bdy */
	    else
		    eptr->status = 0;

CON:	eptr = eptr->Next;
    }

    return;
}





/* fit the given element to external/internal boundary */
int
fit_tet4_inbdy (MeshElem *eptr, int fit_mode, 
		BMeshElem *bdy_l_head, long bdy_num_elem)
{
    int      i, j, quali_type, num_set_1=0, num_set_2=0;
    int      num_mov, mov_mtrl, set_1_done, set_2_done, opt_count;
    NODE_MTRL  mtrl[4];
    REAL     ori_elem_quali, quli, set_1_quli=LOWTOL, set_2_quli=LOWTOL;
    REAL     node_avg_quli[4];
    REAL     ave_dist1, ave_dist2;
    REAL     loc_size_1, loc_size_2, dummy, mov_factor;
    MeshNode **nnptr;
    NodeInfo node_buf[4];

    quali_type = VOLRAT;

    if ((ori_elem_quali = elem_assess (eptr, quali_type)) < LOWTOL)
    {
        /* negative (or tiny) not allowed */
	    fprintf (Diag_file, "\nWarning... Unacceptable elem. VOLRAT = %lf!\n", ori_elem_quali); 
	    return (BAD);
    }

    /* pass elem. node to buffer */
    nnptr = eptr->Elem.tet4.NodePtr;
    for (i=0; i<4; i++)
    {
	    mtrl[i] = BAD;       /* borrow here to do intialization */

	    for (j=0; j<3; j++)    node_buf[i].ori_coor[j] = nnptr[i]->Coor[j];
	    quli = avg_quli (nnptr[i], &node_buf[i].ori_quali, quali_type);

	    dummy = LOWTOL;
	    if (quli < dummy)
	    {
	        fprintf (Diag_file, "\nWarning... min Jacob in adj. Elem = %lf!\n", quli); 
            return (BAD);
	    }
    }

    /* Material classify --- dirty way */
    /* find first material */
    for (i=0; i<4; i++)
    {
	    if (nnptr[i]->Mtrl <= BDY_NODE_CODE)    /* Node on Boundary > 99 */ 
	    {
	        mtrl[MTRL1] = nnptr[i]->Mtrl;
	        break;
	    }
    }
    /* find second material */
    for (i=0; i<4; i++)
    {
	    if (nnptr[i]->Mtrl <= BDY_NODE_CODE && nnptr[i]->Mtrl != mtrl[MTRL1])
	    {
	        mtrl[MTRL2] = nnptr[i]->Mtrl;
	        break;
	    }
    }

    if (mtrl[MTRL1] == BAD || mtrl[MTRL2] == BAD)  
    {
       /* this case happens when previous process moved the nodes of
	  other elem. to BDY and now the nodes of given all sit in
	  same material region besides the BDY nodes
	  That's fine just skip, all set!!
      */
        return (OK);
    }

    /* classify as two set of material and bdy node */
    for (i=0; i<4; i++)
    {
	    if (nnptr[i]->Mtrl > BDY_NODE_CODE)              node_buf[i].set = BDY12;
	    else if (nnptr[i]->Mtrl == mtrl[MTRL1])
	        { node_buf[i].set = MTRL1;   num_set_1++; }
	    else if (nnptr[i]->Mtrl == mtrl[MTRL2])
	        { node_buf[i].set = MTRL2;   num_set_2++; }
	    else fprintf (Diag_file, "\nWarning..Wrong Mtrl code : %d!!\n", nnptr[i]->Mtrl);
    }

    /* find intersection point move to bdy for each elem. node */
    for (i=0; i<4; i++)
    { 
 	    node_buf[i].bdy_ptr =
	        find_inter_bdy (node_buf[i].ori_coor, node_buf[i].mov_coor,
			                &node_buf[i].mov_dist, mtrl, bdy_l_head, bdy_num_elem);

	    if (node_buf[i].bdy_ptr == NULL)
	    {
	        /* can't find intersection with BDY --- set penalty dist. */
	        node_buf[i].mov_dist = EXTRA;
	    }
 
        /* figure out the direction */
        v_make(node_buf[i].ori_coor, node_buf[i].mov_coor, 3, node_buf[i].mov_dir);

        v_norm(node_buf[i].mov_dir, 3);
    }

    /* find average moving distance for each set of nodes */
    ave_dist1 = ave_dist2 = loc_size_1 = loc_size_2 = 0;
    for (i=0; i<4; i++)
    {
	    if (node_buf[i].set == MTRL1)
	    {
	        if (nnptr[i]->status == FIXED || nnptr[i]->status == DONE)
	            ave_dist1 = EXTRA;
	        else
	        {
	            ave_dist1 += node_buf[i].mov_dist;
                loc_size_1 += loc_size (nnptr[i]);
	        }
	    }
	    else if (node_buf[i].set == MTRL2)
	    {
	        if (nnptr[i]->status == FIXED || nnptr[i]->status == DONE)
	                ave_dist2 = EXTRA;
            else
	        {
	            ave_dist2 += node_buf[i].mov_dist;
                loc_size_2 += loc_size (nnptr[i]);
	        }
	    }
    }
    ave_dist1 /= num_set_1;
    ave_dist2 /= num_set_2;
    loc_size_1 /= num_set_1;
    loc_size_2 /= num_set_2;
    
    if (ave_dist1 > XHUGE && ave_dist2 > XHUGE) 
    {
        fprintf (Diag_file, "Warning... ave_dist1=%lf <==> ave_dist2=%lf\n", 
                ave_dist1, ave_dist2);
        return (BAD); /* can't move */
    }
    
    mov_factor = 1.;      /* initial moving factor */
    opt_count  = 0;
OPT:    
    set_1_done = set_2_done = BAD;
    
    /* test move -- set 1 */
    if (ave_dist1 < G_factor*loc_size_1)
    {
        num_mov = num_set_1;
	    mov_mtrl = MTRL1;
	    /* dump a test and move a set of node to BDY */
	    set_new_position_b (nnptr, node_buf, mov_mtrl, FREE, mov_factor);
	
	    /* check out if it's acceptable */
	    set_1_quli = fit_tet4_test (eptr, nnptr, node_avg_quli, quali_type);
	    if (set_1_quli > MIN_QUALITY)  set_1_done = OK;

	    /* dump back for test move of set 2 nodes */
	    set_ori_position (nnptr, node_buf, mov_mtrl);
    }

    /* test move -- set 2 */
    if (ave_dist2 < G_factor*loc_size_2)
    {
        num_mov = num_set_2;
	    mov_mtrl = MTRL2;
	    /* dump a test and move a set of node to BDY */
	    set_new_position_b (nnptr, node_buf, mov_mtrl, FREE, mov_factor);
	
	    /* check out if it's acceptable */
	    set_2_quli = fit_tet4_test (eptr, nnptr, node_avg_quli, quali_type);
	    if (set_2_quli > MIN_QUALITY)  set_2_done = OK;

	    /* dump back for less confusion if the set one is the best one */
	    set_ori_position (nnptr, node_buf, mov_mtrl);
    }

    /* determine which set of node will be move onto the BDY */
    if (set_1_done==BAD && set_2_done==BAD)
    {
        if (fit_mode == NATURE)  
        {   
            if (opt_count > MAX_OPT) 
    		    return (BAD);/* can't fit it */  
    	    else
    	    {   /* do optimum process */
    	        mov_factor *= Opt_factor;
    	        opt_count++;
    	        goto OPT;
            }
        }
	    else if (fit_mode == FORCED)
	    {
	        if (set_1_quli > set_2_quli)
	        {
	            num_mov = num_set_1;
	            mov_mtrl = MTRL1;
	        }
	        else
	        {
	            num_mov = num_set_2;
	            mov_mtrl = MTRL2;
	        }

            /* finally fit the BDY */
            set_new_position_b (nnptr, node_buf, mov_mtrl, FIXED, mov_factor);
	        return (OK);
	    }
    }

    if (set_1_done == BAD)
    {
        num_mov = num_set_2;
	    mov_mtrl = MTRL2;
    }
    else if (set_2_done == BAD)
    {
        num_mov = num_set_1;
	    mov_mtrl = MTRL1;
    }
    else
    {
        if (set_1_quli > set_2_quli)
	    {
	        num_mov = num_set_1;
	        mov_mtrl = MTRL1;
	    }
	    else
	    {
	        num_mov = num_set_2;
	        mov_mtrl = MTRL2;
	    }
    }

    /* finally fit the BDY */
    set_new_position_b (nnptr, node_buf, mov_mtrl, FIXED, mov_factor);
    


    return (OK);
}




/* change a set of node location from node buffer */
void
set_new_position  (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		   int node_status)
{
    int i, j;

    for (i=0; i<4; i++)
    {
        if (node_buf[i].set == mov_mtrl)
	    {
	        if (node_buf[i].bdy_ptr == NULL)
	        {
	            fprintf (Diag_file, "\nWarning... Invalid moving node (set_new_position : move_dist=%lf;   bdy_ptr = %ld\n", node_buf[i].mov_dist, node_buf[i].bdy_ptr);
                continue;
            }
	        /* move the node to BDY */
	        if (node_status == FREE)
            {
	            for (j=0; j<3; j++)
	            {
		            nnptr[i]->Coor[j] = node_buf[i].mov_coor[j];
	            }
            }
	        else
            {
	            /* move the node in inflence zone */
	            sp_move (Bdy_node_head_ptr, Bdy_nodes,
		                 Bdy_elem_head_ptr, Bdy_elem,
		                 Msh_node_head_ptr, Msh_nodes,
		                 Msh_elem_head_ptr, Msh_elem,
		                 nnptr[i], node_buf[i].mov_coor, 0);
            }
	        nnptr[i]->status  = node_status;

	        /* set boundary material code */
	        if (node_status == FIXED)
	        {
	            nnptr[i]->Mtrl = node_buf[i].bdy_ptr->Mtrl_in * MTRL_IN_CODE +
		                node_buf[i].bdy_ptr->Mtrl_out *MTRL_OUT_CODE;      
	        }
	    }
    }
    return;
}



/* change a set of node location from node buffer with a moving factor*/
void
set_new_position_b  (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl, 
		   int node_status, double factor) 
{
   int i, j;
   REAL dir[3], len;

    for (i=0; i<4; i++)
    {
        if (node_buf[i].set == mov_mtrl)
        {
            if (node_buf[i].bdy_ptr == NULL)
            {
	           fprintf (Diag_file, "\nWarning... Invalid moving node (set_new_position : move_dist=%lf;   bdy_ptr = %ld\n", node_buf[i].mov_dist, node_buf[i].bdy_ptr);
               continue;
            }
            /* move the node to BDY */
            if (nnptr[i]->status == FREE || nnptr[i]->status == OUTNODE) 
            {
                if (fabs (factor-1.) < HIGTOL)
                {
	                for (j=0; j<3; j++)
		                nnptr[i]->Coor[j] = node_buf[i].mov_coor[j];
                }
                else
                {
                    v_make (nnptr[i]->Coor, node_buf[i].mov_coor, 3, dir);
                    v_norm (dir, 3);
                    len = v_rang (nnptr[i]->Coor, node_buf[i].mov_coor, 3);

                    for (j=0; j<3; j++)
                        nnptr[i]->Coor[j] = 
                            nnptr[i]->Coor[j] + factor * len * dir[j];
                }
                   
            }

	        /* set boundary material code */
            if (node_status == FIXED)
            {
                nnptr[i]->Mtrl = node_buf[i].bdy_ptr->Mtrl_in * MTRL_IN_CODE +
		                node_buf[i].bdy_ptr->Mtrl_out *MTRL_OUT_CODE;
                if (nnptr[i]->status == FREE)
                {
                    nnptr[i]->status = DONE;
                    nnptr[i]->bdy_ptr = node_buf[i].bdy_ptr;
                }
/* Ziji 1/7/99                else if (nnptr[i]->status == OUTNODE) */
                else if ((nnptr[i]->status == OUTNODE)||(nnptr[i]->status == ONSPBDY))
                {
                    nnptr[i]->bdy_ptr = node_buf[i].bdy_ptr;
                }
                else
                    fprintf (Diag_file, "odd status = %d\n", nnptr[i]->status);
            }
        }
    }
    return;
}



/* change a set of node back to origin location  */
void
set_ori_position  (MeshNode **nnptr, NodeInfo *node_buf, int mov_mtrl)
{
    int i, j;

    for (i=0; i<4; i++)
    {
        if (node_buf[i].set == mov_mtrl)
	    {
	        /* move the node to BDY */
	        for (j=0; j<3; j++)   
	        {
		        nnptr[i]->Coor[j] = node_buf[i].ori_coor[j];
	        }
	    }
    }
    return;
}




/* check the quality of given elem. after fitting trial and dump the result
   to node buffer. return <=0 if the element is invalid for FEM.
   if sucess       return the quali of the elem.
*/

REAL
fit_tet4_test (MeshElem *eptr, MeshNode **nnptr, double *node_quli, 
	       int quali_type)
{
    int    i;
    double min_quli, quli;

    min_quli = 1.e10;

    for (i=0; i<4; i++)
    {
	    if ((quli = avg_quli (nnptr[i], &node_quli[i], quali_type)) < LOWTOL)
	            return (BAD);
        else
            if (quli < min_quli)     min_quli = quli;
	}

    return (min_quli);

    /* check element quality 
    if ((quli = elem_assess (eptr, JACOB)) < LOWTOL)
    {   // negative (or tiny) jacob not allowed 
	    // printf ("\nWarning... Unacceptable elem. Jacob = %lf!\n", quli); 
	    return (BAD);
    }
    else
    {
        for (i=0; i<4; i++)
        {
	        if ((quli = avg_quli (nnptr[i], &node_quli[i], quali_type)) < LOWTOL)
	            return (BAD);
	    }
        quli = elem_assess (eptr, quali_type);
    }
    
    return (quli);
    */
}





/* find shortest distance to certain BDY */
BMeshElem *
find_inter_bdy (REAL *node, REAL *inter_pt, REAL *opt_dist, NODE_MTRL *mtrl,
		        BMeshElem *bdy_l_head, long bdy_num_elem)
{
    int      k;
    long     ii;
    REAL  vec0[3], dist_min, dist;
    REAL  pnt[3], opt_pnt[3];
    BMeshElem *beptr, *opt_beptr; 
    MeshNode *nptr, pt;

    /* dump a node structure for call  pnt2bdy and initialization */
    for (k=0; k<3; k++)
    {
      vec0[k] = pt.Coor[k] = node[k];
      opt_pnt[k] = 0.;
    }
    nptr = &pt;

    opt_beptr = NULL;
    /* traverse all the bounday patches */
    dist_min = 1.e10;
    beptr = bdy_l_head;
    for (ii=0; ii<bdy_num_elem; ii++)
    {
	    if ((beptr->Mtrl_in == mtrl[MTRL1] && beptr->Mtrl_out == mtrl[MTRL2])||
	        (beptr->Mtrl_in == mtrl[MTRL2] && beptr->Mtrl_out == mtrl[MTRL1]) )
	    {  /* right BDY patch */

	        /* box checking with bdy. patch */
	        if (vec0[X]+Global_size<beptr->xmin ||
			    vec0[X]-Global_size > beptr->xmax)  goto G0;
	        if (vec0[Y]+Global_size<beptr->ymin ||
			    vec0[Y]-Global_size > beptr->ymax)  goto G0;
	        if (vec0[Z]+Global_size<beptr->zmin||
			    vec0[Z]-Global_size > beptr->zmax)  goto G0;

	        /* find closest bdy. patch. to move to */
            dist = pnt2bdy (nptr, beptr, pnt);
	        if (dist < dist_min)
	        {
		        dist_min = dist;
		        for (k=0; k<3; k++)    opt_pnt[k] = pnt[k];
		        opt_beptr = beptr;
	        }
	    }
G0:     beptr = beptr->Next;
    }

    *opt_dist = dist_min;
    for (k=0; k<3; k++)   inter_pt[k] = opt_pnt[k]; 
    if (fabs (inter_pt[0] - 999) < HIGTOL)    return (NULL);
    return (opt_beptr);
}




/*
     The function to find intersection point between a straight line
     and a trianglar plane.

     input:   line (two endpoints) --- d[3] , e[3]
	      trianglar plane --- d[3], a[3], b[3]
				  a: a vector from origin to first node
				  b: a vector from first node to second node
				  c: a vector from first node to third node
			   2
			        *
		       b  *   *
		   1     *      *
		       *  *   *  *  3
		 a   *        c
		   *
	   o *
      output:   r --intersection point with the unbound plane defined by the
		    trianglation.

      return:   0 --- OUTBOUND;    INBOUND --- inbound;    PARALLEL ---  parallel
		  COPLANE --- co-plane;     ONEDGE --- the start node d on the bdy
*/
int
line_tri_cross_conf (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r)
{
      REAL t, u, w, x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4;
      REAL bxc[3], cxe[3], bxe[3], ee[3], dp1, dp2, dp3;
      REAL ray_len, dir[3];
      int  k, inbound = OUTBOUND;


RE:   r[0] = r[1] = r[2] = 0.0;
      ee[0] = e[0] - d[0];
      ee[1] = e[1] - d[1];
      ee[2] = e[2] - d[2];

      /*
	 CALCULATE t : the parameter from node d to intersection point along
		       the straight lin d --> e
      */
      bxc[0]=b[1]*c[2]-b[2]*c[1];
      bxc[1]=b[2]*c[0]-b[0]*c[2];
      bxc[2]=b[0]*c[1]-b[1]*c[0];
      dp1=bxc[0]*a[0]+bxc[1]*a[1]+bxc[2]*a[2];
      dp2=bxc[0]*d[0]+bxc[1]*d[1]+bxc[2]*d[2];
      dp3=bxc[0]*ee[0]+bxc[1]*ee[1]+bxc[2]*ee[2];

      /* If (BxC).E = 0 then the line segment and the plane are parallel */

      if ( fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      t=(dp1-dp2)/dp3;

      /* check ray direction  */
      if (t < 0.)
      {
	    ray_len = v_rang (d, e, 3);
	    /* printf ("\nChange search direction .. t=%lf:(ray_len=%lf)\n", t, ray_len);*/
	    v_make (d, e, 3, dir);
	    v_norm (dir, 3);
	    for (k=0; k<3; k++)   e[k] = d[k] - dir[k] * ray_len;
	    goto RE;
      }
      /* find instersection point with unbound plane */
      if (t >= 0.0 && t <= 1.0)
      {
	    r[0] = d[0] + t*ee[0];
	    r[1] = d[1] + t*ee[1];
	    r[2] = d[2] + t*ee[2];
      }
      else
      {   /* out of the range */
	    return (inbound = OUTBOUND);
      }

      /*
	    CALCULATE u --- parmeter for vector b  u=[0,1]
      */
      cxe[0]=c[1]*ee[2]-c[2]*ee[1];
      cxe[1]=c[2]*ee[0]-c[0]*ee[2];
      cxe[2]=c[0]*ee[1]-c[1]*ee[0];
      dp1=cxe[0]*d[0]+cxe[1]*d[1]+cxe[2]*d[2];
      dp2=cxe[0]*a[0]+cxe[1]*a[1]+cxe[2]*a[2];
      dp3=cxe[0]*b[0]+cxe[1]*b[1]+cxe[2]*b[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }
      u = (dp1-dp2)/dp3;
      if (u < 0.0 || u > 1.0)   return (inbound = OUTBOUND);   /* outbound */

      /*
	    CALCULATE w ---- parameter for vector c w=[0,1]
      */

      bxe[0]=b[1]*ee[2]-b[2]*ee[1];
      bxe[1]=b[2]*ee[0]-b[0]*ee[2];
      bxe[2]=b[0]*ee[1]-b[1]*ee[0];
      dp1=bxe[0]*d[0]+bxe[1]*d[1]+bxe[2]*d[2];
      dp2=bxe[0]*a[0]+bxe[1]*a[1]+bxe[2]*a[2];
      dp3=bxe[0]*c[0]+bxe[1]*c[1]+bxe[2]*c[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      w=(dp1-dp2)/dp3;

      /* the if--else if -- else check has to follow the sequence! */
      if(w < 0. ||  u+w > 1.0)
      {
	    /* outbound */
	    return (inbound = OUTBOUND);
      }
      else if (fabs (t) < HIGTOL)
      { /* the start node d (tested node) is on the plane */
	    return (inbound = ONPLANE);
      }
      else if (fabs (u) < HIGTOL || fabs (w) < HIGTOL || fabs (u+w) < HIGTOL)
      {
	    /* ON the edge of tri-patch */
	    return (inbound = ONEDGE);
      }
      else
      {
	    /* inbound */
	    inbound = INBOUND;
      }

EXIT:
      if (inbound == PARALLEL)
      {
	    /* check co-plane */
	    /* following three nodes define a plane */
	    x1 = a[0];      y1 = a[1];       z1 = a[2];
	    x2 = a[0]+b[0]; y2 = a[1]+b[1];  z2 = a[2]+b[2];
	    x3 = a[0]+c[0]; y3 = a[1]+c[1];  z3 = a[2]+c[2];
	    /* check fourth node for co-plane */
	    x4 = d[0];      y4 = d[1];       z4 = d[2];
	    u = (x4-x1)*(y2-y1)*(z3-z1)
	        +(y4-y1)*(z2-z1)*(x3-x1)
	        +(z4-z1)*(x2-x1)*(y3-y1);

	    w = (z4-z1)*(y2-y1)*(x3-x1)
	        +(y4-y1)*(x2-x1)*(z3-z1)
	        +(x4-x1)*(z2-z1)*(y3-y1);

	    t = u - w;

	    if (fabs (t) < HIGTOL)   
	    {
	        inbound = COPLANE;      /* co-plane */
	    }
      }

      return (inbound);
}



/* move a node to a target point with given percentage */
int 
node_moving (REAL *node1, REAL *node2, double mov_factor)
{
  int  k;
  REAL dir[3], len;

  v_make (node1, node2, 3, dir);
  v_norm (dir, 3);
  len = v_rang (node1, node2, 3);
  
  for (k=0; k<3; k++)   node1[k] = node1[k] + mov_factor * len * dir[k];
  return (OK);
}
