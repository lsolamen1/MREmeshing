/*
* ======================================================================
* NIST Guide to Available Math Software.
* Fullsource for module ICCG from package LINALG.
* Retrieved from NETLIB on Thu Jun 13 18:00:15 1996.
*
*  Modified by    John M. Sullivan
*  Ported to C by Qingyang Zhang			2/16/1997
* ======================================================================
*/

/* &&& Please remember to adjust the array index!!! */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define  imod(x,y)  (int)(fmod((double)(x), (double)(y)))



/* Local Function Prototypes  */
int iccgluc (double *a,  int n,     int *ia,   int *ja,   double *af, double *b,
		     double *x,  double *r, double *p, double *s, double tol, 
		     int maxits, int *its,   int *info);
int axpy (double *a, int n, int *ia, int *ja, int i, int js, int je, 
          double t, double *y);
int saxpy2 (int n, double da, double *dx, int incx, double *dy, int incy);
int slot (int *ia, int *ja, int irow, int jcol, int nodcon);
int collapse (int *ia, int *ja, int n, int nodcon);
int insert (double t, double *a, int n, int *ia, int *ja, int i, int j, int k);
int locate (double *a, int n, int *ia, int *ja, int i, int j, int *k);
int mmult (double *a, int n, int *ia, int *ja, double *b, double *x, int job);
int putsum (double t, double *a, int n, int *ia, int *ja, int i, int j);
int cgres (double *a, int n, int *ia, int *ja, double *x, double *b, double *r);
int ssol (double *a, int n, int *ia, int *ja, double *b, int job);
int saxpy (int n, double sa, double *sx, int incx, double *sy, int incy);
int scopy (int n, double *sx, int incx, double *sy, int incy);
double sdot (int n, double *sx, int incx, double *sy, int incy);
int isamax (int n, double *sx, int incx);
int sprsrowzap1 (double *qv, int *iq,  int i, int mxiq, int mxjq);
int kay1 (int i, int j, int *iq, int *jq, int mxiq, int mxjq);

static int lu (double *a, int n, int *ia, int *ja);
static double dot (double *a, int n, int *ia, int *ja, int i, int js,
                   int je, double *b);
static int put (double t, double *a, int n, int *ia, int *ja, int i, int j);




/* Global Varibles */
double rtxmax, rtxmin;


/*fun**********************************************************************
	NAME:			iccgluc
	DESCRIPTION:	this routine performs preconditioned conjugate 
                    gradient on a sparse matrix. the preconditioner 
                    is an incomplete lu of the matrix.
     
                on entry:
                    a  real()
                        contains the elements of the matrix.
        
                    n  integer
                        is the order of the matrix.

                    ia integer(n+1)
                        contains pointers to the start of the rows 
                        in the arrays a and ja.

                    ja integer()
                        contains the column location of the 
                        corresponding elements in the array a.

                    b real (n)
                        contains the right hand side.

                    x real (n)
                        contains an estimate of the solution, the 
                        closer it is to the true solution the faster 
                        the method will converge.

                    tol real
                        is the accuracy desired in the solution.

                    maxits integer
                        is the maximun number of iterations to be taken
                        by the routine.

                    job integer
                        is a flag to signal if incomplete factorization
                        aready exits in array af.
                        job = 0  perform incomplete factorization
                        job = 1  skip incomplete factorization

            on output:
                    af real ()
                        contains the incomplete factorization of the matrix
                        contained in the array a.

                    x real (n)
                        contains the solution.

                    r,p,s real (n)
                        these are scratch work arrays.

                    its integer
                         contains the number of iterations need to converge.

                    info integer
                        signals if normal termination.
                        info = 0 method converged in its iterations
                        info = 1 method converged, but exit occurred because
                                residual norm was less than sqrt(rtxmin).
                        info = -999 method did not converge in maxits iterations.

            The algorithm has the following form.

                form incomplete factors l and u
                x(0) <- initial estiate
                r(0) <- b - a*x(0)
                r(0) <- trans(a)*invtrans(l)*invtrans(u)*inv(u)*inv(l)*r(0)
                p(0) <- r(0)
                i    <- 0
                while r(i) > tol do
                s      <- inv(u)*inv(l)*a*p(i)
                a(i)   <- trans(r(i))*r(i)/(trans(s)*s)
                x(i+1) <- x(i) + a(i)*p(i)
                r(i+1) <- r(i) - a(i)*trans(a)*invtrans(l)*invtrans(u)*s
                b(i)   <- trans(r(i+1))*r(i+1)/(trans(r(i))*r(i))
                p(i+1) <- r(i+1) + b(i)*p(i)
                i      <- i + 1
                end

            real ai,bi,rowold,rownew,xnrm,anrm
            real sdot
            real rtxmax,rtxmin

	RETURN:	    same as info	
***************************************************************************/ 
int 
iccgluc (double *a,  int n,     int *ia,   int *ja,   double *af, double *b,
		 double *x,  double *r, double *p, double *s, double tol, 
		 int maxits, int *its,   int *info)
{
    int     i;
    double  rowold, rownew, ai, bi, anrm, xnrm;

    /* initialize  */
    rtxmin = 1.0e-16;
    *info = 0;
    
    anrm = fabs (a[isamax(ia[n+1]-1, a, 1)]);

    /* form incomplete factors l and u 
     if( job .ne. 0 ) go to 5
    */
    scopy (ia[n+1]-1, a, 1, af, 1);
    lu (af, n, ia, ja);  
         
    /* 5 continue */
    /* r(0) <- b - a*x(0) */

    cgres (a, n, ia, ja, x, b, r);
    
    /*
     r(0) <- trans(a)*invtrans(l)*invtrans(u)*inv(u)*inv(l)*r(0)
     inv(u)*inv(l)*r(0)
    */

    scopy (n,  r, 1,  s,  1);
    ssol  (af, n, ia, ja, s, 1);
    ssol  (af, n, ia, ja, s, 2);

    /* invtrans(l)*invtrans(u)*above */

    ssol (af, n, ia, ja, s, -2);
    ssol (af, n, ia, ja, s, -1);

    /* trans(a)*above   */
    mmult (a, n, ia, ja, r, s, -1);

    /* p(0) <- r(0) */

    scopy (n, r, 1, p, 1);
    rowold = sdot (n, r, 1, r, 1);
    i = 0;

    /* while r(i) > tol do */
    ai = 1.0;
 
    
    /* 10 continue */
L10:    
    xnrm = fabs (x[isamax(n, x, 1)]);
    if( sqrt(rowold) <= tol*(anrm*xnrm) ) goto L12;

    /*
    write(6,*) ' iter residual xnrm ai',i,sqrt(rowold)/(anrm*xnrm),
    $            xnrm,ai
    */
    
    /*
    c
    c  jms changed 6/20/96
    c
    c      if( sqrt(rowold).le.tol*(anrm*xnrm) .and.
    c     &    i.gt.maxits/10) go to 12
    c
    c
    c
    cc    if (rowold .le. rtxmin) go to 25
    */
    /* 13 continue */
    /*
    c
    c        s      <- inv(u)*inv(l)*a*p(i)
    c
    */

    mmult (a,  n, ia, ja, s, p, 1);
    ssol  (af, n, ia, ja, s, 1);
    ssol  (af, n, ia, ja, s, 2);

    /*
    c
    c        a(i)   <- trans(r(i))*r(i)/(trans(s)*s)
    c
    */

    ai = rowold / sdot (n, s, 1, s, 1);

    /*
    c
    c        x(i+1) <- x(i) + a(i)*p(i)
    c
    */

    saxpy (n, ai, p, 1, x, 1);

    /*
    c
    c
    c        r(i+1) <- r(i) - a(i)*trans(a)*invtrans(l)*invtrans(u)*s
    c
    */

    ssol  (af, n, ia, ja, s, -2);
    ssol  (af, n, ia, ja, s, -1);
    mmult (a,  n, ia, ja, b, s, -1);
    saxpy (n, -ai, b, 1,  r, 1);

    /*
    c
    c        b(i)   <- trans(r(i+1))*r(i+1)/(trans(r(i))*r(i))
    c
    */

    rownew = sdot(n, r, 1, r, 1);
    bi = rownew/rowold;

    /*
    c
    c        p(i+1) <- r(i+1) + b(i)*p(i)
    c
    */

    saxpy2 (n, bi, p, 1, r, 1);
    rowold = rownew;

    /*
    c
    c        i      <- i + 1
    c
    */
    
    i = i + 1;
    if ( i > maxits ) goto L20;
   
    goto L10;
L12:
        /*
        12 continue
        15 continue
        */
    *its = i;
    return (*info);
L20:
    /* 20 continue */
    *info = -999;
    *its = maxits;
    return (*info);

    /*
    c  25 continue
    c     info = 1
    c     its = i
    c     return
      end
    */
}
     


/*fun**********************************************************************
	NAME:			axpy
	DESCRIPTION:	this routine computes an axpy for a row of a sparse 
                    matrix with a vector.
                    an axpy is a multiple of a row of the matrix is 
                    added to the vector y.
	RETURN:			if error return negtive value	
***************************************************************************/ 
int 
axpy (double *a, int n, int *ia, int *ja, int i, int js, int je, 
      double t, double *y)
{
    int j, is, ie, ir;

    is = ia [i];
    ie = ia [i+1] - 1;
    for (ir=is; ir<=ie; ir++)
    {
         j = ja[ir];
         if( j > je ) break;
         if( j < js ) continue;
         y[j] = y[j] +  t * a[ir];
    }
    return (0); 
}



/*fun**********************************************************************
	NAME:			saxpy2
	DESCRIPTION:	constant times a vector plus a vector.
                    uses unrolled loops for increments equal to one.     
                    jack dongarra, linpack, 3/11/78.
	RETURN:			if error return negtive value	
***************************************************************************/ 
int
saxpy2 (int n, double da, double *dx, int incx, double *dy, int incy)
{

    /*
      implicit real*8 (a-h,o-z)
      dimension dx(1),dy(1)
      integer i,incx,incy,m,mp1,n  
    */
    int     i, m, ix, iy, mp1;


    if (n < 0)     return (0);
    if (da == 0.0) return (0);
    if (incx == 1 && incy == 1) goto L20;

    /*
    c
    c        code for unequal increments or equal increments
    c          not equal to 1
    c
    */

    ix = 1;
    iy = 1;
    if(incx < 0)    ix = (-n+1)*incx + 1;
    if(incy < 0)    iy = (-n+1)*incy + 1;
    for (i=1; i<=n; i++)
    {
        dx[iy] = dy[iy] + da*dx[ix];
        ix = ix + incx;
        iy = iy + incy;
    }
    return (0);

    /*
    c
    c        code for both increments equal to 1
    c
    c
    c        clean-up loop
    c
    */

L20: 
    m = imod (n,4);
    if( m == 0 ) goto L40;

    for (i=1; i<=m; i++)
    {
        dx[i] = dy[i] + da*dx[i];
    }

    if (n < 4) return (0);

L40:
    mp1 = m + 1;
    for (i=mp1; i<=n; i=i+4)
    {
        dx[i]     = dy[i]     + da*dx[i];
        dx[i + 1] = dy[i + 1] + da*dx[i + 1];
        dx[i + 2] = dy[i + 2] + da*dx[i + 2];
        dx[i + 3] = dy[i + 3] + da*dx[i + 3];
    }
    return (0);
}



/*fun**********************************************************************
	NAME:			dot
	DESCRIPTION:	this routine computes an inner product for a row 
                    of a sparse matrix with a vector..
	RETURN:			if error return negtive value	
***************************************************************************/ 
static double 
dot (double *a, int n, int *ia, int *ja, int i, int js, int je, double *b)
{
    int     j, is, ie, ir;    
    double  t;
    
    t = 0.0;
    is = ia[i];
    ie = ia[i+1] - 1;
    for (ir=is; ir<=ie; ir++)
    {
        j = ja[ir];
        if( j > je ) break;
        if( j < js ) continue;
        t = t + a[ir]*b[j];
    }
    return (t);
}
	  
/*fun**********************************************************************
	NAME:			slot
	DESCRIPTION:	
	RETURN:			if error return negtive value	
***************************************************************************/ 
int
slot (int *ia, int *ja, int irow, int jcol, int nodcon)
{

    int j, k, kk, istart, iend;
    
	istart = (irow-1)*nodcon + 1;
	iend   = istart + nodcon - 1;
	for (j=istart; j<=iend; j++)
    {
	    if(ja[j] == 0)
        {
	        ja[j] = jcol;
		    return (0);
        }
	    if (ja[j] == jcol) return (0);
	    if (jcol < ja[j])
        {
	        if (ja[iend] != 0)
            {
	            printf (" Exceeded sparse connection of %d, irow = %d, jcol = %d, j = %d\n",
                    nodcon, irow, jcol, j);
		        for (kk=istart; kk<=iend; kk++)
                {
		            printf ("   %d  %d\n", kk, ja[kk]);
                }
		    
	            exit (-1);
            }
	        for (k=iend-1; k>=j; k--)
            {
		        ja[k+1] = ja[k];
            }
	        ja[j] = jcol;
		    return (0);
        }
	    if(j == iend)
        {
	        printf (" Exceeded sparse connection of %d, irow = %d, jcol = %d, j = %d \n",
                nodcon, irow, jcol, j);
		    for (kk=istart; kk<=iend; kk++)
            {
		       printf ("    %d  %d\n", kk, ja[kk]);
            }
	        exit (-1);
        }
    }
	return (0);
 }


/*fun**********************************************************************
	NAME:			collapse
	DESCRIPTION:	
	RETURN:			if error return negtive value	
***************************************************************************/ 
int 
collapse (int *ia, int *ja, int n, int nodcon)
{
    int i, ii, j, jj, loc;

	loc = 0;
	for (i=1; i<=n; i++)
    {
	    ia[i] = 0;
	    for (j=(i-1)*nodcon+1; j<= i*nodcon; j++)
        {
		    if(ja[j] != 0)
            {
		        ia[i] = ia[i] + 1;
		        loc++;
		        ja[loc] = ja[j];
            }
            else
		        break;
        }
    }
	jj = 0;
	for (i=1; i<=n; i++)
    {
	    ii = ia[i];
		ia[i] = jj + 1;
		jj = jj + ii;
    }
	ia[n+1] = jj+1;
	return (0);
}

	  
/*fun**********************************************************************
	NAME:			insert
	DESCRIPTION:	this routine rearranges the elements in arrays a and ja
                    and updates array ia for the new element.
	RETURN:			if error return negtive value	
***************************************************************************/ 
int
insert (double t, double *a, int n, int *ia, int *ja, int i, int j, int k)
{
    int l, l1, l2, lb, ip1, np1;

    printf ("**** from insert i = %d, j = %d, ia[i] = %d, ia[i+1] = %d, t = %lf\n", 
        i, j, ia[i], ia[i+1], t);


    l1 = k;
    l2 = ia[n+1] - 1;
    for (lb=l1; lb<=l2; lb++)
    {
        l = l2 - lb + l1;
        a[l+1]  = a[l];
        ja[l+1] = ja[l];
    }

    a[k] = t;
    ja[k] = j;
    ip1 = i + 1;
    np1 = n + 1;
    for (l=ip1; l<=np1; l++)
    {
        ia[l] = ia[l] + 1;
    }
    return (0);
}

/*fun**********************************************************************
	NAME:			locate
	DESCRIPTION:	this routine will locate the i,j-th element in the
                    sparse matrix structure.
	RETURN:			1 = TRUE     0 = FALSE	
***************************************************************************/         
int
locate (double *a, int n, int *ia, int *ja, int i, int j, int *k)
{
    int     l, is, ie, ret;

    is = ia[i];
    ie = ia[i+1] - 1;

    /* row i is from is to ie in array a. */

    for (l=is; l<=ie; l++)
    {
        if(j > ja[l])  continue;
        if(j != ja[l] ) ;
        else
        {
            ret = 1;
            *k = l;
            return (ret);
        }

        if(j >= ja[l]) continue;
        ret = 0;
        *k = 0;
        return (ret);
    }

    /*  get here if should be at the end of a row. */

    ret = 0;
    *k = 0;
    return (ret);
}      



	  
/*fun**********************************************************************
	NAME:			lu
	DESCRIPTION:	this subroutine does incomplete gaussian elimenation
                    on a sparse matrix. the matrix is stored in a sparse
                    data structure.
                    note: no pivoting is done
                        and the factorization is incomplete,
                        i.e., only where there exists a storage location
                        will the operation take place.
	RETURN:			if error return negtive value	
***************************************************************************/ 
static int
lu (double *a, int n, int *ia, int *ja)
{    
    int     i, j, k, l2, kp1, ie, ik, is, kj, ke, ikp1;
    
    for (k=1; k<=n; k++)
    {
        if(!locate(a, n, ia, ja, k, k, &l2)) return (0);
        if( a[l2] == 0.0) return (-1);
        kp1 = k + 1;
        for (i=kp1; i<=n; i++)
        {
            if(!locate(a, n, ia, ja, i, k, &ik)) continue;
            is = ik;
            ie = ia[i+1] - 1;
            kj = l2;
            ke = ia[k+1] - 1;
            a[ik]= a[ik]/a[kj];
            if( kj == ke ) continue;
            kj = kj + 1;
            ikp1 = ik + 1;
            for (j=ikp1; j<=ie; j++)
            {
L10:
                if(kj > ke ) break;
                if(ja[kj] >= ja[j]) goto L15;
                kj = kj + 1;
                goto L10;
L15:
                if(ja[kj] > ja[j]) continue;
                a[j] = a[j] - a[ik]*a[kj];
            }
        }
    }
    return (0); 
}


/*fun**********************************************************************
	NAME:			mmult
	DESCRIPTION:	this routine performs matrix vector multiple
                    for a sparse matrix structure

                    job has the following input meanings:
                    job =  1  matrix vector multiple
                        = -1  matrix transpose vector multiple
                        =  2  unit lower matrix vector multiple
                        = -2  unit lower matrix transpose vector multiple
                        =  3  upper matrix vector multiple
                        = -3  upper matrix transpose vector multiple
	RETURN:			if error return negtive value	
***************************************************************************/ 
int
mmult (double *a, int n, int *ia, int *ja, double *b, double *x, int job)
{
    int     i;

    if(job != 1) goto L15;
    for (i=1; i<=n; i++)
    {
        b[i] = dot (a, n, ia, ja, i, 1, n, x);
    }

    /*  trans(a)*x */
L15:
    if(job != -1 ) goto L35;
    for (i=1; i<=n; i++)
    {
        b[i] = 0.0;
    }

    for (i=1; i<=n; i++)
    {
        axpy(a, n, ia, ja, i, 1, n, x[i], b);
    }

    /*   l*x   when l is unit lower */
L35:
    if(job != 2) goto L45;
    for (i=1; i<=n; i++)
    {
        b[i] = x[i] + dot(a, n, ia, ja, i, 1, i-1, x);
    }

    /* trans(l)*x   when l is unit lower */
L45:
    if(job != -2 ) goto L55;
    for (i=1; i<=n; i++)
    {
        b[i] = x[i];
    }

    for (i=1; i<=n; i++)
    {
        axpy (a, n, ia, ja, i, i, n, x[i], b);
    }

    /* u*x */
L55:
    if (job != 3) goto L65;
    for (i=1; i<=n; i++)
    {
        b[i] = dot(a, n, ia, ja, i, i, n, x);
    }

    /*  trans(u)*x  */
L65:
    if(job != -3) goto L85;
    for (i=1; i<=n; i++)
    {
        b[i] = 0.0;
    }
    for (i=1; i<=n; i++)
    {
        axpy(a, n, ia, ja, i, 1, i, x[i], b);
    }
L85:
    return (0);
}


/*fun**********************************************************************
	NAME:			put
	DESCRIPTION:	this routine will insert an element into the 
                    sparse matrix structure.
	RETURN:			if error return negtive value		
***************************************************************************/         
static int
put (double t, double *a, int n, int *ia, int *ja, int i, int j)
{
    int     k, is, ie;
    
    is = ia[i];
    ie = ia[i+1] - 1;

    
    /* row i is from is to ie in array a. */
    
    for (k=is; k<=ie; k++)
    {
        if(j > ja[k])   continue;
        if(j != ja[k])  goto L5;
        a[k] = t;
        goto L20;
L5:    
        if(j >= ja[k])  continue;
        insert (t, a, n, ia, ja, i, j, k);
        goto L20;
    }

    /* get here if should be at the end of a row. */

    k = ie + 1;
    insert (t, a, n, ia, ja, i, j, k);
L20:
    return (0);
}



/*fun**********************************************************************
	NAME:			putsum 
	DESCRIPTION:	this routine will insert an element into the 
                    sparse matrix structure.
	RETURN:			if error return negtive value		
***************************************************************************/         
int 
putsum (double t, double *a, int n, int *ia, int *ja, int i, int j)
{
    int     k, is, ie;


    is = ia[i];
    ie = ia[i+1] - 1;


    /* row i is from is to ie in array a. */
    for (k=is; k<=ie; k++)
    {
        if(j != ja[k]) continue;
        a[k] = a[k] + t;
        goto L20;

        /*
        c    5    continue
        c         if( j .ge. ja(k) ) go to 12
        c            call insert(t,a,n,ia,ja,i,j,k)
        c            go to 20
        c   12    continue
        */
    }

    /*  get here if should be at the end of a row. */

    printf ("I should not be here\n");
	printf ("i = %d, j = %d, is = %d, ie = %d\n", i, j, is, ie);
	for (k=is; k<=ie; k++)
	  	printf ("k = %d,    ja[k] = %d\n", k, ja[k]);
	
    printf ("Pause...press any to continue!\n");
	getchar (); getchar ();
    k = ie + 1;
    insert(t, a, n, ia, ja, i, j, k);
L20:
    return (0);
}



/*fun**********************************************************************
	NAME:			cgres
	DESCRIPTION:	this routine computes a residual for a*x=b where
                    a is in a sparse structure
	RETURN:			if error return negtive value		
***************************************************************************/         
int
cgres (double *a, int n, int *ia, int *ja, double *x, double *b, double *r)
{
    /* real dot */
    int     i;

    for (i=1; i<=n; i++)
    {
         r[i] = b[i] - dot (a, n, ia, ja, i, 1, n, x);
    }
    return (0);
}


/*fun**********************************************************************
	NAME:			ssol
	DESCRIPTION:	this routine solves a system of equations based on 
                    a sparse matrix date structure. the array b contains 
                    the right hand side on input and on output has 
                    the solution
                    job has the value  1 if l*x = b is to be solved.
                    job has the value -1 if trans(l)*x = b is to be solved.
                    job has the value  2 if u*x = b is to be solved.
                    job has the value -2 if trans(u)*x = b is to be solved.
	RETURN:			if error return negtive value		
***************************************************************************/         
int 
ssol (double *a, int n, int *ia, int *ja, double *b, int job)
{
    int     ib, i, k;
    double  t;


    /* job = 1  solve  l*x = b */
    
    if( job != 1 ) goto L15;

    /* solve l*y=b */
    for (i=2; i<=n; i++)
    {
        b[i] = b[i] - dot (a, n, ia, ja, i, 1, i-1, b);
    }
L15:
    if (job != 2 ) goto L25;

    /*   solve u*x=y */

    for (ib=1; ib<=n; ib++)
    {
        i = n - ib + 1;
        t = dot (a, n, ia, ja, i, i+1, n, b);
        if (!locate(a, n, ia, ja, i, i, &k)) goto L30;
        b[i] = (b[i] - t)/a[k];
    }

    /* job = -2  solve  trans(u)*x = b  */

L25:
    if (job != -2) goto L35;

    /* solve trans(u)*y=b */

    for (i=1; i<=n; i++)
    {
        if(!locate(a, n, ia, ja, i, i, &k)) goto L30;
        b[i] = b[i]/a[k];
        axpy (a, n, ia, ja, i, i+1, n, -b[i], b);
    }

    /* solve trans(l)*x=y  */

L35:
    if (job != -1 ) goto L45;
    for (ib=2; ib<=n; ib++)
    {
        i = n - ib + 2;
        axpy(a, n, ia, ja, i, 1, i-1, -b[i], b);
    }
L45:
    return (0);
L30:
    /* printf (" error no diagonal element: from solve\n"); */
    return (0);
}



/*fun**********************************************************************
	NAME:			saxpy
	DESCRIPTION:	constant times a vector plus a vector.
                    uses unrolled loop for increments equal to one.
                    jack dongarra, linpack, 3/11/78.
	RETURN:			if error return negtive value		
***************************************************************************/         
int
saxpy (int n, double sa, double *sx, int incx, double *sy, int incy)
{

    int     i, ix, iy, m, mp1;
    
    if (n <= 0)      return (-1);
    if (sa == 0.0)   return (-2);
    if (incx==1 && incy==1) goto L20;

    /* code for unequal increments or equal increments not equal to 1 */

    ix = 1;
    iy = 1;
    if (incx < 0)    ix = (-n+1)*incx + 1;
    if (incy < 0)    iy = (-n+1)*incy + 1;
    for (i=1; i<=n; i++)
    {
        sy[iy] = sy[iy] + sa*sx[ix];
        ix = ix + incx;
        iy = iy + incy;
    }
    return (0);

    /* code for both increments equal to 1 */
        
    /* clean-up loop */
L20:
    m = imod (n, 4);
    if( m  ==  0 ) goto L40;
    for (i=1; i<=m; i++)
    {
        sy[i] = sy[i] + sa*sx[i];
    }
    
    if( n < 4 ) return (0);
L40:
    mp1 = m + 1;
    for (i=mp1; i<=n; i=i+4)
    {
        sy[i] = sy[i] + sa*sx[i];
        sy[i + 1] = sy[i + 1] + sa*sx[i + 1];
        sy[i + 2] = sy[i + 2] + sa*sx[i + 2];
        sy[i + 3] = sy[i + 3] + sa*sx[i + 3];
    }
    return (0);
}




/*fun**********************************************************************
	NAME:			scopy
	DESCRIPTION:	copies a vector, x, to a vector, y.
                    uses unrolled loops for increments equal to 1.
                    jack dongarra, linpack, 3/11/78.
	RETURN:			if error return negtive value		
***************************************************************************/         
int 
scopy (int n, double *sx, int incx, double *sy, int incy)
{

    int     ix, iy, i, m, mp1;

    if(n <= 0)      return (-1);
    if(incx==1 && incy==1) goto L20;

    /*  code for unequal increments or equal increments not equal to 1 */

    ix = 1;
    iy = 1;

    if (incx < 0)   ix = (-n+1)*incx + 1;
    if (incy < 0)   iy = (-n+1)*incy + 1;
    for (i=1; i<=n; i++)
    {
        sy[iy] = sx[ix];
        ix = ix + incx;
        iy = iy + incy;
    }
    return (0);

    /* code for both increments equal to 1 */

    /* clean-up loop */

L20:
    m = imod(n, 7);

    if(m  == 0) goto L40;
    for (i=1; i<=m; i++)
    {
        sy[i] = sx[i];
    }
    if( n < 7 ) return (0);
L40:
    mp1 = m + 1;
    for (i=mp1; i<=n; i=i+7)
    {
        sy[i] = sx[i];
        sy[i + 1] = sx[i + 1];
        sy[i + 2] = sx[i + 2];
        sy[i + 3] = sx[i + 3];
        sy[i + 4] = sx[i + 4];
        sy[i + 5] = sx[i + 5];
        sy[i + 6] = sx[i + 6];
    }
    return (0);
}


/*fun**********************************************************************
	NAME:			sdot
	DESCRIPTION:	forms the dot product of two vectors.
                    uses unrolled loops for increments equal to one.
                    jack dongarra, linpack, 3/11/78.
	RETURN:			dot product
***************************************************************************/         
double 
sdot (int n, double *sx, int incx, double *sy, int incy)
{
      int       i, ix, iy, m, mp1;
      double    stemp, ret;

      stemp = 0.0;
      ret   = 0.0;
      if(n <= 0)   return (ret);
      if(incx==1 && incy==1)    goto L20;

    /* code for unequal increments or equal increments not equal to 1 */

    ix = 1;
    iy = 1;
    if(incx < 0)    ix = (-n+1)*incx + 1;
    if(incy < 0)    iy = (-n+1)*incy + 1;
    for (i=1; i<=n; i++)
    {
        stemp = stemp + sx[ix]*sy[iy];
        ix = ix + incx;
        iy = iy + incy;
    }
    ret = stemp;
    return (ret);

    /*  code for both increments equal to 1  */


    /* clean-up loop */
L20:
    m = imod (n, 5);
    if(m == 0) goto L40;
    for (i=1; i<=m; i++)
    {
        stemp = stemp + sx[i]*sy[i];
    }
    if (n < 5 ) goto L60;
L40:
    mp1 = m + 1;
    for (i=mp1; i<=n; i=i+5)
    {
        stemp = stemp + sx[i]*sy[i] + sx[i + 1]*sy[i + 1] +
                sx[i + 2]*sy[i + 2] + sx[i + 3]*sy[i + 3] + sx[i + 4]*sy[i + 4];
    }
L60: 
    ret = stemp;
    return (ret);

}



/*fun**********************************************************************
	NAME:			isamax
	DESCRIPTION:	finds the index of element having max. absolute value.
                    jack dongarra, linpack, 3/11/78.
	RETURN:			the index
***************************************************************************/         
int
isamax (int n, double *sx, int incx)
{
    int     i, ix, ret;
    double  smax;

    ret = 0;
    if (n < 1 ) return (ret);
    ret = 1;
    if (n == 1) return (ret);
    if (incx == 1)  goto L20;

    /* ode for increment not equal to 1 */
    ix = 1;
    smax = fabs(sx[1]);
    ix = ix + incx;
    for (i=2; i<=n; i++)
    {
        if (fabs(sx[ix]) <= smax) goto L5;
        ret = i;
        smax = fabs(sx[ix]);
L5:
        ix = ix + incx;
    }
    return (ret);

    /* code for increment equal to 1 */

L20:
    smax = fabs(sx[1]);
    for (i=2; i<=n; i++)
    {
         if(fabs(sx[i]) <= smax)  continue;
         ret = i;
         smax = fabs(sx[i]);
    }
    return (ret);
}




/*fun**********************************************************************
	NAME:			sprsrowzap1
	DESCRIPTION:	REPLACES ROW I OF QV WITH ZEROS
	RETURN:			if error return negtive value
***************************************************************************/         
int
sprsrowzap1 (double *qv, int *iq,  int i, int mxiq, int mxjq)
{
      /* DIMENSION QV(mxjq),IQ(mxiq) */
    int k, kmin, kmax;

    kmin = iq[i];
    kmax = iq[i+1]-1;
    for (k=kmin; k<=kmax; k++)
    {
        qv[k] = 0.0;
    }
    return (0);
}



/*fun**********************************************************************
	NAME:			kay1
	DESCRIPTION:	FINDS ADDRESS K IN QV FOR Q(I,J)    (updated version.)
	RETURN:			if error return negtive value
***************************************************************************/         
int
kay1 (int i, int j, int *iq, int *jq, int mxiq, int mxjq)
{
    /* INTEGER IQ(mxiq)     INTEGER JQ(mxjq) */

    int     ret, istart, k; 

    ret = 0;
    istart = iq[i];
    for (k=iq[i]; k<=iq[i+1]; k++)
    {
        if (jq[k] != j)     continue;
        ret = k;
        goto L20;
    }

    printf (" Trouble! Could not find kay1 match i=%d, j=%d\n", i, j);
    printf (" Pause ... Press any to continue\n");
    getchar (); getchar ();
L20:
      return (ret);
}






