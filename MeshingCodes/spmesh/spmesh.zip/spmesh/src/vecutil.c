  
/*
  ************************************************************************
  *  vecutil.c :     Vector and Geometry Operation utility routine       *
  *									 *
  *  Qingyang Zhang				   April 8, 1995	 *
  ************************************************************************
*/


#include <stdio.h>
#include <math.h>

#include "basdefs.h"
#include "spmesh.h"


/*
** External Functions
*/



/*
** Local Functions
*/
REAL v_magn(REAL *vec, int n);
void v_cros(REAL *vec1, REAL *vec2, REAL *prod);
REAL v_dot(REAL *vec1, REAL *vec2, int n);
void v_zero(REAL *vec, int n);
void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
int v_norm(REAL *vec, int n);
void v_add(REAL *vec1, REAL *vec2, int n, REAL *vec);
REAL v_angl(REAL *vec1, REAL *vec2, int ideg);
REAL v_rang(REAL *vec0, REAL *vec1, int n);
REAL v_area(REAL *v1, REAL *v2, int n);
REAL v_angl3(REAL *vec1, REAL *vec2, int ideg, int n);
REAL sg_csp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
void sg_dhp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *udhp,
	    REAL *ddhp, int n);
REAL sg_isp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
REAL sg_ang(REAL *v, REAL *p1, REAL *p2, REAL *p3, int n);
REAL sg_dha(REAL *p1, REAL *p2, REAL *p3, REAL *p4, int n);
int  mk_ecs2wcs_mat (double *extrusion,  double *ecs2wcs_mat);
void mat3_mat4 (double *mat3x3, double *mat4x4);
int  xfer_4x4 (double *mat, double *inp);
void xfv2w(double *vm,double vx,double vy,double vz,
				double *wx,double *wy,double *wz );
void xfwm2v(double *wm,double x,double y,double z,
            double *u,double *v,double *w);
/*
      real function v_magn(vec, n)
c
c    calculates the magnitude of a vector of dimension n
c
c    parameters:
c         vec - the vector
c         n   - dimension of the vector
c
*/
REAL
v_magn(REAL *vec, int n)
{
      int  k;
      REAL sum;

      sum = 0.0;
      for (k=0; k<n; k++)
	 sum = sum + vec[k]*vec[k];

      return (sqrt(sum));
}



/*
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine v_cros( vec1, vec2, n, prod )
c
c    calculates the cross product of two vectors of
c    dimension n (n>=3).  vec1 x vec2 = prod
c
c    parameters:
c         vec1 - first vector
c         vec2 - second vector
c            n - dimension of the vectors
c         prod - resultant vector
c
*/
void
v_cros(REAL *vec1, REAL *vec2, REAL *prod)
{

      prod[0] = vec1[1]*vec2[2] - vec1[2]*vec2[1];
      prod[1] = vec1[2]*vec2[0] - vec1[0]*vec2[2];
      prod[2] = vec1[0]*vec2[1] - vec1[1]*vec2[0];

      return;
}



/*
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function v_dot(vec1,vec2, n)
c
c
c    calculates the dot product of two vectors of dimension n
c
c    parameters
c         vec1,2 - the two vectors
c              n - their dimension
c
      real vec1(1), vec2(1), val
      integer n, k
c
c
*/
REAL
v_dot(REAL *vec1, REAL *vec2, int n)
{
      int  k;
      REAL val = 0.0;

      for (k=0; k<n; k++)
	 val = val + vec1[k]*vec2[k];

      return (val);
}


/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine v_zero(vec, n)
c
c        routine to initialize a vector of dimension n to zero
c
c        parameters:
c             n - number of vector coordinates
c             vec - returned zero vector
c
*/
void
v_zero(REAL *vec, int n)
{
      int k;

      for (k=0; k<n; k++)  vec[k] = 0.0;

      return;
}

/*
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine v_make(pnt1, pnt2, n, vec)
c
c        routine to construct a vector from point 1 to point 2
c
c        parameters:
c             pnt1,2 - input point coordinates
c             n - number of coordinates
c             vec - returned vector components
c
*/
void
v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec)
{
      int k;

      for (k=0; k<n; k++)   vec[k] = pnt2[k] - pnt1[k];

      return;
}

/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine v_norm(vec, n)
c
c        routine to normalize a vector
c
c        parameters:
c             vec = vector to be normalized (input)
c                   normalized vector (output)
c             n = number of vector components
c
*/
int
v_norm(REAL *vec, int n)
{
      int    k;
      REAL   magvec;

      magvec = v_magn(vec, n);
      if (fabs (magvec) < HIGTOL) 
      {
	 magvec = HIGTOL;
         for (k=0; k<n; k++)  vec[k] = vec[k] / magvec;
         return (BAD);
      }
      for (k=0; k<n; k++)  vec[k] = vec[k] / magvec;
      return (OK);
}


/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine v_add(vec1, vec2, n, vec)
c
c        routine to add two vectors
c
c        parameters:
c             vec1,2 - input vectors
c             n - number of coordinates
c             vec - returned vector components
c
*/
void
v_add(REAL *vec1, REAL *vec2, int n, REAL *vec)
{
      int k;

      for (k=0; k<n; k++)   vec[k] = vec1[k] + vec2[k];

      return;
}


/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function v_angl( vec1, vec2, ideg)
c
c        routine to calculate the oriented angle between two
c        vectors (ccw = positive, cw = negative)
c
c        parameters:
c             vec1,2 = the input vectors
c             ideg = flag indicating result desired in degrees
c                    (0=radians, 1=degrees)
c
*/
REAL
v_angl(REAL *vec1, REAL *vec2, int ideg)
{
      REAL angle, angle2, angle1;

      if (fabs (vec2[0]) < HIGTOL)
	 angle2 = (PI/2.0) * (vec2[1]/fabs(vec2[1]));
      else
	 angle2 = atan( vec2[1] / vec2[0] );

      if (vec2[0] < 0.0) angle2 = angle2 + PI;
      if (angle2 < 0.0)  angle2 = angle2 + (2.0*PI);

      if (fabs (vec1[0]) < HIGTOL)
	 angle1 = (PI/2.0) * (vec1[1]/fabs(vec1[1]));
      else
	 angle1 = atan( vec1[1] / vec1[0] );

      if (vec1[0] < 0.0) angle1 = angle1 + PI;
      if (angle1 < 0.0)  angle1 = angle1 + (2.0*PI);

      angle = angle2 - angle1;
      if (ideg == 1) angle = angle*180.0/PI;

      return (angle);
}

/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function v_rang( vec0, vec1, n )
c
c     author:  phillip getto
c
c     date:    july 19, 1982
c
c     purpose: to compute the distance between two x, y, z points.
c
      real    vec0(1), vec1(1)
      integer n, i
c
c              vec0 ------ one vector.
c              vec1 ------ the other.
c              n -         dimension
c
      real    work
c
c              work ------ working storage.
c
c     init.
c
      work = 0.0
c
c     sum up the squared differences.
c
*/
REAL
v_rang(REAL *vec0, REAL *vec1, int n)
{
      int i;
      REAL work=0.;

      for (i=0; i<n; i++)  work = work+(vec0[i]-vec1[i])*(vec0[i]- vec1[i]);
      return (sqrt (work));
}


/*
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function v_area(v1, v2, n)
c
c        routine to find the area of the triangle whose
c        edges are represented by two vectors
c
c        parameters:
c             v1,2 - vectors forming edges
c             n    - dimension of vectors
c
*/
REAL
v_area(REAL *v1, REAL *v2, int n)
{
      REAL r[3];

      v_cros(v1, v2, r);

      return (0.5 * v_magn(r, n));
}



/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function v_angl3(vec1, vec2, ideg, n)
c
c    routine to calculate scalar angle between two vectors
c
c        parameters:
c             vec1,2 - the two vectors
c             ideg -   degree/radian flag (0=rad, 1=deg)
c             n      - vector dimension
c
*/
REAL
v_angl3(REAL *vec1, REAL *vec2, int ideg, int n)
{
      REAL mag1, mag2, dprod;
      REAL cosang, angle;

      mag1 = v_magn(vec1, n);
      mag2 = v_magn(vec2, n);
      if (fabs (mag1) < HIGTOL || fabs (mag2) < HIGTOL)
      {
	  /* printf ("\nWARNING:  Zero divide (zero vector) in 'v_angl3.'\n");*/
	  return ((REAL)BAD);
      }

      dprod = v_dot(vec1, vec2, n);

      cosang = dprod / (mag1 * mag2);

      if (cosang < -1.0)
      {
        /*
	 printf ("\nWARNING: cosang less than -1 (%lf)in 'v_angl3.'\n",cosang);
        */
	  cosang = -1.0;

      }
      if (cosang > 1.0)
      {
	/*
	 printf ("\nWARNING: cosang great than 1 (%lf)in 'v_angl3.'\n",cosang);
        */
	  cosang = 1.0;

      }
      angle = acos(cosang);
      if (ideg == 1) angle = angle*180.0/PI;

      return (angle);
}



/*
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine sg_csp(p1, p2, p3, p4, pcen, rad)
c
c        routine to calculate the circumsphere of an tetrahedron
c        by calculating the intersection of the perpendicular
c        bisecting planes of three of the tetrahedron's sides.
c
c        Intersection of planes calculated per Faux and Pratt:
c        'Computational Geometry for Design and Manufacture'
c        pg 67.
c
c        parameters:
c             p1,4 - corner points of tetrahedron.
c                    right hand rule points 1,2,3 points
c                    toward point 4.
c             pcen - returned center point
c             rad - returned radius
c
c
*/
REAL
sg_csp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen)
{
      int    k, iv, iv1, iv2, iv3;
      REAL   u1[3], u2[3], u3[3], a[3], b[3], c[3], d1, d2, d3;
      REAL   denom, pmid[3], vert[3][5], tmp1[3], tmp2[3];


      for (k=0; k<3; k++)
      {
	 vert[k][1] = p1[k];
	 vert[k][2] = p2[k];
	 vert[k][3] = p3[k];
	 vert[k][4] = p4[k];
      }
      iv = 4;
G7:    ;
      iv1 = (int)(fmod((double)iv, 4.)+0.5)+1;
      iv2 = (int)(fmod((double)iv1,4.)+0.5)+1;
      iv3 = (int)(fmod((double)iv2,4.)+0.5)+1;
      /* printf ("\niv=%2d, iv1=%2d, iv2=%2d, iv3=%2d\n", iv, iv1, iv2, iv3);*/
/*
c
c    form vectors along legs of tet. from vertex 4
c
*/
       for (k=0; k<3; k++) tmp1[k] = vert[k][iv];
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv1];
       v_make(tmp1, tmp2, 3, u1);
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv2];
       v_make(tmp1, tmp2, 3, u2);
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv3];
       v_make(tmp1, tmp2, 3, u3);
/*
c
c      call v_make(p4, p1, 3, u1)
c      call v_make(p4, p2, 3, u2)
c      call v_make(p4, p3, 3, u3)
c
c    normalize to make unit vectors
c
*/
      v_norm(u1, 3);
      v_norm(u2, 3);
      v_norm(u3, 3);
/*
c
c   calculate distance to midpoints for sides
c
*/
       for (k=0; k<3; k++) tmp1[k] = vert[k][iv];
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv1];
       d1 = v_rang(tmp1, tmp2, 3) / 2.0;
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv2];
       d2 = v_rang(tmp1, tmp2, 3) / 2.0;
       for (k=0; k<3; k++) tmp2[k] = vert[k][iv3];
       d3 = v_rang(tmp1, tmp2, 3) / 2.0;
/*
c
c      d1 = v_rang(p4, p1, 3) / 2.0
c      d2 = v_rang(p4, p2, 3) / 2.0
c      d3 = v_rang(p4, p3, 3) / 2.0
c
c   calculate perpindicular dist to origin (to define planes)
c
*/
      for (k=0; k<3; k++)  pmid[k] = vert[k][iv] + d1*u1[k];
      d1 = v_dot(pmid, u1, 3);

      for (k=0; k<3; k++)  pmid[k] = vert[k][iv] + d2*u2[k];
      d2 = v_dot(pmid, u2, 3);

      for (k=0; k<3; k++)  pmid[k] = vert[k][iv] + d3*u3[k];
      d3 = v_dot(pmid, u3, 3);
/*
c
c   plug and chug
c
*/
      v_cros(u2, u3, a);
      v_cros(u3, u1, b);
      v_cros(u1, u2, c);

      denom = v_dot(u1, a, 3);
/*
c    check for orthogonal planes
c
*/
      if (fabs (denom) > HIGTOL) goto G40;
      iv = iv1;
      if (iv == 4) goto G40;
      goto G7;
G40:   ;

      if (fabs (denom) < HIGTOL)    denom = HIGTOL;
      for (k=0; k<3; k++)  pcen[k] = (d1*a[k] + d2*b[k] + d3*c[k]) / denom;

      return (v_rang(pcen, p1, 3));
/*
c      radsq = 0.0
c      do 60 k=1,3
c         radsq = radsq + ((pcen(k)-p1(k))*(pcen(k)-p1(k)))
c 60   continue
c
*/
}


/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine sg_dhp(p1, p2, p3, p4, udhp, ddhp, n)
c
c        routine to determine the point defining the
c        dihedral plane associated with the planes
c        p1, p2, p3 and p1, p4, p2 connected along
c        the line p1, p2.  the returned plane is
c        defined by unit vector udhp and perpindicular
c        distance to origin ddhp.
c
c        parameters:
c             p1,2,3,4 - four points defining two planes
c             udhp - returned unit vector normal to the
c                    dihedral plane.
c             ddhp - scalar perpindicular distance from plane
c                    to origin
c             n - vector dimension of coordinates
c
*/
void
sg_dhp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *udhp,
       REAL *ddhp, int n)
{
      int      k;
      REAL     ratio, dist, m[3], vec1[3], vec2[3], area3, area4;


      v_make(p3, p1, n, vec1);
      v_make(p3, p2, n, vec2);
      area3 = v_area(vec1, vec2, n);

      v_make(p4, p1, n, vec1);
      v_make(p4, p2, n, vec2);
      area4 = v_area(vec1, vec2, n);

      v_make(p3, p4, n, vec1);
      v_norm(vec1, n);

      /* The ratio of the distance from middle point (on opposite edge p3-p4
	 and dihedral plane) to each of the ends (p3 and p4) will be the
	 same as the ratio of the areas of the two faces (p1,p2,p3 and p1,p2,p4)
	 so (p4-m)/(p3-m) = area4/area3 and (p3-p4) = (p3-m)+(p4-m)
      */
      if (fabs (area3) < HIGTOL) area3 = HIGTOL;
      ratio = area4/area3;
      dist = v_rang(p3, p4, n);
      dist = dist / (1.+ratio);

      for (k=0; k<n; k++)   
	  m[k] = p3[k] + vec1[k]*dist;

      v_make(m, p1, n, vec1);
      v_make(m, p2, n, vec2);
      v_cros(vec1, vec2, udhp);
      v_norm(udhp, n);

      *ddhp = v_dot(m, udhp, 3);

      return;
}




/*
c
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      subroutine sg_isp(p1, p2, p3, p4, pcen, rad)
c
c        routine to calculate the inscribed sphere of an tetrahedron
c        by calculating the intersection of three of the
c        tetrahedron's dihedral planes.
c
c        Intersection of planes calculated per Faux and Pratt:
c        'Computational Geometry for Design and Manufacture'
c        pg 67.
c
c        parameters:
c             p1,4 - corner points of tetrahedron.
c                    right hand rule points 1,2,3 points
c                    toward point 4.
c             pcen - returned center point
c             rad - returned radius
c         
c
*/
REAL
sg_isp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen)
{
      int   k;
      REAL  a[3], b[3], c[3], norm[3], up1[3], up2[3], up3[3];
      REAL  d1, d2, d3, denom;


      sg_dhp(p1, p2, p3, p4, up1, &d1, 3);
      sg_dhp(p2, p3, p1, p4, up2, &d2, 3);
      sg_dhp(p3, p1, p2, p4, up3, &d3, 3);
/*
c
c   plug and chug
c
*/
      v_cros(up2, up3, a);
      v_cros(up3, up1, b);
      v_cros(up1, up2, c);

      denom = v_dot(up1, a, 3);
      /* check for floating point overflow */
      if (fabs (denom) < HIGTOL)
      {
	denom = HIGTOL;
        /* printf ("\nWarning... Tiny denom in sg_isp!\n"); */
      }
      for (k=0; k<3; k++)  pcen[k] = (d1*a[k] + d2*b[k] + d3*c[k])/denom;

/*
c
c   find perpendicular distance to side plane
c
*/
      v_make(p1, p2, 3, a);
      v_make(p1, p3, 3, b);
      v_cros(a, b, norm);
      v_norm(norm, 3);

      v_make(p1, pcen, 3, c);
      return (v_dot(c, norm, 3));
}



/*
      real function sg_ang(v, p1, p2, p3, n)
c
c        routine to calculate the solid angle formed
c        by a vertex and 3 points in space.  calculates
c        angle as excess of polygon face formed by points.
c
c        parameters:
c             v - the vertex of the angle
c             p1,2,3 - three points forming angle
c             n - vector dimension of points
c
*/
REAL
sg_ang(REAL *v, REAL *p1, REAL *p2, REAL *p3, int n)
{
      REAL vec1[3], vec2[3], vec3[3], sangle, angle;
/*
C      parameter (twopi=6.28318531)
      parameter (twopi=360.0)
*/
      v_make( v, p1, n, vec1);
      v_make( v, p2, n, vec2);
      v_make( v, p3, n, vec3);

      sangle = 0.0;
      angle = fabs(v_angl3(vec1, vec2, 1, 3));  /* unit: degree  */
      sangle = sangle + angle;
      angle = fabs(v_angl3(vec2, vec3, 1, 3));
      sangle = sangle + angle;
      angle = fabs(v_angl3(vec3, vec1, 1, 3));
      sangle = sangle + angle;

      return (sangle);

}


/*
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      real function sg_dha(p1, p2, p3, p4, n)
c
c        routine to calculate the dihedral angle between
c        planes p1, p2, p3 and p1, p4, p2 which share a
c        common line p1,p2
c
c        parameters:
c             p1,2,3,4 - four points that define two planes
c             n - vector dimension of coordinates
c
*/
REAL
sg_dha(REAL *p1, REAL *p2, REAL *p3, REAL *p4, int n)
{

      int      k;
      REAL     d1, d2, ang;
      REAL     vec1[3], vec2[3], u[3], q[3], r[3];


      v_make(p1, p3, n, vec1);
      v_make(p1, p4, n, vec2);
      v_make(p1, p2, n, u);
      v_norm(u, n);

      d1 = v_dot(u, vec1, 3);
      d2 = v_dot(u, vec2, 3);

      for (k=0; k<n; k++)
      {
	 q[k] = p1[k] + d1*u[k];
	 r[k] = p1[k] + d2*u[k];
      }

      v_make(q, p3, n, vec1);
      v_make(r, p4, n, vec2);

      ang = v_angl(vec1, vec2, 1);

      return (ang);
}




/*fun**********************************************************************
	NAME:       	mk_ecs2wcs_mat
	DESCRIPTION:   Given extrusion direction (Ze direction) 
                   use AutoCad's arbitry axis algorithm to determine
				   ECS for planer entity, then create the transform
				   matrix from ECS to WCS
                   The input Ze is not neccessry to be unity vector
	RETURN:     	return error code ( < 0) failed
***************************************************************************/
int
mk_ecs2wcs_mat (double *extrusion,  double *ecs2wcs_mat)
{
	 int     i;
	 double  ex[3], ey[3], ez[3];
	 /* the y axis and z axis in WCS */
	 static double wy[3]={0.0, 1.0, 0.0}, wz[3]={0.0, 0.0, 1.0};
     
     /* initialize */
     for (i=0; i<9; i++)  ecs2wcs_mat[i] = 0.0;
     ecs2wcs_mat[0] = ecs2wcs_mat[4] = ecs2wcs_mat[8] = 1.0;

	 if (v_norm (extrusion, 3) < 0)
		 return (BAD);

	 for (i=0; i<3; i++)     ez[i] = extrusion[i];   /* z dir of ECS */

	 if (v_norm (ez, 3) < 0)
		 return (BAD);

	 /* find  x-axis of the ecs by arbitry axis algorithm */
	 if (fabs (ez[0]) < (1/64.) && fabs (ez[1]) < (1/64.))
         v_cros(wy, ez, ex);
	 else
         v_cros(wz, ez, ex);

	 if (v_norm (ex, 3) < 0)
		 return (BAD);

	/* make y-axis of the ecs: */
    v_cros(ez, ex, ey);
	v_norm (ey, 3);    /* make sure it is a unity vector */

	/* 
       build ECS to WCS transformation matrix by the property of orthogonal
	   matix. the matrix is in 1D array as the convention of CADKEY
	   the transformed point will multiply from left.
    */

	ecs2wcs_mat[0] = ex[0];  ecs2wcs_mat[3] = ex[1];  ecs2wcs_mat[6] = ex[2];
	ecs2wcs_mat[1] = ey[0];  ecs2wcs_mat[4] = ey[1];  ecs2wcs_mat[7] = ey[2];
	ecs2wcs_mat[2] = ez[0];  ecs2wcs_mat[5] = ez[1];  ecs2wcs_mat[8] = ez[2];

	return (OK);
}




/* upgrade a 1D 3x3 matrix to 1D 4x4 matrix */
void
mat3_mat4 (double *mat3x3, double *mat4x4)
{
    /*
    // one dim. array form 4x4 matrix     3x3 matrix
    // | 0  1  2  3  |                  | 0 1 2 |
    // | 4  5  6  7  |                  | 3 4 5 |
    // | 8  9  10 11 |                  | 6 7 8 |
    // | 12 13 14 15 |
    */
    int i;

    for (i=0; i<15; i++)    mat4x4[i] = 0;
    mat4x4[15] = 1.;
    for (i=0; i<3; i++)     mat4x4[i]   = mat3x3[i];  /* first  row */
    for (i=3; i<6; i++)     mat4x4[i+1] = mat3x3[i];  /* second row */
    for (i=6; i<9; i++)     mat4x4[i+2] = mat3x3[i];  /* third  row */
    return ;
}



/* transform a point by multipuly a 4x4 matrix from left pnt * [mat]
   here inp[3]  3D point
*/
int xfer_4x4 (double *mat, double *inp)
{
	 int    i;
	 double w, outp[3];

	 /* outp = inp * [mat4x4]  form
	 outp[0] = inp[0]*mat[0] + inp[1]*mat[4] + inp[2]*mat[8] + mat[12];
	 outp[1] = inp[0]*mat[1] + inp[1]*mat[5] + inp[2]*mat[9] + mat[13];
	 outp[2] = inp[0]*mat[2] + inp[1]*mat[6] + inp[2]*mat[10]+ mat[14];

	 w =  inp[0]*mat[3] + inp[1]*mat[7] + inp[2]*mat[11] + mat[15];
	 */

	 /* outp = [mat4x4] * inp  form */
	 outp[0] = inp[0]*mat[0] + inp[1]*mat[1] + inp[2]*mat[2] + mat[3];
	 outp[1] = inp[0]*mat[4] + inp[1]*mat[5] + inp[2]*mat[6] + mat[7];
	 outp[2] = inp[0]*mat[8] + inp[1]*mat[9] + inp[2]*mat[10]+ mat[11];

	 w =  inp[0]*mat[12] + inp[1]*mat[13] + inp[2]*mat[14] + mat[15];

	 if (fabs (w) < 1.e-10)     return (-1);
	 else if (w != 1.)
		  for (i=0; i<3; i++)   outp[i] /= w;

	 for (i=0; i<3; i++)   inp[i] = outp[i];
	 return (0);
}



void xfv2w(double *vm,double vx,double vy,double vz,
				double *wx,double *wy,double *wz )
{
	 *wx = vx * vm[0] + vy * vm[1] + vz * vm[2];
	 *wy = vx * vm[3] + vy * vm[4] + vz * vm[5];
	 *wz = vx * vm[6] + vy * vm[7] + vz * vm[8];
	 if ( fabs(*wx) < 1.E-15 ) *wx = 0;
	 if ( fabs(*wy) < 1.E-15 ) *wy = 0;
	 if ( fabs(*wz) < 1.E-15 ) *wz = 0;
	 return;
}




void
xfwm2v(double *wm,double x,double y,double z,double *u,double *v,double *w)
/*  transform the world coord [x,y,z] to view coord [u,v] defined by */
/* 	current view matrix wm[9]. */
{
	*u = x * wm[0] + y * wm[3] + z * wm[6];
	*v = x * wm[1] + y * wm[4] + z * wm[7];
	*w = x * wm[2] + y * wm[5] + z * wm[8];
	if ( fabs(*u) < 1.E-15 ) *u = 0;
	if ( fabs(*v) < 1.E-15 ) *v = 0;
	if ( fabs(*w) < 1.E-15 ) *w = 0;
	return;
}

