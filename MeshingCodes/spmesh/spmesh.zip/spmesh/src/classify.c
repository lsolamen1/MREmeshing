 

/*
  ************************************************************************
  *  classify.c :     Geometry and Set operations          	             *
  *									                                     *
  *  Qingyang Zhang				   Feb. 21, 1995	                     *
  ************************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <malloc.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"


/* define global varibles */
#include "defglb.h"

#define GetRandom( min, max ) ((rand() % (int)(((max) + 1) - (min))) + (min))


/*
** External Functions
*/
extern int free_MeshNode (MeshNode *nptr);
extern int debug_check  (char *title);
extern REAL sg_isp(REAL *p1, REAL *p2, REAL *p3, REAL *p4, REAL *pcen);
extern int  alloc_error (char *str);
extern void v_make(REAL *pnt1, REAL *pnt2, int n, REAL *vec);
extern int v_norm(REAL *vec, int n);
extern REAL v_rang(REAL *vec0, REAL *vec1, int n);



/*
** Local Functions
*/


int line_tri_cross (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r);
int mesh_nod_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		   MeshNode *msh_n_head, long n_msh_node,
		   int class_type, MeshNode *msh_n_curt);
void tri_patch_box (REAL *xmin, REAL *ymin, REAL *zmin,
		   REAL *xmax, REAL *ymax, REAL *zmax,
		   BMeshElem *bdy_l_head, long n_bdy_elem);
NODE_MTRL nod_inout (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem, 
               BMeshElem **on_bdy_eptr, int db_flag);
NODE_MTRL nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
                   BMeshElem **on_bdy_eptr);
int kill_element (MeshElem **msh_l_head, long *n_msh_elem, int kill_mode);
int kill_iso_node (MeshNode **msh_n_head, long *n_msh_node);
int elem_checkin(int etype, MeshNode **nnptr, int num_p, 
                 int *kill_table, int num_killed, int kill_mode);
int random_shoot_full (double *st_pnt, double *ed_pnt);
int random_shoot (double *st_pnt, double *ed_pnt, double length);


/*
     The function to find intersection point between a straight line
     and a trianglar plane.

     input:   line (two endpoints) --- d[3] , e[3]
	      trianglar plane --- d[3], a[3], b[3]
				  a: a vector from origin to first node
				  b: a vector from first node to second node
				  c: a vector from first node to third node
			        2
			        *
		       b  *   *
		     1   *      *
		       *  *   *  *  3
		 a   *        c
		   *
	   o *
      output:   r --intersection point with the unbound plane defined by the
		    trianglation.

      return:   0 --- OUTBOUND;    INBOUND --- inbound;    PARALLEL ---  parallel
          ONPLANE --- tested point on the plane.
		  COPLANE --- co-plane;     ONEDGE --- the start node d on the bdy
          PARALLEL is kind of outbound; COPLANE and ONEDGE are kind of inbound;
*/
int
line_tri_cross (REAL *d, REAL *e, REAL *a, REAL *b, REAL *c, REAL *r)
{
      REAL t, u, w, x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4;
      REAL bxc[3], cxe[3], bxe[3], ee[3], dp1, dp2, dp3;
      int  inbound = OUTBOUND;

      r[0] = r[1] = r[2] = 0.0;
      ee[0] = e[0] - d[0];
      ee[1] = e[1] - d[1];
      ee[2] = e[2] - d[2];

      /*
	    CALCULATE t : the parameter from node d to intersection point along
		       the straight lin d --> e
      */
      bxc[0]=b[1]*c[2]-b[2]*c[1];
      bxc[1]=b[2]*c[0]-b[0]*c[2];
      bxc[2]=b[0]*c[1]-b[1]*c[0];
      dp1=bxc[0]*a[0]+bxc[1]*a[1]+bxc[2]*a[2];
      dp2=bxc[0]*d[0]+bxc[1]*d[1]+bxc[2]*d[2];
      dp3=bxc[0]*ee[0]+bxc[1]*ee[1]+bxc[2]*ee[2];

      /* If (BxC).E = 0 then the line segment and the plane are parallel */

      if ( fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      t=(dp1-dp2)/dp3;

      /* find instersection point with unbound plane */
      if (t >= 0.0 && t <= 1.0)
      {
	    r[0] = d[0] + t*ee[0];
	    r[1] = d[1] + t*ee[1];
	    r[2] = d[2] + t*ee[2];
      }
      else
      {   /* out of the range */
	    return (inbound = OUTBOUND);
      }

      /*
	    CALCULATE u --- parmeter for vector b  u=[0,1]
      */
      cxe[0]=c[1]*ee[2]-c[2]*ee[1];
      cxe[1]=c[2]*ee[0]-c[0]*ee[2];
      cxe[2]=c[0]*ee[1]-c[1]*ee[0];
      dp1=cxe[0]*d[0]+cxe[1]*d[1]+cxe[2]*d[2];
      dp2=cxe[0]*a[0]+cxe[1]*a[1]+cxe[2]*a[2];
      dp3=cxe[0]*b[0]+cxe[1]*b[1]+cxe[2]*b[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }
      u = (dp1-dp2)/dp3;
      if (u < 0.0 || u > 1.0)   return (inbound = OUTBOUND);   /* outbound */

      /*
	    CALCULATE w ---- parameter for vector c w=[0,1]
      */

      bxe[0]=b[1]*ee[2]-b[2]*ee[1];
      bxe[1]=b[2]*ee[0]-b[0]*ee[2];
      bxe[2]=b[0]*ee[1]-b[1]*ee[0];
      dp1=bxe[0]*d[0]+bxe[1]*d[1]+bxe[2]*d[2];
      dp2=bxe[0]*a[0]+bxe[1]*a[1]+bxe[2]*a[2];
      dp3=bxe[0]*c[0]+bxe[1]*c[1]+bxe[2]*c[2];

      if(fabs(dp3) < HIGTOL)
      {
	    /* parallel */
	    inbound = PARALLEL;
	    goto EXIT;
      }

      w=(dp1-dp2)/dp3;

      /* the if--else if -- else check has to follow the sequence! */
      if(w < 0. ||  u+w > 1.0)
      {
	    /* outbound */
	    return (inbound = OUTBOUND);
      }
      else if (fabs (t) < HIGTOL)
      {  /* the start node d (tested node) is on the plane */
	    return (inbound = ONPLANE);
      }
      else if (fabs (u) < HIGTOL || fabs (w) < HIGTOL || fabs (u+w - 1.) < HIGTOL)
      {
	    /* ON the edge of tri-patch */
	    return (inbound = ONEDGE);
      }
      else
      {
	    /* inbound */
	    inbound = INBOUND;
      }

EXIT:
      if (inbound == PARALLEL)
      {
	    /* check co-plane */
	    /* following three nodes define a plane */
	    x1 = a[0];      y1 = a[1];       z1 = a[2];
	    x2 = a[0]+b[0]; y2 = a[1]+b[1];  z2 = a[2]+b[2];
	    x3 = a[0]+c[0]; y3 = a[1]+c[1];  z3 = a[2]+c[2];
	    /* check fourth node for co-plane */
	    x4 = d[0];      y4 = d[1];       z4 = d[2];
	    u = (x4-x1)*(y2-y1)*(z3-z1)
	        +(y4-y1)*(z2-z1)*(x3-x1)
	        +(z4-z1)*(x2-x1)*(y3-y1);

	    w = (z4-z1)*(y2-y1)*(x3-x1)
	        +(y4-y1)*(x2-x1)*(z3-z1)
	        +(x4-x1)*(z2-z1)*(y3-y1);

	    t = u - w;

	    if (fabs (t) < HIGTOL)   
	    {
	        inbound = COPLANE;      /* co-plane */
	    }
      }

      return (inbound);

}



/* mesh node classify as different material regions
   class_type = WHOLE   start from first node
   class_type = PART    classify new add-in nodes
*/
int
mesh_nod_classify (BMeshElem *bdy_l_head, long n_bdy_elem,
		   MeshNode *msh_n_head, long n_msh_node,
		   int class_type, MeshNode *msh_n_curt)
{
    int  k, ok_type, db_flag=BAD;
    long ii;
    REAL d[3], e[3];
    REAL xlen, ylen;
    MeshNode *msh_nptr;
    BMeshElem *bdy_patch_ptr;

    ok_type = OK;

    /* node classify */
    if (class_type == WHOLE)       msh_nptr = msh_n_head;
    else if (class_type == PART)   msh_nptr =  msh_nptr = msh_n_curt;
    else fprintf (Diag_file, "\nUnkown type: class_type = %3d\n", class_type);

    /* maximum ray cast distant */
    xlen = 4. * (BDxmax - BDxmin);
    ylen = 4. * (BDymax - BDymin);

    if (Bdy_lst_type == BD3D)
    {   /* single material region */
	    for (ii=0; ii<n_msh_node; ii++)
	    {   /* search for each mesh node */
	        /* start node */
	        d[X] = msh_nptr->Coor[X];
	        d[Y] = msh_nptr->Coor[Y];
	        d[Z] = msh_nptr->Coor[Z];
	        /* end node */
#ifdef RANDOM_VACTOR
            random_shoot_full (d, e);
#else
	        e[X] = d[X] + xlen;
	        e[Y] = d[Y];
	        e[Z] = d[Z];
#endif
	        /* determin where node in */
	        msh_nptr->Mtrl = nod_inout (d, e, bdy_l_head, n_bdy_elem, 
                                       &bdy_patch_ptr, db_flag);
            msh_nptr->bdy_ptr = bdy_patch_ptr;
            /* db_flag = BAD; */
	        msh_nptr = msh_nptr->Next;
	    }
    }
    else if (Bdy_lst_type == BD3DMTRL)
    {
	    for (ii=0; ii<n_msh_node; ii++)
	    {   /* search for each mesh node */
	        /* start node */
	        d[X] = msh_nptr->Coor[X];
	        d[Y] = msh_nptr->Coor[Y];
	        d[Z] = msh_nptr->Coor[Z];
	        /* end node */
#ifdef RANDOM_VACTOR
            random_shoot_full (d, e);
#else
	        e[X] = d[X] + xlen;
	        e[Y] = d[Y];
	        e[Z] = d[Z];
#endif
	        /* determin where node in */
	        msh_nptr->Mtrl = nod_in_region (d, e, bdy_l_head, n_bdy_elem, 
                                            &bdy_patch_ptr);
            msh_nptr->bdy_ptr = bdy_patch_ptr;
            if (msh_nptr->Mtrl > BDY_NODE_CODE && msh_nptr->bdy_ptr == NULL)
                    k = 0;    /* &&& */

	        msh_nptr = msh_nptr->Next;
	    }
    }
    else
    {
	    fprintf (Diag_file, "\nUnkwon Material Type for Node Classify (Bdy_lst_type = %4d!\n",
		            Bdy_lst_type);

	    ok_type = BAD;
    }

    return (ok_type);
}


/* determine node inout property for single material */
NODE_MTRL
nod_inout (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem, 
           BMeshElem **on_bdy_eptr, int db_flag)
{
    int  repeat = 0, cross_type, num_warn=0;
    long jj;
    REAL a[3], b[3], c[3], r[3];
    REAL ray_xmin, ray_xmax, ray_ymin, ray_ymax, ray_zmin, ray_zmax;
    BMeshNode *n_1, *n_2, *n_3;
    BMeshElem *bdy_eptr;

    *on_bdy_eptr = NULL;

    do
    {
	    /* initialize */
	    Mtrl_code[0] = 0;
	    /* find the bounding box (limit) of the vector d --> e */
	    ray_xmin = (d[X] < e[X]) ? d[X] : e[X];
	    ray_xmax = (d[X] > e[X]) ? d[X] : e[X];
	    ray_ymin = (d[Y] < e[Y]) ? d[Y] : e[Y];
	    ray_ymax = (d[Y] > e[Y]) ? d[Y] : e[Y];
	    ray_zmin = (d[Z] < e[Z]) ? d[Z] : e[Z];
	    ray_zmax = (d[Z] > e[Z]) ? d[Z] : e[Z];
        /* debug
        if (db_flag == OK)
	    {
               printf ("\nray box :xmin=%lf, ymin=%lf, zmin=%lf\n", 
                         ray_xmin, ray_ymin, ray_zmin);
               printf ("\nray box :xmax=%lf, ymax=%lf, zmax=%lf\n", 
                         ray_xmax, ray_ymax, ray_zmax);
        }
        */
	    cross_type = OUTBOUND;
	    for (jj=0, bdy_eptr=bdy_l_head; jj<n_bdy_elem; jj++, bdy_eptr=bdy_eptr->Next)
	    {
		    /* check bounding */
		    if (ray_ymin > bdy_eptr->ymax || ray_ymax < bdy_eptr->ymin)   continue;
		    if (ray_zmin > bdy_eptr->zmax || ray_zmax < bdy_eptr->zmin)   continue;
		    if (ray_xmin > bdy_eptr->xmax || ray_xmax < bdy_eptr->xmin)   continue;
		    /* search for each boundary element */
		    n_1 = bdy_eptr->Elem.tri3.NodePtr[0];
		    n_2 = bdy_eptr->Elem.tri3.NodePtr[1];
		    n_3 = bdy_eptr->Elem.tri3.NodePtr[2];
		    /* define vector a, b, c */
		    a[X] = n_1->Coor[X];
		    a[Y] = n_1->Coor[Y];
		    a[Z] = n_1->Coor[Z];

		    b[X] = n_2->Coor[X] - a[X];
		    b[Y] = n_2->Coor[Y] - a[Y];
		    b[Z] = n_2->Coor[Z] - a[Z];

		    c[X] = n_3->Coor[X] - a[X];
		    c[Y] = n_3->Coor[Y] - a[Y];
		    c[Z] = n_3->Coor[Z] - a[Z];
		    /* cross checking */
		    cross_type = line_tri_cross (d, e, a, b, c, r);

		    if (cross_type == INBOUND)
		    {   /*
                if (db_flag == OK)  
                        printf ("Inbound. with BDY patch No. %8d\n", jj+1);
                */
		        Mtrl_code[0] = Mtrl_code[0] + 1;
		    }
		    else if (cross_type == ONPLANE)
		    {   /* on the boundary  */
		        Mtrl_code[0] = MTRL_IN_CODE;
                *on_bdy_eptr = bdy_eptr; /* set node pointer to BDY it sit */
		        return (Mtrl_code[0]);
		    }
		    else if (cross_type == ONEDGE)
		    {   /* vector d-->e is crossed the edge of the BDY */
		        /* disturb the vector direction */
		        e[X] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        e[Y] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        e[Z] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        repeat++;
		        break;
		    }

            /* else (uncertain.) all treat as outbound */

        }

    } while (cross_type == ONEDGE && repeat < 4);

    if (cross_type == ONEDGE)
    {
        fprintf (Diag_file, "\nUncertain Case --- onedge (repeat=%d)\n", repeat);
        return (0);
    }
	/* determine in/out */
    /* if (db_flag == OK)  printf ("Mtrl_code[0] = %3d \n", Mtrl_code[0]);*/
	if(Mtrl_code[0]/2 == (double)Mtrl_code[0]/2.)
	{ /* mod(*) =0 --- even times of intersection --- out side*/
	    return (0);
	}
	else  return (1);    /* inside */

}




/* determine node inout property for multiple material regions */
/* return region_code    if region_code = BAD ??   the checking failed 
   current code can handle max of 9 deferent materials plus outside empty
*/
NODE_MTRL
nod_in_region (REAL *d, REAL *e, BMeshElem *bdy_l_head, long n_bdy_elem,
               BMeshElem **on_bdy_eptr)
{
    int  repeat = 0, k, cross_type;
    long jj;
    NODE_MTRL region_code;
    REAL a[3], b[3], c[3], r[3];
    REAL ray_xmin, ray_xmax, ray_ymin, ray_ymax, ray_zmin, ray_zmax;
    BMeshNode *n_1, *n_2, *n_3;
    BMeshElem *bdy_eptr;

    *on_bdy_eptr = NULL;

    do
    {
	    /* initialize */
	    for (k=0; k<MAX_MTRL_NUM; k++)   Mtrl_code[k] = 0;
	    /* find the bounding box (limit) of the vector d --> e */
	    ray_xmin = (d[X] < e[X]) ? d[X] : e[X];
	    ray_xmax = (d[X] > e[X]) ? d[X] : e[X];
	    ray_ymin = (d[Y] < e[Y]) ? d[Y] : e[Y];
	    ray_ymax = (d[Y] > e[Y]) ? d[Y] : e[Y];
	    ray_zmin = (d[Z] < e[Z]) ? d[Z] : e[Z];
	    ray_zmax = (d[Z] > e[Z]) ? d[Z] : e[Z];

	    cross_type = OUTBOUND;
	    for (jj=0, bdy_eptr=bdy_l_head; jj<n_bdy_elem; jj++, bdy_eptr=bdy_eptr->Next)
	    {
		    /* check bounding */
		    if (ray_ymin > bdy_eptr->ymax || ray_ymax < bdy_eptr->ymin)   continue;
		    if (ray_zmin > bdy_eptr->zmax || ray_zmax < bdy_eptr->zmin)   continue;
		    if (ray_xmin > bdy_eptr->xmax || ray_xmax < bdy_eptr->xmin)   continue;
		    /* search for each boundary element */
		    n_1 = bdy_eptr->Elem.tri3.NodePtr[0];
		    n_2 = bdy_eptr->Elem.tri3.NodePtr[1];
		    n_3 = bdy_eptr->Elem.tri3.NodePtr[2];
		    /* define vector a, b, c */
		    a[X] = n_1->Coor[X];
		    a[Y] = n_1->Coor[Y];
		    a[Z] = n_1->Coor[Z];

		    b[X] = n_2->Coor[X] - a[X];
		    b[Y] = n_2->Coor[Y] - a[Y];
		    b[Z] = n_2->Coor[Z] - a[Z];

		    c[X] = n_3->Coor[X] - a[X];
		    c[Y] = n_3->Coor[Y] - a[Y];
		    c[Z] = n_3->Coor[Z] - a[Z];

		    /* cross checking */
		    cross_type = line_tri_cross (d, e, a, b, c, r);

		    if (cross_type == INBOUND)
		    {/* associated material code counter increment */
		        Mtrl_code[bdy_eptr->Mtrl_in]++;
		        Mtrl_code[bdy_eptr->Mtrl_out]++;
		    }
		    else if (cross_type == ONPLANE)
		    {   /* as combination of the two material regiones */
		        /* the nodes on BDY should not be less than 100 */  
                region_code = bdy_eptr->Mtrl_in * MTRL_IN_CODE 
                            + bdy_eptr->Mtrl_out* MTRL_OUT_CODE;

                *on_bdy_eptr = bdy_eptr;
		        return (region_code);
		    }
		    else if (cross_type == ONEDGE)
		    {   /* vector d-->e is crossed the edge of the BDY */
		        /* disturb the vector direction */
		        e[X] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        e[Y] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        e[Z] += LOWTOL* (GetRandom( 1, 100 )/100.);
		        repeat++;
		        break;
		    }
		    
            /* else (uncertain) all treat as outbound */ 
	    }

    } while (cross_type == ONEDGE && repeat < 4);

    if (cross_type == ONEDGE)
    {
        fprintf (Diag_file, "\nUncertain Case --- onedge (repeat=%d)\n", repeat);
        return (0);
    }

    /* determine in/out */
    for (k=1; k<MAX_MTRL_NUM; k++)
    {
	    if(Mtrl_code[k]/2 == (double)Mtrl_code[k]/2.)
	    {   /* even intersection --- count as outside of this Mtrl */
		    region_code = 0;
	    }
	    else
	    {
		    region_code = k;
		    break;
	    }
    }

    return (region_code);
}



/* find bounding box for each BDY tri-patch */

void
tri_patch_box (REAL *xmin, REAL *ymin, REAL *zmin,
	       REAL *xmax, REAL *ymax, REAL *zmax,
	       BMeshElem *bdy_l_head, long n_bdy_elem)
{
    int   k;
    long jj;
    BMeshNode *nd;
    BMeshElem *bdy_eptr;

    bdy_eptr = bdy_l_head;
    for (jj=0; jj<n_bdy_elem; jj++)
    {
	xmin[jj] = ymin[jj] = zmin[jj] =  1.e10;
	xmax[jj] = ymax[jj] = zmax[jj] = -1.e10;

	/* search for each boundary element */
	for (k=0; k<3; k++)
	{
	   nd = bdy_eptr->Elem.tri3.NodePtr[k];
	   if (nd->Coor[X] < xmin[jj])    xmin[jj] = nd->Coor[X];
	   if (nd->Coor[X] > xmax[jj])    xmax[jj] = nd->Coor[X];
	   if (nd->Coor[Y] < ymin[jj])    ymin[jj] = nd->Coor[Y];
	   if (nd->Coor[Y] > ymax[jj])    ymax[jj] = nd->Coor[Y];
	   if (nd->Coor[Z] < zmin[jj])    zmin[jj] = nd->Coor[Z];
	   if (nd->Coor[Z] > zmax[jj])    zmax[jj] = nd->Coor[Z];
	}

	bdy_eptr = bdy_eptr->Next;
    }
    return;
}


/* eliminate external elements and elem. in killing list 
   kill_mode :   0 = all node (include center node in kill zone then kill it
                 1 = kill it if center node in the zone.
*/
int
kill_element (MeshElem **msh_l_head, long *n_msh_elem, int kill_mode)
{
    static int  num_killed, kill_table[10], user_input=0;
    int  k, num_p;
    long ii, n_tmp_elem;
    MeshElem *tmp_l_head, *eptr, *tmp_next;
    MeshNode **nnptr;
    AdjElem  *aeptr, *prev_aeptr;

    /* make a copy */
    tmp_l_head = *msh_l_head;
    n_tmp_elem = *n_msh_elem;

    if (user_input == 0)
    {
      num_killed = 1;
      for (k=0; k<10; k++)   kill_table[k] = 0;
    

      if (Bdy_lst_type == BD3DMTRL)
	  {  /* create killing table */
        /*
	    printf ("\nHow many material need be eliminated (except \"0\" region) [1-10]:");
	    scanf ("%d", &num_killed);
        
	    for (k=0; k<num_killed; k++)
	    {
	      printf ("\nInput material code for region %2d : ", k+1);
	      scanf ("%d", &kill_table[k]);
	    }
        */
        num_killed = 0;
	    /* 0 (external) mtrl always needs be killed !! */
	    if (num_killed == 0)   num_killed = 1;   

	  }

      if (Ref_batch_flag == OK)  user_input = 1;
      else                       user_input = 0;
        
    }


    /* eliminate element in given region and in 0 materail region  */
    eptr = tmp_l_head;
    for (ii=0; ii< *n_msh_elem; ii++)
    {
        switch (eptr->E_type)
        {  
	        case TET4:
		        num_p = 4;
		        nnptr = eptr->Elem.tet4.NodePtr;
		        break;
	        case PYRAM5:
		        num_p = 5;
		        nnptr = eptr->Elem.pyr5.NodePtr;
		        break;
	        case PRISM6:
		        num_p = 6;
		        nnptr = eptr->Elem.prm6.NodePtr;
		        break;
	        case HEX8:
		        num_p = 8;
		        nnptr = eptr->Elem.hex8.NodePtr;
		        break;
	        case TRI6:
		        num_p = 6;
		        nnptr = eptr->Elem.tri6.NodePtr;
		        break;
	        default:
		        num_p = -1;
		        fprintf (Diag_file, "\nError...Unknown element type!\n");
		        return (BAD);
        }

	    /* save the pointer to next element */
	    tmp_next = eptr->Next;
        if (elem_checkin (eptr->E_type, nnptr, num_p, kill_table, 
                          num_killed, kill_mode) == OK)
	    {
	        /* relink before kill the elem. */
            if (eptr == tmp_l_head)
	        {   /* current elem. is head elem. */
                if (eptr->Next == NULL && eptr->Prev == NULL)
	            {  /* the only element in the elem. list */
                    if (n_tmp_elem == 1)
	                    tmp_l_head = NULL;
                    else 
                        fprintf (Diag_file, "\nError... Elem. number not compatible [1] : %8d;"
                              , n_tmp_elem);
                }
                else if (eptr->Next == eptr->Prev)
	            {  /* only two (include head itself) elem. left in the list */
                    if (n_tmp_elem == 2)
		            {
                        tmp_l_head = eptr->Next;
                        tmp_l_head->Next = tmp_l_head->Prev = NULL;
		            }
                    else 
                        fprintf (Diag_file, "\nError... Elem. number not compatible [2] : %8d;"
                              , n_tmp_elem);
                }
                else
	            {
		            tmp_l_head = eptr->Next;
                    tmp_l_head->Prev = eptr->Prev;
		            eptr->Prev->Next = tmp_l_head;
	            }
            }
            else if (eptr == tmp_l_head->Prev)
	        {  /* last elem. in the list */
                eptr->Prev->Next = tmp_l_head;
                tmp_l_head->Prev = eptr->Prev;
            }
            else
	        {
	            eptr->Prev->Next = eptr->Next;
                eptr->Next->Prev = eptr->Prev;
            }

	        /* eliminate the associated component in node-element list */
            for (k=0; k<num_p; k++)
	        {
                prev_aeptr = aeptr = nnptr[k]->Fst_adj_elem;
                if (nnptr[k]->Num_adj_elem == 0)
	            {
                    fprintf (Diag_file, "\nWarning...Wrong adj_elem list!\n");
	            }
                else
	            {
                    do
		            {
                        if (eptr == aeptr->idx) 
		                {
                            /*
		                    if (aeptr->ptr == NULL)
		                    {   the last element in the list 
                                prev_aeptr->ptr == NULL;
		                    }
                            */
                            if (prev_aeptr == aeptr)
		                    {  /* the first element in the list */
                                nnptr[k]->Fst_adj_elem = aeptr->ptr;
                            } 
                            else
                            {
                                prev_aeptr->ptr = aeptr->ptr;
                            }  
                            free ((char *) aeptr);
                            (nnptr[k]->Num_adj_elem)--;
                            aeptr = prev_aeptr;
                            break;
                        }
                        prev_aeptr = aeptr;
                        aeptr = aeptr->ptr;
		            } while (aeptr);
	            }	    
	        }

	        free ((char *)eptr);
            n_tmp_elem--;

        }

	    eptr = tmp_next;
    }

    /* change global */
    *msh_l_head = tmp_l_head;
    *n_msh_elem = n_tmp_elem;


    return (OK);
}




/* check element status (in/out of interesting region */
/* return 0 --- keep / 1 --- kill it */
/* en_mtrl_count[11]  a counter for element nodes in different region 
   en_mtrl_count[i]   is the number of nodes in material i. (i=0 --outside)
*/
int
elem_checkin (int etype, MeshNode **nnptr, int num_p, 
              int *kill_table, int num_killed, int kill_mode)
{
  int       i, j, k, en_mtrl_count[11], code_in, code_out, flag;
  int       total_num_in_count, in_flag, count;
  NODE_MTRL status; 
  REAL      cen_pt[3], e[3], dummy;
  BMeshElem *dumy_bdy;
  MeshNode  *sub_nptr;
  AdjList   *sub_anptr;


    /* initailization */
    for (i=0; i<=11; i++)     en_mtrl_count[i] = 0;
    for (i=0; i<3; i++)       cen_pt[i] = 0.;


    if (kill_mode == CENTRAL_MODE)
    {   /* only check central node */

        /* check central point in the element to make sure the 
           the element is going to be eliminate 
        */

        /* determine a central point inside the element */
        switch (etype)
	    {
	        case TET4:
#ifdef ISP_CENTRAL
		        /* find the center of inscribed sphere */
		        sg_isp(nnptr[0]->Coor, nnptr[1]->Coor, nnptr[2]->Coor,
			        nnptr[3]->Coor, cen_pt);
#else
                for (i=0; i<4; i++)
                {
                    cen_pt[X] += nnptr[i]->Coor[X];
                    cen_pt[Y] += nnptr[i]->Coor[Y];
                    cen_pt[Z] += nnptr[i]->Coor[Z];
                }
                cen_pt[X] /= 4.;
                cen_pt[Y] /= 4.;
                cen_pt[Z] /= 4.;
#endif
                break;
	        case HEX8:
		        if (Build_blk_type == DELTA_HEX)
		        {
		            /* the central point is the middle point of diagnal 
                            node 3, 5 
                         */
		            for (k=0; k<3; k++)
			            cen_pt[k] = 0.5 * (nnptr[2]->Coor[k] + 
                                                nnptr[4]->Coor[k]); 
		        }
                else
		        {
                    for (i=0; i<8; i++)
                    {
                        cen_pt[X] += nnptr[i]->Coor[X];
                        cen_pt[Y] += nnptr[i]->Coor[Y];
                        cen_pt[Z] += nnptr[i]->Coor[Z];
                    }
                    cen_pt[X] /= 8.;
                    cen_pt[Y] /= 8.;
                    cen_pt[Z] /= 8.;
		        }
		        break;
	        default:
		        fprintf (Diag_file, "\nWarning... elem. type in function: elem_checkin\n");
		        return (0);

	    }

#ifdef RANDOM_VACTOR
        random_shoot_full (cen_pt, e);
#else
        e[X] = cen_pt[X] + 4.*(BDxmax - BDxmin);
        e[Y] = cen_pt[Y];
        e[Z] = cen_pt[Z];
#endif

        if (Bdy_lst_type == BD3D)
        {   /* single material region */
             status = nod_inout (cen_pt, e, Bdy_elem_head_ptr, Bdy_elem, 
                                 &dumy_bdy, 0);  
	    }
        else if (Bdy_lst_type == BD3DMTRL)
        {
	        /* determin where node in */
	        status = nod_in_region (cen_pt, e, Bdy_elem_head_ptr, Bdy_elem, 
                                     &dumy_bdy);
	    }

        if (status >= BDY_NODE_CODE)
	    {   /* the center point on BDY so the elem cross BDY. */
            return (0); /* don't eliminate the elem. */
        }
        else 
	    {
	        for (i=0; i<num_killed; i++)
                if (status == kill_table[i])  return (OK); /* eliminate elem. */
	    }
      
       return (0);
    }
    else if (kill_mode == ONE_LEVEL_MODE)
    {
        /* if all nodes plus their adjacent node in the kill zone then tag it */
        for (i=0; i<num_p; i++)
        {
            status = nnptr[i]->Mtrl;
            for (in_flag=0, j=0; j<num_killed; j++)
                if (status == kill_table[j])  in_flag = 1;

            if (in_flag==0)  return (0);

            /* check adjacent nodes */
            for (count=0, sub_anptr=nnptr[i]->Fst_adj; sub_anptr; count++, sub_anptr=sub_anptr->ptr)
            {
                if (count > nnptr[i]->Num_adj) fprintf (Diag_file, "\nUnconsistent Adj. node list!\n");
                sub_nptr = sub_anptr->idx;
                status   = sub_nptr->Mtrl;
                for (in_flag=0, j=0; j<num_killed; j++)
                    if (status == kill_table[j])  in_flag = 1;

                if (in_flag==0)  return (0);
            }
        }
        return (OK);
    }

     /* ALLMODE */
     /* the index of en_mtrl_count is same as kill_table but not the
          associate material code !!!
     */
    for (i=0; i<num_p; i++)
    {
        /* pre-work to find central point coord. */
        /* these for all type of element, it may not make sense --- the
              "center point may not inside the element solid
        */
        cen_pt[X] += nnptr[i]->Coor[X];
        cen_pt[Y] += nnptr[i]->Coor[Y];
        cen_pt[Z] += nnptr[i]->Coor[Z];

	    status = nnptr[i]->Mtrl;
        if (status != 0)
            dummy = 0;

        if (status >= BDY_NODE_CODE)
	    {
            ;
            /* node on the BDY */
	        /* skip the case on bdy because it is possible when
                all/part of nodes on bdy and rest of nodes are 
		        at external of object, but part of the element 
		        is inside of object!!
		        so set more constrictly 
               
               code_in  = status / MTRL_IN_CODE;
               code_out = (status - code_in * MTRL_IN_CODE) /MTRL_OUT_CODE;
               for (j=0; j<num_killed; j++)
	            {
                    if (code_in == kill_table[j])  en_mtrl_count[j]++;
                    if (code_out == kill_table[j]) en_mtrl_count[j]++;
                }
            */
        }
        else 
	    {
            for (j=0; j<num_killed; j++)
	        {
                if (status == kill_table[j])  en_mtrl_count[j]++;
            }
	    }
    }
  
    /* determine if to eliminate the element */
    /* the index of en_mtrl_count is same as kill_table but not the
          associate material code !!!
    */


    /* acturally if all element nodes fall into eliminated zone, not necessarily
     in same material zone, e.g. a element across two elimiated zone, 
     it could be rmoved. The only problem could occur is in the case the 
     element size is too large to have another uneliminate zone inside the 
     element (all element node are in eliminated zone), that's less possibility
    
     Note that: this step will skip most of follow checking. try this first
     if it works that's OK!
    */
    total_num_in_count = 0; 
    for (i=0; i<num_killed; i++)
       total_num_in_count += en_mtrl_count[i];
  
    if (total_num_in_count >= num_p)  
       return (OK);

    /* if above operation works delete following step late on! (Aug. 6th, 1995) */

    for (i=0; i<num_killed; i++)
    {
        if (en_mtrl_count[i] == num_p)
        {  /* all element nodes fall into same material only one possibility */

            /* check central point in the element to make sure the 
           the element is going to be eliminate 
            */
            /* temperary comment out as the reason shown before */
            /*
            cen_pt[X] /= (REAL)num_p;  
            cen_pt[Y] /= (REAL)num_p;
            cen_pt[Z] /= (REAL)num_p;
            */

            /* determine a central point inside the element */
            switch (etype)
	        {
	            case TET4:
#ifdef ISP_CENTRAL
		            /* find the center of inscribed sphere */
		            sg_isp(nnptr[0]->Coor, nnptr[1]->Coor, nnptr[2]->Coor,
			        nnptr[3]->Coor, cen_pt);
#else
		            cen_pt[X] /= (REAL)num_p;
                    cen_pt[Y] /= (REAL)num_p;
                    cen_pt[Z] /= (REAL)num_p;
#endif 
		            break;
	            case HEX8:
		            if (Build_blk_type == DELTA_HEX)
		            {
		                /* the central point is the middle point of diagnal 
                            node 3, 5 
                         */
		                for (k=0; k<3; k++)
			                cen_pt[k] = 0.5 * (nnptr[2]->Coor[k] + 
                                                nnptr[4]->Coor[k]); 
		            }
                    else
		            {
		                cen_pt[X] /= (REAL)num_p;
                        cen_pt[Y] /= (REAL)num_p;
                        cen_pt[Z] /= (REAL)num_p;
		            }
		            break;
	            default:
		            fprintf (Diag_file, "\nWarning... elem. type in function: elem_checkin\n");
		            continue;

	        }

#ifdef RANDOM_VACTOR
            random_shoot_full (cen_pt, e);
#else
            e[X] = cen_pt[X] + 4.*(BDxmax - BDxmin);
            e[Y] = cen_pt[Y];
            e[Z] = cen_pt[Z];
#endif

            if (Bdy_lst_type == BD3D)
            {   /* single material region */
                status = nod_inout (cen_pt, e, Bdy_elem_head_ptr, Bdy_elem, 
                                 &dumy_bdy, 0);  
	        }
            else if (Bdy_lst_type == BD3DMTRL)
            {
	            /* determin where node in */
	            status = nod_in_region (cen_pt, e, Bdy_elem_head_ptr, Bdy_elem, 
                                     &dumy_bdy);
	        }
            if (status >= BDY_NODE_CODE)
	        {   /* the center point on BDY so the elem cross BDY. */
                return (0); /* don't eliminate the elem. */
            }
            else 
	        {
                if (status == kill_table[i])  return (OK); /* eliminate elem. */
	        }
        }
    }

    /* check the element in 0 material (outside) but with node on external BDY */
    flag = OK;
    for (i=0; i<num_p; i++)
    {
       status = nnptr[i]->Mtrl;
       if (status >= BDY_NODE_CODE)
       {
            /* node on the BDY */
            code_in  = status / MTRL_IN_CODE;
            code_out = (status - code_in * MTRL_IN_CODE) /MTRL_OUT_CODE;
       }
       if (status != 0 || code_out != 0) 
       {
	        flag = 0;
	        break;   /* not a element to be eliminated */ 
       }
   
    }  

  
    return (flag);

}




/* eliminate isolated node which does not related to any elem */

int 
kill_iso_node (MeshNode **msh_n_head, long *n_msh_node)
{

    int  sub_kill;
    long ii, n_tmp_node;
    MeshNode *tmp_n_head, *nptr, *tmp_next, *sub_nptr;
    AdjList  *aptr, *sub_aptr, *prev_sub_aptr;

    /* make a copy */
    tmp_n_head = *msh_n_head;
    n_tmp_node = *n_msh_node;

    nptr = tmp_n_head;
    for (ii=0; ii< *n_msh_node; ii++)
    {
	    /* save the pointer to next element */
	    tmp_next = nptr->Next;
        if (nptr->Fst_adj_elem == NULL)
	    {   /* isolated node it needs be eliminated */
            if (nptr->Num_adj_elem != 0)
               fprintf (Diag_file, "\nWarning... Adj. node-elem list not compatable!\n");

            /* relink the MeshNode link list before kill the node */
            if (nptr == tmp_n_head)
	        {   /* current elem. is head elem. */
                if (nptr->Next == NULL && nptr->Prev == NULL)
	            {  /* the only node in the node list */
                    if (n_tmp_node == 1)
	                    tmp_n_head = NULL;
                    else 
                        fprintf (Diag_file, "\nError... Node. number not compatible [1] : %8d;"
                              , n_tmp_node);
                }
                else if (nptr->Next == nptr->Prev)
	            {  /* only two (include head itself) node left in the list */
                    if (n_tmp_node == 2)
		            {
                        tmp_n_head = nptr->Next;
                        tmp_n_head->Next = tmp_n_head->Prev = NULL;
		            }
                    else 
                        fprintf (Diag_file, "\nError... Node. number not compatible [2] : %8d;"
                              , n_tmp_node);
                }
                else
	            {
		            /* skip link first */
	                nptr->Prev->Next = nptr->Next;
                    nptr->Next->Prev = nptr->Prev;
		            /* set head pointer */
		            tmp_n_head = nptr->Next;
	            }
            }
            else if (nptr == tmp_n_head->Prev)
	        {   /* last node in the list */
                nptr->Prev->Next = tmp_n_head;
                tmp_n_head->Prev = nptr->Prev;
            }
            else
	        {
	            nptr->Prev->Next = nptr->Next;
                nptr->Next->Prev = nptr->Prev;
            }
            
	        /* Befor free the isolated node, eliminate the associated 
             component in node adj list' adj list !! 
            */
            if (nptr->Fst_adj == NULL)
	        {  /* NULL adj. list */
                if (nptr->Num_adj) 
                    fprintf (Diag_file, "\nWarning... nonsense adj node list!\n");
	        }
            else
	        {
                if (nptr->Num_adj == 0)
	            {  
                    fprintf (Diag_file, "\nWarning...Wrong adj node list!\n");
	            }
                else
	            {
                    aptr = nptr->Fst_adj;
                    /* loop through current node adj. list */
                    do
		            {
                        sub_kill = 0;
                        sub_nptr = aptr->idx;
                        if (sub_nptr->Fst_adj == NULL)
		                { /* nptr adj. list has sub_nptr so vice verse */
                            fprintf (Diag_file, "\nWarning...Sub-node adj. list not compatible!\n");
		                }
                        else
		                {
                            prev_sub_aptr = sub_aptr = sub_nptr->Fst_adj;
                            do 
		                    {
			                    /* loop through sub-node adj. list */
			                    if (nptr == sub_aptr->idx) 
			                    { /* find match in sub adj. list */
			                        if (prev_sub_aptr == sub_aptr)
			                        { /*the first element or the only one in the list */
			                            sub_nptr->Fst_adj = sub_aptr->ptr;
			                        } 
			                        else
			                        {
			                            prev_sub_aptr->ptr = sub_aptr->ptr;
			                        }  
			                        free ((char *) sub_aptr);
			                        (sub_nptr->Num_adj)--;
			                        /* sub_aptr = prev_sub_aptr; */
                                    sub_kill = OK;  /* set the flag for find the node */
			                        break;  /* quit inner do loop */
			                    }
                                prev_sub_aptr = sub_aptr;
                                sub_aptr = sub_aptr->ptr;
                            } while (sub_aptr);
                        
		                }
                        if (sub_kill != OK) 
                            fprintf (Diag_file, "\nWarning...Sub-node adj. list mismatch!\n");
                        aptr = aptr->ptr;
		            } while (aptr);
	            }
	        }
            /* free nodes and its adj. list */
	        free_MeshNode (nptr);
            n_tmp_node--;
         
	    }/* */
        nptr = tmp_next;
    }

    /* change global */
    *msh_n_head = tmp_n_head;
    *n_msh_node = n_tmp_node;

    return (OK);
}


/* random_shoot with full range -- point out of domain */
int 
random_shoot_full (double *st_pnt, double *ed_pnt)
{
    double length, max_size, tmp;

    /* find maximum model size */
    max_size = BDxmax - BDxmin;
    tmp = BDymax - BDymin;
    if (max_size < tmp)     max_size = tmp;
     
    tmp = BDzmax - BDzmin;
    if (max_size < tmp)     max_size = tmp;
     
    length = 8.* max_size;      /* make sure the line will shoot out of domain */
    return (random_shoot (st_pnt, ed_pnt, length));
}


/* generate a random shooting point and return the end point of far end */
int 
random_shoot (double *st_pnt, double *ed_pnt, double length)
{
    int  k;
    REAL random_vec[3];

    /* generate a random vector */
    for (k=0; k<3; k++)     random_vec[k] = GetRandom( 1, 100 )/100.;

    if (v_norm(random_vec, 3) == BAD)
    {
        for (k=0; k<3; k++)     random_vec[k] = 0.5;
        v_norm(random_vec, 3);
    }
      
    for (k=0; k<3; k++)     ed_pnt[k] = st_pnt[k] + random_vec[k] * length; 

    return (OK);
}

