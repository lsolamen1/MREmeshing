  
/*
  ************************************************************************
  *  genbrick.c :     Generate brick element for the model    	         *
  *									 *
  *  Qingyang Zhang				   March. 9, 1995	 *
  ************************************************************************
*/

#include <stdio.h>
#include <math.h>
#include <malloc.h>


#include "basdefs.h"
#include "modefs.h"
#include "spmesh.h"


/* define global varibles */
#include "defglb.h"



/*
** External Functions
*/
extern int alloc_error (char *str);
extern int mk_adjlist (MeshNode *n_head, long num_node, MeshElem *e_head, long num_elem); 


/*
** Local Functions
*/
int gen_brick (BMeshNode *bdy_n_head, long bdy_num_node,
              BMeshElem *bdy_l_head, long bdy_num_elem,
              MeshNode **msh_n_head, long *msh_num_node,
              MeshElem **msh_l_head, long *msh_num_elem,
              REAL *g_size);
REAL tri_inscribed_r (REAL *nod_1, REAL *nod_2, REAL *nod_3);



/* generate uniform brick element for the model defined by BDY data */
int
gen_brick (BMeshNode *bdy_n_head, long bdy_num_node,
	   BMeshElem *bdy_l_head, long bdy_num_elem,
	   MeshNode **msh_n_head, long *msh_num_node,
	   MeshElem **msh_l_head, long *msh_num_elem,
           REAL *g_size)
{
  REAL min_size, max_size, act_size, dx, dy, dz;
  REAL *ruler_x, *ruler_y, *ruler_z;
  long ii, g_nd_num, g_el_num;
  int  i, j, k, nx, ny, nz;
  MeshElem *eptr, *msh_l_curt_ptr;
  BMeshElem *beptr;
  BMeshNode *n_1, *n_2, *n_3;
  MeshNode *msh_n_curt_ptr, *nptr, **nd_idx_ptr, **nnptr;

  min_size = 1.e10;
  max_size = -1.e10;

  printf ("\n****** Bounding Box **********");
  printf ("\nXmin = %10.5lf, Ymin = %10.5lf, Zmin = %10.5lf", 
             BDxmin, BDymin, BDzmin);
  printf ("\nXmax = %10.5lf, Ymax = %10.5lf, Zmax = %10.5lf\n", 
             BDxmax, BDymax, BDzmax);

  /* find minimum and maximum inscribed circle diameters
     for BDY trianglar patch, the minimum value is a gauge
     to keep the detail described by BDY data won't be lost
     when the brick elements are generated
  */

  beptr = bdy_l_head;
  for (ii=0; ii<bdy_num_elem; ii++)
  {
    n_1 = beptr->Elem.tri3.NodePtr[0];
    n_2 = beptr->Elem.tri3.NodePtr[1];
    n_3 = beptr->Elem.tri3.NodePtr[2];

    act_size = 2. * tri_inscribed_r (n_1->Coor, n_2->Coor, n_3->Coor);

    if (act_size < min_size)       min_size = act_size;
    if (act_size > max_size)       max_size = act_size;
    beptr = beptr->Next;
  }

  /* determin active size (global size) to generate brick elem. */
/*  printf ("\nInput Mesh Size factor [min:%10.5lf -- max:%10.5lf] (0 -- 1): ",
	  min_size, max_size);
  scanf ("%lf", &s_factor);

  act_size = min_size + s_factor*(max_size - min_size);
*/

  printf ("\nInput Mesh Size  [min:%10.5lf -- max:%10.5lf]: ",
	  min_size, max_size);
  scanf ("%lf", &act_size);

#ifdef NORMALIZE_DATA
  act_size *= Norm_scale;
#endif


  /* find number of interval in x, y, z directions */
  nx = (int)((BDxmax - BDxmin)/act_size + 0.5);
  ny = (int)((BDymax - BDymin)/act_size + 0.5);
  nz = (int)((BDzmax - BDzmin)/act_size + 0.5);

  /* the length of the interval in x, y, z directions */
  dx = (BDxmax - BDxmin)/(REAL)nx;
  dy = (BDymax - BDymin)/(REAL)ny;
  dz = (BDzmax - BDzmin)/(REAL)nz;

  /* find number of nodes will be deployed in x, y, z directions */
  nx++;  ny++; nz++;

  printf ("\ndx = %10.5lf, dy = %10.5lf, dz = %10.5lf", dx, dy, dz);
  printf ("\nnx = %10d, ny = %10d, nz = %10d\n", nx, ny, nz);

  /* generate node coordinates for the deployed nodes */
  /* the new allocated array index start from 1 !! */
  nd_idx_ptr = (MeshNode **) malloc (sizeof (MeshNode *)*(nx*ny*nz+1));

  ruler_x = (REAL *) malloc (sizeof (REAL)*(nx+1));
  ruler_y = (REAL *) malloc (sizeof (REAL)*(ny+1));
  ruler_z = (REAL *) malloc (sizeof (REAL)*(nz+1));
  if (!ruler_x || !ruler_y || !ruler_z || !nd_idx_ptr)   alloc_error ("genbrick-1");

  ruler_x[1] = BDxmin;
  for (i=2; i<=nx; i++)    ruler_x[i] = ruler_x[i-1] + dx;

  ruler_y[1] = BDymin;
  for (i=2; i<=ny; i++)    ruler_y[i] = ruler_y[i-1] + dy;

  ruler_z[1] = BDzmin;
  for (i=2; i<=nz; i++)    ruler_z[i] = ruler_z[i-1] + dz;

  g_nd_num = 0;
  for (k=1; k<=nz; k++)
      for (j=1; j<=ny; j++)
	  for (i=1; i<=nx; i++)
	  {
	     nptr = (MeshNode *) malloc (sizeof (MeshNode));

	     if (!nptr)	alloc_error ("genbrick-2");
	     else
	     {
		    nptr->Fst_adj = NULL;
		    nptr->Num_adj = 0;
		    nptr->Fst_adj_elem = NULL;
		    nptr->Num_adj_elem = 0;
		    nptr->Mtrl = BAD;
		    nptr->status = nptr->in_zone = 0;
		    nptr->Prev = NULL;
		    nptr->Next = NULL;
	     }

	     if (g_nd_num == 0)
	     {  /* first node */
		msh_n_curt_ptr = *msh_n_head = nptr;
	     }
	     else
	     {
		/* set node link */
		msh_n_curt_ptr->Next = nptr;
		nptr->Prev = msh_n_curt_ptr;
		msh_n_curt_ptr = nptr;
	     }
	     nptr->Coor[X] = ruler_x[i];
	     nptr->Coor[Y] = ruler_y[j];
	     nptr->Coor[Z] = ruler_z[k];
	     nd_idx_ptr[g_nd_num+1] = nptr;
	     g_nd_num++;
	  }

   /* close the link */
   nptr->Next = *msh_n_head;
   (*msh_n_head)->Prev = nptr;

   /* pass total num. of nodes to global */
   *msh_num_node = g_nd_num;

  free ((char *)ruler_x);
  free ((char *)ruler_y);
  free ((char *)ruler_z);

  printf ("\nDone On Node Deployment!\n");

  /* generate brick elements */
  /* add an attribute (int) to elem struct!! */
  g_el_num = 0;
  for (k=1; k<nz; k++)
      for (j=1; j<ny; j++)
	  for (i=1; i<nx; i++)
	  {
	     eptr = (MeshElem *) malloc (sizeof (MeshElem));
	     if (!eptr)	alloc_error ("genbrick-3");
	     else
	     {
		eptr->E_type = HEX8;
		eptr->attr = 0;             
		eptr->Mtrl_in = BAD;
		eptr->Mtrl_out = BAD;
		eptr->Prev = NULL;
		eptr->Next = NULL;
	     }

	     if (g_el_num == 0)
	     {  /* first elem */
		msh_l_curt_ptr = *msh_l_head = eptr;
	     }
	     else
	     {
		/* set node link */
		msh_l_curt_ptr->Next = eptr;
		eptr->Prev = msh_l_curt_ptr;
		msh_l_curt_ptr = eptr;
	     }
	     nnptr = eptr->Elem.hex8.NodePtr;
	     nnptr[0] = nd_idx_ptr[nx*ny*(k-1)+nx*(j-1)+i+1];
	     nnptr[1] = nd_idx_ptr[nx*ny*(k-1)+nx*(j  )+i+1];
	     nnptr[2] = nd_idx_ptr[nx*ny*(k  )+nx*(j  )+i+1];
	     nnptr[3] = nd_idx_ptr[nx*ny*(k  )+nx*(j-1)+i+1];
	     nnptr[4] = nd_idx_ptr[nx*ny*(k-1)+nx*(j-1)+i];
	     nnptr[5] = nd_idx_ptr[nx*ny*(k-1)+nx*(j  )+i];
	     nnptr[6] = nd_idx_ptr[nx*ny*(k  )+nx*(j  )+i];
	     nnptr[7] = nd_idx_ptr[nx*ny*(k  )+nx*(j-1)+i];

	     /* determine the type of brick which will be breaken to tet. */
             if((i+j+k)/2 == ((double)(i+j+k)/2.)) eptr->attr = 2; /* mod(*) =0 */
             else                                 eptr->attr = 1;
	     g_el_num++;
	  }

   /* close the link */
   eptr->Next = *msh_l_head;
   (*msh_l_head)->Prev = eptr;

   /* pass total num. of elem.s to global */
   *msh_num_elem = g_el_num;

   free ((char *)nd_idx_ptr);

   *g_size = act_size;

   printf ("\nDone On Creating Brick!\n");

   /* create node adjacent list ! */
   if (*msh_n_head != NULL)
      mk_adjlist (*msh_n_head, *msh_num_node, *msh_l_head, *msh_num_elem);

   printf ("\nDone On Creating Node adjacent list!\n");
  /* determine node attribute (material code and in/out) */


  /* eliminate the element outside of the BDY */




  return (OK);
}



/* find the radius of inscribed circle of the triangle */
REAL 
tri_inscribed_r (REAL *nod_1, REAL *nod_2, REAL *nod_3)
{ 
    REAL a, b, c, s;

    a = sqrt ((nod_2[X]-nod_1[X])*(nod_2[X]-nod_1[X]) + 
              (nod_2[Y]-nod_1[Y])*(nod_2[Y]-nod_1[Y]) +
              (nod_2[Z]-nod_1[Z])*(nod_2[Z]-nod_1[Z]));

    b = sqrt ((nod_3[X]-nod_2[X])*(nod_3[X]-nod_2[X]) + 
              (nod_3[Y]-nod_2[Y])*(nod_3[Y]-nod_2[Y]) +
              (nod_3[Z]-nod_2[Z])*(nod_3[Z]-nod_2[Z]));

    c = sqrt ((nod_3[X]-nod_1[X])*(nod_3[X]-nod_1[X]) + 
              (nod_3[Y]-nod_1[Y])*(nod_3[Y]-nod_1[Y]) +
              (nod_3[Z]-nod_1[Z])*(nod_3[Z]-nod_1[Z]));
    
    s = 0.5 * (a + b + c);

    return (sqrt ((s-a)*(s-b)*(s-c)/s));
}
