/* header file for elasmth.c  */
/* declarations applicable to all options */

     
int MXN, MXN3, MXE, MXIQ, MXJQ;

#define NDOF        3
#define MXNPE       4
#define MXNPR       20
#define MXNSI       MXNPR*NDOF


/*
double stiff[12][12],b[6][12],t[12][6],ba[4],bb[4],bc[4],
       x[MXN],y[MXN],z[MXN],cds[3][4],bt[12][6],vol[MXE];
	 
double ccg1[MXIQ],ccg2[MXIQ],ccg3[MXIQ],
       qv[MXJQ],ccg4[MXJQ],rhs[MXN3],guess[MXN3],delta_z,
       volmax, delta, elas_max, c[6][6][MXMTL+1];
double xb[mxb+1],yb[mxb+1],zb[mxb+1];
double xemin(mxb),xemax(mxb), yemin(mxb),yemax(mxb),zemin(mxb),zemax(mxb);
	 
int    mtrl[MXE],in[MXNPE,MXE],
       ne,nmtrl,nn,npbn,npbe,nnbn,nnbe,nflag,matmax,matmin,
       jbn[MXN],imap[MXE],kc[4],kb[4],
       iq[MXIQ],jq[MXJQ],nn3,nx,ny,nz,nhb,ndiag;

int    ibe(5,mxb), jbe(5,mxb), jbn(mxn)


c	nn  = Number of nodes for volumn mesh
c   ne  = Number of elem. for volumn mesh
c   x(), y(), z() = volumn mesh node coord.
c   in((mxnpe,mxe)= volumn mesh connectivity

c	npbn = 
c	npbe = 
c   mxnpr = maximum number of nodes connected to another node
c   mxnsi = maximum number of dof connectivities per node

c   nbn = Number of physical boundary nodes
c   nbe = Number of physical boundary elements
c   xb(), yb(), zb() = physical boundary node coord.
c   ibe(5,nbe) = Physical boundary platelits (Triangles)-connectivity
c   jbn(nn) = Boundary condition type

c   mbe = Number of numerical boundary elements (using global node
c           numbers
c   jbe(5,mbe) = Numerical boundary platelits (Triangles)
c
c	qv ()	??


*/

double **stiff, **b, **t, **cds, **bt;
double *x, *y, *z, *vol, *ccg1, *ccg2, *ccg3, *ccg4, *rhs;
double *guess, *qv; 
double ba[4+1], bb[4+1], bc[4+1], c[6+1][6+1][2+1], dx[3+1], dy[3+1], dz[3+1];
double delta_z, volmax, delta, elas_max, delta, xyzd[4+1], diff;



int    *mtrl, *jbn, *imap, *iq, *jq, **in;	
int    kc[4+1], kb[4+1]; 
int    ne,nmtrl,nn,npbn,npbe,nnbn,nnbe,nflag,matmax,matmin, nn3, nbn;
int    nx, ny, nz, nhb, ndiag;
int    num_surf,mbe,nbe, nitera;
int    **ibe, **jbe;

char  tab, filnam[80], newnam[80];

/* junk	 
	  common /i_all/ mtrl(mxe),in(mxnpe,mxe),
     1  ne,nmtrl,nn,nnbn,nnbe,nflag,matmax,matmin,
     2  imap(mxe),kc(4),kb(4),jbn(mxn),izone(mxn),
     3  iq(mxiq),jq(mxjq),nn3,jbc_type,
     4  nsession,insn(mxmtl),jnsn(mxmtl*mxb),
     5  iesn(mxmtl),jesn(mxmtl*mxb),jbe(5,mxb),
     6  npbn,npbe,ipbe(5,mxb),ibe(5,mxb),num_surf,mbe,nbe, nitera 

	 
      character*1 tab
	  character*80 filnam, newnam
	  common /talk/ filnam, newnam, tab
*/

