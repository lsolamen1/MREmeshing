======================================================================
                            Spmesh Program
======================================================================
README.TXT
(Written by Ziji Wu and John M. Sullivan, 6/23/99)


Contents:

* Compilation
* Getting Started



Compilation
---------------
This code contains several .C and .h files.
A make file has been created to compile the code.  Please use the command
   make  
to compile it. The executable file will be named 'spmesh'



Getting Started
---------------
'spmesh' is a 3D mesh generation software, which takes triangular
boundary patches of the 3D object and generates a tetrahedral mesh.


It can run in two modes:

1. command line mode:    
   'spmesh'   press return and follow the screen prompts.

2. batch mode:
   'spmesh < xxx.inp'
   where 'xxx.inp' file lists all the parameters the code needs to generate the
   mesh.


Let us follow the instruction when it runs in command line mode:

1. Input internal normalization factor, XN:
   The code determines the bounding box of the geometry to be meshed.
   The length of the body diagonal for this bounding box is normalized 
   to the user specified length 'XN'.  The suggested length of XN is unity.
   At times the user may wish to select a normalization factor other
   than unity.  This is possible, but usually a value of unity is best.
   This is an internal normalization factor only.  It has no effect on
   the input or output files.

            
2. Input the max. number of auto-refinement levels, AR => 0:
   If the value of AR is greater than zero, then the code will check
   for multiple physical boundary platelets within each building block
   of the model.  If a non-zero AR is selected two additional inputs  
   are requested.  While checking for multiple physical platelets 
   within a building block, do you wish to:
      a) Ignore adjacent physical bdy elem? (0=ignore; 1=not ignore):
   and
      b) Ignore same material bdy elem? (0=ignore; 1=not ignore):  

   If auto-refinement is active several diagonals are created across each 
   building block.  If the diagonals intersect multiple physical platelets
   and the user options are satisfied and the maximum number of auto-refinements
   has not been reached, then the building block is tagged for further refinement.

   Auto refinement is not performed until all user specified refinements are
   completed.  The max. AR number is above and beyond any user specified refinements.

 

3. Input NML+ File Name:   
   The input file name uses the "NML+" format, an enhanced data set compared to
   the traditional Thayer school node and element file.  The conversion program
   'cvt24' can convert from the traditional Thayer format to the WPI format and
   vise versa.

4. Input Building Block Element Type:
     ( 0 = cube building block and 1 = deltahedral block) 
   Current system supports Cube and Deltahedral building blocks.  
   Deltahedral block has the property of supporting arbitrary levels 
   of mesh refinement without reducing overall mesh quality. The 
   auto-refinement is not supported on Cube blocks.

5. Input Mesh Size  [min:   lower_lim -- max:   upper_lim]:
   This parameter is the initial edge length of the default building block.
   A suggested range is given based on the range of the physical boundary 
   patch sizes. This assumed that the boundary input data (patch sizes) 
   carried information on the mesh resolution, which is not necessarily true.
   
6. Need Refinement? (No: 0 / Yes: 1) : 
   Mesh refinement will generate user desired mesh resolution in 
   certain regions. 

   This question is asked iteratively, until the user selects '0', for No.

   There are several methods to define the refinement zone:
   1) Along all physical boundaries.  
       If selected, a second prompt requests the refinement distance.
      1-a) Input the distance to BDY 
           Each physical platelet is extruded in all directions based on the
            distance to BDY selected.  Any building block within this extruded
            zone is tagged for refinement.
 
   2) Along a user specified boundary.
      2-a) Enter datafile name containing refinement platelets (*.dat)
         These refinement platelets do not need to be contiguous.  Each
          platelet is examined individually.
      2-b) Input the distance to BDY.  
         This distance serves the same function as option (1a).    

   3) Within a user specified closed volume (*.dat).
      3-a) Enter datafile name containing the refinement zone (*.dat)
      Note: the data file can include material codes, although they are not used.

   4) Batch mode refinement, which combined methods 1, 2 and 3. In 
      the batch file each line defines a refinement zone. 
      (see file: boxref.bat). 
      4-a) Input Batch File Name:  

   5) Refinement based on physical boundary patch sizes.  
      This option tries to match the building block size to the physical boundary
      platelets within the local vicinity of the block in question.  

      5-a) Input the refinement level (Min:  0 - Max:   6):  
           (To prevent over refinement potential)
      5-b) Input the distance to BDY (define refinement zone):
           (Functions the same as option 1a.) 

7. Export Numerical Surfaces? (0 = No, 1 = Yes):  
   User can select to output the numerical surfaces that will be used
   to conform to the physical boundaries.  This option terminates the 
   code at this stage.  Its function is for the investigation of alternate
   mesh conforming strategies.  The default selection should be 0 (zero).
   However, if selected, i.e. 1 = yes, then prompts for:
   a)How many boundary surfaces need be extracted [1-n] : x
     a-a) Please input No.   1 material region code :    
     ...
     a-x) Please input No.   x material region code :    


If Prompt #7 was not selected, then the code continues:

After entering the above information, the code starts with fitting 
speciality nodes and lines, if there are any.  This is followed by
conforming the numerical surfaces to the physical boundary
surfaces, material processing, and other post processing. The following 
questions are asked for output.

8. Need output ? (1=yes / 0=No):
   If option (No = 0) is selected then the code terminates with no further
   information or datafiles. 

9. Output file format (WPI: 0/ Thayer: 1):  
   a) WPI:
      a-a) Output file name (out.nml): 

   b) Thayer (a pair of nod/elm file):
      b-a) Elem. numbering convension (Right Hand Rule(normal in)=0/
           Left Hand Rule(normal out)=1:
          (RHR is first 3 nodes point to the 4th)
      b-b) File Type (Ascii: 0 | Binary: 1) :
      b-c) Output file name (without file extension! default as .nod 
           and .elm) : 

10. How many boundary surfaces need to be extracted [1-1 (-1=quit)]: 
    Type in -1 to quit the program
    The default is to select (-1) and no boundary surfaces are extracted.
    If boundary surfaces are selected, the user is prompted for the 
    desired material surfaces. 



HAVE FUN!

======================================================================
